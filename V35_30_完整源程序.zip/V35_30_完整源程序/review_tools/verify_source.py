from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
items=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
bad=[]
for item in items:
 p=root/item['file']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:bad.append(item['file'])
print('Original files:',len(items),'Mismatches:',len(bad))
for name in bad:print(name)
raise SystemExit(bool(bad))
