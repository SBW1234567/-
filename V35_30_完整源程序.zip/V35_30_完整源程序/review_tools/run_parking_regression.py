from pathlib import Path
import sys,unittest
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[1]
tests=root/'robot_home/racecar_entry_1005_v35_30/tests'
sys.path.insert(0,str(tests))
import test_finish_tracking_v35_30 as cases
assert 'ros_stubs' in sys.modules
suite=unittest.defaultTestLoader.loadTestsFromModule(cases)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
