# V35 30 完整源程序与提交说明

当前版本 PARKING_CONTINUITY_1005_V35_30，车端入口提交 a664b09。
只读采集日期2026-10-06。全部694个原文件保留原字节，其中691个与车端完整清单核对，3个udev规则另行核对。
七个主要源码及安装副本完全一致。采集未启动、停止、安装、构建或修改小车。

## 阅读顺序
1. robot_home/racecar_entry_1005_v35_30/run_v35_30.sh 以及 launch_centered.py。
2. robot_home/racecar/race_competition.sh 与 src/racecar/launch/race_competition.launch.py。
3. robot_home/racecar/src/racecar/scripts/race_task_controller.py 及 race_curve_core.py。
4. 视觉、雷达防护、墙线、扫描对齐、底盘与RF2O源码。
5. SOURCE_MANIFEST.json、SOURCE_SYMBOLS.json、verification中的测试记录。

## 目录
robot_home/racecar/src：完整工作空间源码，15个ROS包，保留构建脚本、消息、模型、配置、地图、厂商源文件和许可文件。
robot_home/racecar_entry_1005_v35_30：当前正式入口及其配套。payload为当前安装覆盖源；rollback为V29精确回退源。两者与manifest是原入口核验所必需的文件，不可因“旧代码”而随意删除。
该入口中的payload_binary/rollback_binary属于原RF2O安装与校验配套二进制。对应C++源码完整存在于src/rf2o_laser_odometry，不以二进制替代源码。
入口tests中的baselines和fixtures是历史软件对照与合成/图像测试资料，不是当前生产控制器。
robot_home/racecar_restore_v29_0925等相邻目录只保留当前入口读取的实际参数文件，目录关系与车端一致。
system_config：设备udev规则、摄像头开机服务和脚本、系统版本信息。仅供复现查阅，不自动安装。
review_tools：本次添加的可移植源码校验及15项停车软件回归入口，和车端原代码明确分开。

## 安全和复现
不要直接把整个目录覆盖回现车。若需要复现，先保存现有工作空间，在兼容RISC-V及ROS 2 Humble环境的独立工作空间检查package.xml依赖并构建。
正常比赛入口会发送运动指令：bash /home/bianbu/racecar_entry_1005_v35_30/run_v35_30.sh /home/bianbu/racecar false。
观察模式改第二参数为true。该模式仍启动driver并回中舵机，不能当成硬件断电。
外部依赖至少包括ROS 2 Humble配套包、NumPy、OpenCV、PyYAML、C++工具链及各package.xml所列依赖；未将Linux/ROS发行版全量源码混入项目。
原入口严格核验已安装版本，重新构建二进制受工具链影响，不能保证异构环境中可执行文件哈希相同。请核对构建与安装版本，不通过删除校验代码掩盖问题。
python3 review_tools/verify_source.py 只校验包内原文件，不连接小车。
python3 review_tools/run_parking_regression.py 使用ROS测试桩和合成扫描/动力模型，不驱动小车。
本次15项停车相关软件测试全通过；合成比较不是实车扫描完整重放，也不证明全程实车成功率或5.85秒实跑用时。

## 公开提交前
核对技术手册封面人员、队名与学校信息；签署授权页并替换为扫描页。
保留第三方许可。部分自有package.xml的license字段仍为TODO，应由权利人确认，不擅自为整个项目统一指定新许可证。
本包不含登录密码、SSH密钥、.git内部目录、build/install/log目录或Python缓存。旧测试/替代控制文件保留在完整src树中，但生产入口不启动它们。
