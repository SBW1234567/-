#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "../include/racecar_driver.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>

// Inputs retain the legacy PWM scaling; they are NOT calibrated m/s or rad/s.
class RacecarDriver : public rclcpp::Node {
  using Clock = std::chrono::steady_clock;
public:
  RacecarDriver() : Node("racecar_driver") {
    auto port = declare_parameter<std::string>("serial_port", "/dev/car");
    const auto baud = declare_parameter<int>("baud_rate", 38400);
    midpoint_ = declare_parameter<double>("steering_midpoint_pwm", 1500.0);
    gain_ = declare_parameter<double>("steering_gain", 1300.0);
    sign_ = declare_parameter<double>("steering_sign", 1.0);
    timeout_ = declare_parameter<double>("command_timeout_sec", 0.5);
    raw_ = declare_parameter<bool>("raw_teleop_mode", false);
    center_sec_ = declare_parameter<double>("startup_center_sec", 3.0);
    center_only_ = declare_parameter<bool>("steering_center_only", false);
    if (!std::isfinite(midpoint_) || midpoint_ < 1000 || midpoint_ > 2000 ||
        !std::isfinite(gain_) || gain_ <= 0 || gain_ > 5000 ||
        (sign_ != 1.0 && sign_ != -1.0) ||
        !std::isfinite(timeout_) || timeout_ < 0.1 || timeout_ > 2.0 ||
        !std::isfinite(center_sec_) || center_sec_ < 0.5 || center_sec_ > 5.0) {
      throw std::runtime_error("Invalid driver parameters; no commands sent");
    }
    if (art_racecar_init(baud, port.data()) != 0)
      throw std::runtime_error("Serial initialization failed");
    center_started_ = Clock::now();
    neutral();
    // Do not subscribe during centring: drive commands cannot accumulate in a queue.
    // Centre-only mode never creates a motion subscription.
    watchdog_ = create_wall_timer(std::chrono::milliseconds(50), [this]() {
      if (center_only_ || !subscription_) {
        active_ = false;
        neutral();
        if (!center_only_ && !fault_ &&
            std::chrono::duration<double>(Clock::now() - center_started_).count() >= center_sec_) {
          subscription_ = create_subscription<geometry_msgs::msg::Twist>(
            raw_ ? "/teleop_cmd_vel" : "/car_cmd_vel", 1,
            [this](const geometry_msgs::msg::Twist::SharedPtr msg) { command(msg); });
          RCLCPP_INFO(get_logger(), "STEERING_CENTER_READY midpoint=%.1f; accepting NEW commands", midpoint_);
        }
        return;
      }
      if (!active_ || std::chrono::duration<double>(Clock::now() - last_).count() > timeout_) {
        if (active_) RCLCPP_WARN(get_logger(), "Command timeout; neutral requested");
        active_ = false;
        neutral();
      }
    });
    RCLCPP_INFO(get_logger(),
      "V23_SERVO_CENTER_0924 source=%s midpoint=%.1f hold=%.2f center_only=%d timeout=%.2f gain=%.1f sign=%.0f",
      raw_ ? "raw_teleop" : "car_cmd_vel", midpoint_, center_sec_, center_only_, timeout_, gain_, sign_);
  }
  ~RacecarDriver() override { neutral(); }
private:
  void command(const geometry_msgs::msg::Twist::SharedPtr msg) {
    const double x = msg->linear.x, z = msg->angular.z;
    if (!std::isfinite(x) || !std::isfinite(z) ||
        (!raw_ && (std::abs(x) > 1.0 || std::abs(z) > 0.45)) ||
        (raw_ && (x < 1340 || x > 1660 || z < 0 || z > 180))) {
      active_ = false;
      neutral();
      RCLCPP_ERROR_THROTTLE(get_logger(), *get_clock(), 2000,
        "Rejected invalid/out-of-envelope command; neutral requested");
      return;
    }
    const double motor = raw_ ? x : 1500.0 + 160.0 * x;
    const double servo = raw_ ? 2500.0 - z * 2000.0 / 180.0
                             : midpoint_ + sign_ * gain_ * z;
    if (!std::isfinite(servo) || servo < 500 || servo > 2500) {
      active_ = false;
      neutral();
      return;
    }
    if (fault_) { neutral(); return; }
    active_ = transmit(motor, servo);
    last_ = Clock::now();
  }
  bool transmit(double motor, double servo) {
    if (send_cmd(static_cast<uint16_t>(motor), static_cast<uint16_t>(servo)) != 0) {
      fault_ = true;
      RCLCPP_ERROR_THROTTLE(get_logger(), *get_clock(), 2000,
        "Serial write failed; non-neutral output locked until restart");
      return false;
    }
    return true;
  }
  void neutral() { transmit(1500.0, midpoint_); }
  double midpoint_ = 1500, gain_ = 1300, sign_ = 1, timeout_ = 0.5, center_sec_ = 3.0;
  bool active_ = false, fault_ = false, raw_ = false, center_only_ = false;
  Clock::time_point last_ = Clock::now(), center_started_ = Clock::now();
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscription_;
  rclcpp::TimerBase::SharedPtr watchdog_;
};

int main(int argc, char **argv) {
  // Installer verifies the actual executable without opening serial or ROS.
  if (argc == 2 && std::string(argv[1]) == "--center-build-info") {
    std::puts("V23_SERVO_CENTER_0924");
    return 0;
  }
  rclcpp::init(argc, argv);
  try {
    auto node = std::make_shared<RacecarDriver>();
    rclcpp::spin(node);
    node.reset();
  } catch (const std::exception &e) {
    RCLCPP_FATAL(rclcpp::get_logger("racecar_driver"), "%s", e.what());
    rclcpp::shutdown();
    return 1;
  }
  rclcpp::shutdown();
  return 0;
}
