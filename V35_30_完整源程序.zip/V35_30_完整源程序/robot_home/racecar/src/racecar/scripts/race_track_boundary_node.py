#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""使用二维激光雷达提取赛道两侧挡板边界。

本节点只负责感知，不发布速度。它在车体坐标系的左右区域分别使用 RANSAC
拟合局部长直线，并发布左右边界距离、赛道中心偏差和边界方向。

/race/track_boundary 数据格式：
[left_distance, right_distance, front_clearance, center_error,
 heading_error, left_wall_valid, right_wall_valid,
 left_proximity, right_proximity]

center_error > 0 表示车辆偏右、建议向左修正；小于 0 表示车辆偏左。
只有长度、拟合误差满足要求并连续多帧出现的条状点云才标记为墙。
"""

import math
import json

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray, String


class RaceTrackBoundaryNode(Node):
    """从 /scan 中拟合左右挡板形成的局部赛道边界。"""

    def __init__(self):
        super().__init__('race_track_boundary')

        self.declare_parameter('auto_start_localization', False)
        self.auto_start_localization = bool(self.get_parameter('auto_start_localization').value)
        self.start_pose_pub = self.create_publisher(String, '/race/start_pose', 5)
        self.start_pose_stamp = 0
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('minimum_range', 0.30)
        self.declare_parameter('maximum_range', 3.5)
        self.declare_parameter('forward_min', -0.25)
        self.declare_parameter('forward_max', 2.8)
        self.declare_parameter('side_min', 0.20)
        self.declare_parameter('side_max', 2.2)
        self.declare_parameter('ransac_iterations', 100)
        self.declare_parameter('maximum_line_error', 0.055)
        self.declare_parameter('minimum_line_points', 8)
        self.declare_parameter('minimum_line_length', 0.55)
        self.declare_parameter('maximum_heading_deg', 55.0)
        self.declare_parameter('front_half_angle_deg', 25.0)
        self.declare_parameter('filter_alpha', 0.35)
        self.declare_parameter('side_guard_forward_max', 1.80)
        self.declare_parameter('side_guard_min_points', 6)
        self.declare_parameter('wall_confirm_frames', 3)
        self.declare_parameter('wall_lost_frames', 3)

        self.scan_topic = str(self.get_parameter('scan_topic').value)
        self.minimum_range = float(self.get_parameter('minimum_range').value)
        self.maximum_range = float(self.get_parameter('maximum_range').value)
        self.forward_min = float(self.get_parameter('forward_min').value)
        self.forward_max = float(self.get_parameter('forward_max').value)
        self.side_min = float(self.get_parameter('side_min').value)
        self.side_max = float(self.get_parameter('side_max').value)
        self.ransac_iterations = int(self.get_parameter('ransac_iterations').value)
        self.maximum_line_error = float(
            self.get_parameter('maximum_line_error').value
        )
        self.minimum_line_points = int(
            self.get_parameter('minimum_line_points').value
        )
        self.minimum_line_length = float(
            self.get_parameter('minimum_line_length').value
        )
        self.maximum_heading = math.radians(
            float(self.get_parameter('maximum_heading_deg').value)
        )
        self.front_half_angle = math.radians(
            float(self.get_parameter('front_half_angle_deg').value)
        )
        self.filter_alpha = float(self.get_parameter('filter_alpha').value)
        self.side_guard_forward_max = float(
            self.get_parameter('side_guard_forward_max').value
        )
        self.side_guard_min_points = int(
            self.get_parameter('side_guard_min_points').value
        )
        self.wall_confirm_frames = int(
            self.get_parameter('wall_confirm_frames').value
        )
        self.wall_lost_frames = int(
            self.get_parameter('wall_lost_frames').value
        )

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
        )
        self.create_subscription(LaserScan, self.scan_topic, self.scan_callback, qos)
        self.publisher = self.create_publisher(
            Float32MultiArray, '/race/track_boundary', 10
        )
        self.rng = np.random.default_rng(2026)
        self.filtered_left = None
        self.filtered_right = None
        self.filtered_heading = 0.0
        self.left_wall_count = 0
        self.right_wall_count = 0
        self.left_wall_missed = 0
        self.right_wall_missed = 0
        self.left_wall_confirmed = False
        self.right_wall_confirmed = False
        self.get_logger().info(
            f'赛道挡板雷达节点已启动：订阅 {self.scan_topic}，发布 /race/track_boundary'
        )

    @staticmethod
    def normalize_line_heading(angle):
        while angle > math.pi / 2.0:
            angle -= math.pi
        while angle < -math.pi / 2.0:
            angle += math.pi
        return angle

    @staticmethod
    def normalize_scan_angle(angle):
        """兼容 N10 的 0..2pi 扫描角，将其归一化到 -pi..pi。"""
        return math.atan2(math.sin(angle), math.cos(angle))

    def fit_boundary_line(self, points):
        """RANSAC 找主直线，再用 PCA 对内点精拟合。"""
        if len(points) < self.minimum_line_points:
            return None

        points = np.asarray(points, dtype=np.float64)
        best_indices = None
        best_count = 0

        for _ in range(self.ransac_iterations):
            first, second = self.rng.choice(len(points), size=2, replace=False)
            delta = points[second] - points[first]
            length = float(np.linalg.norm(delta))
            if length < 0.12:
                continue
            normal = np.array([-delta[1], delta[0]]) / length
            distances = np.abs((points - points[first]) @ normal)
            indices = np.flatnonzero(distances <= self.maximum_line_error)
            if len(indices) > best_count:
                best_count = len(indices)
                best_indices = indices

        if best_indices is None or best_count < self.minimum_line_points:
            return None

        inliers = points[best_indices]
        center = np.mean(inliers, axis=0)
        covariance = np.cov((inliers - center).T)
        values, vectors = np.linalg.eigh(covariance)
        direction = vectors[:, int(np.argmax(values))]
        if direction[0] < 0.0:
            direction = -direction
        heading = self.normalize_line_heading(
            math.atan2(float(direction[1]), float(direction[0]))
        )
        if abs(heading) > self.maximum_heading:
            return None

        projections = (inliers - center) @ direction
        line_length = float(np.max(projections) - np.min(projections))
        if line_length < self.minimum_line_length:
            return None

        normal = np.array([-direction[1], direction[0]])
        distance = abs(float(center @ normal))
        return distance, heading, best_count, line_length

    def start_pose_observation(self, scan, left_line, right_line):
        """Estimate pose in the known start pocket from three CURRENT walls."""
        if left_line is None or right_line is None:
            return dict(valid=False, reason='SIDE_WALL_MISSING')
        ld, lh, lc, ll = left_line
        rd, rh, rc, rl = right_line
        if (abs(ld+rd-.90) > .06 or abs(lh-rh) > math.radians(3)
                or min(lc, rc) < 12 or min(ll, rl) < .65
                or not .25 < rd < .65):
            return dict(valid=False, reason='START_CORRIDOR_MISMATCH')
        heading = (lh+rh)*.5
        if abs(heading) > math.radians(10):
            return dict(valid=False, reason='START_HEADING_OUT_OF_RANGE')
        # Rotate scan points into axes parallel/perpendicular to the corridor.
        rear = []
        angle = scan.angle_min
        for distance in scan.ranges:
            if math.isfinite(distance) and self.minimum_range <= distance <= self.maximum_range:
                a = angle-heading
                px, py = distance*math.cos(a), distance*math.sin(a)
                if -1.5 <= px <= -.25 and -rd+.04 <= py <= ld-.04:
                    rear.append((py, -px))
            angle += scan.angle_increment
        back = self.fit_boundary_line(rear)
        if back is None:
            return dict(valid=False, reason='REAR_WALL_MISSING')
        distance, back_heading, count, length = back
        if (abs(back_heading) > math.radians(3) or count < 12 or length < .55
                or count < .80*len(rear)):
            return dict(valid=False, reason='REAR_WALL_AMBIGUOUS')
        x = distance/math.cos(back_heading)
        if not .25 < x < 1.5:
            return dict(valid=False, reason='START_POSITION_OUT_OF_RANGE')
        return dict(valid=True, reason='THREE_WALLS', x=x, y=rd, yaw=-heading)

    def publish_start_pose(self, scan, left_line, right_line):
        stamp = scan.header.stamp.sec*1000000000+scan.header.stamp.nanosec
        if stamp <= self.start_pose_stamp or stamp <= 0:
            result = dict(valid=False, reason='SCAN_STAMP_NOT_ADVANCING')
        else:
            result = self.start_pose_observation(scan, left_line, right_line)
            self.start_pose_stamp = stamp
        result['schema'] = 1
        result['stamp_ns'] = stamp
        msg = String()
        msg.data = json.dumps(result, allow_nan=False)
        self.start_pose_pub.publish(msg)

    def smooth(self, previous, current):
        if current is None:
            return previous
        if previous is None:
            return current
        return (1.0 - self.filter_alpha) * previous + self.filter_alpha * current

    def update_wall_confirmation(self, side, line):
        """连续确认长直线，短暂漏帧时保留上一帧墙状态。"""
        count_name = f'{side}_wall_count'
        missed_name = f'{side}_wall_missed'
        confirmed_name = f'{side}_wall_confirmed'
        count = getattr(self, count_name)
        missed = getattr(self, missed_name)
        confirmed = getattr(self, confirmed_name)

        if line is not None:
            count = min(self.wall_confirm_frames, count + 1)
            missed = 0
            if count >= self.wall_confirm_frames:
                confirmed = True
        else:
            missed += 1
            if missed >= self.wall_lost_frames:
                count = 0
                confirmed = False

        setattr(self, count_name, count)
        setattr(self, missed_name, missed)
        setattr(self, confirmed_name, confirmed)
        return confirmed

    def exit_spatial_observation(self, scan, left_line, right_line):
        """Append a versioned spatial guard; original 19 fields stay unchanged.

        Bounds are in the existing laser frame, NOT wheel clearances. Close
        self-filtered or missing returns cannot certify free space. Local
        coverage tests rays intersecting y=+/-0.40 over x=-0.30..0.50;
        ahead coverage tests the same sides over x=0.50..1.80.
        """
        rear, front, side, far = 0.30, 0.50, 0.40, 1.80
        local = [-1.0, -1.0]
        ahead = [[-1.0, -1.0], [-1.0, -1.0]]
        totals = [0, 0, 0, 0]
        observed = [0, 0, 0, 0]
        near_unknown = [False, False, False, False]
        local_lo, local_hi = math.atan2(side, front), math.atan2(side, -rear)
        ahead_lo = math.atan2(side, far)
        for index, distance in enumerate(scan.ranges):
            angle = self.normalize_scan_angle(scan.angle_min + index * scan.angle_increment)
            magnitude = abs(angle)
            which = 0 if angle >= 0 else 1
            valid = (math.isfinite(distance)
                     and max(self.minimum_range, scan.range_min) <= distance <= scan.range_max)
            visible = valid or distance == math.inf
            for region, in_region in [(which, local_lo <= magnitude <= local_hi),
                                      (2 + which, ahead_lo <= magnitude < local_lo)]:
                if in_region:
                    totals[region] += 1
                    observed[region] += int(visible)
                    if (math.isfinite(distance) and scan.range_min <= distance < self.minimum_range):
                        near_unknown[region] = True
            if not valid:
                continue
            x, y = distance * math.cos(angle), abs(distance * math.sin(angle))
            if y <= 0:
                continue
            if -rear <= x <= front:
                local[which] = y if local[which] < 0 else min(local[which], y)
            elif front < x <= far and y <= side:
                if ahead[which][0] < 0 or x < ahead[which][0]:
                    ahead[which] = [x, y]
        coverage = [observed[i]/totals[i] if totals[i] else 0.0 for i in range(4)]
        coverage = [0.0 if near_unknown[i] else value for i, value in enumerate(coverage)]
        # Positions 19..39 in /race/track_boundary:
        # schema, local L/R, local coverage L/R, local ray counts L/R,
        # ahead L x/y, ahead R x/y, ahead coverage L/R, ahead ray counts L/R,
        # current unfiltered fit distances L/R, region rear/front/side/far.
        return [2.0, *local, *coverage[:2], *map(float, totals[:2]),
                *ahead[0], *ahead[1], *coverage[2:], *map(float, totals[2:]),
                float(left_line[0]) if left_line is not None else -1.0,
                float(right_line[0]) if right_line is not None else -1.0,
                rear, front, side, far]

    def scan_callback(self, scan):
        left_points = []
        right_points = []
        front_ranges = []
        angle = scan.angle_min

        for distance in scan.ranges:
            valid = (
                math.isfinite(distance)
                and self.minimum_range <= distance <= self.maximum_range
            )
            if valid:
                x = float(distance * math.cos(angle))
                y = float(distance * math.sin(angle))
                if abs(self.normalize_scan_angle(angle)) <= self.front_half_angle:
                    front_ranges.append(float(distance))
                if self.forward_min <= x <= self.forward_max:
                    if self.side_min <= y <= self.side_max:
                        left_points.append((x, y))
                    elif -self.side_max <= y <= -self.side_min:
                        right_points.append((x, y))
            angle += scan.angle_increment

        left_line = self.fit_boundary_line(left_points)
        right_line = self.fit_boundary_line(right_points)
        left_valid = self.update_wall_confirmation('left', left_line)
        right_valid = self.update_wall_confirmation('right', right_line)

        if left_line is not None:
            self.filtered_left = self.smooth(self.filtered_left, left_line[0])
        if right_line is not None:
            self.filtered_right = self.smooth(self.filtered_right, right_line[0])

        headings = []
        if left_line is not None:
            headings.append(left_line[1])
        if right_line is not None:
            headings.append(right_line[1])
        if headings:
            self.filtered_heading = self.smooth(
                self.filtered_heading, sum(headings) / len(headings)
            )

        left_distance = self.filtered_left if left_valid else -1.0
        right_distance = self.filtered_right if right_valid else -1.0
        center_error = 0.0
        if left_valid and right_valid:
            center_error = 0.5 * (left_distance - right_distance)

        left_guard = [
            point[1]
            for point in left_points
            if 0.0 <= point[0] <= self.side_guard_forward_max
        ]
        right_guard = [
            -point[1]
            for point in right_points
            if 0.0 <= point[0] <= self.side_guard_forward_max
        ]
        left_proximity = (
            float(np.percentile(left_guard, 20.0))
            if len(left_guard) >= self.side_guard_min_points
            else -1.0
        )
        right_proximity = (
            float(np.percentile(right_guard, 20.0))
            if len(right_guard) >= self.side_guard_min_points
            else -1.0
        )

        # Diagnostic only: retain the original guard and expose its spatial support.
        # No points means unknown (-1), not a confirmed clear corridor.
        def side_detail(points, sign):
            guard = [(x, sign * y) for x, y in points
                     if 0.0 <= x <= self.side_guard_forward_max]
            local = [y for x, y in guard if x <= 0.50]
            close_x = [x for x, y in guard if y <= 0.40]
            return [min(local) if local else -1.0, float(len(local)),
                    min(close_x) if close_x else -1.0]

        front_clearance = min(front_ranges) if front_ranges else self.maximum_range
        msg = Float32MultiArray()
        msg.data = [
            float(left_distance),
            float(right_distance),
            float(front_clearance),
            float(center_error),
            float(self.filtered_heading),
            float(left_valid),
            float(right_valid),
            left_proximity,
            right_proximity,
        ]
        msg.data.extend(side_detail(left_points, 1.0))
        msg.data.extend(side_detail(right_points, -1.0))
        # Backward-compatible extension: current scan headings and fit presence.
        # Do not reuse the smoothed combined heading or validity hysteresis here.
        msg.data.extend([
            float(left_line[1]) if left_line is not None else 0.0,
            float(right_line[1]) if right_line is not None else 0.0,
            float(left_line is not None), float(right_line is not None),
        ])
        msg.data.extend(self.exit_spatial_observation(scan, left_line, right_line))
        self.publisher.publish(msg)
        if self.auto_start_localization:
            self.publish_start_pose(scan, left_line, right_line)

        self.get_logger().info(
            '挡板: left=%.2f(%d) right=%.2f(%d) near=%.2f/%.2f front=%.2f center=%.2f heading=%.1fdeg'
            % (
                left_distance,
                int(left_valid),
                right_distance,
                int(right_valid),
                left_proximity,
                right_proximity,
                front_clearance,
                center_error,
                math.degrees(self.filtered_heading),
            ),
            throttle_duration_sec=1.0,
        )


def main(args=None):
    rclpy.init(args=args)
    node = RaceTrackBoundaryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
