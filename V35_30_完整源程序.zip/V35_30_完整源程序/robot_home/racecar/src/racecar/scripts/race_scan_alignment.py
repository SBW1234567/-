#!/usr/bin/env python3
"""Raw LSN10 scan -> common aligned scan; never publishes a driving command."""
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import LaserScan
from rcl_interfaces.msg import ParameterDescriptor
from race_scan_alignment_core import align_scan, correction_degrees, rf2o_view


class ScanAlignment(Node):
    def __init__(self):
        super().__init__('race_scan_alignment')
        self.declare_parameter('lidar_yaw_correction_deg', 0.0,
                               ParameterDescriptor(read_only=True))
        self.degrees = correction_degrees(self.get_parameter('lidar_yaw_correction_deg').value)
        self.rf2o_count = None
        self.failed = False
        qos = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT,
                         history=HistoryPolicy.KEEP_LAST)
        self.publisher = self.create_publisher(LaserScan, '/scan', qos)
        self.rf2o_publisher = self.create_publisher(LaserScan, '/race/scan_rf2o', qos)
        self.create_subscription(LaserScan, '/scan_raw', self.callback, qos)
        self.get_logger().info(
            f'LIDAR_ALIGNMENT_0925_V26: correction={self.degrees:+.3f} deg; '
            '/scan_raw (laser_raw) -> /scan (laser_link). Restart to change calibration.')

    def callback(self, scan):
        if self.failed:
            return
        try:
            aligned = align_scan(scan, self.degrees)
            if self.rf2o_count is None:
                self.rf2o_count = len(scan.ranges)
            symmetric = rf2o_view(aligned, self.rf2o_count)
            self.publisher.publish(aligned)
            self.rf2o_publisher.publish(symmetric)
        except ValueError as exc:
            self.failed = True
            self.get_logger().error(f'Scan alignment stopped: {exc}')


def main():
    rclpy.init()
    node = ScanAlignment()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
