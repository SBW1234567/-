#!/usr/bin/env python3
"""Yaw-only correction about the laser origin; no resampling or range filling."""
import copy
import math


def correction_degrees(value):
    if isinstance(value, bool):
        raise ValueError('Lidar correction must be a finite angle within -15..15 degrees.')
    try:
        result = float(value)
    except (ValueError, TypeError):
        raise ValueError('Lidar correction must be a finite angle within -15..15 degrees.')
    if not math.isfinite(result) or abs(result) > 15:
        raise ValueError('Lidar correction must be a finite angle within -15..15 degrees.')
    return result


def align_scan(scan, degrees):
    """Return an aligned scan without changing sample order.

    Positive correction rotates points left (CCW). Ranges, intensities, unknown
    values, acquisition order and timestamps are preserved.
    This is NOT a transform to the body origin: translation remains in TF.
    """
    yaw = math.radians(correction_degrees(degrees))
    if scan.header.frame_id != 'laser_raw':
        raise ValueError('Expected laser_raw frame; refusing possible double correction.')
    n = len(scan.ranges)
    if n < 60 or not all(math.isfinite(v) for v in
                        (scan.angle_min, scan.angle_max, scan.angle_increment)):
        raise ValueError('Invalid scan angular metadata.')
    inc = scan.angle_increment
    if inc <= 0 or (n - 1) * inc > 2 * math.pi + 1.1 * inc:
        raise ValueError('Expected increasing scan angles spanning at most one turn.')
    # Some LSN10 modes report angle_max one sample beyond their last ray.
    last = scan.angle_min + (n - 1) * inc
    if abs(scan.angle_max - last) > 1.01 * inc + 1e-5:
        raise ValueError('Scan length disagrees with angle_max.')
    aligned = copy.deepcopy(scan)
    aligned.header.frame_id = 'laser_link'
    aligned.angle_min = scan.angle_min + yaw
    aligned.angle_max = last + yaw
    return aligned


def rf2o_view(aligned, count):
    """Nearest-ray symmetric view ONLY for the legacy RF2O implementation.

    RF2O hardcodes symmetric angles and fixes its width on the first scan.
    Keep its width constant even if the lidar's samples/revolution vary. Safety
    and mapping consume the exact, unresampled aligned scan instead. Unknown
    source samples stay unknown; no interpolation across missing returns.
    RF2O ignores per-ray times; this view is a snapshot at the original stamp.
    """
    if count < 60:
        raise ValueError('RF2O view needs at least 60 samples.')
    out = copy.deepcopy(aligned)
    out.angle_min = -math.pi
    out.angle_max = math.pi
    out.angle_increment = 2 * math.pi / (count - 1)
    out.time_increment = 0.0
    out.ranges = [math.inf] * count
    has_intensities = len(aligned.intensities) == len(aligned.ranges)
    out.intensities = [0.0] * count if has_intensities else []
    n = len(aligned.ranges)
    full = n * aligned.angle_increment >= 2 * math.pi - 1e-5
    for j in range(count):
        a = out.angle_min + j * out.angle_increment
        relative = (a - aligned.angle_min) % (2 * math.pi)
        # A near-start ray can round to zero from the other side of the seam.
        if relative > 2 * math.pi - aligned.angle_increment / 2:
            relative -= 2 * math.pi
        k = int(math.floor(relative / aligned.angle_increment + .5))
        if k == n and full:
            k = 0
        if 0 <= k < n:
            out.ranges[j] = aligned.ranges[k]
            if has_intensities:
                out.intensities[j] = aligned.intensities[k]
    return out
