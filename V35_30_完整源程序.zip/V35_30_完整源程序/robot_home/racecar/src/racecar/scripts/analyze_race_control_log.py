#!/usr/bin/env python3
"""Summarize the latest passive race-control diagnostic CSV."""

import argparse
import csv
import glob
import os
from collections import Counter


def as_float(row, key, default=0.0):
    try:
        return float(row.get(key, default))
    except (TypeError, ValueError):
        return default


def latest_log():
    paths = glob.glob(os.path.expanduser('~/race_logs/race_control_*.csv'))
    return max(paths, key=os.path.getmtime) if paths else None


def main():
    parser = argparse.ArgumentParser(description='分析小车控制诊断日志')
    parser.add_argument('csv_file', nargs='?', help='CSV路径，默认读取最新日志')
    args = parser.parse_args()
    path = os.path.expanduser(args.csv_file) if args.csv_file else latest_log()
    if not path or not os.path.isfile(path):
        raise SystemExit('没有找到诊断日志：~/race_logs/race_control_*.csv')

    with open(path, newline='', encoding='utf-8') as source:
        rows = list(csv.DictReader(source))
    if not rows:
        raise SystemExit(f'日志为空：{path}')

    diagnostics = Counter()
    phase_order = []
    phase_max_angular = {}
    first_emergency = None
    first_crosswalk = None
    min_left = float('inf')
    min_right = float('inf')
    previous_phase = None

    for row in rows:
        phase = row.get('phase', 'UNKNOWN')
        if phase != previous_phase:
            phase_order.append((as_float(row, 'elapsed_s'), phase))
            previous_phase = phase
        phase_max_angular[phase] = max(
            phase_max_angular.get(phase, 0.0),
            abs(as_float(row, 'cmd_angular')),
        )
        left = as_float(row, 'left_proximity_m', -1.0)
        right = as_float(row, 'right_proximity_m', -1.0)
        if left > 0.0:
            min_left = min(min_left, left)
        if right > 0.0:
            min_right = min(min_right, right)
        if row.get('lidar_emergency') == '1' and first_emergency is None:
            first_emergency = row
        if row.get('vision_crosswalk') == '1' and first_crosswalk is None:
            first_crosswalk = row
        diagnostic = row.get('diagnostic', 'OK')
        if diagnostic and diagnostic != 'OK':
            diagnostics.update(diagnostic.split('|'))

    print(f'日志: {path}')
    print(f'采样数: {len(rows)}，时长: {as_float(rows[-1], "elapsed_s"):.1f}s')
    print('\n任务阶段:')
    for elapsed, phase in phase_order:
        print(f'  {elapsed:7.2f}s  {phase}')
    print('\n各阶段最大 |angular.z|:')
    for phase, value in phase_max_angular.items():
        print(f'  {phase:24s} {value:.3f}')
    print('\n最近墙距:')
    print(f'  左侧: {min_left:.3f}m' if min_left < float('inf') else '  左侧: 无数据')
    print(f'  右侧: {min_right:.3f}m' if min_right < float('inf') else '  右侧: 无数据')

    if first_crosswalk:
        print(
            '\n首次斑马线识别: %.2fs，里程位置=(%.3f, %.3f)m'
            % (
                as_float(first_crosswalk, 'elapsed_s'),
                as_float(first_crosswalk, 'odom_x_m'),
                as_float(first_crosswalk, 'odom_y_m'),
            )
        )
    else:
        print('\n首次斑马线识别: 未检测到')

    if first_emergency:
        print(
            '首次雷达急停: %.2fs，阶段=%s，前方=%.3fm，命令=(%.3f, %.3f)'
            % (
                as_float(first_emergency, 'elapsed_s'),
                first_emergency.get('phase', 'UNKNOWN'),
                as_float(first_emergency, 'lidar_front_m'),
                as_float(first_emergency, 'cmd_linear'),
                as_float(first_emergency, 'cmd_angular'),
            )
        )
    else:
        print('首次雷达急停: 未触发')

    print('\n异常统计:')
    if diagnostics:
        for name, count in diagnostics.most_common():
            print(f'  {name:34s} {count}')
    else:
        print('  未发现规则可识别的异常')


if __name__ == '__main__':
    main()
