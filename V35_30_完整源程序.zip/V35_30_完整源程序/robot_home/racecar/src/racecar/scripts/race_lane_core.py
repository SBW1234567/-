#!/usr/bin/env python3
"""Stamped local corridor observations and bounded lateral-first PID.

Steering output is the driver's dimensionless input, not a wheel angle.
No odometry sign, inferred installation bias, or automatic sign reversal.
"""
import math
import numpy as np


def clip(value,lo,hi):return max(lo,min(hi,value))


def fit_wall(points):
    if len(points)<10:return None
    p=np.asarray(points,dtype=float)
    # A small deterministic set of hypotheses, followed by TLS refinement.
    indices=np.linspace(0,len(p)-1,min(9,len(p)),dtype=int)
    pairs=[(a,b) for a in indices for b in indices if b>a]
    normals=[];origins=[]
    for a,b in pairs:
        v=p[b]-p[a]
        if abs(v[0])<.30 or abs(v[1]/v[0])>math.tan(math.radians(25)):continue
        normals.append(np.array([-v[1],v[0]])/np.linalg.norm(v));origins.append(p[a])
    if not normals:return None
    n=np.asarray(normals);o=np.asarray(origins)
    residual=np.abs(p@n.T-np.sum(o*n,axis=1))
    mask=residual[:,int(np.argmax(np.sum(residual<.035,axis=0)))]<.035
    if int(mask.sum())<10:return None
    q=p[mask];centre=q.mean(axis=0)
    _,vectors=np.linalg.eigh((q-centre).T@(q-centre))
    direction=vectors[:,-1]
    if direction[0]<0:direction=-direction
    heading=math.atan2(direction[1],direction[0]);normal=np.array([-direction[1],direction[0]])
    span=float(np.ptp(q@direction));rms=float(np.sqrt(np.mean(((q-centre)@normal)**2)))
    distance=float(abs(centre@normal))
    if span<.50 or rms>.025 or abs(heading)>math.radians(25):return None
    return [distance,float(heading),int(len(q)),span,rms]


def observe(scan):
    left=[];right=[];ln=[];rn=[]
    for i,r in enumerate(scan.ranges):
        if not math.isfinite(r) or not max(.30,scan.range_min)<=r<=min(3.5,scan.range_max):continue
        a=scan.angle_min+i*scan.angle_increment;x,y=r*math.cos(a),r*math.sin(a)
        if -.15<=x<=1.20 and .15<=abs(y)<=1.20:
            (left if y>0 else right).append((x,y))
        # Same forward reach as the existing entry-side guard; rear start
        # board is not a steering target. Hard body/side guards remain separate.
        if 0.<=x<=.70 and .05<abs(y)<=1.20:
            (ln if y>0 else rn).append(abs(y))
    def supported_near(values):
        if len(values)<3:return None
        values.sort()
        # Reject isolated spikes for steering only, not for collision guards.
        for i in range(len(values)-2):
            if values[i+2]-values[i]<=.04:return float(values[i])
        return None
    return dict(schema=1,stamp_ns=int(scan.header.stamp.sec)*1000000000+int(scan.header.stamp.nanosec),
                left=fit_wall(left),right=fit_wall(right),left_near=supported_near(ln),
                right_near=supported_near(rn),left_points=len(ln),right_points=len(rn))


class FreshLanePID:
    def __init__(self):self.reset()

    def reset(self):
        self.key=None;self.stamp=None;self.time=None;self.output=0.
        self.integral=self.derivative=self.error=self.raw_error=0.
        self.p=self.i=self.d=self.heading_term=self.requested=0.
        self.left=None;self.right=None;self.left_rate=self.right_rate=0.
        self.source='WAIT';self.reason='WAIT';self.heading=0.
        self.left_pred=None;self.right_pred=None

    @staticmethod
    def target(data,force_right=False):
        def valid(w):return w is not None and .25<=w[0]<=.90 and abs(w[1])<=math.radians(25)
        l,r=data['left'],data['right'];lv,rv=valid(l),valid(r)
        if not force_right and lv and rv and abs(l[1]-r[1])<=math.radians(8) and .75<=l[0]+r[0]<=1.10:
            return (l[0]-r[0])/2,(l[1]+r[1])/2,'TWO_WALLS'
        if rv:return .45-r[0],r[1],'RIGHT_WALL'
        if lv and not force_right:return l[0]-.45,l[1],'LEFT_WALL'
        raise ValueError('LANE_WALL_UNCONFIRMED')

    def command(self,data,now,age,phase,force_right=False):
        if age<-.05 or age>.30:raise ValueError('LANE_SCAN_STALE')
        raw,heading,source=self.target(data,force_right)
        key=(phase,source)
        if key!=self.key:
            old=self.output;self.reset();self.output=old;self.key=key
        control_dt=0. if self.time is None else clip(now-self.time,0.,.15)
        stamp=data['stamp_ns'];new=stamp!=self.stamp
        lower,upper=-.025,.025
        if new:
            sample_dt=0. if self.stamp is None else (stamp-self.stamp)*1e-9
            prime=not 0<sample_dt<=.30
            if prime:self.integral=self.derivative=self.left_rate=self.right_rate=0.
            ln,rn=data['left_near'],data['right_near']
            if not prime:
                alpha=sample_dt/(.12+sample_dt)
                self.derivative+=alpha*((raw-self.raw_error)/sample_dt-self.derivative)
                self.left_rate=clip((ln-self.left)/sample_dt,-.5,.5) if ln is not None and self.left is not None else 0.
                self.right_rate=clip((rn-self.right)/sample_dt,-.5,.5) if rn is not None and self.right is not None else 0.
            self.left,self.right=ln,rn
            self.left_pred=ln+.35*min(0.,self.left_rate) if ln is not None else None
            self.right_pred=rn+.35*min(0.,self.right_rate) if rn is not None else None
            error=math.copysign(max(0.,abs(raw)-.015),raw)
            self.reason='CENTER'
            # Continuous proximity error, not a fixed escape angle.
            if self.left_pred is not None and self.left_pred<.40:
                error=min(error,-min(.08,.5*(.40-self.left_pred)));self.reason='LEFT_APPROACH'
            if self.right_pred is not None and self.right_pred<.40:
                error=max(error,min(.08,.5*(.40-self.right_pred)));self.reason='RIGHT_APPROACH'
            if (self.left_pred is not None and self.right_pred is not None
                    and self.left_pred<.32 and self.right_pred<.32):
                raise ValueError('LANE_BOTH_SIDES_CONFLICT')
            # No heading-only turn when centred. Never subtract an assumed
            # initial mounting bias: real initial yaw remains observable.
            h=clip(.04*heading,-.004,.004)*clip(abs(error)/.06,0.,1.)
            if h*error<0:h=0.
            self.heading_term=h;self.p=.35*error;self.d=clip(.07*self.derivative,-.012,.012)
            if self.reason=='LEFT_APPROACH':self.d=min(0.,self.d)
            if self.reason=='RIGHT_APPROACH':self.d=max(0.,self.d)
            if error*self.error<=0 or abs(error)<abs(self.error) or abs(error)<.005:
                self.integral*=max(0.,1-sample_dt/.20)
            candidate=self.integral
            if not prime and age<=.15 and abs(error)<.08 and self.reason=='CENTER':
                candidate=clip(candidate+.008*error*sample_dt,-.002,.002)
            # Integrate only if the full (slew-limited) command can be delivered.
            proposal=self.p+h+self.d+candidate
            realized=clip(clip(proposal,lower,upper),self.output-.06*control_dt,self.output+.06*control_dt)
            if (candidate-self.integral)*(proposal-realized)<=1e-12:self.integral=candidate
            self.i=self.integral;self.requested=self.p+h+self.i+self.d
            self.error,self.raw_error,self.heading=error,raw,heading
            self.source=source;self.stamp=stamp
        if self.left_pred is not None and self.left_pred<.40:upper=0.
        if self.right_pred is not None and self.right_pred<.40:lower=0.
        # Age is sensor acquisition age, not callback arrival age.
        fade=clip((.30-max(0.,age))/.15,0.,1.)
        desired=clip(self.requested*fade,lower,upper)
        rate=.18 if abs(desired)<abs(self.output) or desired*self.output<0 else .06
        self.output=clip(desired,self.output-rate*control_dt,self.output+rate*control_dt)
        # A newly observed close side immediately cancels steering into it.
        self.output=clip(self.output,lower,upper)
        self.time=now
        return self.output
