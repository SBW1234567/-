#!/usr/bin/env python3
"""
从 RViz 的 /goal_pose 话题采集目标点，并按键保存为 CSV。

使用场景：
1. 在 RViz 里用 2D Goal Pose 点选赛道上的多个导航点。
2. 本节点订阅 /goal_pose，把每个点的 x、y、orientation.z、orientation.w 存到内存。
3. 按 f/F 后，把点写入国赛自动任务使用的 competition_waypoints.csv。

注意：
- 这个脚本只负责“采点保存”，不负责让车移动。
- 默认保存到 ~/racecar/src/racecar/config/competition_waypoints.csv。
- 可用 ROS 参数 output_file 修改保存位置。
"""

import csv
import os
import select
import sys
import termios
import tty

import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node


class GoalPoseSubscriber(Node):
    """订阅 RViz 目标点，并保存成后续导航脚本可读取的 CSV 格式。"""

    def __init__(self):
        super().__init__('get_point')

        self.declare_parameter(
            'output_file',
            '~/racecar/src/racecar/config/competition_waypoints.csv',
        )
        self.output_file = os.path.expanduser(
            str(self.get_parameter('output_file').value)
        )

        # RViz 的 “2D Goal Pose” 工具默认发布 geometry_msgs/PoseStamped。
        self.subscription = self.create_subscription(
            PoseStamped,
            '/goal_pose',
            self.pose_stamped_cb,
            10,
        )

        # points 中每一行格式为 [x, y, z, w]。
        # 这里 z/w 指的是四元数 orientation.z 和 orientation.w，不是位置 z。
        self.points = []

        # 保存终端原始设置。get_key 会临时切换到 raw 模式读取单字符。
        self.settings = termios.tcgetattr(sys.stdin)

    def pose_stamped_cb(self, msg):
        """收到一个 RViz 目标点后，把导航真正需要的 4 个数存起来。"""

        gx = msg.pose.position.x
        gy = msg.pose.position.y
        gz = msg.pose.orientation.z
        gw = msg.pose.orientation.w
        self.points.append([gx, gy, gz, gw])
        self.get_logger().info(f'已记录目标点: x={gx:.3f}, y={gy:.3f}, z={gz:.3f}, w={gw:.3f}')

    def get_key(self):
        """非阻塞读取键盘输入；没有按键时返回空字符串。"""

        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def data_write_csv(self, file_name, datas):
        """把采集到的目标点写入 CSV，一行一个导航点。"""

        os.makedirs(os.path.dirname(file_name), exist_ok=True)
        with open(file_name, 'w', newline='', encoding='utf-8') as file_csv:
            writer = csv.writer(file_csv, delimiter=',', quoting=csv.QUOTE_MINIMAL)
            writer.writerow(['name', 'x', 'y', 'orientation_z', 'orientation_w'])
            for index, data in enumerate(datas, start=1):
                writer.writerow([f'point_{index}', *data])
        self.get_logger().info(f'CSV 保存成功，共 {len(datas)} 个点: {file_name}')


def main(args=None):
    rclpy.init(args=args)
    node = GoalPoseSubscriber()

    try:
        while rclpy.ok():
            # spin_once 负责处理 /goal_pose 回调，timeout 让循环还能继续读键盘。
            rclpy.spin_once(node, timeout_sec=0.1)
            key = node.get_key()

            # 按 f/F 保存当前所有点。
            if key == 'f' or key == 'F':
                node.data_write_csv(
                    node.output_file,
                    node.points,
                )

            # Ctrl+C 退出。
            if key == '\x03':
                break
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
