#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""国赛雷达锥桶感知与防撞节点。

Nav2 的 costmap 仍负责真正的绕障和重新规划；本节点负责两件事：
1. 从 /scan 中聚类出前方尺寸接近锥桶的独立障碍物；
2. 当前方距离过小时发布急停信号，交给 race_task_controller 统一停车。

发布 /race/lidar_status，数据格式为：
[cone_detected, cone_x, cone_y, cone_distance,
 front_clearance, caution, emergency, preferred_side, left_clearance, right_clearance]

/race/cone_candidates: repeated [x, y, distance, width, point_count], all candidates.

preferred_side: 1 表示左侧空间更大，-1 表示右侧空间更大，0 表示不确定。
雷达无法仅凭单帧百分之百区分蓝锥桶和围栏，因此颜色识别不是本节点职责。
"""

import math
import time
import json
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray, String


class RaceLidarGuard(Node):
    """提取紧凑障碍物并发布防撞状态。"""

    def __init__(self):
        super().__init__('race_lidar_guard')

        self.declare_parameter('curve_route', False)
        self.curve_route = bool(self.get_parameter('curve_route').value)
        self.declare_parameter('curve_static_body_guard_enabled', False)
        self.curve_static_body_guard_enabled=bool(self.get_parameter('curve_static_body_guard_enabled').value)
        self.declare_parameter('entry_v33_enabled', False)
        self.entry_v33_enabled=bool(self.get_parameter('entry_v33_enabled').value)
        self.declare_parameter('relative_route', False)
        self.relative_route = bool(self.get_parameter('relative_route').value)
        self.relative_pub = self.create_publisher(String, '/race/relative_features', 5)
        self.relative_stamp = 0
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('min_range', 0.20)
        # N10 会扫到车壳、支架和线缆。张皓哲组手册采用 0.30 m
        # 最小有效极径，这里单独保留成参数，便于现场标定。
        self.declare_parameter('self_filter_radius', 0.30)
        self.declare_parameter('max_range', 3.0)
        self.declare_parameter('publish_filtered_scan', True)
        self.declare_parameter('filtered_scan_topic', '/race/scan_filtered')
        self.declare_parameter('forward_range', 2.5)
        self.declare_parameter('lateral_range', 1.5)
        self.declare_parameter('cluster_gap', 0.16)
        self.declare_parameter('min_cluster_points', 4)
        self.declare_parameter('min_cone_width', 0.10)
        # 50 cm 左右的蓝色挡板不能再落入锥桶尺寸范围。
        self.declare_parameter('max_cone_width', 0.32)
        self.declare_parameter('front_half_angle_deg', 25.0)
        self.declare_parameter('caution_distance', 1.20)
        self.declare_parameter('emergency_distance', 0.30)
        self.declare_parameter('clear_distance', 0.80)
        self.declare_parameter('emergency_min_points', 3)
        self.declare_parameter('emergency_hold_time', 0.35)
        self.declare_parameter('entry_open_distance', 0.50)
        self.entry_open_distance = float(self.get_parameter('entry_open_distance').value)
        self.declare_parameter('entry_side_margin', 0.10)
        self.entry_side_margin = float(self.get_parameter('entry_side_margin').value)
        if not math.isfinite(self.entry_side_margin) or not 0.05 <= self.entry_side_margin <= 0.20:
            raise ValueError('Invalid entry_side_margin')
        for name, default in [('entry_body_width', 0.30),
                              ('entry_body_front', 0.21),
                              ('entry_body_rear', 0.18),
                              ('entry_body_margin', 0.05)]:
            self.declare_parameter(name, default)
            value = float(self.get_parameter(name).value)
            if not math.isfinite(value) or value <= 0:
                raise ValueError('Invalid body diagnostic dimension: ' + name)
            setattr(self, name, value)
        self.declare_parameter('relative_body_margin', .03)
        self.relative_body_margin=float(self.get_parameter('relative_body_margin').value)
        if not math.isfinite(self.relative_body_margin) or not 0.<=self.relative_body_margin<=.10:
            raise ValueError('Invalid relative_body_margin')
        self.entry_body_pub = self.create_publisher(String, '/race/entry_body_status', 5)

        self.scan_topic = str(self.get_parameter('scan_topic').value)
        self.min_range = float(self.get_parameter('min_range').value)
        self.self_filter_radius = float(
            self.get_parameter('self_filter_radius').value
        )
        self.max_range = float(self.get_parameter('max_range').value)
        self.publish_filtered_scan = bool(
            self.get_parameter('publish_filtered_scan').value
        )
        self.filtered_scan_topic = str(
            self.get_parameter('filtered_scan_topic').value
        )
        self.forward_range = float(self.get_parameter('forward_range').value)
        self.lateral_range = float(self.get_parameter('lateral_range').value)
        self.cluster_gap = float(self.get_parameter('cluster_gap').value)
        self.min_cluster_points = int(self.get_parameter('min_cluster_points').value)
        self.min_cone_width = float(self.get_parameter('min_cone_width').value)
        self.max_cone_width = float(self.get_parameter('max_cone_width').value)
        self.front_half_angle = math.radians(
            float(self.get_parameter('front_half_angle_deg').value)
        )
        self.caution_distance = float(self.get_parameter('caution_distance').value)
        self.emergency_distance = float(self.get_parameter('emergency_distance').value)
        self.clear_distance = float(self.get_parameter('clear_distance').value)
        self.emergency_min_points = int(self.get_parameter('emergency_min_points').value)
        self.emergency_hold_time = float(self.get_parameter('emergency_hold_time').value)

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
        )
        self.create_subscription(LaserScan, self.scan_topic, self.scan_callback, qos)
        self.filtered_scan_pub = None
        if self.publish_filtered_scan:
            self.filtered_scan_pub = self.create_publisher(
                LaserScan, self.filtered_scan_topic, qos
            )
        self.status_pub = self.create_publisher(
            Float32MultiArray, '/race/lidar_status', 10
        )
        self.candidates_pub = self.create_publisher(Float32MultiArray, '/race/cone_candidates', 5)

        self.emergency_latched = False
        self.emergency_since = 0.0
        self.get_logger().info(
            f'国赛雷达节点已启动：订阅 {self.scan_topic}，'
            f'自车滤波半径={self.self_filter_radius:.2f}m，'
            f'发布 /race/lidar_status 和 {self.filtered_scan_topic}'
        )

    @staticmethod
    def _distance(p1, p2):
        return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

    @staticmethod
    def _normalize_angle(angle):
        """Normalize scanner angles such as 0..2pi to -pi..pi."""
        return math.atan2(math.sin(angle), math.cos(angle))

    def _effective_min_range(self, scan):
        return max(self.min_range, self.self_filter_radius, float(scan.range_min))

    def _range_is_valid(self, distance, scan):
        return (
            math.isfinite(distance)
            and self._effective_min_range(scan) <= distance <= self.max_range
            and distance <= float(scan.range_max)
        )

    def _emergency_range_is_valid(self, distance, angle, scan):
        # The ordinary 0.30 m radial self filter would hide a 0.30 m
        # emergency. Use raw ranges outside the configured body footprint.
        if not (math.isfinite(distance) and max(self.min_range,float(scan.range_min)) <= distance <= min(self.max_range,float(scan.range_max))):
            return False
        x,y=distance*math.cos(angle),distance*math.sin(angle)
        return not (-self.entry_body_rear-.02 <= x <= self.entry_body_front+.02
                    and abs(y) <= self.entry_body_width/2+.02)

    def _publish_filtered_scan(self, scan):
        """发布可直接在 RViz 与原始 /scan 叠加的距离滤波结果。"""
        if self.filtered_scan_pub is None:
            return

        filtered = LaserScan()
        filtered.header = scan.header
        filtered.angle_min = scan.angle_min
        filtered.angle_max = scan.angle_max
        filtered.angle_increment = scan.angle_increment
        filtered.time_increment = scan.time_increment
        filtered.scan_time = scan.scan_time
        filtered.range_min = self._effective_min_range(scan)
        filtered.range_max = min(self.max_range, float(scan.range_max))
        filtered.ranges = [
            float(distance) if self._range_is_valid(distance, scan) else math.inf
            for distance in scan.ranges
        ]
        filtered.intensities = list(scan.intensities)
        self.filtered_scan_pub.publish(filtered)

    def relative_features(self, scan):
        """All-around compact clusters; separate topic leaves legacy detection intact."""
        clusters, current = [], []
        front_total = front_seen = 0
        front = 5.5
        body_clear = True
        body_hits = physical_hits = 0
        nearest_body = None
        curve_candidate=self.curve_route
        static_enforced=not curve_candidate or self.curve_static_body_guard_enabled
        margin=self.relative_body_margin if curve_candidate else .10
        # A 30 cm cone/odometry self filter covers the entire small body box.
        # Curve diagnostic candidates use the existing 20 cm raw minimum;
        # they may include self returns and do not block motion by default.
        # Other profiles retain their original radial self mask and margin.
        body_minimum=max(scan.range_min,self.min_range if curve_candidate else self.self_filter_radius)
        angle = scan.angle_min
        for distance in scan.ranges:
            a = self._normalize_angle(angle)
            valid = (math.isfinite(distance) and max(scan.range_min,self.self_filter_radius) <= distance <= scan.range_max)
            if abs(a) <= math.radians(25):
                front_total += 1
                if valid or distance == math.inf:
                    front_seen += 1
                if valid:
                    front = min(front,distance)
            if math.isfinite(distance) and body_minimum<=distance<=scan.range_max:
                x,y=distance*math.cos(a),distance*math.sin(a)
                if (-self.entry_body_rear-margin < x < self.entry_body_front+margin
                        and abs(y) < self.entry_body_width/2+margin):
                    body_clear=False
                    body_hits+=1
                    if nearest_body is None or distance<nearest_body[0]:nearest_body=[distance,x,y]
                    if -self.entry_body_rear<x<self.entry_body_front and abs(y)<self.entry_body_width/2:
                        physical_hits+=1
            if valid and distance <= 5.5:
                x,y=distance*math.cos(a),distance*math.sin(a)
                point=(x,y,distance,a)
                if current and self._distance(current[-1],point) > self.cluster_gap:
                    clusters.append(current)
                    current=[]
                current.append(point)
            else:
                if current: clusters.append(current)
                current=[]
            angle += scan.angle_increment
        if current: clusters.append(current)
        if len(clusters)>1 and self._distance(clusters[-1][-1],clusters[0][0]) <= self.cluster_gap:
            clusters[0]=clusters[-1]+clusters[0]
            clusters.pop()
        clusters=[c for c in clusters if len(c)>=self.min_cluster_points]
        cones=self.curve_cone_centres(clusters) if self.curve_route else self._find_cones(clusters)
        # A compact return is only a candidate, never a colour-confirmed identity.
        result = dict(cones=[list(c) for c in cones], front=front,
                      front_coverage=front_seen/max(1,front_total), body_clear=body_clear)
        result['body_guard']=dict(policy='STATIC_BODY_FOOTPRINT' if static_enforced else 'DIAGNOSTIC_BODY_CANDIDATE',
            enabled=static_enforced,static_enforced=static_enforced,margin=margin,
            bounds=[-self.entry_body_rear-margin,self.entry_body_front+margin,self.entry_body_width/2+margin],
            hits=body_hits,physical_hits=physical_hits,nearest_dxy=nearest_body,
            minimum_valid_range=body_minimum,clear=body_clear)
        result.update(self.exit_path_features(scan))
        result.update(self.entry_region_features(scan))
        return result

    def exit_path_features(self, scan):
        """Straight swept strip, with the existing 10 cm body padding.

        Distances are longitudinal from the laser, not bumper gaps. Side-wall
        rays outside this strip cannot masquerade as a frontal obstruction.
        Every ray intersecting the strip beyond the nose contributes coverage;
        unknown returns never certify a free path. This is ONLY for departure,
        not a collision model for the later curved cone trajectory.
        """
        half_width = self.entry_body_width/2+.10
        nose = self.entry_body_front
        half_angle = math.atan2(half_width,nose)
        nearest = 5.5
        total = seen = 0
        for i,distance in enumerate(scan.ranges):
            angle = self._normalize_angle(scan.angle_min+i*scan.angle_increment)
            if abs(angle) > half_angle:
                continue
            total += 1
            if distance == math.inf:
                seen += 1
                continue
            if not (math.isfinite(distance) and
                    max(scan.range_min,self.self_filter_radius) <= distance <= scan.range_max):
                continue
            seen += 1
            x,y = distance*math.cos(angle),distance*math.sin(angle)
            if x >= nose and abs(y) <= half_width:
                nearest = min(nearest,x)
        return dict(exit_path_front=nearest,
                    exit_path_coverage=seen/total if total >= 6 else 0.,
                    exit_path_half_width=half_width,exit_path_body_front=nose)

    def entry_region_features(self, scan):
        """Transverse end-board fit and a local straight-departure side envelope.

        A range minimum is NOT an end wall. Require a contiguous wide, flat
        return crossing the forward axis. No odometry translation is used.
        """
        groups, current = [], []
        side_total = side_seen = 0
        side_clear = True
        nearest_side = None
        for i, distance in enumerate(scan.ranges):
            angle = self._normalize_angle(scan.angle_min+i*scan.angle_increment)
            valid = (math.isfinite(distance) and
                     max(scan.range_min, self.self_filter_radius) <= distance <= scan.range_max)
            if math.radians(20) <= abs(angle) <= math.radians(145):
                side_total += 1
                if valid or distance == math.inf:
                    side_seen += 1
            point = None
            if valid:
                x, y = distance*math.cos(angle), distance*math.sin(angle)
                # Includes the rear body and 50 cm ahead of the nose. Returns
                # behind this envelope do not block continuing straight ahead.
                if -self.entry_body_rear-.10 <= x <= self.entry_body_front+.50:
                    nearest_side = min(nearest_side, abs(y)) if nearest_side is not None else abs(y)
                    if abs(y) <= self.entry_body_width/2+self.entry_side_margin:
                        side_clear = False
                if abs(angle) <= math.radians(30) and 1.0 <= x <= 8.5 and -1.0 <= y <= 1.5:
                    point = (x, y)
            if point is not None:
                if current and self._distance(current[-1], point) > .25:
                    groups.append(current)
                    current = []
                current.append(point)
            elif current:
                groups.append(current)
                current = []
        if current:
            groups.append(current)
        if len(groups) > 1 and self._distance(groups[-1][-1], groups[0][0]) <= .25:
            groups[0] = groups[-1]+groups[0]
            groups.pop()
        walls = []
        for group in groups:
            if len(group) < 10:
                continue
            # The end board touches the long side board: they form one scan
            # cluster. Extract transverse support before fitting, rather than
            # fitting that entire L-shaped cluster as a single line.
            seeds = group[::max(1, len(group)//24)][:25]
            best = []
            for i, p in enumerate(seeds):
                for q in seeds[i+1:]:
                    if abs(q[1]-p[1]) < .50:
                        continue
                    a = (q[0]-p[0])/(q[1]-p[1])
                    if abs(a) > math.tan(math.radians(12)):
                        continue
                    b = p[0]-a*p[1]
                    support = [(x,y) for x,y in group if abs(x-a*y-b) <= .04]
                    if len(support) > len(best):
                        best = support
            points = best
            if len(points) < 10:
                continue
            ys = [y for x,y in points]
            span = max(ys)-min(ys)
            # A slightly rotated vehicle can put the entire far wall on one
            # side of its forward ray. Coverage of the road-axis projection is
            # checked below in the fitted wall frame, not in vehicle-frame y.
            if span < .70:
                continue
            mx = sum(x for x,y in points)/len(points)
            my = sum(ys)/len(points)
            var = sum((y-my)**2 for y in ys)
            slope = sum((y-my)*(x-mx) for x,y in points)/max(var, 1e-9)
            intercept = mx-slope*my
            residual = math.sqrt(sum((x-slope*y-intercept)**2 for x,y in points)/len(points))
            if abs(slope) > math.tan(math.radians(12)) or residual > .04:
                continue
            heading = -math.atan(slope)
            distance = intercept*math.cos(heading)
            lateral = sorted(-math.sin(heading)*x+math.cos(heading)*y for x,y in points)
            if min(lateral) > -.15 or max(lateral) < .25:
                continue
            if any(b-a > .25 for a,b in zip(lateral,lateral[1:])):
                continue
            walls.append([distance, heading, span, residual, len(points)])
        # Multiple plausible boards must not authorise a turn.
        wall = walls[0] if len(walls) == 1 else None
        return dict(entry_end_wall=wall, entry_side_clear=side_clear,
                    entry_side_nearest=nearest_side,
                    entry_side_coverage=side_seen/side_total if side_total >= 12 else 0.,
                    entry_side_geometry=[self.entry_body_rear, self.entry_body_front,
                                         self.entry_body_width/2, self.entry_side_margin, .50])

    def publish_relative_features(self, scan):
        stamp=scan.header.stamp.sec*1000000000+scan.header.stamp.nanosec
        result=self.relative_features(scan)
        result.update(schema=3,stamp_ns=stamp,valid=stamp>self.relative_stamp and stamp>0)
        if result['valid']: self.relative_stamp=stamp
        msg=String()
        msg.data=json.dumps(result,allow_nan=False)
        self.relative_pub.publish(msg)

    def curve_cone_centres(self, clusters):
        """Fit compact visible arcs after existing adjacent-ray clustering.

        A surface centroid is biased toward the sensor. Fit a bounded circle
        only where angular support, residual and conditioning justify it.
        Poorly observed/linear fragments remain unconfirmed, not guessed cones.
        """
        result=[]
        for cluster in clusters:
            if len(cluster)<(4 if self.entry_v33_enabled else 5):continue
            points=np.asarray([p[:2] for p in cluster],dtype=float)
            diameter=float(np.max(np.linalg.norm(points[:,None,:]-points[None,:,:],axis=2))) if len(points)<=70 else 9.
            if not (.06 if self.entry_v33_enabled else .10)<=diameter<=.34:continue
            mean=points.mean(axis=0);q=points-mean
            matrix=np.column_stack((2*q,np.ones(len(q))))
            if np.linalg.cond(matrix)>150:continue
            fit=np.linalg.lstsq(matrix,(q*q).sum(axis=1),rcond=None)[0]
            centre=fit[:2]+mean
            radius2=fit[2]+float(fit[:2]@fit[:2])
            if radius2<=0:continue
            radius=math.sqrt(radius2)
            residual=float(np.sqrt(np.mean((np.linalg.norm(points-centre,axis=1)-radius)**2)))
            angles=np.unwrap(np.arctan2(points[:,1]-centre[1],points[:,0]-centre[0]))
            if not (.05<=radius<=.20 and residual<=(.025 if self.entry_v33_enabled else .015)
                    and np.ptp(angles)>=(.35 if self.entry_v33_enabled else .55)):continue
            x,y=map(float,centre)
            result.append((x,y,math.hypot(x,y),min(.32,diameter),len(cluster)))
        return sorted(result,key=lambda c:c[2])

    def _make_clusters(self, scan):
        """按激光束相邻关系聚类，保留前方矩形区域内的点。"""
        clusters = []
        current = []
        angle = scan.angle_min

        for distance in scan.ranges:
            valid = self._range_is_valid(distance, scan)
            if valid:
                x = distance * math.cos(angle)
                y = distance * math.sin(angle)
                valid = 0.0 < x <= self.forward_range and abs(y) <= self.lateral_range

            if valid:
                point = (x, y, distance, angle)
                if current and self._distance(current[-1], point) > self.cluster_gap:
                    if len(current) >= self.min_cluster_points:
                        clusters.append(current)
                    current = []
                current.append(point)
            else:
                if len(current) >= self.min_cluster_points:
                    clusters.append(current)
                current = []
            angle += scan.angle_increment

        if len(current) >= self.min_cluster_points:
            clusters.append(current)

        # The N10 scan starts at 0 and ends at 2*pi.  A target crossing the
        # forward axis therefore appears at both ends of ranges and belongs
        # to one physical cluster.
        if (
            len(clusters) >= 2
            and self._distance(clusters[-1][-1], clusters[0][0])
            <= self.cluster_gap
        ):
            clusters[0] = clusters[-1] + clusters[0]
            clusters.pop()
        return clusters

    def _find_cones(self, clusters):
        """用簇宽度筛出类似锥桶的紧凑障碍物。"""
        cones = []
        for cluster in clusters:
            width = self._distance(cluster[0], cluster[-1])
            if not self.min_cone_width <= width <= self.max_cone_width:
                continue
            x = sum(point[0] for point in cluster) / len(cluster)
            y = sum(point[1] for point in cluster) / len(cluster)
            cones.append((x, y, math.hypot(x, y), width, len(cluster)))
        cones.sort(key=lambda item: item[2])
        return cones

    def _sector_clearance(self, scan, min_angle, max_angle):
        values = []
        angle = scan.angle_min
        for distance in scan.ranges:
            normalized_angle = self._normalize_angle(angle)
            if (
                min_angle <= normalized_angle <= max_angle
                and (self._range_is_valid(distance, scan) or distance == math.inf
                     or (math.isfinite(distance) and distance > self.max_range
                         and distance <= scan.range_max))
            ):
                values.append(min(distance, self.max_range))
            angle += scan.angle_increment
        return min(values) if values else -1.0

    def scan_callback(self, scan):
        self._publish_filtered_scan(scan)
        if self.relative_route:
            self.publish_relative_features(scan)
        clusters = self._make_clusters(scan)
        cones = self._find_cones(clusters)

        front_values = []
        emergency_values = []
        front_observed = False
        angle = scan.angle_min
        for distance in scan.ranges:
            normalized_angle = self._normalize_angle(angle)
            if abs(normalized_angle) <= self.front_half_angle:
                emergency_valid=self._emergency_range_is_valid(distance,normalized_angle,scan)
                if emergency_valid:emergency_values.append(distance)
                front_observed = front_observed or emergency_valid or distance == math.inf or (
                    math.isfinite(distance) and self.max_range < distance <= scan.range_max)
            if (
                abs(normalized_angle) <= self.front_half_angle
                and self._range_is_valid(distance, scan)
            ):
                front_values.append(distance)
            angle += scan.angle_increment

        front_clearance = min(front_values+emergency_values) if front_values or emergency_values else self.max_range
        close_point_count = sum(
            distance <= self.emergency_distance for distance in emergency_values
        )
        raw_emergency = not front_observed or close_point_count >= self.emergency_min_points
        now = time.monotonic()

        # Curve/relative motion already checks the full commanded swept body.
        # Do not keep a neutral command latched until the vehicle somehow
        # moves an already safe 35 cm return out to the old 80 cm threshold.
        emergency_clear_distance=(min(self.clear_distance,self.emergency_distance+.05)
                                  if self.curve_route or self.relative_route else self.clear_distance)
        if raw_emergency:
            self.emergency_latched = True
            self.emergency_since = now
        elif (
            self.emergency_latched
            and (min(emergency_values) if emergency_values else front_clearance) >= emergency_clear_distance
            and now - self.emergency_since >= self.emergency_hold_time
        ):
            self.emergency_latched = False

        caution = front_clearance <= self.caution_distance
        left_clearance = self._sector_clearance(
            scan, self.front_half_angle, math.radians(75.0)
        )
        right_clearance = self._sector_clearance(
            scan, math.radians(-75.0), -self.front_half_angle
        )
        preferred_side = 0.0
        if left_clearance >= 0 and right_clearance >= 0 and abs(left_clearance - right_clearance) > 0.12:
            preferred_side = 1.0 if left_clearance > right_clearance else -1.0

        if cones:
            cone_detected = 1.0
            cone_x, cone_y, cone_distance, cone_width, cone_points = cones[0]
        else:
            cone_detected = 0.0
            cone_x = cone_y = cone_distance = -1.0
            cone_width = -1.0
            cone_points = 0

        candidates_msg = Float32MultiArray()
        candidates_msg.data = [float(value) for candidate in cones for value in candidate]
        self.candidates_pub.publish(candidates_msg)
        msg = Float32MultiArray()
        msg.data = [
            cone_detected,
            float(cone_x),
            float(cone_y),
            float(cone_distance),
            float(front_clearance),
            float(caution),
            float(self.emergency_latched),
            preferred_side,
            float(left_clearance),
            float(right_clearance),
            float(self.entry_side_open(scan)),
        ]
        body_result = self.entry_body_diagnostic(scan)
        # Explanation only; existing lidar_status release bits are unchanged.
        body_result['side_open'] = self.entry_open_diagnostic(scan)
        body_result['emergency_guard']=dict(raw=raw_emergency,latched=self.emergency_latched,
            close_points=close_point_count,stop_distance=self.emergency_distance,
            clear_distance=emergency_clear_distance,hold_seconds=self.emergency_hold_time)
        # Index 11 is a static geometry candidate, never turn authorization.
        msg.data.append(float(body_result['rear_clear_candidate']))
        self.status_pub.publish(msg)
        body_msg = String()
        body_msg.data = json.dumps(body_result, separators=(',', ':'))
        self.entry_body_pub.publish(body_msg)

        self.get_logger().info(
            '雷达: cones=%d candidate=(%.2f,%.2f) d=%.2fm w=%.2fm pts=%d '
            'front=%.2fm caution=%d emergency=%d side=%d'
            % (
                len(cones),
                cone_x,
                cone_y,
                cone_distance,
                cone_width,
                cone_points,
                front_clearance,
                int(caution),
                int(self.emergency_latched),
                int(preferred_side),
            ),
            throttle_duration_sec=1.0,
        )

    def entry_body_diagnostic(self, scan):
        """Explain the legacy left sector; never authorize motion or infer wall identity."""
        total = observed = behind = alongside = ahead = inside = 0
        nearest = None
        rear = self.entry_body_rear + self.entry_body_margin
        front = self.entry_body_front + self.entry_body_margin
        half_width = self.entry_body_width / 2 + self.entry_body_margin
        for i, distance in enumerate(scan.ranges):
            angle = self._normalize_angle(scan.angle_min + i * scan.angle_increment)
            if not math.radians(45) <= angle <= math.radians(135):
                continue
            total += 1
            if distance == math.inf:
                observed += 1
                continue
            if not (math.isfinite(distance) and scan.range_min <= distance <= scan.range_max):
                continue
            observed += 1
            if distance >= self.entry_open_distance:
                continue
            x, y = distance * math.cos(angle), distance * math.sin(angle)
            if nearest is None or distance < nearest[0]:
                nearest = [distance, x, y]
            if x < -rear:
                behind += 1
            elif x > front:
                ahead += 1
            else:
                alongside += 1
                if y <= half_width:
                    inside += 1
        coverage_ok = total >= 6 and observed >= 0.9 * total
        # A positive candidate only explains why rear returns block the old gate.
        # Partial observations are unknown even if they meet the legacy 90% test.
        candidate = total >= 6 and observed == total and alongside == 0 and ahead == 0
        return dict(diagnostic_only=True, turn_authorized=False,
                    rear_clear_candidate=candidate, observed=observed, total=total,
                    legacy_coverage_ok=coverage_ok, behind_rear=behind,
                    alongside=alongside, ahead=ahead, inside_padded_body=inside,
                    nearest_close_dxy=nearest,
                    padded_bounds=[-rear, front, half_width])

    def entry_side_open(self, scan):
        """Require observed free space beside and behind the left shoulder.

        This is a commissioning clearance gate, not a swept-body collision check.
        Missing/near-self returns cannot certify an opening.
        """
        observed = 0
        total = 0
        for index, distance in enumerate(scan.ranges):
            angle = self._normalize_angle(scan.angle_min + index * scan.angle_increment)
            if not math.radians(45) <= angle <= math.radians(135):
                continue
            total += 1
            if math.isfinite(distance) and scan.range_min <= distance <= scan.range_max:
                if distance < self.entry_open_distance:
                    return False
                observed += 1
            elif distance == math.inf:
                observed += 1
        return total >= 6 and observed >= 0.9 * total

    def entry_open_diagnostic(self, scan):
        """Explain the original 45..135 degree gate, including missing returns."""
        total = observed = close = behind = alongside = ahead = 0
        nearest = None
        rear = self.entry_body_rear + self.entry_body_margin
        front = self.entry_body_front + self.entry_body_margin
        for index, distance in enumerate(scan.ranges):
            angle = self._normalize_angle(scan.angle_min + index * scan.angle_increment)
            if not math.radians(45) <= angle <= math.radians(135):
                continue
            total += 1
            if distance == math.inf:
                observed += 1
            elif math.isfinite(distance) and scan.range_min <= distance <= scan.range_max:
                observed += 1
                if distance < self.entry_open_distance:
                    close += 1
                    x, y = distance * math.cos(angle), distance * math.sin(angle)
                    behind += int(x < -rear)
                    ahead += int(x > front)
                    alongside += int(-rear <= x <= front)
                    if nearest is None or distance < nearest[0]:
                        nearest = [distance, x, y]
        reasons = []
        if total < 6:
            reasons.append('TOO_FEW_RAYS')
        if observed < 0.9 * total:
            reasons.append('INCOMPLETE_COVERAGE')
        if close:
            reasons.append('NEAR_RETURNS')
        return dict(reason='|'.join(reasons) if reasons else 'OPEN',
                    total=total, observed=observed, missing=total-observed,
                    near_count=close, behind_rear=behind, alongside=alongside,
                    ahead=ahead, nearest_dxy=nearest,
                    open_distance=self.entry_open_distance,
                    original_gate=self.entry_side_open(scan))


def main(args=None):
    rclpy.init(args=args)
    node = RaceLidarGuard()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
