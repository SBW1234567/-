#!/usr/bin/env python3
"""Record synchronized race-control inputs and outputs without commanding the car."""

import csv
import math
import os
import time
from datetime import datetime

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray, Int16MultiArray, String


class RaceControlDiagnostic(Node):
    """Passive recorder used to identify perception, state, and control faults."""

    def __init__(self):
        super().__init__('race_control_diagnostic')
        self.declare_parameter('output_directory', '~/race_logs')
        self.declare_parameter('command_topic', '/car_cmd_vel')
        self.record_cmd_topic = str(self.get_parameter('command_topic').value)
        if self.record_cmd_topic not in ('/car_cmd_vel', '/race/proposed_cmd_vel'):
            raise ValueError('Unsupported diagnostic command_topic')
        output_directory = os.path.expanduser(
            str(self.get_parameter('output_directory').value)
        )
        os.makedirs(output_directory, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.output_path = os.path.join(
            output_directory, f'race_control_{timestamp}.csv'
        )
        self.output_file = open(
            self.output_path, 'w', newline='', encoding='utf-8'
        )
        self.fields = [
            'wall_time', 'elapsed_s', 'phase', 'control_state',
            'cmd_linear', 'cmd_angular',
            'left_wall_m', 'right_wall_m', 'boundary_front_m',
            'center_error_m', 'wall_heading_deg',
            'left_wall_valid', 'right_wall_valid',
            'left_proximity_m', 'right_proximity_m',
            'cone_detected', 'cone_x_m', 'cone_y_m', 'cone_distance_m',
            'lidar_front_m', 'lidar_caution', 'lidar_emergency',
            'preferred_side', 'vision_red', 'vision_green',
            'vision_crosswalk', 'odom_x_m', 'odom_y_m', 'odom_yaw_deg',
            'cmd_age_s', 'boundary_age_s', 'lidar_age_s', 'vision_age_s',
            'diagnostic', 'route_status', 'odom_age_s', 'vision_present',
            'cmd_source', 'entry_body_status', 'entry_body_age_s',
            'relative_features', 'relative_features_age_s', 'entry_status',
        ]
        self.writer = csv.DictWriter(self.output_file, fieldnames=self.fields)
        self.writer.writeheader()
        self.output_file.flush()

        self.started_at = time.monotonic()
        self.phase = 'UNKNOWN'
        self.control_state = 'UNKNOWN'
        self.cmd_linear = 0.0
        self.cmd_angular = 0.0
        self.boundary = [-1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 0.0, -1.0, -1.0]
        self.lidar = [0.0, -1.0, -1.0, -1.0, -1.0, 0.0, 0.0, 0.0]
        self.vision = [0, 0, 0, 0, 0]
        self.odom = [0.0, 0.0, 0.0]
        self.last_cmd = 0.0
        self.last_boundary = 0.0
        self.last_lidar = 0.0
        self.last_vision = 0.0
        self.last_odom = 0.0
        self.route_status = ''
        self.entry_status = ''
        self.create_subscription(String, '/race/entry_status', self.entry_status_callback, 10)
        self.cmd_source = 'NONE'
        self.entry_body_status = ''
        self.last_entry_body = 0.0
        self.relative_features = ''
        self.last_relative_features = 0.0
        self.create_subscription(String, '/race/relative_features', self.relative_callback, 10)
        self.create_subscription(String, '/race/route_status', self.route_callback, 10)
        self.create_subscription(String, '/race/entry_body_status', self.entry_body_callback, 10)

        self.create_subscription(Twist, self.record_cmd_topic, self.cmd_callback, 20)
        self.create_subscription(
            Float32MultiArray,
            '/race/track_boundary',
            self.boundary_callback,
            20,
        )
        self.create_subscription(
            Float32MultiArray, '/race/lidar_status', self.lidar_callback, 20
        )
        self.create_subscription(
            Int16MultiArray, '/ican_vision', self.vision_callback, 20
        )
        self.create_subscription(
            String, '/race/task_phase', self.phase_callback, 20
        )
        self.create_subscription(
            String, '/race/control_state', self.state_callback, 20
        )
        self.create_subscription(Odometry, '/odom_rf2o', self.odom_callback, 20)
        self.create_timer(0.10, self.record_sample)
        self.get_logger().warn(f'控制诊断记录已启动: {self.output_path}')

    def entry_status_callback(self, msg):
        self.entry_status = msg.data

    def cmd_callback(self, msg):
        self.cmd_source = self.record_cmd_topic
        self.cmd_linear = float(msg.linear.x)
        self.cmd_angular = float(msg.angular.z)
        self.last_cmd = time.monotonic()

    def entry_body_callback(self, msg):
        self.entry_body_status = msg.data
        self.last_entry_body = time.monotonic()

    def relative_callback(self, msg):
        self.relative_features = msg.data
        self.last_relative_features = time.monotonic()

    def boundary_callback(self, msg):
        self.boundary = list(msg.data) + [-1.0] * 9
        self.last_boundary = time.monotonic()

    def lidar_callback(self, msg):
        self.lidar = list(msg.data) + [-1.0] * 8
        self.last_lidar = time.monotonic()

    def vision_callback(self, msg):
        self.vision = list(msg.data) + [0] * 5
        if len(msg.data) < 5:
            self.vision[4] = self.vision[2]
        self.last_vision = time.monotonic()

    def phase_callback(self, msg):
        self.phase = msg.data

    def route_callback(self, msg):
        self.route_status = msg.data

    def state_callback(self, msg):
        self.control_state = msg.data

    def odom_callback(self, msg):
        self.last_odom = time.monotonic()
        q = msg.pose.pose.orientation
        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z),
        )
        self.odom = [
            float(msg.pose.pose.position.x),
            float(msg.pose.pose.position.y),
            math.degrees(yaw),
        ]

    @staticmethod
    def age(now, timestamp):
        return now - timestamp if timestamp > 0.0 else -1.0

    def diagnose(self):
        issues = []
        left = float(self.boundary[0])
        right = float(self.boundary[1])
        left_valid = bool(self.boundary[5])
        right_valid = bool(self.boundary[6])
        left_near = float(self.boundary[7])
        right_near = float(self.boundary[8])
        emergency = bool(self.lidar[6])

        if emergency:
            issues.append('LIDAR_EMERGENCY')
        if self.phase.startswith('ORBIT_CONE') and abs(self.cmd_angular) >= 0.43:
            issues.append('ORBIT_STEERING_SATURATED')
        if left_valid and right_valid:
            if right + 0.08 < left and self.cmd_angular < -0.05:
                issues.append('TURNING_TOWARD_RIGHT_WALL')
            if left + 0.08 < right and self.cmd_angular > 0.05:
                issues.append('TURNING_TOWARD_LEFT_WALL')
        if (
            self.cmd_linear > 0.0
            and 0.0 < right_near < 0.35
            and self.cmd_angular < 0.05
        ):
            issues.append('RIGHT_WALL_RESPONSE_LATE')
        if (
            self.cmd_linear > 0.0
            and 0.0 < left_near < 0.35
            and self.cmd_angular > -0.05
        ):
            issues.append('LEFT_WALL_RESPONSE_LATE')
        if 0.0 < float(self.lidar[4]) < 0.70 and self.cmd_linear > 0.0:
            issues.append('MOVING_WITH_FRONT_TOO_CLOSE')
        return '|'.join(issues) if issues else 'OK'

    def record_sample(self):
        now = time.monotonic()
        diagnostic = self.diagnose()
        row = {
            'wall_time': datetime.now().isoformat(timespec='milliseconds'),
            'elapsed_s': f'{now - self.started_at:.3f}',
            'phase': self.phase,
            'control_state': self.control_state,
            'cmd_linear': f'{self.cmd_linear:.4f}',
            'cmd_angular': f'{self.cmd_angular:.4f}',
            'left_wall_m': f'{float(self.boundary[0]):.4f}',
            'right_wall_m': f'{float(self.boundary[1]):.4f}',
            'boundary_front_m': f'{float(self.boundary[2]):.4f}',
            'center_error_m': f'{float(self.boundary[3]):.4f}',
            'wall_heading_deg': f'{math.degrees(float(self.boundary[4])):.3f}',
            'left_wall_valid': int(bool(self.boundary[5])),
            'right_wall_valid': int(bool(self.boundary[6])),
            'left_proximity_m': f'{float(self.boundary[7]):.4f}',
            'right_proximity_m': f'{float(self.boundary[8]):.4f}',
            'cone_detected': int(bool(self.lidar[0])),
            'cone_x_m': f'{float(self.lidar[1]):.4f}',
            'cone_y_m': f'{float(self.lidar[2]):.4f}',
            'cone_distance_m': f'{float(self.lidar[3]):.4f}',
            'lidar_front_m': f'{float(self.lidar[4]):.4f}',
            'lidar_caution': int(bool(self.lidar[5])),
            'lidar_emergency': int(bool(self.lidar[6])),
            'preferred_side': int(round(float(self.lidar[7]))),
            'vision_red': int(bool(self.vision[0])),
            'vision_green': int(bool(self.vision[1])),
            'vision_crosswalk': int(bool(self.vision[2])),
            'odom_x_m': f'{self.odom[0]:.4f}',
            'odom_y_m': f'{self.odom[1]:.4f}',
            'odom_yaw_deg': f'{self.odom[2]:.3f}',
            'cmd_age_s': f'{self.age(now, self.last_cmd):.3f}',
            'boundary_age_s': f'{self.age(now, self.last_boundary):.3f}',
            'lidar_age_s': f'{self.age(now, self.last_lidar):.3f}',
            'vision_age_s': f'{self.age(now, self.last_vision):.3f}',
            'diagnostic': diagnostic,
            'route_status': self.route_status,
            'entry_status': self.entry_status,
            'odom_age_s': f'{self.age(now, self.last_odom):.3f}',
            'vision_present': int(bool(self.vision[4])),
            'cmd_source': self.cmd_source,
            'entry_body_status': self.entry_body_status,
            'entry_body_age_s': f'{self.age(now, self.last_entry_body):.3f}',
            'relative_features': self.relative_features,
            'relative_features_age_s': f'{self.age(now, self.last_relative_features):.3f}',
        }
        self.writer.writerow(row)
        self.output_file.flush()
        if diagnostic != 'OK':
            self.get_logger().warn(
                '诊断=%s phase=%s cmd=(%.2f,%.2f) wall=(%.2f,%.2f) front=%.2f'
                % (
                    diagnostic,
                    self.phase,
                    self.cmd_linear,
                    self.cmd_angular,
                    float(self.boundary[0]),
                    float(self.boundary[1]),
                    float(self.lidar[4]),
                ),
                throttle_duration_sec=1.0,
            )

    def destroy_node(self):
        if hasattr(self, 'output_file') and not self.output_file.closed:
            self.output_file.flush()
            self.output_file.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = RaceControlDiagnostic()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
