#!/usr/bin/env python3
"""Lightweight, independent latest-scan lane observations for V13 PID."""
import json
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile,ReliabilityPolicy,HistoryPolicy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from race_lane_core import observe


class RaceLaneObserver(Node):
    def __init__(self):
        super().__init__('race_lane_observer')
        qos=QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,history=HistoryPolicy.KEEP_LAST,depth=1)
        self.publisher=self.create_publisher(String,'/race/lane_observation',qos)
        self.create_subscription(LaserScan,'/scan',self.scan_callback,qos)
        self.last_stamp=0

    def scan_callback(self,scan):
        stamp=int(scan.header.stamp.sec)*1000000000+int(scan.header.stamp.nanosec)
        if stamp<=self.last_stamp:return
        self.last_stamp=stamp
        result=observe(scan)
        msg=String();msg.data=json.dumps(result,separators=(',',':'),allow_nan=False)
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args);node=RaceLaneObserver()
    try:rclpy.spin(node)
    finally:node.destroy_node();rclpy.shutdown()


if __name__=='__main__':main()
