#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ICAN/智能车赛题视觉检测节点。

当前版本适配你们已经跑通的 camer_view/OpenCV 方案：
1. 不依赖 camer.launch.py。
2. 不订阅 /image_raw。
3. 节点内部直接打开摄像头 /dev/video20。
4. 检测红灯、绿灯、人行道/斑马线。
5. 发布 /ican_vision 给总控制节点。

发布话题：
  /ican_vision = [red, green, crosswalk_trigger, stop_required, crosswalk_present]
  /image_detection = [red, 0, crosswalk, 0, 0]

运行：
  ros2 run racecar ican_vision_node.py

调试窗口：
  ros2 run racecar ican_vision_node.py --ros-args -p show_debug:=true
"""

from collections import deque
import json
import subprocess
import time

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from std_msgs.msg import Int16MultiArray


class IcanVisionNode(Node):
    """直接读取摄像头的红绿灯和人行道检测节点。"""

    def __init__(self):
        super().__init__('ican_vision_node')

        # 你们实测 OpenCV 能打开的是 /dev/video20，所以默认 camera_index=20。
        self.declare_parameter('camera_index', 20)
        self.declare_parameter('frame_width', 320)
        self.declare_parameter('frame_height', 240)
        self.declare_parameter('show_debug', False)
        self.declare_parameter('min_light_area', 30)
        self.declare_parameter('max_light_area', 12000)
        self.declare_parameter('min_light_circularity', 0.60)
        self.declare_parameter('light_red_min_s', 65)
        self.declare_parameter('light_min_bright_v', 190)
        self.declare_parameter('light_min_bright_fraction', 0.12)
        self.declare_parameter('light_min_hull_occupancy', 0.55)
        self.declare_parameter('light_roi_x_min', 0.12)
        self.declare_parameter('light_roi_x_max', 0.88)
        self.declare_parameter('min_crosswalk_area', 3200)
        self.declare_parameter('crosswalk_weak_area', 1800)
        self.declare_parameter('crosswalk_roi_y_min', 0.30)
        self.declare_parameter('crosswalk_white_max_s', 100)
        self.declare_parameter('crosswalk_white_min_v', 130)
        self.declare_parameter('crosswalk_weak_ratio', 0.045)
        self.declare_parameter('crosswalk_window_frames', 5)
        self.declare_parameter('crosswalk_required_hits', 2)
        self.declare_parameter('red_ratio_threshold', 0.0005)
        self.declare_parameter('green_ratio_threshold', 0.0005)
        self.declare_parameter('crosswalk_ratio_threshold', 0.12)
        self.declare_parameter('crosswalk_trigger_y', 0.733)
        self.declare_parameter('crosswalk_position_frames', 2)
        self.declare_parameter('crosswalk_position_max_gap', 0.25)
        self.declare_parameter('crosswalk_position_max_jump', 0.08)
        self.declare_parameter('camera_fixed_controls', True)
        self.declare_parameter('camera_exposure', 313)
        self.declare_parameter('camera_white_balance', 4000)
        self.trigger_y = float(self.get_parameter('crosswalk_trigger_y').value)
        self.position_frames = int(self.get_parameter('crosswalk_position_frames').value)
        self.position_max_gap = float(self.get_parameter('crosswalk_position_max_gap').value)
        self.position_max_jump = float(self.get_parameter('crosswalk_position_max_jump').value)
        if not 0.0 < self.trigger_y < 1.0 or self.position_frames < 2:
            raise ValueError('Invalid crosswalk position parameters')
        self.position_history = deque(maxlen=self.position_frames)
        self.position_last_time = None
        self.position_reason = 'WAIT_POSITION'
        self.crosswalk_present = False
        self.crosswalk_near_y = -1.0
        self.frames_processed = 0
        self.rate_start = time.monotonic()

        self.camera_index = int(self.get_parameter('camera_index').value)
        self.frame_width = int(self.get_parameter('frame_width').value)
        self.frame_height = int(self.get_parameter('frame_height').value)
        self.show_debug = self.get_parameter('show_debug').value
        self.min_light_area = self.get_parameter('min_light_area').value
        self.max_light_area = self.get_parameter('max_light_area').value
        self.min_light_circularity = self.get_parameter(
            'min_light_circularity'
        ).value
        self.light_roi_x_min = self.get_parameter('light_roi_x_min').value
        self.light_roi_x_max = self.get_parameter('light_roi_x_max').value
        self.light_red_min_s = int(self.get_parameter('light_red_min_s').value)
        self.light_min_bright_v = int(self.get_parameter('light_min_bright_v').value)
        self.light_min_bright_fraction = float(
            self.get_parameter('light_min_bright_fraction').value)
        self.light_min_hull_occupancy = float(
            self.get_parameter('light_min_hull_occupancy').value)
        self.light_diagnostics = {}
        self.light_last_detection = None
        self.min_crosswalk_area = self.get_parameter('min_crosswalk_area').value
        self.crosswalk_weak_area = self.get_parameter('crosswalk_weak_area').value
        self.crosswalk_roi_y_min = self.get_parameter('crosswalk_roi_y_min').value
        self.crosswalk_white_max_s = int(
            self.get_parameter('crosswalk_white_max_s').value
        )
        self.crosswalk_white_min_v = int(
            self.get_parameter('crosswalk_white_min_v').value
        )
        self.crosswalk_weak_ratio = self.get_parameter(
            'crosswalk_weak_ratio'
        ).value
        self.crosswalk_window_frames = max(
            1, int(self.get_parameter('crosswalk_window_frames').value)
        )
        self.crosswalk_required_hits = max(
            1, int(self.get_parameter('crosswalk_required_hits').value)
        )
        self.red_ratio_threshold = self.get_parameter('red_ratio_threshold').value
        self.green_ratio_threshold = self.get_parameter('green_ratio_threshold').value
        self.crosswalk_ratio_threshold = self.get_parameter('crosswalk_ratio_threshold').value
        self.crosswalk_history = deque(maxlen=self.crosswalk_window_frames)

        qos = QoSProfile(depth=10)
        self.vision_pub = self.create_publisher(Int16MultiArray, '/ican_vision', qos)
        self.compat_pub = self.create_publisher(Int16MultiArray, '/image_detection', qos)

        self.cap = self.open_camera(self.camera_index)
        buffer_ok = self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1) # CAMERA_BUFFER_TEST
        self.get_logger().info("CAMERA_BUFFER_TEST: accepted=%s, buffers=%s" % (buffer_ok, self.cap.get(cv2.CAP_PROP_BUFFERSIZE))) # CAMERA_BUFFER_TEST
        self.timer = self.create_timer(0.05, self.process_frame)

        self.get_logger().info('ICAN视觉节点已启动：OpenCV直接读摄像头')
        self.get_logger().info(f'摄像头: /dev/video{self.camera_index}')
        self.get_logger().info('发布: /ican_vision = [红灯, 绿灯, 人行道到位, 是否停车, 人行道可见]')
        self.get_logger().info('兼容发布: /image_detection = [红灯, 0, 人行道, 0, 0]')

    def open_camera(self, camera_index):
        """打开摄像头，优先使用 V4L2 后端，失败后退回 OpenCV 默认后端。"""

        cap = cv2.VideoCapture(camera_index, cv2.CAP_V4L2)
        if not cap.isOpened():
            self.get_logger().warn(f'V4L2 打开 /dev/video{camera_index} 失败，尝试默认后端')
            cap = cv2.VideoCapture(camera_index)

        if not cap.isOpened():
            raise RuntimeError(f'无法打开摄像头 /dev/video{camera_index}')

        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 30.0)
        if bool(self.get_parameter('camera_fixed_controls').value):
            controls = {
                'auto_exposure': 1,
                'exposure_time_absolute': int(self.get_parameter('camera_exposure').value),
                'white_balance_automatic': 0,
                'white_balance_temperature': int(self.get_parameter('camera_white_balance').value),
            }
            try:
                for key, value in controls.items():
                    subprocess.run(['v4l2-ctl', '-d', f'/dev/video{camera_index}',
                                    f'--set-ctrl={key}={value}'], check=True,
                                   capture_output=True, text=True, timeout=3)
                result = subprocess.run(['v4l2-ctl', '-d', f'/dev/video{camera_index}',
                                         '--get-ctrl=' + ','.join(controls)], check=True,
                                        capture_output=True, text=True, timeout=3)
                actual = {}
                for line in result.stdout.splitlines():
                    if ':' in line:
                        key, value = line.split(':', 1)
                        actual[key.strip()] = int(value.strip().split()[0])
                if any(actual.get(k) != v for k, v in controls.items()):
                    raise RuntimeError('Camera controls did not match requested values')
                self.get_logger().info('Camera controls verified: ' + result.stdout.strip())
            except Exception:
                cap.release()
                raise
        self.get_logger().info('Capture: %.0fx%.0f, requested 30 FPS, reported %.1f FPS' % (
            cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT),
            cap.get(cv2.CAP_PROP_FPS)))
        return cap

    def detect_traffic_light(self, frame):
        """Detect lit lenses from colored rims, including overexposed white cores.

        Area is measured in the processed image (normally 320x240). A white
        core can complete a colored lens, but cannot create a color candidate.
        The ROI and camera exposure remain unchanged from V19.
        """
        h, w = frame.shape[:2]
        x0 = int(w * self.light_roi_x_min)
        x1 = int(w * self.light_roi_x_max)
        roi = frame[0:int(h * 0.60), x0:x1]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        red_mask = cv2.inRange(hsv, np.array([0, self.light_red_min_s, 80]),
                              np.array([12, 255, 255]))
        red_mask |= cv2.inRange(hsv, np.array([160, self.light_red_min_s, 80]),
                               np.array([180, 255, 255]))
        green_mask = cv2.inRange(hsv, np.array([35, 70, 70]),
                                np.array([90, 255, 255]))
        red_area, red_diag, red_debug = self._light_candidates(
            hsv, red_mask, self.red_ratio_threshold)
        green_area, green_diag, green_debug = self._light_candidates(
            hsv, green_mask, self.green_ratio_threshold)
        red_detected, green_detected = red_area > 0.0, green_area > 0.0
        both = red_detected and green_detected
        # A larger green lens must never erase an independently valid red lens.
        if both:
            green_detected = False
        self.light_diagnostics = {
            'roi': [x0, 0, x1 - x0, roi.shape[0]],
            'red': red_diag, 'green': green_diag,
            'decision': ('AMBIGUOUS_RED_PRIORITY' if both else
                         'RED' if red_detected else 'GREEN' if green_detected
                         else 'NO_LIT_LENS'),
        }
        debug_mask = cv2.bitwise_or(red_debug, green_debug)
        return (int(red_detected), int(green_detected), debug_mask,
                red_area, green_area)

    def _light_candidates(self, hsv, color_mask, ratio_threshold):
        """Measure actual seed pixels; closing is only for rim connectivity."""
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        connected = cv2.morphologyEx(color_mask, cv2.MORPH_CLOSE, kernel)
        contours, _ = cv2.findContours(
            connected, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        effective_min = max(float(self.min_light_area),
                            float(ratio_threshold) * color_mask.size)
        candidates, rejected = [], {}
        best_area = 0.0
        for contour in contours:
            hull = cv2.convexHull(contour)
            area = float(cv2.contourArea(hull))
            # Skip pixel noise before allocating a candidate-local mask.
            if area < effective_min or area > self.max_light_area:
                reason = 'AREA_SMALL' if area < effective_min else 'AREA_LARGE'
                rejected[reason] = rejected.get(reason, 0) + 1
                continue
            x, y, width, height = cv2.boundingRect(hull)
            aspect = width / max(float(height), 1.0)
            perimeter = float(cv2.arcLength(hull, True))
            circularity = 4.0 * np.pi * area / max(perimeter * perimeter, 1e-6)
            # Coordinate-span normalization also rejects small solid rectangles.
            extent = area / max(float((width - 1) * (height - 1)), 1.0)
            candidate = {
                'bbox': [x, y, width, height], 'area': round(area, 1),
                'circularity': round(float(circularity), 3),
                'extent': round(extent, 3),
            }
            reason = None
            if not 0.45 <= aspect <= 2.2:
                reason = 'ASPECT'
            elif circularity < self.min_light_circularity:
                reason = 'NOT_ROUND'
            elif not 0.35 <= extent <= 0.94:
                reason = 'RECTANGLE_OR_THIN'
            if reason is None:
                local_hull = hull - np.array([[[x, y]]], dtype=hull.dtype)
                inside_mask = np.zeros((height, width), dtype=np.uint8)
                cv2.drawContours(inside_mask, [local_hull], -1, 255, -1)
                inside = inside_mask > 0
                region = hsv[y:y + height, x:x + width]
                # Original color mask, not morphology-created white pixels.
                colored = (color_mask[y:y + height, x:x + width] > 0) & inside
                color_pixels = int(np.count_nonzero(colored))
                hull_pixels = max(int(np.count_nonzero(inside)), 1)
                bright_pixels = int(np.count_nonzero(
                    colored & (region[:, :, 2] >= self.light_min_bright_v)))
                bright_fraction = bright_pixels / max(color_pixels, 1)
                core = (inside & (region[:, :, 2] >= 220)
                        & (region[:, :, 1] <= 120))
                occupancy = float(np.count_nonzero(colored | core)) / hull_pixels
                candidate.update({
                    'color_pixels': color_pixels,
                    'bright_fraction': round(bright_fraction, 3),
                    'core_fraction': round(float(np.count_nonzero(core)) /
                                           hull_pixels, 3),
                    'occupancy': round(occupancy, 3),
                })
                if color_pixels < 3 or color_pixels / hull_pixels < 0.08:
                    reason = 'TOO_LITTLE_COLOR'
                elif occupancy < self.light_min_hull_occupancy:
                    reason = 'EMPTY_HULL'
                elif (bright_pixels < 3 or
                      bright_fraction < self.light_min_bright_fraction):
                    reason = 'UNLIT_COLOR'
            candidate['reason'] = reason or 'ACCEPTED'
            if reason:
                rejected[reason] = rejected.get(reason, 0) + 1
            else:
                best_area = max(best_area, area)
            candidates.append(candidate)
        # Keep both colors and rejection evidence, but bound each diagnostic log.
        candidates.sort(key=lambda item: (item['reason'] == 'ACCEPTED',
                                           item['area']), reverse=True)
        diagnostic = {'accepted_area': round(best_area, 1),
                      'effective_min_area': round(effective_min, 1),
                      'candidates': candidates[:3], 'rejected': rejected}
        return best_area, diagnostic, connected

    def log_light_diagnostics(self, red, green):
        """State changes bypass throttling; periodic detail remains bounded."""
        decision = self.light_diagnostics.get('decision', 'UNKNOWN')
        state = (int(red), int(green), decision)
        if state != self.light_last_detection:
            self.get_logger().info(
                'LIGHT_EVENT red=%d green=%d decision=%s red_area=%.1f green_area=%.1f'
                % (red, green, decision,
                   self.light_diagnostics.get('red', {}).get('accepted_area', 0.),
                   self.light_diagnostics.get('green', {}).get('accepted_area', 0.)))
            self.light_last_detection = state
        self.get_logger().info(
            'LIGHT_DIAG ' + json.dumps(self.light_diagnostics, separators=(',', ':')),
            throttle_duration_sec=1.0)

    def detect_crosswalk(self, frame):
        """检测横向排列、长边沿行驶方向的多张白纸，并判断图像位置。"""

        h, w = frame.shape[:2]
        roi_y0 = int(h * self.crosswalk_roi_y_min)
        roi = frame[roi_y0:h, :]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)

        lower_white = np.array(
            [0, 0, self.crosswalk_white_min_v],
            dtype=np.uint8,
        )
        upper_white = np.array(
            [180, self.crosswalk_white_max_s, 255],
            dtype=np.uint8,
        )
        white_mask = cv2.inRange(hsv, lower_white, upper_white)

        kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, (5, 3)
        )
        white_mask = cv2.morphologyEx(
            white_mask,
            cv2.MORPH_OPEN,
            kernel,
            iterations=1,
        )
        white_mask = cv2.morphologyEx(
            white_mask,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=1,
        )

        contours, _ = cv2.findContours(
            white_mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )

        candidates = []

        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < 35.0:
                continue

            x, y, width, height = cv2.boundingRect(contour)

            if height <= 0:
                continue

            horizontal_aspect = width / float(height)

            horizontal_paper = (
                horizontal_aspect >= 0.45
                and width >= w * 0.05
                and width <= w * 0.25
                and height >= roi.shape[0] * 0.025
            )

            if not horizontal_paper:
                continue

            candidates.append(
                {
                    'cx': x + width * 0.5,
                    'cy': y + height * 0.5,
                    'width': float(width),
                    'height': float(height),
                    'area': area,
                }
            )

        # 找出位于同一横排的白纸。
        best_row = []

        for reference in candidates:
            row = []

            for candidate in candidates:
                allowed_y_error = max(
                    8.0,
                    0.8 * max(
                        reference['height'],
                        candidate['height'],
                    ),
                )

                if abs(candidate['cy'] - reference['cy']) <= allowed_y_error:
                    row.append(candidate)

            if len(row) > len(best_row):
                best_row = row

        best_row.sort(key=lambda item: item['cx'])

        # 检查相邻白纸的间距，过滤墙面、灯光等白色物体。
        valid_indices = set()

        for index in range(len(best_row) - 1):
            left = best_row[index]
            right = best_row[index + 1]

            average_width = max(
                1.0,
                0.5 * (left['width'] + right['width']),
            )
            center_spacing = right['cx'] - left['cx']
            spacing_ratio = center_spacing / average_width

            if 1.00 <= spacing_ratio <= 2.8:
                valid_indices.add(index)
                valid_indices.add(index + 1)

        stripe_count = len(valid_indices)
        total_area = sum(
            best_row[index]['area']
            for index in valid_indices
        )

        roi_area = max(1, roi.shape[0] * roi.shape[1])
        white_ratio = (
            float(np.count_nonzero(white_mask)) / float(roi_area)
        )

        strong_detected = (
            stripe_count >= 3
            and total_area >= self.min_crosswalk_area
            and white_ratio >= self.crosswalk_ratio_threshold
        )

        weak_detected = (
            stripe_count >= 3
            and total_area >= self.crosswalk_weak_area
            and white_ratio >= self.crosswalk_weak_ratio
        )

        # Keep the current-frame presence separate from the stop trigger.
        self.crosswalk_present = bool(strong_detected or weak_detected)
        central = sorted((best_row[i] for i in valid_indices),
                         key=lambda item: abs(item['cx'] - w * 0.5))[:3]
        near_y = float(np.median([
            (roi_y0 + item['cy'] + item['height'] * 0.5) / h
            for item in central
        ])) if len(central) >= 3 else -1.0
        self.crosswalk_near_y = near_y
        crosswalk_detected = self.confirm_position(
            self.crosswalk_present, near_y, time.monotonic(),
            strong=strong_detected)
        history_hits = len(self.position_history)

        return (
            int(crosswalk_detected),
            white_mask,
            stripe_count,
            white_ratio,
            total_area,
            int(weak_detected),
            int(strong_detected),
            history_hits,
        )

    def confirm_position(self, present, near_y, now, strong=False):
        """Confirm current geometry without discarding normal approach motion.

        A short missing frame retains evidence but never triggers a stop. The
        next valid frame must still be within the original freshness window.
        Growing near_y is expected while approaching; a large backwards jump
        starts a new sequence. Close strong geometry has already passed the
        unchanged white/area/three-paper filters and must not be missed while
        waiting for a second frame at the bottom of the image.
        """
        if not np.isfinite(now):
            self.position_history.clear()
            self.position_last_time = None
            self.position_reason = 'INVALID_CLOCK'
            return False
        previous_time = self.position_last_time
        gap = now - previous_time if previous_time is not None else None
        if gap is not None and gap <= 0.0:
            self.position_history.clear()
            self.position_last_time = None
            self.position_reason = 'NONADVANCING_CLOCK'
            return False
        if gap is not None and gap > self.position_max_gap:
            self.position_history.clear()
            self.position_last_time = None
        if not present or not np.isfinite(near_y) or not 0.0 <= near_y <= 1.0:
            self.position_reason = 'WAIT_CURRENT_GEOMETRY'
            return False
        backwards = bool(self.position_history and
            self.position_history[-1] - near_y > self.position_max_jump)
        if backwards:
            self.position_history.clear()
        self.position_last_time = now
        self.position_history.append(near_y)
        if backwards:
            self.position_reason = 'BACKWARD_POSITION_RESET'
            return False
        if strong and near_y >= max(.80, self.trigger_y):
            self.position_reason = 'STRONG_NEAR_IMMEDIATE'
            return True
        confirmed = (len(self.position_history) >= self.position_frames
            and near_y >= self.trigger_y
            and float(np.median(self.position_history)) >= self.trigger_y)
        self.position_reason = 'POSITION_CONFIRMED' if confirmed else 'WAIT_POSITION'
        return confirmed

    def _largest_valid_blob_area(self, mask):
        """返回二值图中最大色块面积。"""

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        max_area = 0
        for cnt in contours:
            max_area = max(max_area, cv2.contourArea(cnt))
        return max_area

    def process_frame(self):
        """定时读取摄像头帧，完成识别并发布结果。"""

        ret, frame = self.cap.read()
        if not ret:
            self.confirm_position(False, -1.0, time.monotonic())
            self.get_logger().warn('摄像头读取失败，本帧跳过', throttle_duration_sec=1.0)
            return

        if frame.shape[1] != self.frame_width or frame.shape[0] != self.frame_height:
            frame = cv2.resize(frame, (self.frame_width, self.frame_height), interpolation=cv2.INTER_AREA)

        red, green, light_mask, red_area, green_area = self.detect_traffic_light(frame)
        self.log_light_diagnostics(red, green)
        (
            crosswalk,
            crosswalk_mask,
            stripe_count,
            white_ratio,
            crosswalk_area,
            weak_crosswalk,
            strong_crosswalk,
            history_hits,
        ) = self.detect_crosswalk(frame)
        stop_required = 1 if red or crosswalk else 0

        vision_msg = Int16MultiArray()
        vision_msg.data = [red, green, crosswalk, stop_required, int(self.crosswalk_present)]
        self.vision_pub.publish(vision_msg)

        compat_msg = Int16MultiArray()
        compat_msg.data = [red, 0, crosswalk, 0, 0]
        self.compat_pub.publish(compat_msg)

        self.get_logger().info(
            f'视觉: red={red}, green={green}, crosswalk={crosswalk}, stop={stop_required}, '
            f'red_area={red_area:.0f}, green_area={green_area:.0f}, '
            f'crosswalk_stripes={stripe_count}, white_ratio={white_ratio:.3f}, '
            f'crosswalk_area={crosswalk_area:.0f}, weak={weak_crosswalk}, '
            f'strong={strong_crosswalk}, '
            f'position_hits={history_hits}/{self.position_frames}, '
            f'present={int(self.crosswalk_present)}, near_y={self.crosswalk_near_y:.3f}, '
            f'trigger_y={self.trigger_y:.3f}, confirmation={self.position_reason}',
            throttle_duration_sec=0.5,
        )
        self.frames_processed += 1
        elapsed = time.monotonic() - self.rate_start
        if elapsed >= 5.0:
            self.get_logger().info(f'VISION_RATE: {self.frames_processed / elapsed:.1f} Hz')
            self.rate_start = time.monotonic()
            self.frames_processed = 0

        if self.show_debug:
            debug = frame.copy()
            cv2.putText(debug, f'RED: {red}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            cv2.putText(debug, f'GREEN: {green}', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.putText(debug, f'CROSSWALK: {crosswalk}', (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
            cv2.imshow('ican_vision_debug', debug)
            cv2.imshow('traffic_light_mask', light_mask)
            cv2.imshow('crosswalk_mask', crosswalk_mask)
            cv2.waitKey(1)

    def destroy_node(self):
        """退出节点时释放摄像头。"""

        if hasattr(self, 'cap') and self.cap is not None:
            self.cap.release()
        cv2.destroyAllWindows()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = IcanVisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
