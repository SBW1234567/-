#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""国赛现场在线任务节点。

本节点不读取地图和 CSV 路点。比赛启动后，它使用实时激光雷达选择前方
可通行方向，并不断向现场运行的 Nav2 发送短距离滚动目标。检测到紧凑障碍
（锥桶候选）后，按照参数指定的左右顺序生成绕行目标。红绿灯、人行道和
急停由 race_task_controller 统一处理。

注意：二维雷达无法识别锥桶颜色。正式比赛前必须用真实赛道验证锥桶聚类、
绕行左右顺序和绿灯后终点距离。
"""

import math
import time

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import Odometry
from rclpy.action import ActionClient
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from rclpy.time import Time
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool, Float32MultiArray, Int16MultiArray, String
from tf2_ros import Buffer, TransformException, TransformListener


def clamp(value, low, high):
    return max(low, min(high, value))


class RaceOnlineMissionNode(Node):
    """利用现场传感器持续生成局部 Nav2 目标。"""

    def __init__(self):
        super().__init__('race_online_mission')

        self.declare_parameter('startup_delay', 12.0)
        self.declare_parameter('goal_period', 1.5)
        self.declare_parameter('lookahead_distance', 1.2)
        self.declare_parameter('candidate_max_angle_deg', 65.0)
        self.declare_parameter('candidate_step_deg', 10.0)
        self.declare_parameter('sector_half_width_deg', 7.0)
        self.declare_parameter('minimum_clearance', 0.55)
        self.declare_parameter('cone_trigger_distance', 1.8)
        self.declare_parameter('cone_close_distance', 0.85)
        self.declare_parameter('cone_lost_time', 0.8)
        self.declare_parameter('cone_lateral_offset', 0.62)
        # 1 表示从锥桶左侧通过，-1 表示从右侧通过。
        self.declare_parameter('cone_pass_sides', [-1, 1])
        self.declare_parameter('finish_after_green_distance', 2.0)
        self.declare_parameter('scan_timeout', 0.8)

        self.startup_delay = float(self.get_parameter('startup_delay').value)
        self.goal_period = float(self.get_parameter('goal_period').value)
        self.lookahead = float(self.get_parameter('lookahead_distance').value)
        self.max_angle = math.radians(
            float(self.get_parameter('candidate_max_angle_deg').value)
        )
        self.angle_step = math.radians(
            float(self.get_parameter('candidate_step_deg').value)
        )
        self.sector_half_width = math.radians(
            float(self.get_parameter('sector_half_width_deg').value)
        )
        self.minimum_clearance = float(
            self.get_parameter('minimum_clearance').value
        )
        self.cone_trigger_distance = float(
            self.get_parameter('cone_trigger_distance').value
        )
        self.cone_close_distance = float(
            self.get_parameter('cone_close_distance').value
        )
        self.cone_lost_time = float(self.get_parameter('cone_lost_time').value)
        self.cone_lateral_offset = float(
            self.get_parameter('cone_lateral_offset').value
        )
        self.cone_pass_sides = [
            1 if int(side) >= 0 else -1
            for side in self.get_parameter('cone_pass_sides').value
        ]
        self.finish_after_green_distance = float(
            self.get_parameter('finish_after_green_distance').value
        )
        self.scan_timeout = float(self.get_parameter('scan_timeout').value)

        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
        )
        self.create_subscription(LaserScan, '/scan', self.scan_callback, sensor_qos)
        self.create_subscription(
            Float32MultiArray,
            '/race/lidar_status',
            self.lidar_status_callback,
            10,
        )
        self.create_subscription(Int16MultiArray, '/ican_vision', self.vision_callback, 10)
        self.create_subscription(Odometry, '/odom', self.odom_callback, 20)

        self.state_pub = self.create_publisher(String, '/race/mission_state', 10)
        self.finished_pub = self.create_publisher(Bool, '/race/mission_finished', 10)
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.tf_buffer = Buffer(cache_time=Duration(seconds=10.0))
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.start_time = time.monotonic()
        self.last_scan_time = 0.0
        self.scan = None
        self.cone = None
        self.cone_index = 0
        self.active_cone_seen_close = False
        self.last_cone_seen_time = 0.0
        self.travel_distance = 0.0
        self.last_odom_xy = None
        self.green_distance = None
        self.finished = False
        self.last_heading = 0.0
        self.timer = self.create_timer(self.goal_period, self.control_tick)
        self.publish_state('WAITING_FOR_SLAM')
        self.get_logger().warn('在线任务节点已启动：不读取地图，不读取 CSV，不需要 RViz 点目标')

    def publish_state(self, text):
        msg = String()
        msg.data = text
        self.state_pub.publish(msg)

    def scan_callback(self, msg):
        self.scan = msg
        self.last_scan_time = time.monotonic()

    def lidar_status_callback(self, msg):
        if len(msg.data) < 8 or msg.data[0] < 0.5:
            self.cone = None
            return
        self.cone = (float(msg.data[1]), float(msg.data[2]), float(msg.data[3]))
        self.last_cone_seen_time = time.monotonic()
        if self.cone[2] <= self.cone_close_distance:
            self.active_cone_seen_close = True

    def vision_callback(self, msg):
        if len(msg.data) < 2:
            return
        green = bool(msg.data[1])
        if green and self.green_distance is None:
            self.green_distance = self.travel_distance
            self.get_logger().warn('检测到绿灯，开始计算至终点区的现场行驶距离')

    def odom_callback(self, msg):
        x = float(msg.pose.pose.position.x)
        y = float(msg.pose.pose.position.y)
        if self.last_odom_xy is not None:
            step = math.hypot(x - self.last_odom_xy[0], y - self.last_odom_xy[1])
            if step < 0.5:
                self.travel_distance += step
        self.last_odom_xy = (x, y)

    def sector_clearance(self, center):
        values = []
        angle = self.scan.angle_min
        for distance in self.scan.ranges:
            if (
                abs(math.atan2(math.sin(angle - center), math.cos(angle - center)))
                <= self.sector_half_width
                and math.isfinite(distance)
                and self.scan.range_min <= distance <= self.scan.range_max
            ):
                values.append(float(distance))
            angle += self.scan.angle_increment
        if not values:
            return min(self.lookahead * 1.5, float(self.scan.range_max))
        values.sort()
        # 少量离群近点不应使方向选择剧烈跳变。
        return values[min(2, len(values) - 1)]

    def choose_free_heading(self):
        best_heading = 0.0
        best_score = -1e9
        angle = -self.max_angle
        while angle <= self.max_angle + 1e-6:
            clearance = self.sector_clearance(angle)
            forward_score = math.cos(angle)
            smooth_score = math.cos(angle - self.last_heading)
            blocked_penalty = 4.0 if clearance < self.minimum_clearance else 0.0
            score = 1.7 * min(clearance, 2.5) + forward_score + 0.4 * smooth_score - blocked_penalty
            if score > best_score:
                best_score = score
                best_heading = angle
            angle += self.angle_step
        self.last_heading = 0.65 * self.last_heading + 0.35 * best_heading
        return self.last_heading

    def choose_local_target(self):
        now = time.monotonic()
        if (
            self.cone_index < len(self.cone_pass_sides)
            and self.active_cone_seen_close
            and self.cone is None
            and now - self.last_cone_seen_time >= self.cone_lost_time
        ):
            self.cone_index += 1
            self.active_cone_seen_close = False
            self.publish_state(f'CONE_{self.cone_index}_PASSED')
            self.get_logger().warn(f'已通过第 {self.cone_index} 个锥桶候选')

        if (
            self.cone is not None
            and self.cone_index < len(self.cone_pass_sides)
            and self.cone[2] <= self.cone_trigger_distance
        ):
            cone_x, cone_y, _ = self.cone
            side = self.cone_pass_sides[self.cone_index]
            target_x = clamp(cone_x + 0.35, 0.65, self.lookahead)
            target_y = cone_y + side * self.cone_lateral_offset
            target_y = clamp(target_y, -0.95, 0.95)
            self.publish_state(f'PASS_CONE_{self.cone_index + 1}')
            return target_x, target_y

        heading = self.choose_free_heading()
        self.publish_state('ONLINE_FORWARD')
        return self.lookahead * math.cos(heading), self.lookahead * math.sin(heading)

    def local_target_to_map_pose(self, local_x, local_y):
        try:
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_footprint', Time(), timeout=Duration(seconds=0.25)
            )
        except TransformException as exc:
            self.get_logger().warn(f'等待 map->base_footprint TF: {exc}', throttle_duration_sec=2.0)
            return None

        translation = transform.transform.translation
        rotation = transform.transform.rotation
        yaw = math.atan2(
            2.0 * (rotation.w * rotation.z + rotation.x * rotation.y),
            1.0 - 2.0 * (rotation.y * rotation.y + rotation.z * rotation.z),
        )
        map_x = translation.x + math.cos(yaw) * local_x - math.sin(yaw) * local_y
        map_y = translation.y + math.sin(yaw) * local_x + math.cos(yaw) * local_y
        target_yaw = yaw + math.atan2(local_y, max(local_x, 1e-3))

        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = map_x
        pose.pose.position.y = map_y
        pose.pose.orientation.z = math.sin(target_yaw * 0.5)
        pose.pose.orientation.w = math.cos(target_yaw * 0.5)
        return pose

    def finish(self):
        if self.finished:
            return
        self.finished = True
        msg = Bool()
        msg.data = True
        self.finished_pub.publish(msg)
        self.publish_state('FINISHED')
        self.get_logger().warn('在线任务完成，已请求总控制节点锁停')

    def control_tick(self):
        if self.finished:
            return
        now = time.monotonic()
        if now - self.start_time < self.startup_delay:
            return
        if self.scan is None or now - self.last_scan_time > self.scan_timeout:
            self.publish_state('WAITING_FOR_SCAN')
            return
        if not self.nav_client.server_is_ready():
            self.publish_state('WAITING_FOR_NAV2')
            return
        if (
            self.green_distance is not None
            and self.travel_distance - self.green_distance >= self.finish_after_green_distance
        ):
            self.finish()
            return

        local_x, local_y = self.choose_local_target()
        pose = self.local_target_to_map_pose(local_x, local_y)
        if pose is None:
            return
        goal = NavigateToPose.Goal()
        goal.pose = pose
        self.nav_client.send_goal_async(goal)
        self.get_logger().info(
            f'在线局部目标: x={local_x:.2f}, y={local_y:.2f}, cone_index={self.cone_index}',
            throttle_duration_sec=1.0,
        )


def main(args=None):
    rclpy.init(args=args)
    node = RaceOnlineMissionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
