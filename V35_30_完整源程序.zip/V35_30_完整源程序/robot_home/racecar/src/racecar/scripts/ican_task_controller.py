#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ICAN 赛题总控制节点。

设计原则：
1. Nav2 继续负责正常导航和避障。
2. 视觉节点只负责识别，不直接控制小车。
3. 本节点作为最终速度闸门：
   - 订阅 Nav2 平滑后的速度 /car_cmd_vel_nav
   - 订阅视觉结果 /ican_vision
   - 发布最终底盘速度 /car_cmd_vel

视觉消息格式：
  /ican_vision = [red, green, crosswalk, stop_required]

控制策略：
  - 红灯连续检测到 N 帧：停车 red_stop_duration 秒。
  - 人行道连续检测到 N 帧：停车 crosswalk_stop_duration 秒。
  - 绿灯：不主动停车，正常放行 Nav2 速度。
  - 正常情况：直接转发 Nav2 的速度。
"""

import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import QoSProfile
from std_msgs.msg import Int16MultiArray


class IcanTaskController(Node):
    """赛题总控制节点：融合导航速度和视觉事件。"""

    def __init__(self):
        super().__init__('ican_task_controller')

        self.declare_parameter('nav_cmd_topic', '/car_cmd_vel_nav')
        self.declare_parameter('final_cmd_topic', '/car_cmd_vel')
        self.declare_parameter('vision_topic', '/ican_vision')
        self.declare_parameter('red_stop_duration', 3.0)
        self.declare_parameter('crosswalk_stop_duration', 3.0)
        self.declare_parameter('event_confirm_frames', 3)
        self.declare_parameter('event_cooldown', 2.0)
        self.declare_parameter('stop_linear_x', 0.0)
        self.declare_parameter('stop_angular_z', 0.0)

        self.nav_cmd_topic = self.get_parameter('nav_cmd_topic').value
        self.final_cmd_topic = self.get_parameter('final_cmd_topic').value
        self.vision_topic = self.get_parameter('vision_topic').value
        self.red_stop_duration = float(self.get_parameter('red_stop_duration').value)
        self.crosswalk_stop_duration = float(self.get_parameter('crosswalk_stop_duration').value)
        self.event_confirm_frames = int(self.get_parameter('event_confirm_frames').value)
        self.event_cooldown = float(self.get_parameter('event_cooldown').value)
        self.stop_linear_x = float(self.get_parameter('stop_linear_x').value)
        self.stop_angular_z = float(self.get_parameter('stop_angular_z').value)

        qos = QoSProfile(depth=10)

        self.nav_sub = self.create_subscription(
            Twist,
            self.nav_cmd_topic,
            self.nav_cmd_callback,
            qos,
        )
        self.vision_sub = self.create_subscription(
            Int16MultiArray,
            self.vision_topic,
            self.vision_callback,
            qos,
        )
        self.cmd_pub = self.create_publisher(Twist, self.final_cmd_topic, qos)

        # 用定时器持续发布停车命令，避免底盘保留上一帧速度。
        self.stop_timer = self.create_timer(0.05, self.control_loop)

        self.latest_nav_cmd = Twist()
        self.latest_vision = [0, 0, 0, 0]
        self.last_vision_time = 0.0

        self.red_count = 0
        self.crosswalk_count = 0

        self.active_event = 'none'
        self.stop_until = 0.0
        self.last_event_end_time = 0.0

        self.get_logger().info('ICAN总控制节点已启动')
        self.get_logger().info(f'订阅导航速度: {self.nav_cmd_topic}')
        self.get_logger().info(f'订阅视觉结果: {self.vision_topic}')
        self.get_logger().info(f'发布最终速度: {self.final_cmd_topic}')
        self.get_logger().warn('注意：navigation_no_smoother.launch.py 必须把 velocity_smoother 输出 remap 到 /car_cmd_vel_nav')

    def nav_cmd_callback(self, msg):
        """保存 Nav2 最新速度；如果没有停车事件，立即转发。"""

        self.latest_nav_cmd = msg
        if not self.is_stopping():
            self.cmd_pub.publish(msg)

    def vision_callback(self, msg):
        """处理视觉识别结果，参考 2025ROS 的红灯锁定停车状态机。"""

        data = list(msg.data)
        while len(data) < 4:
            data.append(0)

        red = int(data[0])
        green = int(data[1])
        crosswalk = int(data[2])
        self.latest_vision = [red, green, crosswalk, int(data[3])]
        self.last_vision_time = time.time()

        self.red_count = self.red_count + 1 if red else 0
        self.crosswalk_count = self.crosswalk_count + 1 if crosswalk else 0

        # 已经在停车中时，不重复触发新事件。
        if self.is_stopping():
            return

        # 冷却时间内不重复触发，防止同一个红灯/人行道反复停车。
        now = time.time()
        if now - self.last_event_end_time < self.event_cooldown:
            return

        if self.red_count >= self.event_confirm_frames:
            self.start_stop_event('red_light', self.red_stop_duration)
        elif self.crosswalk_count >= self.event_confirm_frames:
            self.start_stop_event('crosswalk', self.crosswalk_stop_duration)
        elif green:
            self.get_logger().info('检测到绿灯，保持放行', throttle_duration_sec=1.0)

    def start_stop_event(self, event_name, duration):
        """启动一个锁定停车事件。"""

        self.active_event = event_name
        self.stop_until = time.time() + duration
        self.get_logger().warn(f'触发 {event_name}，停车 {duration:.1f} 秒')
        self.publish_stop()

    def is_stopping(self):
        """当前是否处于停车事件中。"""

        return self.active_event != 'none' and time.time() < self.stop_until

    def control_loop(self):
        """定时控制：停车期间持续发 0，停车结束后恢复转发导航速度。"""

        if self.is_stopping():
            remaining = self.stop_until - time.time()
            self.publish_stop()
            self.get_logger().warn(
                f'{self.active_event} 停车中，剩余 {remaining:.1f} 秒',
                throttle_duration_sec=0.5,
            )
            return

        if self.active_event != 'none':
            finished_event = self.active_event
            self.active_event = 'none'
            self.stop_until = 0.0
            self.last_event_end_time = time.time()
            self.red_count = 0
            self.crosswalk_count = 0
            self.get_logger().warn(f'{finished_event} 停车结束，恢复 Nav2 速度')
            self.cmd_pub.publish(self.latest_nav_cmd)

    def publish_stop(self):
        """发布停车速度。"""

        stop_msg = Twist()
        stop_msg.linear.x = self.stop_linear_x
        stop_msg.angular.z = self.stop_angular_z
        self.cmd_pub.publish(stop_msg)


def main(args=None):
    rclpy.init(args=args)
    node = IcanTaskController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.publish_stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
