#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""国赛单圈自动路点任务节点。

启动后读取赛前标定的 CSV 路点，等待 Cartographer/Nav2 就绪，然后依次发送
NavigateToPose 目标。最后一个路点必须放在终点区中心；成功后发布
/race/mission_finished，让总控制节点永久停车。
"""

import csv
import os
import time

import rclpy
from action_msgs.msg import GoalStatus
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from std_msgs.msg import Bool, String


class RaceMissionNode(Node):
    """一次性执行 CSV 中的全部路点。"""

    def __init__(self):
        super().__init__('race_mission')

        default_file = os.path.join(
            get_package_share_directory('racecar'),
            'config',
            'competition_waypoints.csv',
        )
        self.declare_parameter('waypoint_file', default_file)
        self.declare_parameter('startup_delay', 12.0)
        self.declare_parameter('max_retries_per_goal', 2)
        self.declare_parameter('autostart', True)

        self.waypoint_file = os.path.expanduser(
            str(self.get_parameter('waypoint_file').value)
        )
        self.startup_delay = float(self.get_parameter('startup_delay').value)
        self.max_retries = int(self.get_parameter('max_retries_per_goal').value)
        self.autostart = bool(self.get_parameter('autostart').value)

        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        finish_qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.finished_pub = self.create_publisher(
            Bool, '/race/mission_finished', finish_qos
        )
        self.state_pub = self.create_publisher(String, '/race/mission_state', 10)

        self.waypoints = self._read_waypoints(self.waypoint_file)
        self.index = 0
        self.retry_count = 0
        self.goal_handle = None
        self.start_time = time.monotonic()
        self.started = False
        self.done = False
        self.create_timer(0.5, self.start_check)

        self.get_logger().info(
            f'国赛任务节点加载 {len(self.waypoints)} 个路点: {self.waypoint_file}'
        )
        if not self.waypoints:
            self.get_logger().error(
                '路点文件为空。先在训练场运行 get.py，用 2D Goal Pose 标定路线并按 f 保存。'
            )

    def _read_waypoints(self, path):
        points = []
        if not os.path.isfile(path):
            return points
        with open(path, 'r', encoding='utf-8-sig') as csv_file:
            for row in csv.reader(csv_file):
                if not row or row[0].strip().startswith('#'):
                    continue
                try:
                    if len(row) >= 5:
                        name = row[0].strip() or f'point_{len(points) + 1}'
                        values = row[1:5]
                    else:
                        name = f'point_{len(points) + 1}'
                        values = row[0:4]
                    x, y, z, w = [float(value) for value in values]
                except (ValueError, IndexError):
                    continue
                if abs(z) < 1e-9 and abs(w) < 1e-9:
                    w = 1.0
                points.append((name, x, y, z, w))
        return points

    def _publish_state(self, text):
        msg = String()
        msg.data = text
        self.state_pub.publish(msg)

    def start_check(self):
        if self.started or self.done or not self.autostart:
            return
        if not self.waypoints:
            self._finish(False, 'NO_WAYPOINTS')
            return
        if time.monotonic() - self.start_time < self.startup_delay:
            return
        if not self.nav_client.server_is_ready():
            self.get_logger().warn(
                '等待 Nav2 navigate_to_pose...', throttle_duration_sec=2.0
            )
            return
        self.started = True
        self._publish_state('STARTED')
        self.get_logger().warn('Nav2 已就绪，开始执行国赛单圈路线')
        self._send_current_goal()

    def _send_current_goal(self):
        name, x, y, z, w = self.waypoints[self.index]
        goal = NavigateToPose.Goal()
        goal.pose = PoseStamped()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = x
        goal.pose.pose.position.y = y
        goal.pose.pose.orientation.z = z
        goal.pose.pose.orientation.w = w
        self.get_logger().warn(
            f'发送路点 {self.index + 1}/{len(self.waypoints)} [{name}] x={x:.2f}, y={y:.2f}'
        )
        future = self.nav_client.send_goal_async(goal)
        future.add_done_callback(self._goal_response)

    def _goal_response(self, future):
        try:
            self.goal_handle = future.result()
        except Exception as exc:
            self._goal_failed(f'发送目标异常: {exc}')
            return
        if not self.goal_handle.accepted:
            self._goal_failed('目标被 Nav2 拒绝')
            return
        self.goal_handle.get_result_async().add_done_callback(self._goal_result)

    def _goal_result(self, future):
        try:
            status = future.result().status
        except Exception as exc:
            self._goal_failed(f'获取导航结果异常: {exc}')
            return

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.retry_count = 0
            self.get_logger().info(f'已到达路点 {self.index + 1}')
            self.index += 1
            if self.index >= len(self.waypoints):
                self._finish(True, 'FINISHED')
            else:
                self._send_current_goal()
        else:
            self._goal_failed(f'导航状态码 {status}')

    def _goal_failed(self, reason):
        if self.retry_count < self.max_retries:
            self.retry_count += 1
            self.get_logger().warn(
                f'{reason}，重试当前路点 {self.retry_count}/{self.max_retries}'
            )
            self._send_current_goal()
            return
        self.get_logger().error(f'{reason}，当前路点连续失败，任务锁停')
        self._finish(False, 'FAILED')

    def _finish(self, success, state):
        if self.done:
            return
        self.done = True
        msg = Bool()
        # 失败也发布 True，确保无人干预规则下车辆不会失控继续行驶。
        msg.data = True
        self.finished_pub.publish(msg)
        self._publish_state(state)
        if success:
            self.get_logger().warn('全部路点完成，车辆在终点区锁停')
        else:
            self.get_logger().error(f'任务未完成，安全锁停：{state}')


def main(args=None):
    rclpy.init(args=args)
    node = RaceMissionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
