#!/usr/bin/env python3
"""Opt-in route experiment. Original crosswalk/competition launch stays intact.

Default dry_run publishes proposals only; the motor topic receives zeros.
Calibration is mandatory even for a valid path preview. Ends after two cones,
with an explicit TEST_COMPLETE hold, NOT a claim of a completed competition.
"""
import math
import time

import rclpy
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from geometry_msgs.msg import Twist

from race_task_controller import RaceTaskController
from race_route_geometry import Model, Tracker, LinkedOrbitPath, TargetLock, ScanSpace, candidates, world, local, distance, plan


class OutputGate:
    def __init__(self, actual, proposed, owner):
        self.actual, self.proposed, self.owner = actual, proposed, owner

    def publish(self, msg):
        self.proposed.publish(msg)
        self.actual.publish(Twist() if self.owner.dry_run or self.owner.calibration_error else msg)


class RouteController(RaceTaskController):
    TRANSFER_CONES = 'TRANSFER_CONES'
    def __init__(self):
        super().__init__()
        defaults = {
            'route_dry_run': True, 'route_calibrated': False,
            'route_front': 0., 'route_rear': 0., 'route_half_width': 0.,
            'route_curvature_gain': 0., 'route_speed_upper': 0.,
            'route_stopping_distance': 0., 'route_margin': .10,
            'route_laser_x': 0., 'route_laser_y': 0., 'route_laser_yaw': 0.,
            'route_odom_rear_x': 0., 'route_odom_rear_y': 0., 'route_odom_rear_yaw': 0.,
            'route_scan_frame': '', 'route_odom_frame': '', 'route_odom_child': '',
            'route_scan_topic': '/scan', 'route_target_radius': .85,
        }
        self.r = {}
        for name, default in defaults.items():
            self.declare_parameter(name, default)
            self.r[name] = self.get_parameter(name).value
        self.dry_run = bool(self.r['route_dry_run'])
        self.calibration_error = ''
        self.model = Model(*(float(self.r['route_'+k]) for k in
                             ('front', 'rear', 'half_width', 'curvature_gain', 'speed_upper',
                              'stopping_distance', 'margin')))
        try:
            self.model.validate()
            if not self.r['route_calibrated']:
                raise ValueError('route_calibrated=false')
            if not all(self.r[k] for k in ('route_scan_frame', 'route_odom_frame', 'route_odom_child')):
                raise ValueError('Exact scan/odom frame names required')
            offsets = [float(self.r['route_'+k]) for k in
                       ('laser_x','laser_y','laser_yaw','odom_rear_x','odom_rear_y','odom_rear_yaw')]
            if not all(math.isfinite(v) for v in offsets):
                raise ValueError('Nonfinite frame offsets')
            radius = float(self.r['route_target_radius'])
            # Circumscribed 280 mm square base + partial-surface centroid error.
            minimum = .20+.12+self.model.half_width+self.model.margin
            if not math.isfinite(radius) or not minimum <= radius <= 1.5:
                raise ValueError('Target radius does not cover body/cone uncertainty')
            if radius < 1./(self.model.curvature_gain*self.model.command_limit):
                raise ValueError('Target radius smaller than calibrated turning radius')
        except ValueError as e:
            self.calibration_error = str(e)
        self.cmd_pub = OutputGate(self.cmd_pub, self.create_publisher(Twist, '/race/route_proposed_cmd', 10), self)
        self.preview_pub = self.create_publisher(String, '/race/planner_status', 10)
        self.tracker = Tracker()
        self.path = None
        self.target_lock = None
        self.used_centers = []
        self.space = None
        self.scan_received = 0.
        self.scan_stamp = 0.
        self.valid_scan_stamp = 0.
        self.odom_frame_ok = False
        self.route_number = 1
        self.route_reason = 'WAIT_SCAN'
        self.last_plan = 0.
        self.wait_since = None
        self.route_finished = False
        self.last_planner_publish = 0.
        self.observed_frames = ''
        self.observed_odom = ''
        self.create_subscription(LaserScan, str(self.r['route_scan_topic']), self.route_scan,
                                 qos_profile_sensor_data)

    def odom_callback(self, msg):
        super().odom_callback(msg)
        if hasattr(self, 'r'):
            self.observed_odom = f'odom_frame={msg.header.frame_id} odom_child={msg.child_frame_id}'
            self.odom_frame_ok = (msg.header.frame_id == self.r['route_odom_frame']
                                  and msg.child_frame_id == self.r['route_odom_child'])

    def rear_pose(self):
        if self.last_odom_xy is None or self.last_yaw is None:
            return None
        p = world((float(self.r['route_odom_rear_x']), float(self.r['route_odom_rear_y'])),
                  (*self.last_odom_xy, self.last_yaw))
        return (*p, self.last_yaw+float(self.r['route_odom_rear_yaw']))

    def route_scan(self, msg):
        now = time.monotonic()
        self.observed_frames = f'scan_frame={msg.header.frame_id} odom_match={self.odom_frame_ok}'
        pose = self.rear_pose()
        stamp = msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
        self.space = None
        if (self.calibration_error or pose is None or not self.odom_frame_ok
                or msg.header.frame_id != self.r['route_scan_frame']
                or stamp <= self.scan_stamp or abs(stamp-getattr(self, 'last_motion_stamp', 0)) > .15
                or now-self.last_odom_time > .15
                or not all(math.isfinite(v) for v in (stamp, msg.angle_min, msg.angle_increment,
                                                       msg.range_min, msg.range_max))
                or msg.angle_increment == 0 or msg.range_max <= msg.range_min):
            self.route_reason = 'SCAN_OR_FRAME_NOT_READY'
            return
        self.scan_stamp = stamp
        xy = world((float(self.r['route_laser_x']), float(self.r['route_laser_y'])), pose)
        laser = (*xy, pose[2]+float(self.r['route_laser_yaw']))
        self.space = ScanSpace(list(msg.ranges), msg.angle_min, msg.angle_increment,
                               msg.range_min, msg.range_max, laser, pose, self.model)
        points = candidates(msg.ranges, msg.angle_min, msg.angle_increment, msg.range_min, msg.range_max)
        # Remove only points inside the actual measured body, not a blind 30cm disc.
        points = [world(p, laser) for p in points]
        points = [p for p in points if not (-self.model.rear <= local(p, pose)[0] <= self.model.front
                                           and abs(local(p, pose)[1]) <= self.model.half_width)]
        self.tracker.update(points, now)
        self.scan_received = now

    def update_phase(self, now):
        # Obstacle phases are advanced only by the route planner, never by 60/150deg.
        if self.phase in (self.SEEK_CONE_1, self.ENTER_OBSTACLES, self.ORBIT_CONE_1,
                          self.SEEK_CONE_2, self.ORBIT_CONE_2, self.CROSSWALK_EXIT_WAIT, self.TRANSFER_CONES):
            return
        if self.sensors_ready(now) and not self.lidar_emergency:
            super().update_phase(now)
        elif self.phase == self.CROSSWALK_STOP:
            self.still_since = None

    def report(self, reason):
        self.route_reason = reason
        now = time.monotonic()
        if now-self.last_planner_publish < .5:
            return
        self.last_planner_publish = now
        tracks = [(t.id, round(t.xy[0], 3), round(t.xy[1], 3), t.hits,
                   round(now-t.seen, 3)) for t in self.tracker.tracks]
        m = String()
        m.data = (f'dry_run={self.dry_run} phase={self.phase} reason={reason} '
                  f'calibration={self.calibration_error or "OK"} '
                  f'target={self.path.id if self.path else -1} '
                  f'route_mode={getattr(self.path,"mode","NONE")} '
                  f'progress={self.path.progress if self.path else 0:.3f} tracks={tracks}')
        m.data += ' '+self.observed_frames
        m.data += ' '+self.observed_odom
        self.preview_pub.publish(m)
        self.get_logger().info(m.data, throttle_duration_sec=1.)

    def hold(self, reason):
        self.publish_stop()
        self.report(reason)
        if self.wait_since is None:
            self.wait_since = time.monotonic()
        elif time.monotonic()-self.wait_since > 5 and not self.dry_run and not self.route_finished:
            self.fail_route('PLANNER_HOLD_TIMEOUT_'+reason)

    def route_tick(self, now):
        if self.route_finished:
            self.hold('TEST_COMPLETE_TWO_CONES_NOT_FULL_RACE')
            return
        if self.calibration_error:
            self.hold('CALIBRATION_REQUIRED')
            return
        if not self.sensors_ready(now) or self.lidar_emergency:
            # Do not advance route progress during emergency or stale data.
            if self.path and self.rear_pose():
                p = self.rear_pose()
                self.path.last_pose = p
                self.path.last_bearing = math.atan2(p[1]-self.path.center[1], p[0]-self.path.center[0])
            self.hold('LIDAR_EMERGENCY' if self.lidar_emergency else 'SENSOR_WAIT')
            return
        if self.space is None or now-self.scan_received > .20:
            self.hold('FRESH_SYNCHRONIZED_SCAN_REQUIRED')
            return
        if self.valid_scan_stamp == self.scan_stamp:
            return  # no extra command or confidence from the same scan
        self.valid_scan_stamp = self.scan_stamp
        pose = self.rear_pose()
        # Scan-space ray origin stays at capture pose, body prediction starts now.
        self.space.body_pose = pose
        if self.route_number == 1 and not self.entry_done:
            if not self.post_crosswalk_clearance_complete():
                if self.travel_distance-self.first_cone_seek_start_distance >= self.post_crosswalk_max_straight_distance:
                    self.hold('EXIT_NOT_CONFIRMED')
                    return
                cmd = self.crosswalk_exit_command()
                p = pose
                k = self.model.curvature_gain*cmd.angular.z/self.steering_sign
                reserve = max(.6, self.model.stopping_distance+self.model.speed_upper*self.model.latency)
                safe = self.space.footprint_free(pose)
                for _ in range(math.ceil(reserve/.05)):
                    p = (p[0]+.05*math.cos(p[2]+k*.025), p[1]+.05*math.sin(p[2]+k*.025), p[2]+k*.05)
                    safe = safe and self.space.footprint_free(p)
                if not safe:
                    self.hold('EXIT_SWEEP_BLOCKED_OR_UNKNOWN')
                    return
                self.wait_since = None
                self.cmd_pub.publish(cmd)
                self.report('EXIT_HEADING_WITH_SWEEP_CHECK')
                return
            self.entry_done = True
            self.set_phase(self.ENTER_OBSTACLES)
        if self.path is None:
            choices = [t for t in self.tracker.tracks if t.hits >= 5 and now-t.seen <= .20
                       and now-t.first >= .3 and .2 < local(t.xy, pose)[0] < 2.5
                       and all(distance(t.xy, p) > .6 for p in self.used_centers)]
            side = 1 if self.route_number == 1 else -1
            choices = [t for t in choices if local(t.xy, pose)[1]*side > -.15]
            choices.sort(key=lambda t: distance(t.xy, pose))
            if not choices or (len(choices)>1 and distance(choices[1].xy, pose)-distance(choices[0].xy, pose)<.35):
                self.hold('TARGET_MISSING_OR_AMBIGUOUS')
                return
            self.path = LinkedOrbitPath(choices[0], pose, side, float(self.r['route_target_radius']))
            self.target_lock = TargetLock(choices[0])
            self.set_phase(self.ORBIT_CONE_1 if self.route_number == 1 else self.ORBIT_CONE_2)
        if self.target_lock is None or not self.target_lock.resolve(self.tracker.tracks,now,self.used_centers):
            self.hold('LOCKED_TARGET_LOST_OR_MOVED')
            return
        self.path.id = self.target_lock.id
        if self.path.mode == 'FIRST' and self.path.next_lock is None:
            # Observe all bearings. Route order comes from the linked geometry,
            # not a requirement that cone 2 already be on the car's right.
            next_choices = [t for t in self.tracker.tracks if t.id != self.path.id
                            and t.hits >= 5 and now-t.seen <= .20 and now-t.first >= .3
                            and .6 < distance(t.xy,self.path.center) < 4.
                            and distance(t.xy,pose) < 3.]
            next_choices.sort(key=lambda t: distance(t.xy,self.path.center))
            if next_choices and (len(next_choices)==1 or
                    distance(next_choices[1].xy,self.path.center)-distance(next_choices[0].xy,self.path.center)>.35):
                if not self.path.connect(next_choices[0]):
                    self.hold('CONE_SPACING_TOO_SMALL_FOR_TANGENT')
                    return
            elif self.path.progress > math.pi+.6:
                self.hold('SECOND_TARGET_MISSING_OR_AMBIGUOUS')
                return
        if self.path.next_lock is not None and self.path.mode != 'SECOND':
            if not self.path.next_lock.resolve(self.tracker.tracks,now,(self.path.first_center,)):
                self.hold('SECOND_TARGET_RECONFIRM_REQUIRED')
                return
        # Freeze landmark anchor for progress measurement; validate it against live tracking.
        try:
            self.path.observe_motion(pose)
        except ValueError:
            self.fail_route('ROUTE_POSE_DISCONTINUITY')
            return
        if self.path.mode == 'TRANSFER':
            self.set_phase(self.TRANSFER_CONES)
        elif self.path.mode == 'SECOND' and self.route_number == 1:
            self.used_centers.append(self.path.first_center)
            self.target_lock = self.path.next_lock
            self.route_number = 2
            self.set_phase(self.ORBIT_CONE_2)
        if self.path.progress < -.25:
            self.fail_route('WRONG_ORBIT_DIRECTION')
            return
        if self.path.complete(pose):
            self.publish_stop()
            self.route_finished = True
            self.report('TEST_COMPLETE_TWO_CONES_NOT_FULL_RACE')
            return
        started = time.monotonic()
        result = plan(self.space, self.path, self.last_lane_angular, now-self.last_lane_command_time)
        elapsed = time.monotonic()-started
        if elapsed > .15 or time.monotonic()-self.scan_received > .30:
            self.hold('PLANNER_TOO_SLOW')
            return
        if result is None:
            self.hold('NO_SAFE_FORWARD_ARC')
            return
        self.wait_since = None
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign*result[1]
        self.last_lane_angular, self.last_lane_command_time = result[1], time.monotonic()
        self.cmd_pub.publish(cmd)
        self.report('TRACKED_COLLISION_CHECKED_ARC')

    def control_loop(self):
        if not hasattr(self, 'tracker'):
            return
        if self.phase in (self.SEEK_CONE_1, self.ENTER_OBSTACLES, self.ORBIT_CONE_1,
                          self.SEEK_CONE_2, self.ORBIT_CONE_2, self.CROSSWALK_EXIT_WAIT, self.TRANSFER_CONES):
            self.route_tick(time.monotonic())
        else:
            super().control_loop()
            self.report('CALIBRATION_REQUIRED' if self.calibration_error else self.phase)


def main(args=None):
    rclpy.init(args=args)
    node = RouteController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.publish_stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
