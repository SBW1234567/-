#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ICAN 视觉调参测试工具。

这个脚本只用于测试视觉，不参与正式跑车：
1. 直接打开 /dev/video20。
2. 显示原图、红灯 mask、绿灯 mask、人行道 mask。
3. 用滑块现场调整 HSV 阈值和面积阈值。
4. 在终端打印 red/green/crosswalk 检测结果。

按键：
  q：退出
  p：打印当前所有参数，方便复制回 ican_vision_node.py
"""

import cv2
import numpy as np


CAMERA_INDEX = 20
FRAME_WIDTH = 320
FRAME_HEIGHT = 240


def nothing(_):
    pass


def create_trackbars():
    cv2.namedWindow("tune", cv2.WINDOW_NORMAL)

    # 红灯两个 Hue 区间固定在红色附近，滑块主要调 S/V 和面积。
    cv2.createTrackbar("red_s_min", "tune", 90, 255, nothing)
    cv2.createTrackbar("red_v_min", "tune", 80, 255, nothing)
    cv2.createTrackbar("red_area", "tune", 80, 5000, nothing)

    cv2.createTrackbar("green_h_min", "tune", 35, 180, nothing)
    cv2.createTrackbar("green_h_max", "tune", 90, 180, nothing)
    cv2.createTrackbar("green_s_min", "tune", 70, 255, nothing)
    cv2.createTrackbar("green_v_min", "tune", 70, 255, nothing)
    cv2.createTrackbar("green_area", "tune", 80, 5000, nothing)

    cv2.createTrackbar("white_v_min", "tune", 150, 255, nothing)
    cv2.createTrackbar("white_s_max", "tune", 80, 255, nothing)
    cv2.createTrackbar("stripe_area", "tune", 80, 5000, nothing)
    cv2.createTrackbar("stripe_count", "tune", 2, 8, nothing)


def get_params():
    return {
        "red_s_min": cv2.getTrackbarPos("red_s_min", "tune"),
        "red_v_min": cv2.getTrackbarPos("red_v_min", "tune"),
        "red_area": max(1, cv2.getTrackbarPos("red_area", "tune")),
        "green_h_min": cv2.getTrackbarPos("green_h_min", "tune"),
        "green_h_max": cv2.getTrackbarPos("green_h_max", "tune"),
        "green_s_min": cv2.getTrackbarPos("green_s_min", "tune"),
        "green_v_min": cv2.getTrackbarPos("green_v_min", "tune"),
        "green_area": max(1, cv2.getTrackbarPos("green_area", "tune")),
        "white_v_min": cv2.getTrackbarPos("white_v_min", "tune"),
        "white_s_max": cv2.getTrackbarPos("white_s_max", "tune"),
        "stripe_area": max(1, cv2.getTrackbarPos("stripe_area", "tune")),
        "stripe_count": max(1, cv2.getTrackbarPos("stripe_count", "tune")),
    }


def largest_area(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return 0
    return max(cv2.contourArea(cnt) for cnt in contours)


def detect(frame, params):
    h, w = frame.shape[:2]
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    light_roi = hsv[0:int(h * 0.55), :]
    red_mask1 = cv2.inRange(
        light_roi,
        np.array([0, params["red_s_min"], params["red_v_min"]]),
        np.array([12, 255, 255]),
    )
    red_mask2 = cv2.inRange(
        light_roi,
        np.array([160, params["red_s_min"], params["red_v_min"]]),
        np.array([180, 255, 255]),
    )
    red_mask = red_mask1 | red_mask2

    green_mask = cv2.inRange(
        light_roi,
        np.array([params["green_h_min"], params["green_s_min"], params["green_v_min"]]),
        np.array([params["green_h_max"], 255, 255]),
    )

    kernel_light = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel_light, iterations=1)
    red_mask = cv2.dilate(red_mask, kernel_light, iterations=1)
    green_mask = cv2.morphologyEx(green_mask, cv2.MORPH_OPEN, kernel_light, iterations=1)
    green_mask = cv2.dilate(green_mask, kernel_light, iterations=1)

    red_area = largest_area(red_mask)
    green_area = largest_area(green_mask)
    red = int(red_area >= params["red_area"])
    green = int(green_area >= params["green_area"])
    if red and green:
        if red_area >= green_area:
            green = 0
        else:
            red = 0

    cross_roi = hsv[int(h * 0.45):h, :]
    white_mask = cv2.inRange(
        cross_roi,
        np.array([0, 0, params["white_v_min"]]),
        np.array([180, params["white_s_max"], 255]),
    )
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 3))
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_OPEN, kernel_cross, iterations=1)
    white_mask = cv2.morphologyEx(white_mask, cv2.MORPH_CLOSE, kernel_cross, iterations=2)

    contours, _ = cv2.findContours(white_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    stripe_count = 0
    for cnt in contours:
        x, y, bw, bh = cv2.boundingRect(cnt)
        area = cv2.contourArea(cnt)
        aspect = bw / max(float(bh), 1.0)
        if area >= params["stripe_area"] and aspect > 2.0 and bw > w * 0.12:
            stripe_count += 1
    crosswalk = int(stripe_count >= params["stripe_count"])

    return red, green, crosswalk, red_mask, green_mask, white_mask, red_area, green_area, stripe_count


def print_params(params):
    print("\n===== 当前调参结果 =====")
    for key, value in params.items():
        print(f"{key}: {value}")
    print("========================\n")


def main():
    create_trackbars()
    cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_V4L2)
    if not cap.isOpened():
        cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        raise RuntimeError(f"无法打开 /dev/video{CAMERA_INDEX}")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)

    while True:
        ok, frame = cap.read()
        if not ok:
            print("读取摄像头失败")
            continue
        frame = cv2.resize(frame, (FRAME_WIDTH, FRAME_HEIGHT), interpolation=cv2.INTER_AREA)

        params = get_params()
        red, green, crosswalk, red_mask, green_mask, white_mask, red_area, green_area, stripe_count = detect(frame, params)

        debug = frame.copy()
        cv2.putText(debug, f"red={red} area={red_area:.0f}", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        cv2.putText(debug, f"green={green} area={green_area:.0f}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        cv2.putText(debug, f"crosswalk={crosswalk} stripes={stripe_count}", (10, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        cv2.imshow("camera", debug)
        cv2.imshow("red_mask", red_mask)
        cv2.imshow("green_mask", green_mask)
        cv2.imshow("crosswalk_mask", white_mask)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("p"):
            print_params(params)

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
