"""ROS-free experimental 2-D tracking and forward-only local planner.

Distances are metres, poses are rear-axle poses in odom, steering commands are
the existing driver's dimensionless input (NOT a ROS yaw rate).
Unknown laser rays are never promoted to free space. Not a certified planner.
"""
import math
import time
from dataclasses import dataclass


def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


def world(p, pose):
    x, y, a = pose
    return (x + math.cos(a)*p[0] - math.sin(a)*p[1],
            y + math.sin(a)*p[0] + math.cos(a)*p[1])


def local(p, pose):
    x, y, a = pose
    return (math.cos(a)*(p[0]-x) + math.sin(a)*(p[1]-y),
            -math.sin(a)*(p[0]-x) + math.cos(a)*(p[1]-y))


def distance(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


@dataclass
class Track:
    id: int
    xy: tuple
    hits: int
    first: float
    seen: float


class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1

    def update(self, points, now):
        self.tracks = [t for t in self.tracks if now-t.seen <= 1.0]
        pairs = sorted((distance(t.xy, p), i, j)
                       for i, t in enumerate(self.tracks) for j, p in enumerate(points))
        used_t, used_p = set(), set()
        for d, i, j in pairs:
            if d > .22 or i in used_t or j in used_p:
                continue
            t, p = self.tracks[i], points[j]
            # Do not count repeated timestamps as independent observations.
            if now > t.seen:
                t.hits = t.hits+1 if now-t.seen <= .35 else 1
                t.xy = (.65*t.xy[0]+.35*p[0], .65*t.xy[1]+.35*p[1])
                t.seen = now
            used_t.add(i)
            used_p.add(j)
        for j, p in enumerate(points):
            if j not in used_p:
                self.tracks.append(Track(self.next_id, p, 1, now, now))
                self.next_id += 1
        return self.tracks


def candidates(ranges, amin, inc, rmin, rmax):
    """Adjacent-beam clusters; retain all bearings for persistent side tracking.

    Long clusters are walls/large obstacles, never cone candidates. Small wall
    fragments remain ambiguous; this is intentionally geometric, not semantic.
    """
    clusters, current = [], []
    for i, r in enumerate(ranges):
        if math.isfinite(r) and max(.05, rmin) <= r <= min(3., rmax):
            p = (r*math.cos(amin+i*inc), r*math.sin(amin+i*inc))
            gap = min(.14, .04+2.0*r*abs(inc))
            if current and distance(p, current[-1]) > gap:
                clusters.append(current)
                current = []
            current.append(p)
        else:
            if current:
                clusters.append(current)
                current = []
    if current:
        clusters.append(current)
    if (len(clusters) > 1 and abs(abs(inc)*len(ranges)-2*math.pi) < .05
            and distance(clusters[-1][-1], clusters[0][0]) < .10):
        clusters[0] = clusters.pop()+clusters[0]
    result = []
    for cluster in clusters:
        if len(cluster) < 4:
            continue
        width = max(distance(p, cluster[0]) for p in cluster)
        if not .10 <= width <= .32:
            continue
        result.append((sum(p[0] for p in cluster)/len(cluster),
                       sum(p[1] for p in cluster)/len(cluster)))
    return result


@dataclass
class Model:
    front: float       # rear axle to foremost body point
    rear: float        # rear axle to rearmost body point
    half_width: float
    curvature_gain: float   # measured curvature per driver steering input
    speed_upper: float      # measured conservative m/s upper bound at drive command
    stopping_distance: float
    margin: float = .10
    command_limit: float = .22
    slew: float = .55
    latency: float = .25

    def validate(self):
        values = tuple(vars(self).values())
        if not all(math.isfinite(v) and v > 0 for v in values):
            raise ValueError('All vehicle calibration values must be finite and positive')
        if not (.1 < self.front < 1.5 and self.rear < 1 and .05 < self.half_width < .6
                and self.command_limit <= .45 and self.speed_upper < 3
                and self.curvature_gain < 30 and self.margin >= .05):
            raise ValueError('Vehicle calibration outside supported bounds')


class ScanSpace:
    def __init__(self, ranges, amin, inc, rmin, rmax, laser_pose, body_pose, model):
        self.ranges, self.amin, self.inc = ranges, amin, inc
        self.rmin, self.rmax = rmin, rmax
        self.laser_pose, self.body_pose, self.model = laser_pose, body_pose, model

    def free(self, p):
        m = self.model
        q = local(p, self.body_pose)
        # Only the occupied initial body is known free, not its margin.
        if -m.rear <= q[0] <= m.front and abs(q[1]) <= m.half_width:
            return True
        q = local(p, self.laser_pose)
        r = math.hypot(*q)
        a = math.atan2(q[1], q[0])
        if not self.inc or not self.ranges or r < self.rmin:
            return False
        count = len(self.ranges)
        period = round(2*math.pi/abs(self.inc))
        if period >= 3 and count in (period,period+1):
            i = round((a-self.amin)/self.inc) % period
            rays = [self.ranges[(i+j) % period] for j in (-1,0,1)]
        else:
            indexes = [(a+turn*2*math.pi-self.amin)/self.inc for turn in (-1, 0, 1)]
            indexes = [i for i in indexes if 1 <= i < count-2]
            if not indexes:
                return False
            i = round(indexes[0])
            rays = self.ranges[i-1:i+2]
        # Infinity/NaN may mean no return or invalid; conservative until verified.
        return all(math.isfinite(v) and self.rmin <= v <= self.rmax and r+.03 < v
                   for v in rays)

    def footprint_free(self, pose):
        m = self.model
        # Interior grid as well as edges detects a point obstacle inside the body.
        extra = m.margin + m.speed_upper*m.latency
        nx = math.ceil((m.front+m.rear+2*extra)/.08)
        ny = math.ceil((2*m.half_width+2*extra)/.08)
        return all(self.free(world((-m.rear-extra+(m.front+m.rear+2*extra)*i/nx,
                                   -m.half_width-extra+(2*m.half_width+2*extra)*j/ny), pose))
                   for i in range(nx+1) for j in range(ny+1))


class OrbitPath:
    """Ordered half-orbit around a tracked landmark, not vehicle yaw completion.

    First direction +1, second -1. Start bearing is frozen when the target locks.
    Progress is polar displacement of the rear axle around the target; the target
    must also be behind the car before a half orbit can complete.
    """
    def __init__(self, track, pose, direction, radius):
        self.id, self.center = track.id, track.xy
        self.direction, self.radius = direction, radius
        self.last_bearing = math.atan2(pose[1]-self.center[1], pose[0]-self.center[0])
        self.start_bearing = self.last_bearing
        self.progress = 0.
        self.last_pose = pose

    def observe_motion(self, pose):
        b = math.atan2(pose[1]-self.center[1], pose[0]-self.center[0])
        delta = wrap(b-self.last_bearing)*self.direction
        if abs(delta) > .25 or distance(pose, self.last_pose) > .4:
            raise ValueError('Discontinuous route pose')
        self.progress += delta
        self.last_bearing, self.last_pose = b, pose

    def goal(self, pose):
        if self.progress >= math.pi-.35:
            a = self.start_bearing+self.direction*math.pi
            # Leave on a tangent instead of circling indefinitely at x~=0.
            return (self.center[0]+self.radius*math.cos(a)-self.direction*.8*math.sin(a),
                    self.center[1]+self.radius*math.sin(a)+self.direction*.8*math.cos(a))
        b = math.atan2(pose[1]-self.center[1], pose[0]-self.center[0])
        # Look ahead on the correct side; the cone itself is never a waypoint.
        a = b+self.direction*.55
        return (self.center[0]+self.radius*math.cos(a),
                self.center[1]+self.radius*math.sin(a))

    def complete(self, pose):
        return (self.progress >= math.pi-.2 and local(self.center, pose)[0] < -.15
                and distance(pose, self.center) >= self.radius-.1)


class TargetLock:
    """Re-identify only one stable track close to a frozen landmark anchor.

    Three NEW observations are required after an identity change; timer ticks
    cannot add evidence. Ambiguity or a move outside the gate means stop.
    """
    def __init__(self, track):
        self.id, self.center, self.seen = track.id, track.xy, track.seen
        self.pending = None
        self.count = 0
        self.pending_seen = -math.inf

    def resolve(self, tracks, now, excluded=()):
        choices = [t for t in tracks if now-t.seen <= .30
                   and distance(t.xy,self.center) <= .18
                   and all(distance(t.xy,p) > .6 for p in excluded)]
        if len(choices) != 1:
            self.pending, self.count = None, 0
            return False
        t = choices[0]
        if t.id == self.id:
            self.seen = t.seen
            return True
        if now-self.seen > 3.:
            return False
        if t.id != self.pending:
            self.pending, self.count, self.pending_seen = t.id, 0, -math.inf
        if t.seen > self.pending_seen:
            self.count += 1
            self.pending_seen = t.seen
        if self.count < 3 or t.hits < 3:
            return False
        self.id, self.seen = t.id, t.seen
        self.pending, self.count = None, 0
        return True


class LinkedOrbitPath(OrbitPath):
    """CCW first circle -> inner common tangent -> CW second circle.

    Never concludes first orbit solely from accumulated angle. The physical
    tangent gate and heading must be reached before transfer. Geometry that
    cannot fit two disjoint safety circles is rejected, not squeezed through.
    """
    def __init__(self, track, pose, direction, radius):
        super().__init__(track,pose,direction,radius)
        self.mode = 'FIRST'
        self.first_center = self.center
        self.next_lock = None

    def connect(self, track):
        d = distance(self.first_center,track.xy)
        if d <= 2*self.radius+.10:
            return False
        a = math.atan2(track.xy[1]-self.first_center[1],track.xy[0]-self.first_center[0])
        a -= self.direction*math.acos(2*self.radius/d)
        n = (math.cos(a),math.sin(a))
        self.tangent = (-self.direction*n[1],self.direction*n[0])
        self.entry = (self.first_center[0]+self.radius*n[0],self.first_center[1]+self.radius*n[1])
        self.exit = (track.xy[0]-self.radius*n[0],track.xy[1]-self.radius*n[1])
        self.segment_length = distance(self.entry,self.exit)
        self.gate_bearing = a
        self.next_lock = TargetLock(track)
        return True

    def projection(self, pose):
        return ((pose[0]-self.entry[0])*self.tangent[0]
                +(pose[1]-self.entry[1])*self.tangent[1])

    def observe_motion(self, pose):
        if self.mode != 'TRANSFER':
            super().observe_motion(pose)
        else:
            if distance(pose,self.last_pose) > .4:
                raise ValueError('Discontinuous transfer pose')
            self.last_pose = pose
        if self.next_lock is None or self.mode == 'SECOND':
            return
        heading = math.atan2(self.tangent[1],self.tangent[0])
        aligned = abs(wrap(pose[2]-heading)) < .45
        if (self.mode == 'FIRST' and distance(pose,self.entry)<.35
                and self.projection(pose)>=-.10 and aligned):
            self.mode = 'TRANSFER'
        if (self.mode == 'TRANSFER' and self.projection(pose)>=self.segment_length-.10
                and distance(pose,self.exit)<.35 and aligned):
            self.mode = 'SECOND'
            self.center, self.id = self.next_lock.center,self.next_lock.id
            self.direction = -self.direction
            self.progress = 0.
            self.last_bearing = math.atan2(pose[1]-self.center[1],pose[0]-self.center[0])
            self.start_bearing = self.last_bearing

    def goal(self, pose):
        if self.mode == 'SECOND':
            return super().goal(pose)
        b = math.atan2(pose[1]-self.center[1],pose[0]-self.center[0])
        if self.next_lock is None:
            # Observe farther while continuing the required first orbit, not its
            # old premature tangent exit. Controller imposes a progress bound.
            a = b+self.direction*.55
            return (self.center[0]+self.radius*math.cos(a),self.center[1]+self.radius*math.sin(a))
        remaining = wrap(self.gate_bearing-b)*self.direction
        if self.mode == 'TRANSFER' or -.25 <= remaining <= .55:
            s = max(0.,self.projection(pose))+.50
            if s <= self.segment_length:
                return (self.entry[0]+s*self.tangent[0],self.entry[1]+s*self.tangent[1])
            # Look ahead onto second circle to avoid a steering discontinuity.
            a = self.gate_bearing+math.pi-self.direction*(s-self.segment_length)/self.radius
            return (self.next_lock.center[0]+self.radius*math.cos(a),
                    self.next_lock.center[1]+self.radius*math.sin(a))
        a = b+self.direction*.55
        return (self.center[0]+self.radius*math.cos(a),self.center[1]+self.radius*math.sin(a))

    def complete(self, pose):
        return self.mode == 'SECOND' and super().complete(pose)


def plan(space, path, previous, dt):
    """Sample slew-limited driver commands and check their swept footprints.

    Receding-horizon arc preview, not a global solver: no feasible arc => stop.
    Includes stopping-distance reserve. Never uses wall-avoidance sign overrides.
    """
    m, start = space.model, space.body_pose
    if not math.isfinite(dt) or dt < 0:
        return None
    goal = path.goal(start)
    horizon = max(1.0, m.stopping_distance+m.speed_upper*m.latency+.4)
    best = None
    deadline = time.monotonic()+.10
    change = m.slew*min(.15, max(0., dt))
    if not math.isfinite(previous) or abs(previous)>m.command_limit:
        return None  # do not turn a stale/out-of-range input into an overlimit command
    commands = sorted(set(max(previous-change, min(previous+change,
                          -m.command_limit+2*m.command_limit*i/16)) for i in range(17)),
                      key=lambda u: abs(u-previous))
    if not space.footprint_free(start):
        return None
    for u in commands:
        if time.monotonic() > deadline:
            return None
        pose = start
        poses = []
        valid = True
        # Reject current overlap before any forward command.
        for _ in range(math.ceil(horizon/.05)):
            if time.monotonic() > deadline:
                return None
            k = m.curvature_gain*u
            ds = .05
            pose = (pose[0]+ds*math.cos(pose[2]+k*ds/2),
                    pose[1]+ds*math.sin(pose[2]+k*ds/2), wrap(pose[2]+k*ds))
            if (distance(pose, path.center) < path.radius-.12
                    or not space.footprint_free(pose)):
                valid = False
                break
            poses.append(pose)
        if not valid:
            continue
        b0 = math.atan2(start[1]-path.center[1], start[0]-path.center[0])
        b1 = math.atan2(pose[1]-path.center[1], pose[0]-path.center[0])
        advance = wrap(b1-b0)*path.direction
        transfer = getattr(path,'mode','') == 'TRANSFER'
        exiting = getattr(path,'mode','') == 'SECOND' and path.progress >= math.pi-.35
        if not transfer and not exiting and advance < -.02:
            continue
        cost = distance(pose, goal)
        if not transfer and not exiting:
            cost += .7*abs(distance(pose, path.center)-path.radius)
        if exiting:
            heading = path.start_bearing+path.direction*1.5*math.pi
            cost += .8*abs(wrap(pose[2]-heading))
        cost += .2*abs(u-previous)-(0. if exiting else .4*advance)
        if best is None or cost < best[0]:
            best = (cost, u, poses)
    return best
