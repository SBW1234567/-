-- racecar 的 Cartographer 2D SLAM 参数。
--
-- 这个文件决定“小车第一圈建图时如何融合雷达和 IMU”。
-- 当前配置适合实车：乐山雷达 /scan + IMU /IMU_data，不依赖轮速里程计。
-- 如果建图漂移、地图撕裂、车体方向乱跳，优先检查本文件里的 frame、IMU、雷达距离和后端优化参数。

include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,

  -- 地图坐标系。Nav2 的全局地图和路径规划也使用 map。
  map_frame = "map",

  -- Cartographer 用哪个坐标系作为姿态跟踪主体。
  -- 这里用 IMU_link，表示主要利用 IMU 的姿态变化辅助雷达匹配。
  -- 注意大小写必须和 URDF/TF 里发布的 frame_id 完全一致。
  tracking_frame = "IMU_link",

  -- Cartographer 对外发布的小车主体坐标系。
  -- Nav2 通常使用 base_footprint 作为机器人底盘平面坐标系。
  published_frame = "base_footprint",

  -- Cartographer 会维护 map -> odom -> base_footprint 这条 TF 链。
  odom_frame = "odom",

  -- true 表示由 Cartographer 提供 odom 坐标系。
  -- 因为当前方案没有可靠轮速里程计，所以不使用外部 odom。
  provide_odom_frame = true,

  -- 将 3D 姿态投影到 2D 平面，适合平面赛道小车。
  publish_frame_projected_to_2d = true,

  -- 不使用轮速/外部里程计。
  use_odometry = false,
  use_nav_sat = false,
  use_landmarks = false,

  -- 当前只使用一个 2D 激光雷达话题 /scan。
  num_laser_scans = 1,
  num_multi_echo_laser_scans = 0,
  num_subdivisions_per_laser_scan = 1,
  num_point_clouds = 0,

  -- TF 查询超时时间。过小会因为 TF 延迟导致丢数据，过大则问题反馈变慢。
  lookup_transform_timeout_sec = 0.2,

  -- Cartographer 内部 submap、位姿和轨迹发布频率。
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 5e-3,
  trajectory_publish_period_sec = 30e-3,

  -- 采样比例。1.0 表示所有对应传感器数据都参与计算。
  rangefinder_sampling_ratio = 1.,
  odometry_sampling_ratio = 1.,
  fixed_frame_pose_sampling_ratio = 1.,
  imu_sampling_ratio = 1.,
  landmarks_sampling_ratio = 1.,
}

-- 使用 2D SLAM。赛道是平面环境，不需要 3D 建图。
MAP_BUILDER.use_trajectory_builder_2d = true

-- 雷达有效距离范围。
-- min_range 过滤太近的车体反射/噪声；max_range 根据雷达实际量程设置。
TRAJECTORY_BUILDER_2D.min_range = 0.30
TRAJECTORY_BUILDER_2D.max_range = 10.0

-- 当某束激光没有击中障碍物时，Cartographer 假设它扫到这个长度。
TRAJECTORY_BUILDER_2D.missing_data_ray_length = 3.

-- 启用 IMU 融合。若 IMU 坐标系、方向或话题异常，建图会明显漂。
TRAJECTORY_BUILDER_2D.use_imu_data = true

-- 在线相关扫描匹配。
-- 没有轮速里程计时必须依靠雷达前端匹配，否则小车运动估计会不稳。
TRAJECTORY_BUILDER_2D.use_online_correlative_scan_matching = true

-- 运动过滤器角度阈值。设得较小表示很小的转角也会参与建图更新。
TRAJECTORY_BUILDER_2D.motion_filter.max_angle_radians = math.rad(0.1)

-- 关闭 Cartographer 后端全局优化和回环约束搜索。
-- 这套参数更偏向“比赛短时间跑一圈”：降低算力压力，避免回环误匹配把地图拉裂。
-- 如果以后要做完整、可复用地图，可以重新开启 optimize_every_n_nodes 并调回环参数。
POSE_GRAPH.optimize_every_n_nodes = 0
POSE_GRAPH.global_sampling_ratio = 0.0
POSE_GRAPH.constraint_builder.sampling_ratio = 0.0
POSE_GRAPH.constraint_builder.min_score = 0.65
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.7

-- 通过极大的时间阈值基本禁止全局约束搜索。
POSE_GRAPH.global_constraint_search_after_n_seconds = 1e9
POSE_GRAPH.constraint_builder.log_matches = false

return options
