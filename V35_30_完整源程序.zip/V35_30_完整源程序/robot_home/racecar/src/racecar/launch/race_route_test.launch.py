"""Separate opt-in test launch. Original competition launch is unchanged."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    root = get_package_share_directory('racecar')
    params = os.path.join(root, 'config', 'competition_params.yaml')
    route = os.path.join(root, 'config', 'route_planner.yaml')
    return LaunchDescription([
        DeclareLaunchArgument('no_rviz', default_value='true'),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(os.path.join(root, 'launch', 'Run_explorer.launch.py')),
                                 launch_arguments={'no_rviz': LaunchConfiguration('no_rviz'),
                                                   'enable_nav2': 'false', 'enable_race_odom': 'true'}.items()),
        Node(package='racecar', executable='race_route_controller.py', name='race_task_controller',
             output='screen', parameters=[params, route]),
        TimerAction(period=1., actions=[
            Node(package='racecar', executable='race_lidar_guard.py', name='race_lidar_guard', output='screen', parameters=[params]),
            Node(package='racecar', executable='race_track_boundary_node.py', name='race_track_boundary', output='screen', parameters=[params]),
            Node(package='racecar', executable='ican_vision_node.py', name='ican_vision_node', output='screen', parameters=[params]),
        ]),
    ])
