"""国赛整车一键启动：现场SLAM、视觉、雷达边界和分阶段总控制。"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    racecar_dir = get_package_share_directory('racecar')
    params_file = os.path.join(racecar_dir, 'config', 'competition_params.yaml')
    no_rviz = LaunchConfiguration('no_rviz')

    return LaunchDescription([
        DeclareLaunchArgument('entry_v34_enabled', default_value='false'),
        DeclareLaunchArgument('entry_v33_enabled', default_value='false'),
        DeclareLaunchArgument('entry_v32_enabled', default_value='false'),
        DeclareLaunchArgument('lane_parallel_band_enabled', default_value='false'),
        DeclareLaunchArgument('lane_band_min_distance', default_value='0.38'),
        DeclareLaunchArgument('lane_band_max_distance', default_value='0.50'),
        DeclareLaunchArgument('lane_band_target_heading_deg', default_value='1.0'),
        DeclareLaunchArgument('bounded_heading_control', default_value='false'),
        DeclareLaunchArgument('lane_nominal_width', default_value='0.90'),
        DeclareLaunchArgument('lane_heading_gain', default_value='0.45'),
        DeclareLaunchArgument('lane_target_heading_deg', default_value='3.0'),
        DeclareLaunchArgument('lane_cautious_heading_deg', default_value='1.5'),
        DeclareLaunchArgument('lane_straight_drive', default_value='0.35'),
        DeclareLaunchArgument('side_distance_guard_enabled', default_value='true'),
        DeclareLaunchArgument('side_steering_guard_enabled', default_value='true'),
        DeclareLaunchArgument('exit_front_stop_distance', default_value='0.85'),
        DeclareLaunchArgument('entry_open_distance', default_value='0.50'),
        DeclareLaunchArgument('entry_side_margin', default_value='0.10'),
        DeclareLaunchArgument('lidar_yaw_correction_deg', default_value='0.0'),
        DeclareLaunchArgument('steering_midpoint_pwm', default_value='1500.0'),
        DeclareLaunchArgument('startup_center_sec', default_value='3.0'),
        DeclareLaunchArgument('no_rviz', default_value='false'),
        DeclareLaunchArgument('enable_slam', default_value='true'),
        DeclareLaunchArgument('test_stop_after_entry', default_value='false'),
        DeclareLaunchArgument('test_stop_after_exit', default_value='false'),
        DeclareLaunchArgument('dry_run', default_value='false'),
        DeclareLaunchArgument('exit_continuous', default_value='false'),
        DeclareLaunchArgument('relative_route', default_value='false'),
        DeclareLaunchArgument('curve_route', default_value='false'),
        DeclareLaunchArgument('entry_prepare_drive', default_value='0.35'),
        DeclareLaunchArgument('layout_8x4', default_value='false'),
        DeclareLaunchArgument('layout_auto_start', default_value='true'),
        DeclareLaunchArgument('layout_start_x', default_value='-1.0'),
        DeclareLaunchArgument('layout_start_y', default_value='-1.0'),
        DeclareLaunchArgument('layout_start_yaw_deg', default_value='0.0'),
        DeclareLaunchArgument('layout_odom_sign', default_value='0.0'),
        DeclareLaunchArgument('layout_odom_scale', default_value='1.0'),
        DeclareLaunchArgument('layout_rear_extent', default_value='0.18'),
        DeclareLaunchArgument('layout_front_extent', default_value='0.21'),
        DeclareLaunchArgument('layout_half_width', default_value='0.15'),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(racecar_dir, 'launch', 'Run_explorer.launch.py')
            ),
            # 正式比赛由总控直接生成低速指令，禁止 Nav2 recovery spin 抢控制权。
            launch_arguments={
                'no_rviz': no_rviz,
                'lidar_yaw_correction_deg': LaunchConfiguration('lidar_yaw_correction_deg'),
                'enable_nav2': 'false',
                'enable_slam': LaunchConfiguration('enable_slam'),
                'enable_race_odom': 'true',
                'steering_midpoint_pwm': LaunchConfiguration('steering_midpoint_pwm'),
                'startup_center_sec': LaunchConfiguration('startup_center_sec'),
            }.items(),
        ),

        # 总控制先启动，保证 Nav2 后续产生的速度不会绕过比赛状态机。
        Node(
            package='racecar',
            executable='race_task_controller.py',
            name='race_task_controller',
            output='screen',
            parameters=[params_file, {
                'entry_v34_enabled': ParameterValue(LaunchConfiguration('entry_v34_enabled'), value_type=bool),
                'entry_v33_enabled': ParameterValue(LaunchConfiguration('entry_v33_enabled'), value_type=bool),
                'entry_v32_enabled': ParameterValue(LaunchConfiguration('entry_v32_enabled'), value_type=bool),
                'lane_parallel_band_enabled': ParameterValue(LaunchConfiguration('lane_parallel_band_enabled'), value_type=bool),
                'lane_band_min_distance': ParameterValue(LaunchConfiguration('lane_band_min_distance'), value_type=float),
                'lane_band_max_distance': ParameterValue(LaunchConfiguration('lane_band_max_distance'), value_type=float),
                'lane_band_target_heading_deg': ParameterValue(LaunchConfiguration('lane_band_target_heading_deg'), value_type=float),
                'bounded_heading_control': ParameterValue(LaunchConfiguration('bounded_heading_control'), value_type=bool),
                'lane_nominal_width': ParameterValue(LaunchConfiguration('lane_nominal_width'), value_type=float),
                'lane_heading_gain': ParameterValue(LaunchConfiguration('lane_heading_gain'), value_type=float),
                'lane_target_heading_deg': ParameterValue(LaunchConfiguration('lane_target_heading_deg'), value_type=float),
                'lane_cautious_heading_deg': ParameterValue(LaunchConfiguration('lane_cautious_heading_deg'), value_type=float),
                'lane_straight_drive': ParameterValue(LaunchConfiguration('lane_straight_drive'), value_type=float),
                'side_distance_guard_enabled': ParameterValue(LaunchConfiguration('side_distance_guard_enabled'), value_type=bool),
                'side_steering_guard_enabled': ParameterValue(LaunchConfiguration('side_steering_guard_enabled'), value_type=bool),
                'exit_front_stop_distance': ParameterValue(LaunchConfiguration('exit_front_stop_distance'), value_type=float),
                'entry_prepare_drive': ParameterValue(LaunchConfiguration('entry_prepare_drive'), value_type=float),
                'curve_route': ParameterValue(LaunchConfiguration('curve_route'), value_type=bool),
                'relative_route': ParameterValue(LaunchConfiguration('relative_route'), value_type=bool),
                'layout_auto_start': ParameterValue(LaunchConfiguration('layout_auto_start'), value_type=bool),
                'layout_8x4': ParameterValue(LaunchConfiguration('layout_8x4'), value_type=bool),
                'layout_start_x': ParameterValue(LaunchConfiguration('layout_start_x'), value_type=float),
                'layout_start_y': ParameterValue(LaunchConfiguration('layout_start_y'), value_type=float),
                'layout_start_yaw_deg': ParameterValue(LaunchConfiguration('layout_start_yaw_deg'), value_type=float),
                'layout_odom_sign': ParameterValue(LaunchConfiguration('layout_odom_sign'), value_type=float),
                'layout_odom_scale': ParameterValue(LaunchConfiguration('layout_odom_scale'), value_type=float),
                'layout_rear_extent': ParameterValue(LaunchConfiguration('layout_rear_extent'), value_type=float),
                'layout_front_extent': ParameterValue(LaunchConfiguration('layout_front_extent'), value_type=float),
                'layout_half_width': ParameterValue(LaunchConfiguration('layout_half_width'), value_type=float),
                'exit_continuous': ParameterValue(
                LaunchConfiguration('exit_continuous'), value_type=bool),
                'test_stop_after_entry': ParameterValue(
                LaunchConfiguration('test_stop_after_entry'), value_type=bool),
                'test_stop_after_exit': ParameterValue(
                    LaunchConfiguration('test_stop_after_exit'), value_type=bool),
                'dry_run': ParameterValue(LaunchConfiguration('dry_run'), value_type=bool)}],
        ),

        # 被动记录所有控制输入输出，不发布速度，不影响总控。
        Node(
            package='racecar',
            executable='race_control_diagnostic.py',
            name='race_control_diagnostic',
            output='screen',
            parameters=[{'command_topic': ParameterValue(PythonExpression([
                "'/race/proposed_cmd_vel' if '", LaunchConfiguration('dry_run'),
                "'.lower() in ('true', '1') else '/car_cmd_vel'"
            ]), value_type=str)}],
        ),

        TimerAction(
            period=1.0,
            actions=[
                Node(
                    package='racecar',
                    executable='race_lidar_guard.py',
                    name='race_lidar_guard',
                    output='screen',
                    parameters=[params_file, {
                        'entry_v33_enabled': ParameterValue(LaunchConfiguration('entry_v33_enabled'), value_type=bool),
                        'curve_route': ParameterValue(LaunchConfiguration('curve_route'), value_type=bool),
                        'relative_route': ParameterValue(LaunchConfiguration('relative_route'), value_type=bool),
                        'entry_body_rear': ParameterValue(LaunchConfiguration('layout_rear_extent'), value_type=float),
                        'entry_body_front': ParameterValue(LaunchConfiguration('layout_front_extent'), value_type=float),
                        'entry_open_distance': ParameterValue(LaunchConfiguration('entry_open_distance'), value_type=float),
                        'entry_side_margin': ParameterValue(LaunchConfiguration('entry_side_margin'), value_type=float),
                        'entry_body_width': ParameterValue(PythonExpression([
                            '2.0 * ', LaunchConfiguration('layout_half_width')]), value_type=float),
                    }],
                ),
                Node(
                    package='racecar',
                    executable='race_track_boundary_node.py',
                    name='race_track_boundary',
                    output='screen',
                    parameters=[params_file, {'auto_start_localization': ParameterValue(PythonExpression([
                        "'", LaunchConfiguration('layout_8x4'), "'.lower() in ('true','1') and '",
                        LaunchConfiguration('layout_auto_start'), "'.lower() in ('true','1')"]), value_type=bool)}],
                ),
                Node(
                    package='racecar',
                    executable='ican_vision_node.py',
                    name='ican_vision_node',
                    output='screen',
                    parameters=[params_file],
                ),
            ],
        ),

    ])
