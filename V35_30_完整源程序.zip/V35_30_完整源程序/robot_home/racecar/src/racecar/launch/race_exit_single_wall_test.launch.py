"""Bounded departure commissioning; defaults to observing commands only."""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    root = get_package_share_directory('racecar')
    params = os.path.join(root, 'config', 'competition_params.yaml')
    dry = LaunchConfiguration('dry_run')
    command_topic = PythonExpression([
        "'/race/proposed_cmd_vel' if '", dry,
        "'.lower() in ('true', '1') else '/car_cmd_vel'",
    ])
    return LaunchDescription([
        DeclareLaunchArgument('no_rviz', default_value='true'),
        DeclareLaunchArgument('dry_run', default_value='true'),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(root, 'launch', 'Run_explorer.launch.py')),
            launch_arguments={'no_rviz': LaunchConfiguration('no_rviz'),
                              'enable_nav2': 'false', 'enable_race_odom': 'true'}.items()),
        Node(package='racecar', executable='race_task_controller.py',
             name='race_task_controller', output='screen',
             parameters=[params, {'test_stop_after_exit': True,
                                  'test_stop_after_entry': False,
                                  'exit_single_wall_control': True,
                                  'exit_spatial_guard': True,
                                  'dry_run': ParameterValue(dry, value_type=bool)}]),
        Node(package='racecar', executable='race_control_diagnostic.py',
             name='race_control_diagnostic', output='screen',
             parameters=[{'command_topic': ParameterValue(command_topic, value_type=str)}]),
        TimerAction(period=1.0, actions=[
            Node(package='racecar', executable='race_lidar_guard.py', name='race_lidar_guard',
                 output='screen', parameters=[params]),
            Node(package='racecar', executable='race_track_boundary_node.py', name='race_track_boundary',
                 output='screen', parameters=[params]),
            Node(package='racecar', executable='ican_vision_node.py', name='ican_vision_node',
                 output='screen', parameters=[params]),
        ]),
    ])
