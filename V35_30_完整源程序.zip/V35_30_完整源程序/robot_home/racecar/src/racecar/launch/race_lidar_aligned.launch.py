"""Lidar and calibration only. Does not launch the motor/servo driver."""
import math
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import LifecycleNode, Node


def lidar_nodes(context):
    degrees = float(LaunchConfiguration('lidar_yaw_correction_deg').perform(context))
    if not math.isfinite(degrees) or abs(degrees) > 15:
        raise ValueError('lidar_yaw_correction_deg must be finite and within -15..15.')
    config = os.path.join(get_package_share_directory('lslidar_driver'),
                          'params', 'lidar_uart_ros2', 'lsn10.yaml')
    return [
        # Preserve installed device/port settings; override only topic and frame.
        LifecycleNode(package='lslidar_driver', executable='lslidar_driver_node',
                      name='lslidar_driver_node', namespace='', output='screen',
                      emulate_tty=True, parameters=[config, {
                          'scan_topic': '/scan_raw', 'frame_id': 'laser_raw',
                          'pubScan': True, 'pubPointCloud2': False}]),
        Node(package='racecar', executable='race_scan_alignment.py',
             name='race_scan_alignment', output='screen',
             parameters=[{'lidar_yaw_correction_deg': degrees}]),
        # laser_link is a virtual frame at the laser origin, parallel to the body.
        Node(package='tf2_ros', executable='static_transform_publisher',
             name='base_footprint2laser_link',
             arguments=['--x', '0.07', '--y', '0', '--z', '0', '--yaw', '0',
                        '--pitch', '0', '--roll', '0', '--frame-id', 'base_footprint',
                        '--child-frame-id', 'laser_link']),
        # Raw scans are correctly located too. This is not a second rotation of /scan.
        Node(package='tf2_ros', executable='static_transform_publisher',
             name='laser_link2laser_raw',
             arguments=['--x', '0', '--y', '0', '--z', '0',
                        '--yaw', str(math.radians(degrees)), '--pitch', '0', '--roll', '0',
                        '--frame-id', 'laser_link', '--child-frame-id', 'laser_raw']),
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('lidar_yaw_correction_deg', default_value='0.0'),
        OpaqueFunction(function=lidar_nodes),
    ])
