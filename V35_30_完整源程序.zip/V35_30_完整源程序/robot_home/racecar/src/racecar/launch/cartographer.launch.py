"""
Cartographer SLAM 启动文件。

这个 launch 文件负责启动第一圈自主探索/建图需要的两个核心节点：
1. cartographer_node：读取雷达、IMU 和 TF，实时估计小车位姿并生成子地图。
2. cartographer_occupancy_grid_node：把 Cartographer 的子地图转换成 Nav2 能使用的 /map。

比赛流程里，如果要“第一圈边跑边建图并导航”，Run_explorer.launch.py 会间接启动本文件。
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    """生成 ROS2 launch 描述。"""

    # 实车运行时必须使用系统真实时间；只有 Gazebo 仿真才需要改成 true。
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    # racecar 包安装后的 share 目录。
    # Cartographer 的 lua 参数文件会从 share/racecar/config/cartographer 里读取。
    racecar_share = get_package_share_directory('racecar')
    cartographer_config_dir = os.path.join(racecar_share, 'config', 'cartographer')

    # /map 栅格地图分辨率，单位是米/格。
    # 0.05 表示每个格子 5cm，精度较高，但计算量比 0.1 更大。
    resolution = LaunchConfiguration('resolution', default='0.05')

    # occupancy_grid_node 发布 /map 的周期，单位秒。
    # 比赛中一边建图一边导航时，1.0 秒一般够用；如果地图更新慢可适当调小。
    publish_period_sec = LaunchConfiguration('publish_period_sec', default='1.0')

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='是否使用仿真时间。实车为 false，Gazebo 仿真为 true。',
        ),
        DeclareLaunchArgument(
            'resolution',
            default_value='0.05',
            description='Cartographer 输出 OccupancyGrid 地图的分辨率。',
        ),
        DeclareLaunchArgument(
            'publish_period_sec',
            default_value='1.0',
            description='OccupancyGrid 地图发布周期。',
        ),

        # Cartographer 主 SLAM 节点：
        # 输入 /scan、/IMU_data、TF；输出 map->odom 等 TF 和内部 submap。
        Node(
            package='cartographer_ros',
            executable='cartographer_node',
            name='cartographer_node',
            output='log',
            parameters=[{'use_sim_time': use_sim_time}],
            arguments=[
                '-configuration_directory', cartographer_config_dir,
                '-configuration_basename', 'racecar_2d.lua',
            ],
            # Cartographer 默认订阅话题名是 imu，这里映射到车上实际发布的 /IMU_data。
            # 如果以后 IMU 驱动发布的话题名改了，只需要改这里。
            remappings=[
                ('imu', '/IMU_data'),
            ],
        ),

        # 把 Cartographer 的 submap 转成标准 nav_msgs/OccupancyGrid，
        # Nav2 的 global_costmap/static_layer 会订阅这个 /map。
        Node(
            package='cartographer_ros',
            executable='cartographer_occupancy_grid_node',
            name='cartographer_occupancy_grid_node',
            output='log',
            parameters=[{'use_sim_time': use_sim_time}],
            arguments=[
                '-resolution', resolution,
                '-publish_period_sec', publish_period_sec,
            ],
        ),
    ])
