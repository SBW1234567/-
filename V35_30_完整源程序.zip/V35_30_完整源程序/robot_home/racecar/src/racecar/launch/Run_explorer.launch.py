"""
Run_explorer.launch.py
----------------------
racecar 的“在线建图 + 导航”总启动文件。

这个 launch 是 explorer_multi.sh 的底座，负责一次性启动：
  1. 底盘驱动 racecar_driver
  2. joint_state_publisher
  3. LSN10 雷达
  4. IMU
  5. base_footprint 到 laser_link / IMU_link 的静态 TF
  6. Cartographer 在线 SLAM
  7. Nav2 导航
  8. 可选 RViz2

核心数据流：
  /scan + /IMU_data -> Cartographer -> /map + map->odom TF
  /map + /scan + /odom -> Nav2 -> /cmd_vel

TF 链路：
  map -> odom -> base_footprint -> laser_link
                                  -> IMU_link

ICAN/训练使用方式：
  ros2 launch racecar Run_explorer.launch.py
  ros2 launch racecar Run_explorer.launch.py no_rviz:=true

注意：
  这个文件只负责“启动系统底座”，不负责选点、跑圈、红绿灯停车。
  多点跑圈逻辑在 nav2_waypoint_cycle/waypoint_cycle.py 中。
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.actions import Node
import launch_ros.actions


def generate_launch_description():
    # use_sim_time=false 表示使用实车真实时间。
    # 仿真/Gazebo 才通常设置为 true。
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    enable_slam = LaunchConfiguration('enable_slam')
    enable_nav2 = LaunchConfiguration('enable_nav2')
    enable_race_odom = LaunchConfiguration('enable_race_odom')

    # racecar_dir 是 racecar 包安装后的 share 目录。
    # launch/config/rviz 等文件都从这里拼路径。
    racecar_dir = get_package_share_directory('racecar')
    launch_dir = os.path.join(racecar_dir, 'launch')

    # 雷达和 IMU 是独立 ROS2 包，通过 IncludeLaunchDescription 拉起来。
    lslidar_driver_share_dir = get_package_share_directory('lslidar_driver')
    imu_launch_share_dir = get_package_share_directory('imu_get')

    # Nav2 参数文件：Cartographer 模式专用。
    # 这里不使用 AMCL，因为定位由 Cartographer 在线 SLAM 提供。
    nav_carto_param = os.path.join(racecar_dir, 'config', 'nav_carto.yaml')

    # RViz2 显示配置，主要用于看 /map、TF、costmap、路径和机器人位姿。
    rviz_config_dir = os.path.join(racecar_dir, 'rviz', 'racecar_cartographer.rviz')

    return LaunchDescription([
        DeclareLaunchArgument('lidar_yaw_correction_deg', default_value='0.0'),
        DeclareLaunchArgument('steering_midpoint_pwm', default_value='1500.0'),
        DeclareLaunchArgument('startup_center_sec', default_value='3.0'),
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation clock if true',
        ),
        DeclareLaunchArgument(
            'enable_slam',
            default_value='true',
            description='Start Cartographer; V27 race entry disables the unused global SLAM.',
        ),
        DeclareLaunchArgument(
            'enable_nav2',
            default_value='true',
            description='Start Nav2. Formal race state-machine mode sets this false.',
        ),
        DeclareLaunchArgument(
            'enable_race_odom',
            default_value='false',
            description='Publish /odom_rf2o for the formal race state machine.',
        ),

        # ==========================================
        # 第一层：底盘驱动 + 传感器
        # ==========================================

        # 底盘驱动节点。
        # 它负责和下位机/串口通信，最终把速度指令转换成车的运动。
        Node(
            package='racecar_driver',
            executable='racecar_driver_node',
            name='racecar_driver',
            output='screen',
            parameters=[{
                'steering_midpoint_pwm': ParameterValue(LaunchConfiguration('steering_midpoint_pwm'), value_type=float),
                'startup_center_sec': ParameterValue(LaunchConfiguration('startup_center_sec'), value_type=float),
            }],
        ),

        # 发布关节状态，主要给 robot_state / RViz 使用。
        # 对实际导航不是最核心，但保留有助于可视化。
        launch_ros.actions.Node(
            package='joint_state_publisher',
            executable='joint_state_publisher',
            name='joint_state_publisher',
        ),

        # LSN10 雷达驱动。输出通常是 /scan。
        # Nav2 和 Cartographer 都依赖 /scan。
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(launch_dir, 'race_lidar_aligned.launch.py')
            ),
            launch_arguments={'lidar_yaw_correction_deg': LaunchConfiguration('lidar_yaw_correction_deg')}.items(),
        ),

        # 正式比赛总控需要连续里程计来计算绕锥角度和终点行驶距离。
        # Cartographer 提供 odom TF，但不发布 nav_msgs/Odometry 话题，因此这里
        # RF2O uses the equivalent symmetric /race/scan_rf2o view and its TF.
        # 关闭其里程计 TF，避免与
        # Cartographer 发布的 odom -> base_footprint 发生冲突。
        Node(
            package='rf2o_laser_odometry',
            executable='rf2o_laser_odometry_node',
            name='race_rf2o_laser_odometry',
            output='screen',
            condition=IfCondition(enable_race_odom),
            parameters=[{
                'laser_scan_topic': '/race/scan_rf2o',
                'odom_topic': '/odom_rf2o',
                'publish_tf': False,
                'base_frame_id': 'base_footprint',
                'odom_frame_id': 'odom',
                'init_pose_from_topic': '',
                'freq': 20.0,
            }],
        ),

        # IMU 驱动。当前 Cartographer 配置会把 /IMU_data remap 到 /imu 使用。
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(imu_launch_share_dir, 'launch', 'imu_get.launch.py')
            )
        ),

        # Laser TF is published once by race_lidar_aligned.launch.py.

        # 静态 TF：base_footprint -> IMU_link。
        # x=0.1653 表示 IMU 相对车体中心向前 0.1653 m。
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_footprint2imu_link',
            arguments=['0.1653', '0.0', '0.0', '0.0', '0.0', '0.0',
                       'base_footprint', 'IMU_link'],
        ),

        # ==========================================
        # 第二层：Cartographer 在线 SLAM
        # ==========================================
        # 延迟启动是为了等雷达和 IMU 先发布数据。
        # 如果 Cartographer 太早启动，可能出现等待话题或 TF 的警告。
        TimerAction(
            period=2.0,
            condition=IfCondition(enable_slam),
            actions=[
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(
                        os.path.join(launch_dir, 'cartographer.launch.py')
                    ),
                    launch_arguments={'use_sim_time': use_sim_time}.items(),
                ),
            ],
        ),

        # ==========================================
        # 第三层：Nav2 导航栈
        # ==========================================
        # 使用 navigation_no_smoother.launch.py：
        #   去掉 smoother_server，降低实车生命周期切换出错概率。
        # 使用 nav_carto.yaml：
        #   全局地图来自 Cartographer 的 /map，定位不走 AMCL。
        # 延迟启动是为了等 /map、map->odom TF 初步可用。
        TimerAction(
            period=3.0,
            condition=IfCondition(enable_nav2),
            actions=[
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(
                        os.path.join(launch_dir, 'navigation_no_smoother.launch.py')
                    ),
                    launch_arguments={
                        'use_sim_time': use_sim_time,
                        'params_file': nav_carto_param,
                        'use_composition': 'False',
                        'autostart': 'True',
                    }.items(),
                ),
            ],
        ),

        # ==========================================
        # RViz2 可视化
        # ==========================================
        # 默认启动 RViz，方便训练时看地图和点目标。
        # explorer_multi.sh --no-rviz 会传入 no_rviz:=true 禁用它。
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_dir],
            parameters=[{'use_sim_time': use_sim_time}],
            output='log',
            condition=UnlessCondition(LaunchConfiguration('no_rviz', default='false')),
        ),
    ])
