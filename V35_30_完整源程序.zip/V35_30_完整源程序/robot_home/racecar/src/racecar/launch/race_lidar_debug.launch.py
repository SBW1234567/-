"""只启动 N10、雷达过滤节点和 RViz，供静止状态检查自车反射。"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    racecar_dir = get_package_share_directory('racecar')
    lidar_dir = get_package_share_directory('lslidar_driver')
    params = os.path.join(racecar_dir, 'config', 'competition_params.yaml')
    rviz_config = os.path.join(racecar_dir, 'rviz', 'race_lidar_debug.rviz')

    return LaunchDescription([
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(lidar_dir, 'launch', 'lsn10_launch.py')
            )
        ),
        Node(
            package='racecar',
            executable='race_lidar_guard.py',
            name='race_lidar_guard',
            parameters=[params],
            output='screen',
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            name='race_lidar_debug_rviz',
            arguments=['-d', rviz_config],
            output='screen',
        ),
    ])
