#!/bin/bash
#
# explorer_multi.sh
# -----------------
# 训练模式一键启动脚本。
#
# 这个脚本是目前“跑一圈训练”的主入口：
#   1. 启动 racecar 的 Run_explorer.launch.py
#      - 底盘驱动
#      - 雷达
#      - IMU
#      - Cartographer 在线建图
#      - Nav2 导航
#      - 可选 RViz2
#   2. 等 Nav2 基本启动完成后，再启动 nav2_waypoint_cycle
#      - 在 RViz 中点多个路径点
#      - 终端按 r 后开始依次导航
#      - --no-loop 时跑完一圈就停止
#
# 常用命令：
#   bash explorer_multi.sh --no-loop
#       推荐训练命令：启动 RViz，多点导航只执行一次。
#
#   bash explorer_multi.sh --no-rviz --no-loop
#       车上不启动 RViz，适合在远程电脑上开 RViz 观察。
#
#   bash explorer_multi.sh --save-map --no-loop
#       Ctrl+C 退出时保存 Cartographer 地图。
#
# waypoint_cycle 终端快捷键：
#   r：开始执行已经选好的多点导航
#   c：清除所有点 / 停止当前导航
#   f：保存当前地图
#
# 注意：
#   这个脚本适合训练和调试；正式比赛如果不能人工点点，需要在
#   waypoint_cycle.py 基础上改成“自动生成目标点”的比赛节点。

Run_explorer=""
SAVE_MAP=false
NO_RVIZ=false
NO_LOOP=false

# 解析命令行参数。这里只用简单开关，方便比赛现场少敲命令。
for arg in "$@"; do
    if [ "$arg" = "--save-map" ]; then
        SAVE_MAP=true
    elif [ "$arg" = "--no-rviz" ]; then
        NO_RVIZ=true
    elif [ "$arg" = "--no-loop" ]; then
        NO_LOOP=true
    fi
done

terminate() {
    echo ""
    echo "========================================"
    echo "  正在终止 Cartographer/Nav2 训练模式..."
    echo "========================================"

    # 如果启动时带了 --save-map，就在退出前保存当前在线建出的地图。
    # 同时保存 pbstream 和 pgm/yaml：
    #   pbstream：Cartographer 可继续使用的内部状态
    #   pgm/yaml：Nav2 map_server 可直接加载的栅格地图
    if [ "$SAVE_MAP" = true ]; then
        echo "正在保存地图..."
        WORKSPACE_DIR=$(cd "$(dirname "$0")" && pwd)
        MAP_DIR="$WORKSPACE_DIR/src/racecar/map"
        TIMESTAMP=$(date +%Y%m%d_%H%M%S)
        MAP_NAME="carto_map_${TIMESTAMP}"

        ros2 service call /finish_trajectory cartographer_ros_msgs/srv/FinishTrajectory "{trajectory_id: 0}" 2>/dev/null
        sleep 1
        ros2 service call /write_state cartographer_ros_msgs/srv/WriteState "{filename: '${MAP_DIR}/${MAP_NAME}.pbstream'}" 2>/dev/null
        sleep 1

        ros2 run nav2_map_server map_saver_cli -f "${MAP_DIR}/${MAP_NAME}" --ros-args -p save_map_timeout:=5.0 2>/dev/null
        echo "地图已保存到: ${MAP_DIR}/${MAP_NAME}"
    fi

    # Run_explorer.launch.py 是后台启动的；退出脚本时要一起杀掉，
    # 避免下次再启动时出现重复节点、重复 TF、话题冲突。
    if [ -n "$Run_explorer" ] && kill -0 "$Run_explorer" 2>/dev/null; then
        kill "$Run_explorer"
        wait "$Run_explorer" 2>/dev/null
    fi
    echo "所有进程已终止。"
    exit 0
}

# 捕获 Ctrl+C 和系统终止信号，统一走 terminate，保证能清理后台进程。
trap terminate SIGINT SIGTERM

# 获取脚本所在目录。车上通常是 ~/workspace/racecar。
WORKSPACE_DIR=$(cd "$(dirname "$0")" && pwd)

# 兼容 Humble/Foxy 两种 ROS2 环境。当前工程主要按 Humble 使用。
if [ -f "/opt/bros/humble/setup.bash" ]; then
    source /opt/bros/humble/setup.bash
elif [ -f "/opt/ros/humble/setup.bash" ]; then
    source /opt/ros/humble/setup.bash
elif [ -f "/opt/ros/foxy/setup.bash" ]; then
    source /opt/ros/foxy/setup.bash
else
    echo "未找到 ROS2 环境：/opt/bros/humble、/opt/ros/humble、/opt/ros/foxy"
    exit 1
fi

# 加载当前工作空间编译后的 install 环境，否则 ros2 找不到 racecar 包。
if [ -f "$WORKSPACE_DIR/install/setup.bash" ]; then
    source "$WORKSPACE_DIR/install/setup.bash"
fi

# 注意：
# 不要在远程车上随便设置 FASTRTPS_DEFAULT_PROFILES_FILE。
# 这个脚本默认使用 DDS 组播发现本机节点；远程 RViz 可以单独配置 peer。
echo "========================================"
echo "  racecar Cartographer + Nav2 多点导航训练模式"
echo "========================================"
echo "  快捷键: r=开始  c=清除/停止  f=保存地图"
echo "  RViz2: $([ "$NO_RVIZ" = false ] && echo "启用" || echo "禁用")"
echo "  循环:  $([ "$NO_LOOP" = true ] && echo "关闭，跑完一遍停止" || echo "开启，跑完后从头继续")"
echo "========================================"
echo ""

# 第一阶段：启动底盘、传感器、Cartographer、Nav2。
# --no-rviz 时把 no_rviz:=true 传给 Run_explorer.launch.py。
if [ "$NO_RVIZ" = true ]; then
    ros2 launch racecar Run_explorer.launch.py no_rviz:=true &
else
    ros2 launch racecar Run_explorer.launch.py &
fi
Run_explorer=$!

# 第二阶段：等待 Nav2 生命周期节点初始化。
# 如果车上启动慢，可以把 8 改大，例如 12 或 15。
echo "等待 Nav2 就绪..."
sleep 8

# 第三阶段：启动多点导航节点。
# 这里前台运行是故意的：waypoint_cycle.py 需要从终端读取 r/c/f 快捷键。
if [ "$NO_LOOP" = true ]; then
    echo "启动多点导航节点：单次模式，跑完最后一个点后停止。"
    ros2 run nav2_waypoint_cycle nav2_waypoint_cycle --ros-args -p enable_loop:=false
else
    echo "启动多点导航节点：循环模式，跑完后回到第一个点。"
    ros2 run nav2_waypoint_cycle nav2_waypoint_cycle --ros-args -p enable_loop:=true
fi
