#!/bin/bash

MAP_DIR="/home/bianbu/racecar/src/racecar/map"
MAP_NAME="test_map"

mkdir -p "$MAP_DIR"

echo "正在保存地图到：$MAP_DIR/$MAP_NAME"

ros2 run nav2_map_server map_saver_cli \
-f "$MAP_DIR/$MAP_NAME" \
--ros-args \
-p save_map_timeout:=30.0 \
-p map_subscribe_transient_local:=true

if [ $? -eq 0 ]; then
    echo "地图保存成功："
    echo "$MAP_DIR/$MAP_NAME.yaml"
    echo "$MAP_DIR/$MAP_NAME.pgm"
else
    echo "地图保存失败，请确认 /map 话题正在发布。"
fi