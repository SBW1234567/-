#!/bin/bash
# 国赛正式运行唯一入口。现场建图并自动生成局部目标，不读取预存地图或 CSV 路点。

WORKSPACE_DIR=$(cd "$(dirname "$0")" && pwd)

if [ -f "/opt/bros/humble/setup.bash" ]; then
    source /opt/bros/humble/setup.bash
elif [ -f "/opt/ros/humble/setup.bash" ]; then
    source /opt/ros/humble/setup.bash
elif [ -f "/opt/ros/foxy/setup.bash" ]; then
    source /opt/ros/foxy/setup.bash
else
    echo "未找到 ROS2 环境：/opt/bros/humble、/opt/ros/humble、/opt/ros/foxy"
    exit 1
fi

if [ ! -f "$WORKSPACE_DIR/install/setup.bash" ]; then
    echo "未找到 install/setup.bash，请先在 $WORKSPACE_DIR 执行 colcon build --packages-select racecar"
    exit 1
fi

source "$WORKSPACE_DIR/install/setup.bash"

echo "========================================"
echo "  国赛单圈任务启动"
echo "  现场SLAM + 视觉 + 雷达边界 + 分阶段总控制"
echo "========================================"

exec ros2 launch racecar race_competition.launch.py "$@"
