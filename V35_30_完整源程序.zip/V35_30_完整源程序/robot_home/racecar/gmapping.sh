#!/bin/bash

run_car_pid=""
slam_gmapping_pid=""
rviz_pid=""

# Ctrl+C 时终止所有后台进程
terminate() {
  echo ""
  echo "终止所有后台进程..."

  if [ -n "$rviz_pid" ] && kill -0 "$rviz_pid" 2>/dev/null; then
    kill "$rviz_pid"
  fi

  if [ -n "$slam_gmapping_pid" ] && kill -0 "$slam_gmapping_pid" 2>/dev/null; then
    kill "$slam_gmapping_pid"
  fi

  if [ -n "$run_car_pid" ] && kill -0 "$run_car_pid" 2>/dev/null; then
    kill "$run_car_pid"
  fi

  wait "$rviz_pid" "$slam_gmapping_pid" "$run_car_pid" 2>/dev/null

  echo "所有进程已终止。"
  exit 0
}

trap terminate SIGINT SIGTERM

# 配置 ROS 2 环境
source /opt/ros/humble/setup.bash
source /home/bianbu/racecar/install/setup.bash

# 启动小车底盘、雷达等节点
echo "启动 ROS 2 launch 文件：Run_car.launch.py"
ros2 launch racecar Run_car.launch.py &
run_car_pid=$!

# 等待底盘和雷达节点启动
sleep 5

# 启动 Gmapping 建图
echo "启动 slam_gmapping 节点"
ros2 launch slam_gmapping slam_gmapping.launch.py &
slam_gmapping_pid=$!

# 等待 /map、TF 等数据建立
sleep 3

# 启动 RViz2
echo "启动 RViz2"
rviz2 &
rviz_pid=$!

echo "所有节点已启动"

# 等待后台进程
wait "$run_car_pid" "$slam_gmapping_pid" "$rviz_pid"