#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SAVE_MAP=false
NO_RVIZ=false
for arg in "$@"; do
  case "$arg" in
    --save-map) SAVE_MAP=true ;;
    --no-rviz) NO_RVIZ=true ;;
    *) echo "Usage: $0 [--save-map] [--no-rviz]" >&2; exit 2 ;;
  esac
done

set +u
if [[ -f /opt/bros/humble/setup.bash ]]; then source /opt/bros/humble/setup.bash
set +u
elif [[ -f /opt/ros/humble/setup.bash ]]; then source /opt/ros/humble/setup.bash
elif [[ -f /opt/ros/foxy/setup.bash ]]; then source /opt/ros/foxy/setup.bash
else echo "ROS2 setup not found" >&2; exit 1; fi
source "$WORKSPACE_DIR/install/setup.bash"

MAP_DIR="$WORKSPACE_DIR/src/racecar/map"
mkdir -p "$MAP_DIR"
LAUNCH_ARGS=("/home/bianbu/racecar/tools/mapping_teleop.launch.py" "lidar_yaw_correction_deg:=-3.0" "steering_midpoint_pwm:=1500.0" "startup_center_sec:=3.0")
if [[ "$NO_RVIZ" == true ]]; then LAUNCH_ARGS+=("no_rviz:=true"); fi

cleanup() {
  set +e
  printf '\nStopping teleop and saving map...\n'
  ros2 topic pub --once /teleop_cmd_vel geometry_msgs/msg/Twist "{linear: {x: 1500.0}, angular: {z: 90.0}}" >/dev/null 2>&1
  if [[ "$SAVE_MAP" == true ]]; then
    stamp=$(date +%Y%m%d_%H%M%S)
    base="$MAP_DIR/teleop_map_${stamp}"
    ros2 run nav2_map_server map_saver_cli -f "$base" --ros-args -p save_map_timeout:=30.0
    ros2 service call /finish_trajectory cartographer_ros_msgs/srv/FinishTrajectory "{trajectory_id: 0}" >/dev/null 2>&1
    sleep 1
    ros2 service call /write_state cartographer_ros_msgs/srv/WriteState "{filename: '$base.pbstream', include_unfinished_submaps: true}" >/dev/null 2>&1
    echo "saved map files: $base.pgm $base.yaml $base.pbstream"
  fi
  [[ -n "${LAUNCH_PID:-}" ]] && kill "$LAUNCH_PID" 2>/dev/null
}
trap cleanup EXIT INT TERM

echo "Starting mapping only: driver raw_teleop_mode=true, Nav2/waypoint_cycle disabled"
ros2 launch "${LAUNCH_ARGS[@]}" &
LAUNCH_PID=$!
sleep 5

echo "Checking ROS graph before enabling motion..."
ros2 topic info /teleop_cmd_vel -v | sed -n '1,18p'
ros2 topic hz /scan --window 5 >/tmp/mapping_scan_hz.$$ 2>&1 &
HZ_PID=$!
sleep 2
kill "$HZ_PID" 2>/dev/null
cat /tmp/mapping_scan_hz.$$ 2>/dev/null || true
rm -f /tmp/mapping_scan_hz.$$

echo "Starting the car's existing racecar_teleop.py. Use i/u/o/j/l/m/,/. and space/k to stop."
python3 "$WORKSPACE_DIR/src/racecar/scripts/racecar_teleop.py"
