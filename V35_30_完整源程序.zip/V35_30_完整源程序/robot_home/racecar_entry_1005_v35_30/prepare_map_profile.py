#!/usr/bin/env python3
"""Prepare an optional map-assist profile; never modifies a source map or car.

Usage: python3 prepare_map_profile.py --map course.yaml --alignment field.json
       --output maps/official
The alignment is a separate SE(2) calibration, not lidar yaw compensation.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

import cv2
import numpy as np


def inside_polygon(points, polygon):
    polygon = np.asarray(polygon, dtype=float)
    if polygon.ndim != 2 or polygon.shape[1] != 2 or len(polygon) < 3 or not np.isfinite(polygon).all():
        raise ValueError('Polygon requires at least three finite [x,y] vertices')
    x, y = points[:, 0], points[:, 1]
    result = np.zeros(len(points), dtype=bool)
    boundary = np.zeros(len(points), dtype=bool)
    for a, b in zip(polygon, np.roll(polygon, -1, axis=0)):
        dx, dy = b-a
        if dx*dx+dy*dy < 1e-20:
            continue
        cross = (x-a[0])*dy-(y-a[1])*dx
        dot = (x-a[0])*dx+(y-a[1])*dy
        boundary |= (abs(cross) <= 1e-9) & (dot >= -1e-9) & (dot <= dx*dx+dy*dy+1e-9)
        if dy != 0:
            result ^= ((a[1] > y) != (b[1] > y)) & (x < a[0]+(y-a[1])*dx/dy)
    return result | boundary


def read_grid(source):
    """Return bottom-to-top OccupancyGrid data; PGM alone has the opposite row order."""
    source = Path(source).resolve()
    if source.suffix.lower() == '.json':
        data = json.loads(source.read_text(encoding='utf-8'))
        meta = data['metadata']
        grid = np.asarray(data['data'], dtype=np.int16).reshape(int(meta['height']), int(meta['width']))
        resolution, origin = float(meta['resolution']), meta['origin']
        provenance = {'occupancy_json': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
    else:
        import yaml
        meta = yaml.safe_load(source.read_text(encoding='utf-8'))
        if meta.get('mode', 'trinary') != 'trinary':
            raise ValueError('Export map in ROS trinary mode before preparing this profile')
        image_path = (source.parent / meta['image']).resolve()
        image = cv2.imdecode(np.fromfile(str(image_path), dtype=np.uint8), cv2.IMREAD_UNCHANGED)
        if image is None or image.ndim != 2 or image.dtype != np.uint8:
            raise ValueError('Expected an 8-bit grayscale ROS map image')
        prob = image.astype(float)/255.0
        if not int(meta.get('negate', 0)):
            prob = 1.0-prob
        free, occupied = float(meta['free_thresh']), float(meta['occupied_thresh'])
        if not 0 <= free < occupied <= 1:
            raise ValueError('Invalid ROS map thresholds')
        grid = np.full(image.shape, -1, dtype=np.int16)
        grid[prob < free] = 0
        grid[prob > occupied] = 100
        grid = np.flipud(grid).copy()
        resolution, origin = float(meta['resolution']), meta['origin']
        provenance = {'map_yaml': str(source), 'map_yaml_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                      'image': str(image_path), 'image_sha256': hashlib.sha256(image_path.read_bytes()).hexdigest()}
    if grid.ndim != 2 or grid.size > 2000000 or min(grid.shape) < 2 or not .01 <= resolution <= .10:
        raise ValueError('Expected a finite small-course map at 1–10 cm resolution, <=2 million cells')
    if len(origin) != 3 or not all(math.isfinite(float(v)) for v in origin) or abs(float(origin[2])) > 1e-9:
        raise ValueError('This profile format requires map image origin yaw=0; re-export with an axis-aligned grid')
    if np.any((grid < -1) | (grid > 100)):
        raise ValueError('Invalid occupancy values')
    return grid, resolution, np.asarray(origin[:2], dtype=float), provenance


def prepare(source, alignment, output):
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('Use a new output directory; existing profiles are never overwritten')
    alignment = Path(alignment).resolve()
    settings = json.loads(alignment.read_text(encoding='utf-8'))
    transform = np.asarray(settings['course_to_map'], dtype=float)
    if transform.shape != (3,) or not np.isfinite(transform).all():
        raise ValueError('course_to_map must be [tx_m,ty_m,yaw_rad]')
    grid, resolution, origin, provenance = read_grid(source)
    yy, xx = np.indices(grid.shape)
    points = np.column_stack((origin[0]+(xx.ravel()+.5)*resolution, origin[1]+(yy.ravel()+.5)*resolution))
    c, s = math.cos(transform[2]), math.sin(transform[2])
    course = (points-transform[:2]) @ np.array([[c, -s], [s, c]])
    region = inside_polygon(course, settings['valid_course_polygon'])
    for polygon in settings.get('exclude_map_polygons', []):
        region &= ~inside_polygon(points, polygon)
    region = region.reshape(grid.shape)
    valid = region & (grid >= 0)
    occupied = valid & (grid >= 65)
    if occupied.sum() < 50 or valid.sum() < 100:
        raise ValueError('Insufficient in-course known cells / occupied features')
    # Distance only to retained in-course occupied cells; exterior and unknown
    # cells cannot create likelihood peaks. Unknown endpoint queries are penalized.
    distances = cv2.distanceTransform((~occupied).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)*resolution
    distances = np.minimum(distances, .20).astype(np.float32)
    output.mkdir(parents=True)
    np.savez_compressed(output/'distance_field.npz', distances=distances, valid=valid.astype(np.uint8),
                        origin_xy=origin, resolution=np.asarray(resolution))
    profile = dict(schema=1, profile_id=settings['profile_id'], distance_field='distance_field.npz',
                   distance_field_sha256=hashlib.sha256((output/'distance_field.npz').read_bytes()).hexdigest(),
                   course_to_map=transform.tolist(), valid_course_polygon=settings['valid_course_polygon'],
                   exclude_map_polygons=settings.get('exclude_map_polygons', []),
                   purpose='Optional current-scan seed and certified-route preference; never a motion authorization or start gate',
                   provenance=provenance, alignment_sha256=hashlib.sha256(alignment.read_bytes()).hexdigest(),
                   retained_occupied_cells=int(occupied.sum()), retained_known_cells=int(valid.sum()))
    (output/'profile.json').write_text(json.dumps(profile, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (output/'alignment.json').write_bytes(alignment.read_bytes())
    # A preview of the actual matching mask, not a touched-up replacement map.
    display = np.full(grid.shape, 160, dtype=np.uint8)
    display[valid] = 245
    display[occupied] = 0
    ok, png = cv2.imencode('.png', np.flipud(display))
    if ok:
        png.tofile(str(output/'assist_mask.png'))
    return profile


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--map', required=True, type=Path)
    parser.add_argument('--alignment', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    result = prepare(args.map, args.alignment, args.output)
    print(json.dumps({'profile': str(args.output/'profile.json'), 'profile_id': result['profile_id'],
                      'retained_occupied_cells': result['retained_occupied_cells']}, ensure_ascii=False))
