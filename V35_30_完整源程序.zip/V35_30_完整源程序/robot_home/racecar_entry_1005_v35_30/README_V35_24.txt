V35.24 — 连续行驶修复（离线候选，尚未安装）
版本：CONTINUITY_1002_V35_24
基线：已交付 V35.23 DISTANCE_PARKING_1002_V35_23

当前状态
本包在电脑上离线准备，不连接车辆。车辆最后已验证安装的是 V35.23。
本地测试结果记录在包外 LOCAL_VALIDATION.json；本文不代表车端安装或实车验证通过。
旧 V35.23 目录和压缩包保持不变。

修改范围
- 斑马线后入口直行：原全局定位锚的 0.80 m / 2 s 限额可能产生额外短停。在当前局部墙线、三方向一致、实际里程计和原始扫描都新鲜时，允许同一锚下最多 1.80 m / 6 s 的有限直行。原 x=4.40 m 入口转弯停车界限、净前进 0.80 m 斑马线门槛及实际停稳后 3.2 s 等待不变。
- 第一桶静止恢复：优先尝试原始扫描检查清楚的较强同向转弯（0.32、0.28、0.24），保留实际停稳、预转向等待和当前舵角扫描检查。没有扩大车身碰撞允许范围；已经太贴近挡板、或真实转向能力不足时，仍可能没有可行的前进路线。
- 终点段：用同一末墙距离和实际速度连续调整驱动，减小固定速度阈值造成的反复停走；最终收油保持到真实停稳，再判定完成或有限补位。保留源数据失鲜停车、最近障碍、车体窗口与停稳要求，不用发出零驱动代替停车。
- 生产代码只改控制器的 entry_v34_progress、curve_obstacle_recovery、finish_parking_reset、finish_parking_command、finish_parking_bound_command、finish_parking_verified 六个方法。除三个版本字符串外，其余方法和模块结构逐 AST 对照固定 V23，几何核心、视觉、YAML、雷达保护、launch、RF2O 和底盘 driver 不改。
- 若实际末墙回波仍在接近，即使里程计窗口看似静止，也不能宣告停车完成；控制支路和最终阶段切换均复核该条件。

修改前 Git 备份
本地独立仓库：car_patch_v35_24（不继承 Study 父目录历史）
基线提交：9bd1e78dfaab7bcc6c501bc0583a19797b276b0b
bundle：offline_backups/v23_baseline_9bd1e78dfaab.bundle
166 个基线交付文件与已交付 V23 ZIP 逐字节核对一致，bundle 已 verify。
该本地备份不代替重新联网安装时的实际车端备份。
安装和回退脚本都先核对实际状态，再创建车端 Git 备份，备份失败不修改源码。

安装（车辆联网后，只安装和构建，不启动比赛）
  bash /home/bianbu/racecar_entry_1002_v35_24/install.sh /home/bianbu/racecar

核对安装
  bash /home/bianbu/racecar_entry_1002_v35_24/verify_v35_24.sh /home/bianbu/racecar

后续人工运行命令（本次离线准备不执行）
  bash /home/bianbu/racecar_entry_1002_v35_24/run_v35_24.sh /home/bianbu/racecar false
默认 dry_run=true；false 允许实车运动。Ctrl+C 停止。

回退 V23（只回退和构建）
  bash /home/bianbu/racecar_entry_1002_v35_24/rollback_v35_23.sh /home/bianbu/racecar
六文件源码与安装内容必须核对精确 V23 哈希，未知修改不会覆盖。
回退后人工运行命令：
  bash /home/bianbu/racecar_entry_1002_v35_23/run_v35_23.sh /home/bianbu/racecar false

本地测试入口
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 tests/run_tests_v35_24.py
新版本按明确方法范围逐 AST 对照固定 V23 控制器。
新增入口短停 7 项、第一桶选择 8 项、终点连续距离控制 14 项；原 V23 停车和独立动力模型继续测试当前控制器。
旧第一桶测试仅将预转向硬编码改成所选角度自洽，并调整模拟每次扫描耗时以保留“按实际发布时刻计时”的反例。四项旧 V23 停车策略测试窄更新连续控制、最终滑行及新的起步截止字段，保留相应边界断言；新增第一桶与终点测试另将固定 V23 源码作为反事实对照。
七项旧 V22 策略测试明确绑定历史 V22 基线，不能当作 V24 运行证据。其中六项为既有历史对照；新增移入历史的一项要求强制给定余动轨迹期间始终零驱动，该时序合同已被连续低输入控制取代。当前 V24 对同一源轨迹检查低输入、不补位、不虚报完成，并保留输入驱动的指数/非线性惯性模型验证。其它十八项旧 V22 停车测试继续测试当前控制器，原 V22 测试文件完整保留。
旧视觉 21 张标定图、报告和历史基线保留。

隔离 ROS 检查（仅车辆联网安装后，dry_run、localhost-only、不启动 driver/camera/lidar）
  python3 tests/validate_real_ros_startup_v35_24.py --workspace /home/bianbu/racecar --report /tmp/real_ros_startup_v35_24.json
  python3 tests/validate_start_zone_v35_24.py --workspace /home/bianbu/racecar --report /tmp/real_ros_start_zone_v35_24.json
  python3 tests/validate_traffic_v35_24.py --workspace /home/bianbu/racecar --report /tmp/real_ros_traffic_v35_24.json
  python3 tests/validate_traffic_images_v35_24.py --workspace /home/bianbu/racecar --report /tmp/real_ros_traffic_images_v35_24.json
  python3 tests/validate_finish_parking_v35_24.py --workspace /home/bianbu/racecar --report /tmp/real_ros_finish_parking_v35_24.json
DOMAIN227 缺传感器零驱动，228 起步区斑马线，229 红绿灯 DDS，230 实拍识别链路，231 停车 DDS。
停车脚本显式设置末段阶段，不是全赛道或真实动力学试跑。尚未执行这些车端检查。

保留的物理约束
0 驱动映射 PWM1500 中性请求，不等于主动瞬时制动；本补丁不修改 driver，不加入反向制动。
停车规则要求四轮在 80 cm 终点区内，软件保留保守车体模型以及新鲜末墙、实际停稳证据。
前进行驶保留车头前 10 cm 缓冲；停稳后的完成几何前余量 3 cm、后余量 2 cm，最近前回波也必须在车头前余量外。
独立动力模型与历史日志不能替代实车标定；源数据延迟也不能当作纯机械惯行距离。
第一桶路径及偏斜板检查使用记录位姿和明确声明的模拟扫描；CSV 未保存精确规划起点与完整原始雷达，不应称为完整实跑重放。模型耗时比较也不是实车预计耗时。
