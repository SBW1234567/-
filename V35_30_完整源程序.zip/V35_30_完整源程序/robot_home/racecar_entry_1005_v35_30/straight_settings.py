"""Explicit, bounded straight-controller configuration; no hardware access."""
from pathlib import Path
import math
import yaml

LIMITS = {'lane_nominal_width': (.80, 1.05), 'lane_heading_gain': (.20, .70),
          'lane_target_heading_deg': (1., 5.), 'lane_cautious_heading_deg': (.5, 3.),
          'lane_straight_drive': (.28, .35)}

def validate_straight(data):
    if not isinstance(data, dict) or set(data) != set(LIMITS)|{'bounded_heading_control'}:
        raise ValueError('Invalid straight control keys')
    if type(data['bounded_heading_control']) is not bool:
        raise ValueError('bounded_heading_control must be boolean')
    result = dict(data)
    for key, (lo, hi) in LIMITS.items():
        v = data[key]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not lo <= v <= hi:
            raise ValueError('Invalid '+key)
        result[key] = float(v)
    if result['lane_cautious_heading_deg'] > result['lane_target_heading_deg']:
        raise ValueError('Cautious target exceeds normal target')
    return result

def read_straight(path=None):
    path = Path(__file__).resolve().parent.parent/'racecar_restore_v29_0925/straight_control.yaml' if path is None else path
    try:
        data = yaml.safe_load(path.read_text(encoding='utf-8'))
    except yaml.YAMLError as exc:
        raise ValueError('Invalid straight control YAML') from exc
    if not isinstance(data, dict) or data.get('schema') != 1:
        raise ValueError('Unknown straight control schema')
    return validate_straight({k:v for k,v in data.items() if k != 'schema'})
