"""Read bounded departure band settings; no hardware or baseline config writes."""
import math
from pathlib import Path
import yaml

LIMITS = {'lane_band_min_distance': (.32, .42),
          'lane_band_max_distance': (.46, .58),
          'lane_band_target_heading_deg': (.5, 1.5)}


def validate_band(data):
    if not isinstance(data, dict) or set(data) != set(LIMITS)|{'lane_parallel_band_enabled'}:
        raise ValueError('Invalid parallel band keys')
    if type(data['lane_parallel_band_enabled']) is not bool:
        raise ValueError('lane_parallel_band_enabled must be boolean')
    result = dict(data)
    for key, (lo,hi) in LIMITS.items():
        value = data[key]
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError('Invalid '+key)
        result[key] = float(value)
    if result['lane_band_max_distance']-result['lane_band_min_distance'] < .04:
        raise ValueError('Configured band must be at least 0.04 m wide')
    return result


def read_band(path=None):
    path = Path(__file__).resolve().parent.parent/'racecar_entry_0926_v35/parallel_band.yaml' if path is None else Path(path)
    data = yaml.safe_load(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict) or type(data.get('schema')) is not int or data['schema'] != 1:
        raise ValueError('Unknown parallel band schema')
    return validate_band({k:v for k,v in data.items() if k!='schema'})
