"""V28 seven-file install/rollback checks using real payloads and temporary trees."""
import copy
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
import apply_patch as installer

class PackageV3528Tests(unittest.TestCase):
    def test_only_reviewed_runtime_functions_and_methods_change_against_v27(self):
        scope=json.loads((PACKAGE/'tests/v35_28_scope.json').read_text(encoding='utf-8'))
        self.assertTrue(scope['frozen'],'V28 runtime scope must be reviewed and frozen')
        for stem,filename in (('controller','race_task_controller.py'),('core','race_curve_core.py')):
            old=ast.parse((PACKAGE/'tests/baselines'/f'{stem}_before_v35_28.py').read_text(encoding='utf-8'))
            new=ast.parse((PACKAGE/'payload/src/racecar/scripts'/filename).read_text(encoding='utf-8').replace('FIRST_CONE_CLEARANCE_1004_V35_28','OPTIONAL_MAP_ASSIST_1003_V35_27'))
            def members(tree):
                functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
                methods={c.name+'.'+n.name:n for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef)}
                return functions,methods
            for kind,before,after in zip(('functions','methods'),members(old),members(new)):
                changed={n for n in before.keys() & after.keys() if ast.dump(before[n])!=ast.dump(after[n])}
                self.assertEqual(changed,set(scope[stem+'_changed_'+kind]),stem+' '+kind)
                self.assertEqual(after.keys()-before.keys(),set(scope[stem+'_new_'+kind]))
                self.assertEqual(before.keys()-after.keys(),set(scope[stem+'_removed_'+kind]))
            for tree in (old,new):
                tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef)]
                for c in tree.body:
                    if isinstance(c,ast.ClassDef):c.body=[n for n in c.body if not isinstance(n,ast.FunctionDef)]
            # New profile helpers may add imports/classes. Their residual module
            # AST is pinned separately after explicit review, never ignored.
            residual=ast.dump(new,include_attributes=False).encode('utf-8')
            self.assertEqual(hashlib.sha256(residual).hexdigest(),
                             scope[stem+'_module_ast_sha256'],stem+' imports/classes/constants changed outside frozen review')

    def test_v27_controller_baseline_and_rollback_remain_exact(self):
        expected='ca4d2b3eb0a8949a761086470c777459a5feaa21e10dfc1a21a40face76d7899'
        for relative in ('tests/baselines/controller_before_v35_28.py',
                         'rollback/src/racecar/scripts/race_task_controller.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_v27_core_baseline_and_rollback_remain_exact(self):
        expected='c78ff3128c5ce16664fface148f57249cfba227aaddc2e0fc44eb3df237b653e'
        for relative in ('tests/baselines/core_before_v35_28.py',
                         'rollback/src/racecar/scripts/race_curve_core.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_original_v22_parking_test_source_is_preserved(self):
        old_tests=PACKAGE/'tests/test_finish_parking_v35_22.py'
        self.assertEqual(hashlib.sha256(old_tests.read_bytes()).hexdigest(),
                         '3e8575055c7fc69c74624bb9e8a7b9051127a3b757deb7932eeb018a57a48ab6')

    def test_first_cone_historical_comparison_keeps_exact_v21(self):
        path=PACKAGE/'tests/baselines/controller_before_v35_22.py'
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         'f3c8f5b1c2e1e666bac22452dfd7a9576805586a7c3b369ab4f31eda34197fbe')

    def test_vision_config_and_guard_retain_exact_v27(self):
        expected={
            'src/racecar/scripts/race_lidar_guard.py':'2651735dd452a24def8d00b3fbaf41c02df41b8df975852f745237b0395c2e4f',
            'src/racecar/scripts/ican_vision_node.py':'f06836a2f4fd71afbb921950fdb6dd90f822e844481dc1a2e9fb0f9456886e9a',
            'src/racecar/config/competition_params.yaml':'7adc3341f9a5adb57a9e1a58dc97d6dc28a1b725a3b0030c5105e4f74ea46852',
        }
        for relative,value in expected.items():
            for directory in ('payload','rollback'):
                with self.subTest(path=relative,directory=directory):
                    self.assertEqual(hashlib.sha256((PACKAGE/directory/relative).read_bytes()).hexdigest(),value)

    def test_historical_vision_calibration_keeps_original_v19_inputs(self):
        report=json.loads((PACKAGE/'CALIBRATION_V35_20.json').read_text(encoding='utf-8'))
        for filename,key in (('vision_before_v35_20.py','v19_source_sha256'),
                             ('competition_params_before_v35_20.yaml','v19_config_sha256')):
            self.assertEqual(hashlib.sha256((PACKAGE/'tests/baselines'/filename).read_bytes()).hexdigest(),report[key])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/scripts/ican_vision_node.py').read_bytes()).hexdigest(),report['v20_source_sha256'])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/config/competition_params.yaml').read_bytes()).hexdigest(),report['v20_config_sha256'])

    def test_runner_arguments_preserve_exact_v27_slam_off_and_profile_interface(self):
        def function(path,name):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        current=function(PACKAGE/'launch_centered.py','make_command')
        baseline=function(PACKAGE/'tests/baselines/launch_centered_before_v35_28.py','make_command')
        self.assertEqual(ast.dump(current),ast.dump(baseline))
        switches=[n for n in ast.walk(current) if isinstance(n,ast.Constant) and n.value=='enable_slam:=false']
        self.assertEqual(len(switches),1)
        runner=(PACKAGE/'run_v35_28.sh').read_text(encoding='utf-8')
        self.assertIn('RACE_DRY_RUN=${2:-true}',runner)
        self.assertIn('RACE_PREPARE_DRIVE=${3:-0.35}',runner)
        self.assertIn('RACE_MAP_PROFILE=${4:-$PATCH_DIR/maps/lab_20261003/profile.json}',runner)
        self.assertIn('export RACECAR_MAP_PROFILE="$RACE_MAP_PROFILE"',runner)

    def test_install_and_rollback_snapshot_precedes_source_mutation(self):
        for filename,label,action in (
                ('install.sh','before-v35-28-install','--workspace "$RACE_WORKSPACE"\n'),
                ('rollback_v35_27.sh','before-v35-28-rollback-to-v35-27','--workspace "$RACE_WORKSPACE" --rollback')):
            shell=(PACKAGE/filename).read_text(encoding='utf-8')
            snapshot='python3 /home/bianbu/snapshot_vehicle_git.py --label '+label
            mutation='python3 "$PATCH_DIR/apply_patch.py" '+action
            with self.subTest(script=filename):
                self.assertIn('set -e\n',shell)
                self.assertIn('"$(readlink -f -- "$RACE_WORKSPACE")" != /home/bianbu/racecar',shell)
                self.assertLess(shell.index('--check'),shell.index(snapshot))
                self.assertLess(shell.index(snapshot),shell.index(mutation))

    def test_exact_seven_file_overlay_includes_both_launches_and_rollback(self):
        base,overlay,changes=installer.load_manifests()
        self.assertEqual(overlay['version'],'FIRST_CONE_CLEARANCE_1004_V35_28')
        self.assertEqual(base['version'],overlay['base'])
        self.assertEqual(overlay['base'],'OPTIONAL_MAP_ASSIST_1003_V35_27')
        self.assertEqual(len(changes),7)
        controller=(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py').read_text(encoding='utf-8')
        self.assertEqual(controller.count('FIRST_CONE_CLEARANCE_1004_V35_28'),3)
        self.assertNotIn('OPTIONAL_MAP_ASSIST_1003_V35_27',controller)
        baselines={item['path']:item for item in base['files']}
        for relative in ('src/racecar/scripts/ican_vision_node.py','src/racecar/config/competition_params.yaml',
                         'src/racecar/launch/race_competition.launch.py','src/racecar/launch/Run_explorer.launch.py'):
            self.assertIn(relative,changes)
            self.assertNotIn(relative,base['dependencies'])
            self.assertIsNotNone(changes[relative]['installed_path'])
            self.assertEqual(changes[relative]['installed_path'],baselines[relative]['installed_path'])

    def test_both_launches_remain_byte_exact_v27_and_slam_defaults_stay_true(self):
        hashes={'Run_explorer.launch.py':'378c0f8ce22dc13cd10452f0264cf3bcc9597ed4792dff647b9179a499207a56',
                'race_competition.launch.py':'4d05f6a82bd832e67cbfdef01b2682ecbb5a03f619ef21a1e92ebacbd46e87e2'}
        for filename,expected in hashes.items():
            relative='src/racecar/launch/'+filename
            for mode in ('payload','rollback'):
                data=(PACKAGE/mode/relative).read_bytes()
                self.assertEqual(hashlib.sha256(data).hexdigest(),expected)
            tree=ast.parse(data)
            declarations=[n for n in ast.walk(tree) if isinstance(n,ast.Call)
                          and isinstance(n.func,ast.Name) and n.func.id=='DeclareLaunchArgument'
                          and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='enable_slam']
            self.assertEqual(len(declarations),1)
            default=next(k.value for k in declarations[0].keywords if k.arg=='default_value')
            self.assertEqual(ast.literal_eval(default),'true')

    def test_original_lab_profile_and_field_remain_exact_v27(self):
        expected={'maps/lab_20261003/profile.json':'6728579a332c036f14cbae1b096b56248b326cc9677138b20023b18c3131820f',
                  'maps/lab_20261003/distance_field.npz':'9b97e48066d71b44dd2e6bd6b7fce742fb208f4cc92672079e0080d413305441'}
        for relative,value in expected.items():
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),value)

    def fixture(self):
        base,overlay,changes=installer.load_manifests()
        base=copy.deepcopy(base)
        base['files']=[i for i in base['files'] if i['path'] in changes]
        cmake=b'project(racecar)\n'
        base['dependencies']={'src/racecar/CMakeLists.txt':hashlib.sha256(cmake).hexdigest()}
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name)/'racecar'
        for relative,data in [('src/racecar/CMakeLists.txt',cmake)]:
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for relative,item in changes.items():
            for name in (relative,item['installed_path']):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(PACKAGE/'rollback'/relative,target)
        loader=patch.object(installer,'load_manifests',return_value=(base,overlay,changes));loader.start();self.addCleanup(loader.stop)
        running=patch.object(installer,'active_race_processes',return_value=[]);running.start();self.addCleanup(running.stop)
        return root,changes

    def build_fixture(self,root,changes):
        for relative,item in changes.items():shutil.copyfile(root/relative,root/item['installed_path'])

    def test_all_seven_sources_and_installed_files_return_to_exact_v27(self):
        root,changes=self.fixture()
        installer.validate_tree(root,'original_v35',binaries=False)
        installer.copy_version(root,binaries=False)
        archives=list(root.parent.glob('racecar_before_entry_v35_28_*.tar.gz'))
        self.assertEqual(len(archives),1)
        with tarfile.open(archives[0]) as archive:
            self.assertEqual(set(archive.getnames()),set(changes))
            for relative in changes:
                self.assertEqual(archive.extractfile(relative).read(),(PACKAGE/'rollback'/relative).read_bytes())
        self.build_fixture(root,changes)
        installer.validate_tree(root,'v35',binaries=False)
        installer.copy_version(root,rollback=True,binaries=False)
        self.build_fixture(root,changes)
        installer.validate_tree(root,'original_v35',binaries=False)
        for relative,item in changes.items():
            expected=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual((root/relative).read_bytes(),expected)
            self.assertEqual((root/item['installed_path']).read_bytes(),expected)

    def test_unknown_installed_vision_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/changes['src/racecar/scripts/ican_vision_node.py']['installed_path']
        target.write_bytes(target.read_bytes()+b'\n# user edit\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
        self.assertEqual(list(root.parent.glob('racecar_before_*')),[])

    def test_unknown_yaml_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/'src/racecar/config/competition_params.yaml'
        target.write_bytes(target.read_bytes()+b'\n# user tuning\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

    def test_unknown_launch_source_or_install_is_rejected_before_any_write(self):
        root,changes=self.fixture()
        for relative in ('src/racecar/launch/Run_explorer.launch.py',
                         'src/racecar/launch/race_competition.launch.py'):
            for candidate in (relative,changes[relative]['installed_path']):
                with self.subTest(path=candidate):
                    target=root/candidate;original=target.read_bytes()
                    target.write_bytes(original+b'\n# unrecognized local edit\n')
                    before={r:(root/r).read_bytes() for r in changes}
                    with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
                        installer.copy_version(root,binaries=False)
                    self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
                    self.assertEqual(list(root.parent.glob('racecar_before_*')),[])
                    target.write_bytes(original)

    def test_active_car_is_not_modified(self):
        root,changes=self.fixture()
        before={r:(root/r).read_bytes() for r in changes}
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing race'):
                installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

if __name__=='__main__':unittest.main(verbosity=2)
