"""Stopped-only tolerance, entrance recovery, cancellation and geometry parity."""
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from threading import Event
import importlib.util
import math
import sys
import time
import unittest
from unittest.mock import patch
import numpy as np
import test_straight as t
import test_entry_quick as q

g=t.core


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        t.ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=t.controller.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        c=self.c;c.phase=c.SEEK_CONE_1
        c.entry_v33_braked=c.entry_v34_turn_stop=c.entry_hold=True
        c.last_odom_xy=(5.,.7);c.last_yaw=.1;c.last_odom_time=100.
        for now in (99.4,99.6,99.8,100.):c.record_still_sample(now,now,5.,.7,.1)
        self.assertTrue(c.odom_is_still(100.))
        c.entry_plan_anchor=dict(pose=(5.2,.79,0.),started=100.,checked=100.,odom=(5.,.7,.1),
            samples=deque(c.odom_still_samples),stamp=100.)
        c.entry_plan_cancel=Event()

    def test_0384_gap_holds_reference_but_not_still_gate(self):
        c=self.c
        self.assertFalse(c.odom_is_still(100.384))
        self.assertTrue(c.entry_plan_anchor_valid(100.384))
        self.assertEqual(c.entry_plan_reference_reason,'HELD_WAIT_FRESH_ODOM')
        self.assertFalse(c.entry_gate_snapshot(100.384)['STOPPED'])
        self.assertEqual(c.odom_max_gap,.30)

    def test_gap_recovers_without_clearing_plan_but_rebuilds_strict_stop_evidence(self):
        c=self.c
        self.assertTrue(c.entry_plan_anchor_valid(100.384))
        for now in (100.4,100.6,100.8,101.0):
            c.entry_plan_observe_odom(now,now,5.,.7,.1)
            c.record_still_sample(now,now,5.,.7,.1)
            c.last_odom_time=now
            self.assertTrue(c.entry_plan_anchor_valid(now))
            if now==100.4:self.assertFalse(c.odom_is_still(now))
        self.assertTrue(c.odom_is_still(101.0))

    def test_over_060_gap_revokes_and_cancels(self):
        c=self.c
        self.assertFalse(c.entry_plan_anchor_valid(100.601))
        self.assertTrue(c.entry_plan_cancel.is_set())
        self.assertEqual(c.entry_plan_reference_reason,'CONTROL_POLL_GAP')

    def test_odom_gap_not_hidden_by_regular_polls(self):
        c=self.c
        for now in (100.1,100.3,100.5):self.assertTrue(c.entry_plan_anchor_valid(now))
        self.assertFalse(c.entry_plan_anchor_valid(100.601))
        self.assertEqual(c.entry_plan_reference_reason,'ODOM_STALE')

    def test_returned_to_origin_does_not_erase_motion(self):
        c=self.c
        c.entry_plan_observe_odom(100.1,100.1,5.016,.7,.1)
        c.entry_plan_observe_odom(100.2,100.2,5.,.7,.1)
        self.assertIsNone(c.entry_plan_anchor)
        self.assertEqual(c.entry_plan_reference_reason,'ODOM_MOVED')
        self.assertTrue(c.entry_plan_cancel.is_set())

    def test_late_message_stamp_revokes_reference(self):
        self.c.entry_plan_observe_odom(100.1,100.7,5.,.7,.1)
        self.assertIsNone(self.c.entry_plan_anchor)

    def test_relaxation_not_valid_in_crosswalk_or_curve(self):
        for phase in (self.c.CROSSWALK_STOP,self.c.ENTER_OBSTACLES,self.c.APPROACH_CROSSWALK):
            with self.subTest(phase=phase):
                self.setUp();self.c.phase=phase
                self.assertFalse(self.c.entry_plan_anchor_valid(100.384))
                self.assertFalse(self.c.odom_is_still(100.384))

    def recovery(self,cache_time=100.,distance=.75,braked=True,hits=3,scan_age=.1,fault=''):
        c=self.c;c.entry_v33_braked=braked;c.curve_scan_wait=c.curve_pose_wait=True
        c.curve_scan_wait_since=99.;c.curve_scan_recovery_hits=hits
        c.curve_scan=object();c.curve_scan_time=100.1-scan_age
        c.rel_data={};c.rel_time=100.;c.lane_ready=False;c.corridor_time=80.
        c.curve_locator.pose=(4.69,.75,.039);c.curve_locator.time=99.88;c.curve_locator.hits=2
        obs=(None,None,{},20.,(distance,0.,8,.6,.005))
        c.entry_v34_wall_cache.append((123,cache_time,obs))
        with patch.object(c,'sensors_ready',return_value=True), \
             patch.object(c,'curve_wait_fault',return_value=fault), \
             patch.object(c.curve_tracks,'ready',return_value=True):
            c.curve_update_scan_wait(100.1)
            c.curve_update_pose_wait(100.1)

    def test_current_entry_wall_clears_scan_and_pose_wait(self):
        self.recovery()
        self.assertFalse(self.c.curve_scan_wait)
        self.assertFalse(self.c.curve_pose_wait)
        self.assertIsNone(self.c.curve_follower)

    def test_bad_wall_or_scan_or_obstacle_cannot_clear_wait(self):
        for options in (dict(cache_time=99.),dict(distance=1.3),dict(braked=False),
                        dict(hits=2),dict(scan_age=.26),dict(fault='REL_BODY_OR_EMERGENCY')):
            with self.subTest(options=options):
                self.setUp();self.recovery(**options)
                self.assertTrue(self.c.curve_scan_wait)

    def test_inflight_cancel_is_consumed_and_new_plan_can_submit(self):
        c=self.c;started=Event();release=Event();event=c.entry_plan_cancel
        def job():
            started.set();release.wait(2.)
            g._plan_check(event,None,time.monotonic())
        with ThreadPoolExecutor(max_workers=1) as executor:
            future=executor.submit(job);self.assertTrue(started.wait(1.))
            c.entry_plan_job=(future,(5.2,.79,0.),g.CONES,100.,c.curve_generation)
            c.curve_poll_entry_plan(100.7)
            self.assertTrue(event.is_set());release.set()
            with self.assertRaises(g.PlanningInterrupted):future.result(timeout=2.)
        c.curve_poll_entry_plan(100.71)
        self.assertIsNone(c.entry_plan_job);self.assertFalse(c.route_fault)
        c.curve_locator.pose=(5.2,.79,0.);c.last_odom_time=100.8
        with patch.object(c,'entry_gate_snapshot',return_value={'STOPPED':True}), \
             patch.object(c.entry_plan_executor,'submit',return_value=Future()) as submit:
            c.curve_update(100.8)
        self.assertEqual(submit.call_count,1)
        self.assertFalse(c.entry_plan_cancel.is_set())
        self.assertIn('deadline',submit.call_args.kwargs)


class PlannerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('previous_geometry',t.PACKAGE/'rollback/src/racecar/scripts/race_curve_core.py')
        cls.old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=cls.old;spec.loader.exec_module(cls.old)

    def test_batch_collision_matches_scalar_over_random_and_contact_poses(self):
        rng=np.random.default_rng(3515)
        poses=np.column_stack((rng.uniform(-.2,8.2,1800),rng.uniform(-.2,4.2,1800),rng.uniform(-math.pi,math.pi,1800)))
        poses=np.vstack((poses,[[.2,.8,0.],[3.5,.25,0.],[5.,.3,0.],[7.7,2.,0.],
                                [6.,1.5,0.],[3.2,1.15,0.]]))
        for p in poses:
            self.assertEqual(g.path_body_clear([p]),self.old.body_clear(p),p)
        for i in range(0,len(poses),20):
            batch=poses[i:i+20]
            self.assertEqual(g.path_body_clear(batch),all(self.old.body_clear(p) for p in batch))

    def test_planner_preserves_paths_and_failure_results(self):
        for pose,cones in [((5.2,.79,0.),g.CONES),((4.691245,.746386,.039256),g.CONES),
                           ((5.0,.6,.1),g.CONES),((5.2,.79,0.),((6.,2.2),(2.,2.))),
                           ((4.4,.2,-.4),g.CONES)]:
            with self.subTest(pose=pose,cones=cones):
                try:old=self.old.plan_entry_path(pose,cones)
                except ValueError as exc:
                    with self.assertRaisesRegex(ValueError,str(exc)):g.plan_entry_path(pose,cones)
                else:
                    new=g.plan_entry_path(pose,cones)
                    np.testing.assert_array_equal(new.samples,old.samples)
                    self.assertTrue(all(self.old.body_clear(p,cones) for p in new.samples))

    def test_cancelled_plan_does_not_run_search(self):
        event=Event();event.set()
        with patch.object(g,'make_path') as make:
            with self.assertRaisesRegex(g.PlanningInterrupted,'PLAN_CANCELLED'):g.plan_entry_path((5.2,.79,0.),cancel=event)
        make.assert_not_called()

    def test_deadline_exits_even_when_geometry_keeps_failing(self):
        with patch.object(g.time,'monotonic',side_effect=[10.,10.,12.,12.]):
            with self.assertRaisesRegex(g.PlanningInterrupted,'PLAN_DEADLINE'):
                g.plan_entry_path((4.4,.2,-.4),deadline=11.)

    def test_cancel_during_candidate_stops_before_next_candidate(self):
        event=Event();old=g.make_path
        def candidate(*a,**kw):
            event.set();raise ValueError('PATH_CURVATURE')
        with patch.object(g,'make_path',side_effect=candidate) as make:
            with self.assertRaisesRegex(g.PlanningInterrupted,'PLAN_CANCELLED'):
                g.plan_entry_path((5.2,.79,0.),cancel=event)
        self.assertEqual(make.call_count,1)

if __name__=='__main__':unittest.main(verbosity=2)
