"""Source-time controller prediction; no ROS runtime or vehicle is contacted."""
import math
from collections import deque
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as fixtures

cm,core,ros=fixtures.cm,fixtures.core,fixtures.ros


class CurvePredictionTests(unittest.TestCase):
    def setUp(self):
        self.mono_now=100.
        clock=patch.object(cm.time,'monotonic',side_effect=lambda:self.mono_now)
        clock.start();self.addCleanup(clock.stop)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.phase=self.c.ENTER_OBSTACLES;self.c.curve_follower=object()
        self.c.curve_control_prediction_enabled=True
        # These existing boundary tests exercise an explicitly configured .75s
        # budget. V35.14's default 1.0s budget has separate regression coverage.
        self.c.curve_prediction_max_time=.75
        self.ros_ns=round(1000.5e9)
        self.c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=self.ros_ns))
        self.c.curve_locator.pose=(5.,1.,.15);self.c.curve_locator.time=100.
        self.c.curve_locator.hits=3;self.c.curve_pose_odom=(.07,0.,0.)
        self.c.curve_pose_stamp=round(1000.e9);self.c.curve_pose_odom_stamp=self.c.curve_pose_stamp
        self.c.curve_pose_odom_alignment='SCAN_ALIGNED'

    def source(self,t,pose,received=100.,ros_time=1000.5):
        """Send a base-frame pose with its original scan source timestamp."""
        ns=round(t*1e9);yaw=pose[2]
        msg=NS(header=NS(stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)),
            pose=NS(pose=NS(position=NS(x=pose[0],y=pose[1]),orientation=NS(x=0.,y=0.,z=math.sin(yaw/2),w=math.cos(yaw/2)))),
            twist=NS(twist=NS(linear=NS(x=99.),angular=NS(z=99.))))
        self.ros_ns=round(ros_time*1e9)
        self.mono_now=received
        self.c.odom_callback(msg)

    def straight(self,speed=1.,received=100.,ros_time=1000.5):
        self.source(999.9,(-.1*speed,0.,0.),received-.1,ros_time-.1)
        self.source(1000.,(0.,0.,0.),received,ros_time)

    def assert_pose(self,actual,expected):
        self.assertIsNotNone(actual)
        for x,y in zip(actual,expected):self.assertAlmostEqual(x,y,places=7)

    def test_delayed_source_pose_is_advanced_to_actual_control_time(self):
        self.straight();c=self.c;before=list(c.curve_odom_samples)
        expected=core.bridge_pose(c.curve_locator.pose,c.curve_pose_odom,(.57,0.,0.))
        self.assert_pose(c.curve_pose_estimate(100.),expected)
        self.assertEqual(c.curve_motion_status['policy'],'SOURCE_PREDICTED')
        self.assertAlmostEqual(c.curve_motion_status['prediction_dt_s'],.5)
        self.assertAlmostEqual(c.curve_motion_status['speed_mps'],1.)
        self.assertEqual(c.curve_motion_status['rf2o_twist_mps'],99.)
        self.assertEqual(list(c.curve_odom_samples),before)
        self.assertEqual(c.curve_pose_stamp,round(1000e9))
        self.assertEqual(c.curve_pose_odom_stamp,round(1000e9))

    def test_small_source_delay_does_not_use_old_nearest_sample_as_current(self):
        self.straight(ros_time=1000.1)
        self.assertEqual(self.c.curve_odom_at(round(1000.1e9)),(.07,0.,0.))
        result=self.c.curve_pose_estimate(100.)
        self.assert_pose(result,core.bridge_pose(self.c.curve_locator.pose,(.07,0.,0.),(.17,0.,0.)))

    def test_constant_arc_preserves_control_and_scan_time_frames(self):
        c=self.c;velocity=(1.,0.,1.5)
        base0=(0.,0.,0.);base1=c.curve_integrate_motion(base0,velocity,.1)
        self.source(999.9,base0,99.9,1000.4);self.source(1000.,base1,100.,1000.5)
        c.curve_pose_odom=tuple(c.curve_odom_samples[-1][1:4]);c.curve_scan_stamp=round(1000.3e9)
        expected_base=c.curve_integrate_motion(base1,velocity,.5)
        expected_laser=(expected_base[0]+.07*math.cos(expected_base[2]),expected_base[1]+.07*math.sin(expected_base[2]),expected_base[2])
        expected=core.bridge_pose(c.curve_locator.pose,c.curve_pose_odom,expected_laser)
        current=c.curve_pose_estimate(100.)
        self.assert_pose(current,expected)
        scan_base=c.curve_integrate_motion(base1,velocity,.3)
        scan_laser=(scan_base[0]+.07*math.cos(scan_base[2]),scan_base[1]+.07*math.sin(scan_base[2]),scan_base[2])
        self.assert_pose(c.curve_scan_pose(100.,current),core.bridge_pose(c.curve_locator.pose,c.curve_pose_odom,scan_laser))
        self.assertAlmostEqual(c.curve_motion_status['prediction_dt_s'],.5)
        self.assertAlmostEqual(c.curve_motion_status['scan_prediction_dt_s'],.3)

    def test_source_clock_age_wins_over_fresh_receipt(self):
        self.straight(ros_time=1000.8)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(self.c.curve_motion_status['odom_source_age_s'],.8)

    def test_predictive_distance_is_bounded_without_clamping_a_stale_pose(self):
        self.straight(speed=2.,ros_time=1000.5)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertAlmostEqual(self.c.curve_motion_status['prediction_distance_m'],1.)

    def test_gross_source_velocity_is_rejected(self):
        self.straight(speed=3.5,ros_time=1000.1)
        self.assertIsNone(self.c.curve_motion_velocity)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_VELOCITY_REJECTED')
        self.assertIsNone(self.c.curve_motion_status['speed_mps'])

    def test_exact_source_time_cannot_bypass_gross_velocity_rejection(self):
        self.straight(speed=3.5,ros_time=1000.)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_VELOCITY_REJECTED')
        self.assertAlmostEqual(self.c.curve_motion_status['rejected_speed_mps'],3.5)

    def test_new_incomplete_pair_clears_old_usable_speed(self):
        self.straight();self.source(1000.02,(.02,0.,0.),100.02,1000.52)
        self.assertEqual(self.c.curve_motion_status['velocity_policy'],'SOURCE_SPAN_REJECTED')
        self.assertIsNone(self.c.curve_motion_status['speed_mps'])
        self.assertIsNone(self.c.curve_motion_velocity)

    def test_gross_yaw_velocity_is_rejected_at_exact_source_time(self):
        self.source(999.9,(0.,0.,0.),99.9,999.9)
        self.source(1000.,(0.,0.,.55),100.,1000.)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_VELOCITY_REJECTED')

    def test_prediction_turn_is_bounded_separately_from_speed(self):
        self.source(999.9,(0.,0.,0.),99.9,1000.4)
        self.source(1000.,(0.,0.,.4),100.,1000.5)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(self.c.curve_motion_status['prediction_yaw_rad'],2.)

    def test_incomplete_source_pair_cannot_make_a_prediction(self):
        self.source(1000.,(0.,0.,0.))
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'WAIT_SOURCE_VELOCITY')

    def test_zero_measured_velocity_removes_old_motion_after_stop(self):
        self.straight();self.c.curve_pause_active=True
        self.assertIsNotNone(self.c.curve_pose_estimate(100.))
        self.source(1000.1,(0.,0.,0.),100.1,1000.6)
        result=self.c.curve_pose_estimate(100.1)
        self.assert_pose(result,self.c.curve_locator.pose)
        self.assertEqual(self.c.curve_motion_status['speed_mps'],0.)

    def test_short_pause_does_not_discard_real_coasting_velocity(self):
        self.straight(ros_time=1000.3);c=self.c;c.curve_pause_active=True
        self.assertIsNotNone(c.curve_pose_estimate(100.))
        self.source(1000.2,(.2,0.,0.),100.2,1000.5)
        self.assertIsNotNone(c.curve_pose_estimate(100.2))
        self.assertEqual(c.curve_motion_status['policy'],'SOURCE_PREDICTED')

    def test_post_stop_measurements_are_still_available_after_long_pause(self):
        self.straight(ros_time=1000.3);c=self.c;c.curve_pause_active=True
        c.curve_pose_estimate(100.)
        self.source(1000.6,(.6,0.,0.),100.6,1000.9)
        self.source(1000.7,(.6,0.,0.),100.7,1001.)
        self.assertIsNotNone(c.curve_pose_estimate(100.7))
        self.assertEqual(c.curve_motion_status['speed_mps'],0.)

    def test_clock_jump_does_not_become_extra_motion(self):
        self.straight();self.ros_ns+=round(.3e9)
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_CLOCK_CHANGED')

    def test_before_handoff_real_bridge_is_unchanged(self):
        self.straight();c=self.c;c.curve_follower=None;c.phase=c.SEEK_CONE_1
        self.assert_pose(c.curve_pose_estimate(100.),c.curve_locator.pose)
        self.assertEqual(c.curve_pose_estimate_reason,'ODOM_BRIDGED')

    def test_crosswalk_does_not_predict_or_change_still_detector(self):
        c=self.c;c.curve_follower=None;c.phase=c.CROSSWALK_STOP
        self.straight();before=list(c.odom_still_samples)
        self.assert_pose(c.curve_pose_estimate(100.),c.curve_locator.pose)
        self.assertEqual(list(c.odom_still_samples),before)

    def test_scan_alignment_limit_is_explicit_instead_of_fallback_current(self):
        self.straight();c=self.c;c.curve_scan_stamp=round(1000.8e9)
        self.assertIsNone(c.curve_scan_pose(100.,(999.,999.,0.)))
        self.assertEqual(c.curve_motion_status['scan_pose_policy'],'SOURCE_PREDICTION_LIMIT')

    def test_recent_unanchored_wall_pose_does_not_claim_control_time(self):
        self.straight();self.c.curve_pose_odom=None
        self.assertIsNone(self.c.curve_pose_estimate(100.))
        self.assertEqual(self.c.curve_pose_estimate_reason,'WAIT_ODOM_ALIGNMENT')


if __name__=='__main__':unittest.main(verbosity=2)
