"""V21 17:14 first-cone presteer resets under delayed stationary sources.

Pose/cones/handoff come from the recorded run; the unlogged exact planner seed
and raw scan are not reconstructed. Handbook raycasts isolate the timing bug.
Baseline methods are compiled from the fixed exact V21 source for comparison;
the moving rollback directory now contains V22 and cannot serve this test.
"""
import ast
from collections import deque
import copy
import importlib.util
import math
from pathlib import Path
import sys
from types import MethodType
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_controller_recovery_v35_13 as fixture

cm,core=helpers.cm,helpers.core
STOP=(6.736928392193244,2.2626159161299784,2.026814941383028)
HANDOFF=(5.565858938178845,.8601056696563996,.11761866582210344)
CONES=((6.239025302501285,1.8905091068437998),(1.9999683361858744,1.982182670712573))
PATH=None


class FirstConeDwellV3522Tests(unittest.TestCase):
    source=fixture.ControllerRecoveryTests.source
    inputs=fixture.ControllerRecoveryTests.inputs

    def setUp(self):
        global PATH
        fixture.ControllerRecoveryTests.setUp(self)
        patch.object(core,'CONES',CONES).start()
        if PATH is None:
            # V26's earlier normal path clears this pose after locate advances.
            # Keep the exact V25 geometry to manufacture the SAME blocked-path
            # timing situation, while exercising the CURRENT controller below.
            # This is a current stop-proof regression, not historical policy.
            file=Path(__file__).parent/'baselines/core_before_v35_26.py'
            spec=importlib.util.spec_from_file_location('dwell_fixed_v25_geometry',file)
            module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
            spec.loader.exec_module(module)
            PATH=module.plan_entry_path(HANDOFF,cones=CONES)
        c=self.c;c.phase=c.ORBIT_CONE_1;c.curve_curvature_gain=5.;c.curve_cones=CONES
        f=c.curve_follower=core.PathFollower(PATH)
        f.index=min(range(len(PATH.samples)),key=lambda j:core.dist(PATH.samples[j],STOP))
        f.progress=float(PATH.lengths[f.index])
        c.curve_locator.pose=STOP;c.curve_pose_odom=STOP
        c.curve_odom_samples.clear();c.curve_motion_samples.clear()
        c.last_motion_stamp=0.;c.last_odom_xy=None;c.last_yaw=None
        for t in (999.,999.2,999.35):self.source(t,STOP)
        self.inputs(STOP)

    def presteer(self):
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        # V24 chooses the stronger clear first-cone arc. The V22 dwell and
        # source-proof contract applies to the steering actually selected.
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertTrue(self.c.curve_recovery_state['first_standstill_proof'])
        return self.c.curve_recovery_state

    def tick(self,dt=.1,new_source=False,pose=STOP):
        self.now+=dt;self.ros_time+=dt
        if new_source:self.source(self.ros_time-.65,pose)
        self.inputs(pose)
        return self.c.curve_command(self.now)

    def test_recorded_delay_keeps_dwell_and_launches_only_after_fresh_check(self):
        state=self.presteer();started=state['started'];holds=0
        for step in range(1,13):
            command=self.tick(new_source=step%3==0)
            if command.linear.x>0.:break
            self.assertIs(self.c.curve_recovery_state,state)
            self.assertEqual(state['started'],started)
            self.assertAlmostEqual(command.angular.z,state['steer'])
            if self.c.curve_recovery_status.get('previous_stop_proof'):
                holds+=1
                self.assertTrue(self.c.curve_recovery_status['previous_stop_proof']['zero_drive_only'])
        self.assertGreater(holds,0)
        self.assertGreater(command.linear.x,0.)
        self.assertGreaterEqual(self.now-started,.60)
        self.assertLessEqual(self.now-started,1.21)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertTrue(self.c.curve_recovery_status['standstill']['valid'])
        self.assertEqual(self.c.curve_recovery_status['final_check_reason'],'')
        self.assertNotIn('first_standstill_proof',state)

    def test_exact_v21_baseline_resets_under_same_delayed_source_sequence(self):
        path=Path(__file__).resolve().parents[1]/'tests/baselines/controller_before_v35_22.py'
        cls=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.ClassDef))
        names={'curve_recovery_stopped','curve_recovery_hold_command','curve_obstacle_recovery'}
        namespace=dict(cm.__dict__)
        for node in cls.body:
            if isinstance(node,ast.FunctionDef) and node.name in names:
                exec(compile(ast.Module(body=[copy.deepcopy(node)],type_ignores=[]),str(path),'exec'),namespace)
                patch.object(self.c,node.name,MethodType(namespace[node.name],self.c)).start()
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.);resets=0
        for step in range(1,13):
            command=self.tick(new_source=step%3==0)
            self.assertEqual(command.linear.x,0.)
            if self.c.curve_recovery_state is None:resets+=1
        self.assertGreaterEqual(resets,3)

    def test_bounded_hold_never_renews_proof_source_or_clearance_time(self):
        state=self.presteer();proof=dict(state['first_standstill_proof']);checked=state['checked_at']
        self.now+=.2;self.ros_time+=.2
        command=self.c.curve_recovery_hold_command(self.now)
        self.assertIsNotNone(command);self.assertEqual(command.linear.x,0.)
        self.assertEqual(state['first_standstill_proof'],proof)
        self.assertEqual(state['checked_at'],checked)
        self.now+=.11;self.ros_time+=.11
        command=self.c.curve_recovery_hold_command(self.now)
        self.assertIsNotNone(command);self.assertEqual(command.linear.x,0.)
        self.assertEqual(state['first_standstill_proof'],proof)
        self.now+=.21;self.ros_time+=.21
        self.assertIsNone(self.c.curve_recovery_hold_command(self.now))

    def test_old_proof_alone_cannot_launch_even_if_dwell_and_raw_are_clear(self):
        state=self.presteer();started=state['started']
        self.assertEqual(self.tick(.3,new_source=True).linear.x,0.)
        self.assertEqual(self.tick(.2).linear.x,0.)
        # A new but still .85-second-old sample arrives after .7 seconds of
        # zero-drive preposition. Raw geometry is clear; current stop evidence
        # is nevertheless still too old to launch, so only steering is held.
        self.now+=.2;self.ros_time+=.2;self.inputs(STOP)
        self.source(self.ros_time-.85,STOP)
        checks=[];original=self.c.curve_check_sweep
        def record(*args):
            result=original(*args);checks.append(result);return result
        with patch.object(self.c,'curve_check_sweep',side_effect=record):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(checks[-1],(True,'CLEAR_RAW'))
        self.assertGreaterEqual(self.now-started,.6)
        self.assertTrue(self.c.curve_recovery_status['previous_stop_proof']['valid'])

    def test_measured_push_and_rotation_invalidate_existing_proof(self):
        state=self.presteer();saved=copy.deepcopy(state);samples=list(self.c.curve_motion_samples)
        for defect in ('push','rotate','source_gap','regress','clock_back','clock_jump','drive','old_receipt'):
            with self.subTest(defect=defect):
                self.now=100.2;self.ros_time=1000.2;c=self.c
                c.curve_recovery_state=copy.deepcopy(saved);state=c.curve_recovery_state
                c.curve_motion_samples=deque(samples,maxlen=8);c.last_odom_time=100.2
                c.curve_last_drive_time=98.5
                if defect in ('push','rotate'):
                    x,y,h=STOP
                    moved=(x+.06,y,h) if defect=='push' else (x,y,h+.12)
                    c.curve_motion_samples.append((999500000000,*moved))
                # V26 permits up to .80 s only for cached ZERO-drive holding;
                # .81 s remains a disconnect, not evidence of current stop.
                elif defect=='source_gap':c.curve_motion_samples.append((1000160000000,*STOP))
                elif defect=='regress':c.curve_motion_samples=deque(samples[:-1],maxlen=8)
                elif defect=='clock_back':self.ros_time=999.99
                elif defect=='clock_jump':self.ros_time=1000.4
                elif defect=='drive':c.curve_last_drive_time=100.1
                else:c.last_odom_time=self.now-.81
                self.assertFalse(c.curve_first_preposition_still(state,self.now))
                self.assertNotIn('first_standstill_proof',state)

    def test_still_sliding_or_no_original_proof_cannot_gain_zero_hold(self):
        c=self.c
        samples=list(c.curve_motion_samples)
        for i,s in enumerate(samples):samples[i]=(s[0],STOP[0]+i*.03,STOP[1],STOP[2])
        c.curve_motion_samples=deque(samples,maxlen=8)
        self.assertFalse(c.curve_recovery_stopped(self.now))
        command=c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertIsNone(c.curve_recovery_state)
        self.assertIsNone(c.curve_recovery_hold_command(self.now))

    def test_cached_first_proof_is_unavailable_in_second_cone(self):
        state=self.presteer();self.c.phase=self.c.ORBIT_CONE_2
        self.now+=.2;self.ros_time+=.2
        self.assertIsNone(self.c.curve_recovery_hold_command(self.now))
        self.assertNotIn('first_standstill_proof',state)

    def test_new_raw_obstacle_still_blocks_after_successful_preposition(self):
        self.presteer()
        for _ in range(2):self.tick(.3,new_source=True)
        self.now+=.1;self.ros_time+=.1;self.source(self.ros_time-.65,STOP);self.inputs(STOP)
        steer=self.c.curve_recovery_state['steer']
        arc=core.constant_steer_horizon(STOP,steer,5.,distance=.65,initial_steer=steer)
        x,y=core.local(arc[15],STOP);scan=self.c.curve_scan
        k=round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment)%len(scan.ranges)
        scan.ranges[k]=math.hypot(x,y)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)


if __name__=='__main__':unittest.main(verbosity=2)
