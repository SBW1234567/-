#!/usr/bin/env python3
"""Real ROS controller/shebang smoke test; starts no driver or sensor node."""
import argparse
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',type=Path,default=Path('/home/bianbu/racecar'))
    parser.add_argument('--report',type=Path,default=Path('/tmp/real_ros_startup_v35_21.json'))
    parser.add_argument('--seconds',type=float,default=8.)
    args=parser.parse_args()
    if not 2.<=args.seconds<=30.:parser.error('--seconds must be between 2 and 30')

    # Set isolation BEFORE importing any ROS library in this parent process.
    os.environ['ROS_DOMAIN_ID']='217'
    os.environ['ROS_LOCALHOST_ONLY']='1'
    workspace=args.workspace.resolve()
    executable=workspace/'install/racecar/lib/racecar/race_task_controller.py'
    installed_yaml=workspace/'install/racecar/share/racecar/config/competition_params.yaml'
    params=installed_yaml if installed_yaml.is_file() else workspace/'src/racecar/config/competition_params.yaml'
    topic='/codex_validation/proposed_cmd_vel'
    command=[str(executable),'--ros-args','--params-file',str(params)]
    for value in ('dry_run:=true','curve_route:=true','relative_route:=true',
                  'exit_continuous:=true','entry_v32_enabled:=true',
                  'entry_v33_enabled:=true','entry_v34_enabled:=true'):
        command.extend(('-p',value))
    # dry_run overrides final_cmd_topic to /race/proposed_cmd_vel internally.
    command.extend(('-r','/race/proposed_cmd_vel:='+topic,
                    '-r','/car_cmd_vel:=/codex_validation/unused_cmd_vel'))
    report=dict(passed=False,workspace=str(workspace),executable=str(executable),
        params_file=str(params),command=command,ros_domain_id=217,localhost_only=True,
        driver_started=False,sensors_started=False,physical_command_topic_used=False,
        observe_seconds=args.seconds,twist_messages=0,nonzero_commands=[],
        task_phase_messages=[],route_phases=[],control_states=[],errors=[])
    child=None;listener=None;rclpy=None;output=''
    with tempfile.TemporaryFile(mode='w+b') as logfile:
        try:
            if not executable.is_file():raise RuntimeError('Installed controller is missing')
            if not params.is_file():raise RuntimeError('Vehicle parameter YAML is missing')
            if not os.access(executable,os.X_OK):raise RuntimeError('Installed controller is not executable')
            raw=executable.read_bytes();first=raw.partition(b'\n')[0]
            if not raw.startswith(b'#!') or b'\r' in first:
                raise RuntimeError('Installed controller has an invalid POSIX shebang')
            import rclpy as real_rclpy
            from rclpy.node import Node
            from geometry_msgs.msg import Twist
            from std_msgs.msg import String
            rclpy=real_rclpy;rclpy.init(args=[])
            listener=Node('codex_v35_21_startup_observer')

            def twist(msg):
                report['twist_messages']+=1
                values=[msg.linear.x,msg.linear.y,msg.linear.z,
                        msg.angular.x,msg.angular.y,msg.angular.z]
                if any(not math.isfinite(v) or abs(v)>1e-12 for v in values):
                    report['nonzero_commands'].append(values)

            def phase(msg):
                if msg.data not in report['task_phase_messages']:
                    report['task_phase_messages'].append(msg.data)

            def route(msg):
                # STARTUP is assigned in the constructor; the task_phase topic
                # only emits later transitions. The heartbeat proves its value.
                match=re.search(r'(?:^|\s)phase=([^\s]+)',msg.data)
                if match and match.group(1) not in report['route_phases']:
                    report['route_phases'].append(match.group(1))

            def state(msg):
                if msg.data not in report['control_states']:
                    report['control_states'].append(msg.data)

            subscriptions=[listener.create_subscription(Twist,topic,twist,10),
                listener.create_subscription(String,'/race/task_phase',phase,10),
                listener.create_subscription(String,'/race/route_status',route,10),
                listener.create_subscription(String,'/race/control_state',state,10)]
            child=subprocess.Popen(command,env=dict(os.environ),cwd=str(workspace),
                stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
            report['pid']=child.pid;started=time.monotonic()
            while time.monotonic()-started<args.seconds and child.poll() is None:
                rclpy.spin_once(listener,timeout_sec=.10)
            report['observed_seconds']=time.monotonic()-started
            report['alive_after_observation']=child.poll() is None
            report['published_topics']=[name for name,_ in listener.get_topic_names_and_types()]
            if not report['alive_after_observation']:report['errors'].append('Controller exited before observation finished')
            if report['twist_messages']<3:report['errors'].append('No sustained main-loop zero-command publications')
            if report['nonzero_commands']:report['errors'].append('Unexpected nonzero dry-run command')
            if not (report['task_phase_messages'] or report['route_phases']):
                report['errors'].append('No phase transition or route heartbeat observed')
            if '/car_cmd_vel' in report['published_topics']:
                report['errors'].append('Unexpected physical command topic in isolated domain')
        except Exception as exc:
            report['errors'].append(type(exc).__name__+': '+str(exc))
        finally:
            if child is not None:
                if child.poll() is None:
                    child.send_signal(signal.SIGINT)
                    try:child.wait(timeout=3.)
                    except subprocess.TimeoutExpired:
                        report['errors'].append('SIGINT did not release controller within three seconds')
                        os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3.)
                report['returncode']=child.returncode
                report['child_exited']=child.poll() is not None
                if child.returncode not in (0,130):report['errors'].append('Unexpected controller return code: '+str(child.returncode))
            if listener is not None:listener.destroy_node()
            if rclpy is not None and rclpy.ok():rclpy.shutdown()
            logfile.seek(0);output=logfile.read().decode('utf-8',errors='replace')
            report['controller_output']=output
            if 'Traceback (most recent call last)' in output:
                report['errors'].append('Controller raised a traceback during startup or shutdown')
            report['passed']=not report['errors']
            args.report.parent.mkdir(parents=True,exist_ok=True)
            args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed=report['passed'],twist_messages=report['twist_messages'],
        route_phases=report['route_phases'],returncode=report.get('returncode'),
        errors=report['errors'],report=str(args.report)),ensure_ascii=False),flush=True)
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
