"""Ray-cast board geometry for the post-crosswalk wall-fit tolerances."""
import math
from pathlib import Path
import sys
import types
import unittest

SCRIPTS=Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import race_curve_core as core


def scan_segments(segments):
    """Nearest ray intersection with finite physical board segments."""
    n=720;increment=2*math.pi/n;ranges=[]
    for i in range(n):
        dx,dy=math.cos(i*increment),math.sin(i*increment)
        hits=[]
        for (ax,ay),(bx,by) in segments:
            sx,sy=bx-ax,by-ay
            determinant=dx*sy-dy*sx
            if abs(determinant)<1e-12:continue
            distance=(ax*sy-ay*sx)/determinant
            along=(ax*dy-ay*dx)/determinant
            if distance>0. and 0.<=along<=1.:hits.append(distance)
        ranges.append(min(hits) if hits else math.inf)
    return types.SimpleNamespace(ranges=ranges,angle_min=0.,angle_increment=increment,
                                 range_min=.05,range_max=12.)


def straight_board(side=-1,distance=.9,heading=0.,lo=-2.,hi=2.):
    slope=math.tan(math.radians(heading))
    intercept=side*distance/math.cos(math.radians(heading))
    return scan_segments([((lo,intercept+slope*lo),(hi,intercept+slope*hi))])


def joined_board(bend=8.,gap=.0,distance=.72):
    # Right-side horizontal rear board, then a mildly angled front board.
    x=.35;y=-distance;slope=math.tan(math.radians(bend))
    return scan_segments([((-2.,y),(x,y)),
                          ((x,y+gap),(2.,y+gap+slope*(2.-x)))])


class UnevenWallTests(unittest.TestCase):
    def test_logged_distance_beyond_old_75cm_fit_recovers(self):
        for distance in (.78,.90,1.04):
            with self.subTest(distance=distance):
                scan=straight_board(distance=distance)
                self.assertIsNone(core.nearby_wall(scan,-1))
                self.assertIsNone(core.local_wall_direction(scan,-1)['near'])
                wall=core.nearby_wall(scan,-1,uneven=True)
                self.assertIsNotNone(wall)
                self.assertAlmostEqual(wall[0],distance,places=5)
                direction=core.local_wall_direction(scan,-1,uneven=True)
                self.assertIsNotNone(direction['near'])
                self.assertEqual(direction['weight'],1.)

    def test_tilted_boards_22_degrees_both_sides(self):
        for side in (-1,1):
            for heading in (-22.,22.):
                with self.subTest(side=side,heading=heading):
                    scan=straight_board(side=side,heading=heading)
                    self.assertIsNone(core.nearby_wall(scan,side))
                    self.assertIsNone(core.local_wall_direction(scan,side)['near'])
                    wall=core.nearby_wall(scan,side,uneven=True)
                    self.assertIsNotNone(wall)
                    self.assertAlmostEqual(math.degrees(wall[1]),heading,places=5)
                    direction=core.local_wall_direction(scan,side,uneven=True)
                    self.assertIsNotNone(direction['near'])
                    self.assertAlmostEqual(math.degrees(direction['near'][1]),heading,places=5)

    def test_mild_joined_board_bend_has_independent_segment_support(self):
        scan=joined_board(distance=.60)
        self.assertIsNotNone(core.nearby_wall(scan,-1,uneven=True))
        relaxed=core.local_wall_direction(scan,-1,uneven=True)
        self.assertIsNotNone(relaxed['near'])
        self.assertIsNotNone(relaxed['rear'])
        self.assertIsNotNone(relaxed['ahead'])
        self.assertEqual(relaxed['weight'],1.)
        self.assertEqual(relaxed['reason'],'SEGMENTS_AGREE')
        strict=core.local_wall_direction(scan,-1)
        self.assertLess(strict['weight'],relaxed['weight'])

    def test_small_board_joint_step_still_fits_local_wall(self):
        scan=joined_board(bend=6.,gap=.02)
        self.assertIsNotNone(core.nearby_wall(scan,-1,uneven=True))
        direction=core.local_wall_direction(scan,-1,uneven=True)
        self.assertIsNotNone(direction['near'])
        self.assertTrue(any(direction[key] is not None for key in ('rear','ahead')))
        self.assertGreater(direction['weight'],0.)

    def test_large_join_offset_does_not_become_full_supported_direction(self):
        direction=core.local_wall_direction(joined_board(bend=0.,gap=.20),-1,uneven=True)
        self.assertLess(direction['weight'],1.)

    def test_steep_35_degree_geometry_rejected(self):
        for side in (-1,1):
            for heading in (-35.,35.):
                scan=straight_board(side=side,distance=.7,heading=heading)
                self.assertIsNone(core.nearby_wall(scan,side,uneven=True))
                self.assertIsNone(core.local_wall_direction(scan,side,uneven=True)['near'])

    def test_far_arena_wall_rejected(self):
        scan=straight_board(distance=1.4)
        self.assertIsNone(core.nearby_wall(scan,-1,uneven=True))
        self.assertIsNone(core.local_wall_direction(scan,-1,uneven=True)['near'])

    def test_short_flat_clutter_cannot_supply_wall_support(self):
        scan=straight_board(distance=.55,lo=.15,hi=.33)
        self.assertIsNone(core.nearby_wall(scan,-1,uneven=True))
        self.assertIsNone(core.local_wall_direction(scan,-1,uneven=True)['near'])

    def test_small_cone_surface_cannot_become_side_wall(self):
        cx,cy,r=.25,-.55,.09
        vertices=[(cx+r*math.cos(i*2*math.pi/64),cy+r*math.sin(i*2*math.pi/64))
                  for i in range(64)]
        scan=scan_segments(list(zip(vertices,vertices[1:]+vertices[:1])))
        self.assertIsNone(core.nearby_wall(scan,-1,uneven=True))
        self.assertIsNone(core.local_wall_direction(scan,-1,uneven=True)['near'])

    def test_original_default_and_entry_behavior_stays_available(self):
        scan=straight_board(distance=.90)
        self.assertIsNone(core.nearby_wall(scan,-1))
        self.assertIsNotNone(core.nearby_wall(scan,-1,entry=True))
        scan=straight_board(distance=.45,heading=4.)
        self.assertIsNotNone(core.nearby_wall(scan,-1))
        self.assertEqual(core.local_wall_direction(scan,-1)['weight'],1.)


if __name__=='__main__':unittest.main(verbosity=2)
