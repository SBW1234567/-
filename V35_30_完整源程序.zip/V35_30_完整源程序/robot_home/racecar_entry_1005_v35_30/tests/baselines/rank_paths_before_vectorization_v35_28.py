"""Frozen pre-batching V28 route scorer, explicit equivalence reference."""
def rank_paths(self, paths):
    """Optional bounded clearance ranking of certified first-cone routes.

    Sampled padded footprints are scored against the frozen map. This
    deliberately does not certify or veto a route: unknown coverage,
    unavailable maps, negligible improvements or budget overruns select
    the default candidate. It neither waits for loading nor changes the
    concurrent registration helper's diagnostic state.
    """
    started=_map_time.perf_counter()
    detail=dict(state='NOT_READY',profile_id=self._profile_id,selected_index=0,
                candidates=min(len(paths),4),scores=[],budget_ms=30.)
    if not self.ready or len(paths)<2:
        if self.ready:detail['state']='SINGLE_CANDIDATE'
        return 0,detail
    deadline=started+.030
    # A small interior grid includes both the perimeter and body interior.
    # This is only a route preference; the full-resolution live sweep is
    # unchanged. Dimensions match the existing .08m padded raw check.
    xx,yy=np.meshgrid(np.linspace(-.265,.28,7),np.linspace(-.23,.23,7))
    body=np.column_stack((xx.ravel(),yy.ravel()))
    for path in paths[:4]:
        if _map_time.perf_counter()>=deadline:
            detail['state']='BUDGET_EXPIRED';return 0,detail
        samples=np.asarray(path.samples,dtype=float)
        if samples.ndim!=2 or samples.shape[0]<321 or samples.shape[1]<3 or not np.isfinite(samples[:321,:3]).all():
            detail['state']='INVALID_PATH';return 0,detail
        poses=samples[np.arange(0,321,4),:3]
        cs,sn=np.cos(poses[:,2]),np.sin(poses[:,2])
        x=poses[:,0,None]+cs[:,None]*body[None,:,0]-sn[:,None]*body[None,:,1]
        y=poses[:,1,None]+sn[:,None]*body[None,:,0]+cs[:,None]*body[None,:,1]
        course=np.column_stack((x.ravel(),y.ravel()))
        mc,ms=_map_math.cos(self._transform[2]),_map_math.sin(self._transform[2])
        mapped=course@np.array([[mc,ms],[-ms,mc]])+self._transform[:2]
        values,known=self._values(mapped[:,0],mapped[:,1])
        known &= self._inside(course,self._course_polygon)
        for polygon in self._excludes:known &= ~self._inside(mapped,polygon)
        coverage=float(np.mean(known))
        if coverage<.98:
            detail['state']='INSUFFICIENT_MAP_COVERAGE';return 0,detail
        # Unknown points cannot increase the apparent clearance.
        values=np.where(known,values,0.).reshape(len(poses),len(body))
        clearance=np.min(values,axis=1)
        minimum=float(np.min(clearance));lower=float(np.quantile(clearance,.15))
        score=minimum+.25*lower+.05*float(np.mean(clearance))
        detail['scores'].append(dict(min_clearance_m=minimum,lower_clearance_m=lower,
            score_m=score,known_fraction=coverage,poses=len(poses),points_per_pose=len(body)))
    detail['elapsed_ms']=1000.*(_map_time.perf_counter()-started)
    if _map_time.perf_counter()>=deadline:
        detail['state']='BUDGET_EXPIRED';return 0,detail
    values=[s['score_m'] for s in detail['scores']]
    selected=int(np.argmax(values))
    improvement=values[selected]-values[0]
    detail['improvement_m']=improvement
    if selected and improvement>=.015:
        detail.update(state='MAP_CLEARANCE_PREFERRED',selected_index=selected)
        return selected,detail
    detail['state']='DEFAULT_CLEARANCE_PREFERRED'
    return 0,detail
