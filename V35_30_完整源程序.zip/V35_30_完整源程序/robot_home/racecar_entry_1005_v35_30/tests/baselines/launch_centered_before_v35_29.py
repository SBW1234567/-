#!/usr/bin/env python3
"""Persist one observed midpoint and run the verified V27 driver/competition."""
import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from lidar_settings import read_correction, checked
from guard_settings import read_guards, validate_guards
from straight_settings import read_straight, validate_straight
from band_settings import read_band, validate_band


def midpoint(value):
    try:
        n = float(value)
    except (ValueError, TypeError):
        raise ValueError('Midpoint must be an integer PWM value between 1400 and 1600.')
    if isinstance(value, bool) or not math.isfinite(n) or not 1400 <= n <= 1600 or n != round(n):
        raise ValueError('Midpoint must be an integer PWM value between 1400 and 1600.')
    return int(n)


def settings_path():
    return Path.home()/'.config/racecar/steering_center.json'


def read_midpoint(path):
    if not path.exists():
        return 1500
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema') != 1:
        raise ValueError('Unknown steering settings schema.')
    return midpoint(data['steering_midpoint_pwm'])


def save_midpoint(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps({'schema': 1, 'steering_midpoint_pwm': midpoint(value)}, indent=2)+'\n', encoding='utf-8')
    temporary.replace(path)


def select_map_profile(value, package):
    """Resolve a replaceable profile without adding a prerequisite to driving."""
    requested = str(value).strip() if value is not None else str(package/'maps/lab_20261003/profile.json')
    if requested.lower() == 'off':
        return 'off', 'disabled by selection'
    if not requested:
        return 'off', 'empty profile selection'
    path = Path(requested).expanduser()
    try:
        if path.is_dir():
            path = path/'profile.json'
        path = path.resolve()
        if not path.is_file():
            return 'off', 'profile missing: '+str(path)
        return str(path), 'profile selected; controller validates its contents'
    except (OSError, RuntimeError, ValueError) as exc:
        return 'off', 'profile unavailable: '+str(exc)


def make_command(mode, root, value, dry_run, prepare_drive=.35, stop_at_entry=False, lidar_yaw=0.0, guards=None, straight=None, band=None):
    lidar_yaw = checked(lidar_yaw)
    if mode == 'scan':
        return ['ros2', 'launch', 'racecar', 'race_lidar_aligned.launch.py',
                f'lidar_yaw_correction_deg:={lidar_yaw}']
    if mode == 'center':
        return [str(root/'install/racecar_driver/lib/racecar_driver/racecar_driver_node'),
                '--ros-args', '-p', f'steering_midpoint_pwm:={value:.1f}',
                '-p', 'steering_center_only:=true', '-p', 'startup_center_sec:=3.0']
    guards = validate_guards(guards if guards is not None else {
        'side_distance_guard_enabled': True, 'side_steering_guard_enabled': True,
        'exit_front_stop_distance': .85})
    guard_args = [f'{key}:={str(value).lower()}' for key, value in guards.items()]
    straight = validate_straight(read_straight() if straight is None else straight)
    straight_args = [f'{key}:={str(value).lower()}' for key, value in straight.items()]
    band = validate_band(read_band() if band is None else band)
    if band['lane_parallel_band_enabled'] and not straight['bounded_heading_control']:
        raise ValueError('Parallel band requires bounded_heading_control=true in V29 settings')
    band_args = [f'{key}:={str(value).lower()}' for key, value in band.items()]
    return ['bash', str(root/'race_competition.sh'), 'no_rviz:=true', 'enable_slam:=false',
            'relative_route:=true', 'curve_route:=true', 'exit_continuous:=true',
            'entry_v32_enabled:=true', 'entry_v33_enabled:=true', 'entry_v34_enabled:=true', 'test_stop_after_exit:=false',
            'layout_8x4:=false', 'layout_auto_start:=false',
            'layout_rear_extent:=0.185', 'layout_front_extent:=0.20', 'layout_half_width:=0.15',
            f'lidar_yaw_correction_deg:={lidar_yaw}', f'entry_prepare_drive:={prepare_drive}', f'test_stop_after_entry:={str(stop_at_entry).lower()}',
            f'dry_run:={dry_run}', f'steering_midpoint_pwm:={value:.1f}', 'startup_center_sec:=3.0'] + guard_args + straight_args + band_args


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['center', 'run', 'scan'])
    parser.add_argument('workspace', type=Path)
    parser.add_argument('--midpoint', type=midpoint)
    parser.add_argument('--dry-run', choices=['true', 'false'], default='true')
    parser.add_argument('--prepare-drive', type=float, default=.35)
    parser.add_argument('--stop-at-entry', action='store_true')
    args = parser.parse_args()
    if not math.isfinite(args.prepare_drive) or args.prepare_drive != .35:
        parser.error('V35 uses the verified 0.35 input; lower inputs have not been calibrated on this car')
    if args.mode != 'center' and args.midpoint is not None:
        parser.error('Adjust midpoint with center.sh first.')
    root = args.workspace.resolve()
    package = Path(__file__).resolve().parent
    from apply_patch import active_race_processes
    running = active_race_processes()
    if running:
        raise SystemExit('Stop the existing driver/competition with Ctrl+C first. PIDs: ' + ', '.join(running))
    # Prevent two copies of these new runners from starting simultaneously.
    import fcntl
    config = settings_path()
    config.parent.mkdir(parents=True, exist_ok=True)
    lock = os.open(str(config.with_suffix('.lock')), os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('A centred runner is already active; stop it with Ctrl+C first.')
    os.set_inheritable(lock, True)
    subprocess.run([sys.executable, str(package/'apply_patch.py'), '--workspace', str(root), '--verify-install'], check=True)
    if args.mode == 'run':
        profile, profile_note = select_map_profile(os.environ.get('RACECAR_MAP_PROFILE'), package)
        os.environ['RACECAR_MAP_PROFILE'] = profile
    guards = read_guards() if args.mode == 'run' else None
    straight = read_straight() if args.mode == 'run' else None
    band = read_band() if args.mode == 'run' else None
    lidar_yaw = read_correction() if args.mode != 'center' else 0.0
    value = read_midpoint(config) if args.midpoint is None else args.midpoint
    if args.mode == 'center':
        save_midpoint(config, value)
        print(f'CENTER ONLY: motor neutral, steering PWM={value}. Saved in {config}. Ctrl+C to stop.', flush=True)
    elif args.mode == 'scan':
        print(f'LIDAR ONLY: correction={lidar_yaw:+.3f} deg. Motor/servo driver is not started.', flush=True)
    else:
        print(f'GUARD SETTINGS: {guards}', flush=True)
        print(f'STRAIGHT SETTINGS: {straight}', flush=True)
        print(f'PARALLEL BAND SETTINGS: {band}', flush=True)
        print(f'MAP ASSIST: {profile}; {profile_note}', flush=True)
        print(f'V35.28 FIRST_CONE_CLEARANCE_1004_V35_28 lidar correction={lidar_yaw:+.3f} deg; entry preparation: steering PWM={value}, centre hold=3 sec, dry_run={args.dry_run}', flush=True)
    os.chdir(root)
    command = make_command(args.mode, root, value, args.dry_run, args.prepare_drive, args.stop_at_entry, lidar_yaw, guards, straight, band)
    os.execvp(command[0], command)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, subprocess.CalledProcessError) as exc:
        raise SystemExit(str(exc))
