#!/usr/bin/env python3
"""ROS-free V11 geometry, laser registration and path feedback.

Metres/radians refer to the laser frame. Steering/speed outputs are the existing
driver's dimensionless inputs. Defaults are engineering values, not calibration.
"""
import math
import copy
import time
from dataclasses import dataclass
from statistics import median
import numpy as np


class PlanningInterrupted(RuntimeError):
    def __init__(self, reason, elapsed_ms=0.0):
        super().__init__(reason)
        self.reason = reason
        self.elapsed_ms = elapsed_ms


def clip(x, lo, hi): return max(lo, min(hi, x))
def wrap(x): return math.atan2(math.sin(x), math.cos(x))
def dist(a, b): return math.hypot(a[0]-b[0], a[1]-b[1])
def world(p, pose):
    c,s=math.cos(pose[2]),math.sin(pose[2])
    return (pose[0]+c*p[0]-s*p[1],pose[1]+s*p[0]+c*p[1])
def local(p, pose):
    c,s=math.cos(pose[2]),math.sin(pose[2]);x,y=p[0]-pose[0],p[1]-pose[1]
    return (c*x+s*y,-s*x+c*y)


WALLS=(((0.,0.),(8.,0.)),((8.,0.),(8.,4.)),((8.,4.),(0.,4.)),
       ((0.,4.),(0.,0.)),((0.,.9),(3.2,.9)),((4.8,3.1),(8.,3.1)))
CONES=((6.,2.),(2.,2.))


def register_scan(locator, scan, received, yaw, seed):
    """Worker-only registration on a private locator; preserve observation time."""
    started=time.perf_counter()
    ranges=np.asarray(scan.ranges,dtype=float)
    valid=np.isfinite(ranges)&(ranges>=max(scan.range_min,.30))&(ranges<=min(9.,scan.range_max))
    angles=scan.angle_min+np.flatnonzero(valid)*scan.angle_increment
    radii=ranges[valid]
    points=np.column_stack((radii*np.cos(angles),radii*np.sin(angles)))
    accepted=locator.update(points,received,yaw,seed)
    return locator,accepted,time.perf_counter()-started


def segment_distance(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=clip(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/max(dx*dx+dy*dy,1e-12),0,1)
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)


def segment_box(a,b,rear,front,half):
    """Liang-Barsky intersection, including contact with padded body."""
    lo,hi=0.,1.
    for p,q in ((-(b[0]-a[0]),a[0]+rear),(b[0]-a[0],front-a[0]),
                (-(b[1]-a[1]),a[1]+half),(b[1]-a[1],half-a[1])):
        if abs(p)<1e-12:
            if q<0:return False
        elif p<0:lo=max(lo,q/p)
        else:hi=min(hi,q/p)
        if lo>hi:return False
    return True


def body_clear(pose,cones=CONES,margin=.10,front=.20,rear=.185,half=.15):
    for a,b in WALLS:
        if segment_box(local(a,pose),local(b,pose),rear+margin,front+margin,half+margin):
            return False
    # Cone radius includes uncertainty in the cluster centre and footprint.
    for cone in cones:
        x,y=local(cone,pose)
        dx=max(-rear-x,0.,x-front);dy=max(abs(y)-half,0.)
        if math.hypot(dx,dy)<=.20+margin:return False
    return .2<pose[0]<7.8 and .2<pose[1]<3.8


def path_body_clear(samples,cones=CONES,margin=.10,front=.20,rear=.185,half=.15):
    """Batch the same padded-box/segment and cone checks; no subsampling."""
    poses=np.asarray(samples,dtype=float)
    if (not np.isfinite(poses).all() or not np.all((poses[:,0]>.2)&(poses[:,0]<7.8)
            &(poses[:,1]>.2)&(poses[:,1]<3.8))):return False
    c,s=np.cos(poses[:,2]),np.sin(poses[:,2])
    def transform(point):
        dx=point[0]-poses[:,0];dy=point[1]-poses[:,1]
        return c*dx+s*dy,-s*dx+c*dy
    for a,b in WALLS:
        ax,ay=transform(a);bx,by=transform(b)
        lo=np.zeros(len(poses));hi=np.ones(len(poses));possible=np.ones(len(poses),dtype=bool)
        for p,q in ((-(bx-ax),ax+rear+margin),(bx-ax,front+margin-ax),
                    (-(by-ay),ay+half+margin),(by-ay,half+margin-ay)):
            parallel=np.abs(p)<1e-12
            possible &= ~(parallel & (q<0))
            ratio=np.divide(q,p,out=np.zeros_like(q),where=~parallel)
            lo=np.where((~parallel)&(p<0),np.maximum(lo,ratio),lo)
            hi=np.where((~parallel)&(p>0),np.minimum(hi,ratio),hi)
        if np.any(possible & (lo<=hi)):return False
    for cone in cones:
        x,y=transform(cone)
        dx=np.maximum(np.maximum(-rear-x,0.),x-front);dy=np.maximum(np.abs(y)-half,0.)
        if np.any(np.hypot(dx,dy)<=.20+margin):return False
    return True


def quintic(a,b,va,vb,aa=(0,0),ab=(0,0),n=160):
    """Hermite segment with shared endpoint first and second derivatives.

    Adjacent segments share position/first/second derivatives (C2), not merely
    a visual tangent. Curvature and body clearance are checked after sampling.
    """
    a,b,va,vb,aa,ab=map(lambda x:np.asarray(x,dtype=float),(a,b,va,vb,aa,ab))
    r0=b-a-va-aa/2;r1=vb-va-aa;r2=ab-aa
    c3=10*r0-4*r1+r2/2;c4=-15*r0+7*r1-r2;c5=6*r0-3*r1+r2/2
    t=np.linspace(0,1,n,endpoint=False)[:,None]
    p=a+va*t+aa*t*t/2+c3*t**3+c4*t**4+c5*t**5
    v=va+aa*t+3*c3*t**2+4*c4*t**3+5*c5*t**4
    acc=aa+6*c3*t+12*c4*t**2+20*c5*t**3
    speed=np.linalg.norm(v,axis=1)
    if min(speed)<.05:raise ValueError('PATH_CUSP')
    k=(v[:,0]*acc[:,1]-v[:,1]*acc[:,0])/speed**3
    return np.column_stack((p,np.arctan2(v[:,1],v[:,0]),k))


@dataclass
class Path:
    samples: np.ndarray
    lengths: np.ndarray
    gates: tuple
    max_curvature: float


def make_path(start,cones=CONES,tangents=None,min_radius=.55,check_body=True,first_pass_offset=.05,checkpoint=None,
              first_east_offset=1.02,first_north_offset=(-.15,.70),first_north_cap=2.75,
              segment_tangents=None,knot_curvatures=None,
              second_west_offset=(-1.02,.05),upper_join=(2.1,3.55),second_exit_profile=False):
    if checkpoint is not None:checkpoint()
    c1,c2=cones
    tangents=tangents or (2.55,1.905,1.324,1.328,1.878,3.118,1.972)
    curvatures=knot_curvatures or (0.,1.20,1.10,-1.10,-1.20,-.60,0.)
    ends=segment_tangents or tuple((tangents[i],tangents[i+1]) for i in range(6))
    if second_exit_profile:
        # Keep both first-cone segments exactly as requested. Construct the
        # second-cone turn once, without the fallback's near-straight/reverse
        # curvature patch while the car is still facing the upper wall.
        # Carry the west-side tangent north before finishing the bend. This
        # retains the existing checked recovery arcs from an outward heading
        # error; moving the same tangent south made those arcs miss the new
        # reference by >30 cm even though the board/raw sweeps were clear.
        second_west_offset=(-.97,.60);upper_join=(2.4,3.55)
        ends=tuple(ends[:3])+((1.8,2.2),(1.8,2.4),(2.4,1.972))
        curvatures=tuple(curvatures[:3])+(-.80,-1.20,0.,0.)
    # The north side of cone 1 stays BELOW the upper divider; the south side
    # of cone 2 stays ABOVE the lower divider. The final leg goes around its
    # free end before joining the upper traffic-light corridor.
    knots=[tuple(start[:2]),(c1[0]+first_east_offset,c1[1]-first_pass_offset),
           (c1[0]+first_north_offset[0],min(first_north_cap,c1[1]+first_north_offset[1])),
           (c2[0]+.15,max(1.25,c2[1]-.70)),
           (c2[0]+second_west_offset[0],c2[1]+second_west_offset[1]),
           tuple(upper_join),(5.45,3.55)]
    headings=[start[2],math.pi/2,math.pi,math.pi,math.pi/2,0.,0.]
    # The follower uses arc length. Different endpoint parameter speeds are
    # allowed, while shared position, heading and curvature preserve G2
    # continuity. Equal parameter speeds retain the original C2 construction.
    pieces=[]
    for i,(va,vb) in enumerate(ends):
        ha,hb=headings[i:i+2];ka,kb=curvatures[i:i+2]
        pieces.append(quintic(knots[i],knots[i+1],
            (va*math.cos(ha),va*math.sin(ha)),(vb*math.cos(hb),vb*math.sin(hb)),
            (-ka*va*va*math.sin(ha),ka*va*va*math.cos(ha)),
            (-kb*vb*vb*math.sin(hb),kb*vb*vb*math.cos(hb))))
    samples=np.vstack(pieces+[np.array([[*knots[-1],headings[-1],0.]])])
    lengths=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(samples[:,:2],axis=0),axis=1))]
    if np.max(np.diff(lengths))>.055:raise ValueError('PATH_SAMPLE_GAP')
    maximum=float(np.max(np.abs(samples[:,3])))
    if maximum>1/min_radius:raise ValueError('PATH_CURVATURE')
    if second_exit_profile and np.max(samples[480:801,3])>.003:
        raise ValueError('PATH_SECOND_REVERSE_CURVATURE')
    if checkpoint is not None:checkpoint()
    if check_body and not path_body_clear(samples,cones):raise ValueError('PATH_BODY_CLEARANCE')
    path=Path(samples,lengths,tuple(float(lengths[i*160]) for i in range(1,7)),maximum)
    if second_exit_profile:
        path.upper_exit_start=path.gates[3]
        path.upper_straight_start=path.gates[4]
        path.upper_exit_family='COMPACT_CLOCKWISE_ZERO_CURVATURE_JOIN'
    return path


def plan_path(start,cones=CONES,min_radius=.55,checkpoint=None,second_exit_profile=False):
    """Bounded deterministic search over shared tangent magnitudes.

    Cone movements do not force the nominal curve's curvature onto a tighter
    passage. Bounded coordinate search; no threshold relaxation on failure.
    """
    if checkpoint is not None:checkpoint()
    base=np.array([2.55,1.905,1.324,1.328,1.878,3.118,1.972])
    try:return make_path(start,cones,tuple(base),min_radius,checkpoint=checkpoint,
                         second_exit_profile=second_exit_profile)
    except ValueError:pass
    def evaluate(v):
        if checkpoint is not None:checkpoint()
        try:
            p=make_path(start,cones,tuple(v),.01,False,checkpoint=checkpoint,
                        second_exit_profile=second_exit_profile)
            peaks=[float(np.max(abs(p.samples[i*160:(i+1)*160,3]))) for i in range(6)]
            score=sum(max(0.,k-1/min_radius)**2 for k in peaks)+.002*sum(k*k for k in peaks)
            return score,p
        except ValueError:return math.inf,None
    score,path=evaluate(base)
    for delta in (.12,.08,.05):
        for j in range(7):
            for sign in (-1,1):
                v=base.copy();v[j]+=sign*delta
                value,p=evaluate(v)
                if value<score:score,path,base=value,p,v
        if (path is not None and path.max_curvature<=1/min_radius and
                path_body_clear(path.samples,cones)):return path
    raise ValueError('PATH_NO_FEASIBLE_CURVE')


def _plan_check(cancel=None, deadline=None, started=None):
    if cancel is not None and cancel.is_set():
        elapsed=1000.*(time.monotonic()-started) if started is not None else 0.0
        raise PlanningInterrupted('PLAN_CANCELLED_REFERENCE_EXPIRED', elapsed)
    if deadline is not None and time.monotonic()>deadline:
        elapsed=1000.*(time.monotonic()-started) if started is not None else 0.0
        raise PlanningInterrupted('PLAN_DEADLINE', elapsed)


def plan_entry_path(start,cones=CONES,min_radius=.55,cancel=None,deadline=None):
    """Try wider entry poses without changing radius or body clearance limits."""
    started=time.monotonic()
    def checkpoint():_plan_check(cancel,deadline,started)
    def done(path):
        checkpoint()
        path.planning_ms=1000.*(time.monotonic()-started)
        return path
    def build(*args,**kwargs):
        return make_path(*args,**kwargs,second_exit_profile=True)
    checkpoint()
    # Turn before reaching the north divider. The incoming leg and the east
    # quarter-turn need different parameter speeds; sharing one tangent
    # magnitude forced the old first leg to peak near 1.7/m. Keep the complete
    # body/radius certificate and cap the first half-orbit at 1.35/m. Also
    # reject reverse-curvature approaches: a small absolute curvature alone
    # can hide an initial right turn that wastes the available board clearance.
    east_y=max(1.90,cones[0][1]-.15)
    radius=min(2.70,cones[0][1]+.70)-east_y
    if radius>.60:
        dx=cones[0][0]+1.0-start[0]
        first=round(clip(2.8*dx-2.1,1.6,6.4),1)
        end=round(clip(.7*dx+.9+east_y-(cones[0][1]-.15),1.7,3.0),1)
        profiles=[(first+da,end+db) for da,db in
                  ((0.,0.),(.2,0.),(-.2,0.),(0.,-.1),(.2,-.1),(-.2,-.1),(0.,.1))]
        profiles.extend(((2.4,2.0),(3.5,2.3),(5.0,2.7),(5.8,2.7),(2.0,2.0),(2.2,2.1)))
        for incoming,end in dict.fromkeys(profiles):
            checkpoint()
            try:
                # East-to-north is an approximately circular quarter-turn.
                # Its geometry follows the remaining height below the board,
                # instead of squeezing the same curve into every cone offset.
                path=build(start,cones,min_radius=min_radius,first_pass_offset=cones[0][1]-east_y,checkpoint=checkpoint,
                    first_east_offset=1.0,first_north_offset=(1.0-radius,.70),first_north_cap=2.70,
                    segment_tangents=((incoming,end),(radius*math.pi/2,radius*math.pi/2),(1.8,1.45),
                                      (1.35,2.2),(2.0,2.4),(2.4,1.972)),
                    knot_curvatures=(0.,1./radius,1./radius,-.80,-1.20,0.,0.),
                    second_west_offset=(-1.12,.24),upper_join=(2.3,3.55))
                first_half=path.samples[:321,3]
                peak=float(np.max(np.abs(first_half)));minimum=float(np.min(first_half))
                if peak>1.35 or minimum<-.02:continue
                # Finish the second-cone turn with zero curvature. The old
                # nominally straight join retained -0.6/m and immediately
                # bent back out of the upper corridor. Keep this family only
                # when both outside-cone segments remain one clockwise turn.
                exit_curve=path.samples[480:801,3]
                if np.max(np.abs(exit_curve))>1.35 or np.max(exit_curve)>.003:continue
                path.entry_family='WIDE_FIRST_CONE'
                path.first_half_max_curvature=peak
                path.first_half_min_curvature=minimum
                path.upper_exit_start=path.gates[3]
                path.upper_straight_start=path.gates[4]
                path.upper_exit_family='ZERO_CURVATURE_JOIN'
                return done(path)
            except ValueError:continue
    # Try certified fixed candidates before spending the worker budget on the
    # coordinate optimizer. Preserve the old families for other entry poses.
    try:return done(build(start,cones,min_radius=min_radius,checkpoint=checkpoint))
    except ValueError:pass
    # An early stopped entry needs a longer first tangent AND a longer tangent
    # at the east side of cone 1. The old north-shifted-cone bank tried only
    # first<=2.6 / second<=1.9, so repeating it could never reach this family.
    # Keep the outer passage and all downstream knots; certify the COMPLETE
    # curve with the original radius, spacing, wall and cone body checks.
    if cones[0][0]-start[0]>=1.0:
        for first in (2.8,3.2,3.8,4.4):
            for third,fourth,fifth in ((1.4,1.35,1.75),(1.6,1.328,1.8)):
                checkpoint()
                try:
                    return done(build(start,cones,
                        (first,2.1,third,fourth,fifth,3.118,1.972),min_radius,
                        first_pass_offset=.25,checkpoint=checkpoint))
                except ValueError:continue
    # Only the first two tangent lengths vary; downstream route knots and
    # first-cone outer passage remain unchanged. Every candidate is certified.
    for first in (2.8,3.2,2.2,1.8,1.4,1.0):
        for second in (1.9,1.5,2.2,1.2):
            _plan_check(cancel,deadline,started)
            try:return done(build(start,cones,(first,second,1.324,1.328,1.878,3.118,1.972),min_radius,checkpoint=checkpoint))
            except ValueError:continue
    # A measured cone north of nominal leaves less room below the upper
    # divider. Reach the same outer passage slightly earlier, then use the
    # extra forward space to turn. All walls, cone clearances, sample spacing
    # and minimum radius still apply to every point of the complete route.
    for offset in (.25,.35):
        for first in (2.2,1.8,1.4,2.6):
            for second in (1.7,1.9):
                for fourth,fifth in ((1.328,1.8),(1.35,1.75),(1.45,1.8)):
                    _plan_check(cancel,deadline,started)
                    try:
                        return done(build(start,cones,(first,second,1.4,fourth,fifth,3.118,1.972),
                                         min_radius,first_pass_offset=offset,checkpoint=checkpoint))
                    except ValueError:continue
    try:return done(plan_path(start,cones,min_radius,checkpoint=checkpoint,second_exit_profile=True))
    except ValueError:raise ValueError('ENTRY_NO_FEASIBLE_CURVE')


class WallLocalizer:
    """Bounded point-to-line registration against the handbook's six boards.

    Starts only from a fresh end-board + right-wall observation, never from a
    guessed starting pose or odometry translation. Requires both wall normals
    to constrain x/y; longitudinal corridors alone cannot authorize progress.
    """
    def __init__(self, entry_wide=False):
        self.entry_wide=entry_wide
        self.pose=None;self.time=None;self.yaw=None;self.hits=0
        self.residual=math.inf;self.reason='WAIT_END_AND_SIDE_WALL'

    def update(self,points,now,odom_yaw,seed=None):
        if self.time is not None and now<=self.time:return False
        if len(points)<45:
            self.hits=0;self.reason='WALL_POINTS_MISSING';return False
        points=np.asarray(points,dtype=float)[::2]
        if self.pose is None:
            if seed is None:return False
            guess=np.array(seed,dtype=float)
        else:
            # A new scan may reseed an expired locator. Never keep rejecting
            # every later scan merely because the last successful fit aged.
            if seed is not None:
                guess=np.array(seed,dtype=float)
            elif now-self.time>.4:
                self.reason='WAIT_FRESH_SEED';return False
            else:
                guess=np.array(self.pose,dtype=float)
                if self.yaw is not None:guess[2]+=wrap(odom_yaw-self.yaw)
        origin=guess.copy()
        a=np.asarray([w[0] for w in WALLS]);b=np.asarray([w[1] for w in WALLS])
        v=b-a;length2=(v*v).sum(axis=1);normals=np.column_stack((-v[:,1],v[:,0]))/np.sqrt(length2)[:,None]
        ok=False
        for _ in range(7):
            c,s=math.cos(guess[2]),math.sin(guess[2]);rot=np.array([[c,-s],[s,c]])
            q=points@rot.T+guess[:2]
            # Same finite-segment distances, without the Nx6x2 temporary tensors.
            dx=q[:,0,None]-a[None,:,0];dy=q[:,1,None]-a[None,:,1]
            t=np.clip((dx*v[None,:,0]+dy*v[None,:,1])/length2,0,1)
            dd2=(dx-t*v[None,:,0])**2+(dy-t*v[None,:,1])**2
            idx=np.argmin(dd2,axis=1);mask=dd2[np.arange(len(q)),idx]<.20**2
            n=normals[idx[mask]];p=points[mask];qq=q[mask];aa=a[idx[mask]]
            if len(p)<35 or min(np.sum(abs(n[:,0])>.5),np.sum(abs(n[:,1])>.5))<10:break
            error=((qq-aa)*n).sum(axis=1)
            deriv=np.column_stack((-s*p[:,0]-c*p[:,1],c*p[:,0]-s*p[:,1]))
            jac=np.column_stack((n,(deriv*n).sum(axis=1)))
            weight=np.minimum(1.,.045/np.maximum(abs(error),1e-9))
            matrix=jac.T@(weight[:,None]*jac)
            if np.linalg.cond(matrix)>1500:break
            step=np.linalg.solve(matrix,-jac.T@(weight*error))
            step[:2]=np.clip(step[:2],-.12,.12);step[2]=clip(step[2],-.06,.06)
            guess+=step
            self.residual=float(np.sqrt(np.mean(error**2)))
            ok=self.residual<.065
            if np.linalg.norm(step)<1e-4:break
        if (not ok or dist(guess,origin)>.30 or abs(wrap(guess[2]-origin[2]))>.14
                or not .25<guess[0]<7.75 or not (.15 if self.entry_wide else .25)<guess[1]<3.75):
            self.hits=0;self.reason='WALL_REGISTRATION_REJECTED';return False
        # Limit per-frame motion independently of the registration seed.
        if self.pose is not None and seed is None and dist(guess,self.pose)>.30:
            self.hits=0;self.reason='WALL_POSE_JUMP';return False
        self.pose=(float(guess[0]),float(guess[1]),wrap(float(guess[2])))
        self.time,self.yaw=now,odom_yaw;self.hits=min(20,self.hits+1)
        self.reason='TRACKING';return True


class ConeTracks:
    """Layout-gated cluster association; do not swap identities at crossings."""
    def __init__(self, entry_relaxed=False, entry_wide=False):
        self.entry_relaxed=entry_relaxed
        self.entry_wide=entry_wide
        self.xy=list(CONES);self.hits=[0,0];self.seen=[-1e9,-1e9]
        self.stamp=-1;self.reason='WAIT'

    def update(self,cones,pose,stamp,now):
        if stamp<=self.stamp:return
        self.stamp=stamp
        candidates=[world(c,pose) for c in cones]
        for i,expected in enumerate(CONES):
            # First-cone acquisition only. Still reject ambiguous candidates,
            # repeated stamps and jumps; the second-cone rules stay unchanged.
            acquiring=self.entry_relaxed and i==0
            radius=(.90 if self.entry_wide else .45) if acquiring else .38
            step=(.85 if self.entry_wide else .40) if acquiring and self.hits[i]==0 else .30
            choices=[p for c,p in zip(cones,candidates)
                     if (not self.entry_wide or i==0 or len(c)<5 or c[4]>=5)
                     and dist(p,expected)<radius and dist(p,self.xy[i])<step]
            if len(choices)==1:
                p=choices[0]
                first_wide_hit=self.entry_wide and acquiring and self.hits[i]==0
                self.hits[i]=min(20,self.hits[i]+1) if now-self.seen[i] < (.50 if acquiring and self.entry_wide else .35) else 1
                # Seed the unconfirmed track at its measurement, not 30% of
                # the way from the nominal cone. Otherwise a valid 0.5 m
                # offset rejects its own next hit against the 0.3 m step gate.
                self.xy[i]=tuple(p) if first_wide_hit else tuple(.7*a+.3*b for a,b in zip(self.xy[i],p))
                self.seen[i]=now
            else:self.hits[i]=0
        self.reason='PAIRED' if min(self.hits)>=5 and abs(dist(*self.xy)-4)<.45 else 'PARTIAL'

    def ready(self,i,now,reuse_sec=0.0):
        # The first cone is already constrained by the wide acquisition radius,
        # unique candidate and bounded position jump in update(). At a stopped
        # entry, one fresh high-quality hit can start the certified planner;
        # path, body-clearance and swept-scan checks remain mandatory.
        required=1 if self.entry_wide and i==0 else (2 if self.entry_relaxed and i==0 else 5)
        freshness=.45 if self.entry_wide and i==0 else .3
        # A stopped entry may briefly outlive the scan that first confirmed
        # the cone while the registration/planner worker catches up.  The
        # caller must opt in; normal moving tracking remains strict.
        if reuse_sec>0 and self.entry_wide and i==0:
            freshness=max(freshness,float(reuse_sec))
        return self.hits[i]>=required and 0<=now-self.seen[i]<freshness


class PathFollower:
    def __init__(self,path,enable_integral=False):
        self.enable_integral=enable_integral
        self.path=path;self.index=0;self.progress=0.;self.time=None
        self.error=0.;self.integral=0.;self.derivative=0.;self.output=0.
        self.lateral=0.;self.heading=0.;self.target=None;self.curvature=0.
        self.p=self.i=self.d=self.ff=0.
        self.preview_curvature=0.;self.speed=.9;self.last_pose=None
        self.response_output=0.;self.response_tau=.12;self.response_time=None;self.reprime=False

    def reset_feedback(self,preserve_output=False):
        if not preserve_output:
            self.time=None;self.output=0.;self.response_output=0.;self.response_time=None;self.last_pose=None
        self.error=0.;self.integral=0.;self.derivative=0.;self.reprime=True
        self.p=self.i=self.d=0.

    def locate(self,pose):
        if not all(math.isfinite(v) for v in pose[:3]):raise ValueError('CURVE_TRACK_ERROR')
        lo=max(0,self.index-8)
        hi=min(len(self.path.samples),max(self.index+1,
            int(self.path.lengths.searchsorted(self.progress+1.5,side='right'))))
        a=self.path.samples[lo:hi]
        # Arc length is independent of sampling density. Exclude the opposite
        # tangent so a nearby return leg cannot steal progress on an S curve.
        heading=a[:,2]-pose[2]
        compatible=np.abs(np.arctan2(np.sin(heading),np.cos(heading)))<=math.pi/2+1e-12
        # The rollout calls this exact search dozens of times per command.
        # Component arrays avoid a temporary Nx2 matrix and its axis reduction;
        # masking in place preserves the original range, heading test and ties.
        if not len(a):raise ValueError('CURVE_TRACK_ERROR')
        dx=a[:,0]-pose[0];dy=a[:,1]-pose[1]
        distances=dx*dx+dy*dy;distances[~compatible]=np.inf
        nearest=int(distances.argmin())
        if not compatible[nearest]:raise ValueError('CURVE_TRACK_ERROR')
        j=max(self.index,nearest+lo)
        if dist(self.path.samples[j],pose)>.80:raise ValueError('CURVE_TRACK_ERROR')
        self.index=j;self.progress=float(self.path.lengths[self.index])
        return self.index

    def second_cone_approach(self):
        """The short approach to the clockwise second-cone turn only."""
        g=self.path.gates
        return g[2]-1.25<=self.progress<min(g[3],g[2]+.45)

    def approach_feedforward(self,feedforward,error):
        """Let a large approach error settle before anticipating the turn.

        This is used by command() in both the real controller and its future
        rollout. A clockwise preview must not overcome the left correction
        needed when the car arrives north of, and angled toward, cone two.
        """
        scale=1.
        if self.second_cone_approach() and feedforward*error<0.:
            heading=clip((abs(self.heading)-.15)/.35,0.,1.)
            lateral=clip((abs(self.lateral)-.05)/.12,0.,1.)
            scale=1.-.80*max(heading,lateral)
        return feedforward*scale

    def command(self,pose,now,curvature_gain=6.,limit=.32,preview_distance=.20):
        index=self.locate(pose);path=self.path
        q=path.samples[index];dx,dy=q[0]-pose[0],q[1]-pose[1]
        self.lateral=-math.sin(q[2])*dx+math.cos(q[2])*dy
        self.heading=wrap(q[2]-pose[2])
        ahead=min(len(path.samples)-1,int(path.lengths.searchsorted(self.progress+max(0.,preview_distance))))
        self.target=tuple(path.samples[ahead,:2]);self.curvature=float(q[3])
        # Geometry supplies feed-forward. Feedback acts separately on lateral
        # error and tangent direction, not on cone bearing or frozen world yaw.
        self.upper_exit_active=self.progress>=getattr(path,'upper_exit_start',math.inf)
        lateral_heading=math.atan2(1.3*self.lateral,.65)
        if self.upper_exit_active:
            # Recover lateral position along the remaining straight rather
            # than requesting a steep crossing toward its outer wall. At the
            # fifth-run +0.40m error the old +0.68rad lateral term overruled a
            # -0.53rad heading error and still commanded a left turn.
            lateral_heading=clip(math.atan2(self.lateral,.90),-.30,.30)
        self.lateral_heading=lateral_heading
        error=self.heading+lateral_heading
        dt=0. if self.time is None else now-self.time
        response_clock=self.time if self.response_time is None else self.response_time
        response_dt=0. if response_clock is None else now-response_clock
        prime=self.reprime or not 0<dt<=.35
        self.reprime=False
        if response_dt>0.:
            self.response_output+=(1.-math.exp(-min(response_dt,.50)/self.response_tau))*(self.output-self.response_output)
        self.response_time=now
        if dt>0.:
            if self.last_pose is not None and dt<=.50:
                measured=dist(pose,self.last_pose)/dt
                if math.isfinite(measured):self.speed=.65*self.speed+.35*clip(measured,.05,1.5)
        if prime:self.derivative=0.;self.integral=0.
        else:
            alpha=dt/(.08+dt)
            self.derivative+=alpha*((error-self.error)/dt-self.derivative)
            if error*self.error<=0 or abs(error)<abs(self.error)*.9:
                self.integral*=max(0.,1-dt/.2)
        # Delayed yaw extrapolation can lead the real turn during changes in
        # steering. Lower feedback gains avoid repeatedly cancelling the
        # geometric feed-forward on that transient (V35.12 log/lag replay).
        kp,kd=(.24,.020) if self.upper_exit_active else (.16,.015)
        self.p=kp*error;self.d=kd*self.derivative
        # Source latency belongs to pose prediction. This short spatial preview
        # compensates steering response only; the old target was diagnostic and
        # feed-forward used zero curvature at the entrance's first sample.
        segment=path.samples[index:ahead+1,3]
        self.preview_curvature=float(segment.mean()) if len(segment) else self.curvature
        self.ff=self.approach_feedforward(self.preview_curvature/curvature_gain,error)
        # Small bounded I removes persistent tracking bias, with anti-windup
        # against the combined feed-forward, amplitude and slew limits.
        candidate=self.integral
        if self.enable_integral and not prime:
            if abs(error)<.30:
                candidate=clip(candidate+.003*error*dt,-.008,.008)
            delta_i=.75*max(0.,min(dt,.20))
            proposed=self.ff+self.p+candidate+self.d
            realizable=clip(clip(proposed,-limit,limit),self.output-delta_i,self.output+delta_i)
            if (candidate-self.integral)*(proposed-realizable)<=1e-12:
                self.integral=candidate
        self.i=self.integral
        requested=self.ff+self.p+self.i+self.d
        # A first/long-gap command must not freeze at zero. A cold start gets a
        # bounded initial step; subsequent slew uses real elapsed control time.
        steering_dt=.20 if self.time is None else max(0.,min(dt,.20))
        delta=.75*steering_dt
        self.output=clip(clip(requested,-limit,limit),self.output-delta,self.output+delta)
        self.error=error;self.time=now;self.last_pose=tuple(pose[:3])
        return self.output

    def horizon(self,distance=.85):
        end=int(self.path.lengths.searchsorted(self.progress+distance))
        return self.path.samples[self.index:min(end+1,len(self.path.samples)):3]


def _sweep_gap_support(ranges, valid, k, inc, full_circle):
    """Infer only a tiny missing run bounded by four consistent real returns.

    This is a spatial approximation, not an observation of the missing rays.
    Near-self, finite out-of-range and negative-infinite returns are never filled.
    No history, map free cells, or previously inferred rays are used as support.
    """
    n=len(ranges)
    def index(i):
        return i%n if full_circle else (i if 0<=i<n else None)
    def missing(i):
        return math.isnan(ranges[i]) or ranges[i]==math.inf
    if not missing(k):return None,'INVALID_RANGE'
    gap={k};bounds=[]
    for direction in (-1,1):
        i=k
        for _ in range(3):
            i=index(i+direction)
            if i is None:return None,'SCAN_EDGE'
            if valid[i]:
                bounds.append(i);break
            if not missing(i):return None,'INVALID_NEIGHBOR'
            gap.add(i)
            if len(gap)>2:return None,'GAP_TOO_WIDE'
        else:return None,'GAP_TOO_WIDE'
    span=(len(gap)+1)*inc
    if span>math.radians(3.)+1e-12:return None,'GAP_ANGLE'
    outer=[index(bounds[0]-1),index(bounds[1]+1)]
    if any(i is None or not valid[i] for i in outer):return None,'NO_SUPPORT'
    support=[float(ranges[i]) for i in bounds+outer]
    near=min(support)
    if max(support)-near>.10+1e-12:return None,'DEPTH_EDGE'
    if 2*near*math.sin(span/2)>.12+1e-12:return None,'SUPPORT_TOO_FAR'
    # Use the nearest real support minus 5 cm, never an optimistic average.
    return (near-.05,span,gap),'SUPPORTED'


def scan_observes_body(scan,pose,samples,margin=.08,*,allow_small_gaps=False,
                       allow_scan_edge=False,diagnostics=None):
    """Check sampled future body against raw polar free-space observations.

    The default remains strict. Opt-in tolerates at most two adjacent NaN/+inf
    rays with measured support on both sides, small angular/spatial extent,
    at most three inferred rays and at most 5% of required rays per check.
    This cannot prove the absence of an object hidden entirely in a missing ray.
    All grid points
    outside the current self footprint must have observed free range; raw rays
    inside padded future rectangles independently detect small intervening hits.
    """
    detail=diagnostics if diagnostics is not None else {}
    detail.clear()
    used=set();inferred=set();cache={}
    detail.update(policy='BOUNDED_GAPS' if allow_small_gaps else 'STRICT',
                  inferred_rays=0,edge_rays=0,checked_rays=0)
    def finish(ok,reason,**fields):
        detail.update(result=reason,inferred_rays=len(inferred),checked_rays=len(used),**fields)
        return ok,reason
    if scan is None:return finish(False,'SCAN_GEOMETRY')
    ranges=np.asarray(scan.ranges,dtype=float);n=len(ranges);inc=scan.angle_increment
    if (n<60 or not math.isfinite(inc) or inc<=0 or not math.isfinite(scan.angle_min)
            or not math.isfinite(scan.range_min) or not math.isfinite(scan.range_max)
            or scan.range_max<max(scan.range_min,.30)):
        return finish(False,'SCAN_GEOMETRY')
    if hasattr(scan,'header') and hasattr(scan.header,'stamp'):
        stamp=scan.header.stamp
        detail['scan_stamp_ns']=int(stamp.sec)*1000000000+int(stamp.nanosec)
    angles=scan.angle_min+np.arange(n)*inc
    valid=np.isfinite(ranges)&(ranges>=max(scan.range_min,.30))&(ranges<=scan.range_max)
    points=np.column_stack((ranges[valid]*np.cos(angles[valid]),ranges[valid]*np.sin(angles[valid])))
    # LSN10 repeats the first direction at period=round(2*pi/inc), and some
    # modes allocate one extra beam beyond that repeated endpoint. Keep all
    # raw finite returns above for obstacles; only queries use unique bins.
    tolerance=max(1e-5,.05*inc)
    turn_bins=2*math.pi/inc
    period=int(round(turn_bins)) if math.isfinite(turn_bins) and turn_bins<=n+1 else n+2
    exact_period=period>=1 and abs(period*inc-2*math.pi)<=tolerance
    angular_span=getattr(scan,'angle_max',math.nan)-scan.angle_min
    declared_turn=math.isfinite(angular_span) and abs(angular_span-2*math.pi)<=tolerance
    # The alignment node currently reports the last allocated beam as max.
    # Accept that exact one-beam extension too, never an arbitrary near turn.
    declared_extra=(math.isfinite(angular_span)
                    and abs(angular_span-(2*math.pi+inc))<=tolerance)
    duplicated_endpoint=(exact_period and (n==period+1
        or (n==period+2 and (declared_turn or declared_extra))))
    if duplicated_endpoint:
        unique=ranges[:period].copy()
        for i in range(period,n):
            k=i%period;first,last=float(unique[k]),float(ranges[i])
            first_missing=math.isnan(first) or first==math.inf
            last_missing=math.isnan(last) or last==math.inf
            first_valid=math.isfinite(first) and max(scan.range_min,.30)<=first<=scan.range_max
            if first_missing:
                unique[k]=last
            elif last_missing:
                pass
            elif not first_valid:
                pass
            elif not valid[i]:
                unique[k]=last
            else:
                unique[k]=min(first,last)
        # Invalid finite/negative-infinite duplicates remain invalid. Only a
        # NaN/+inf can use its measured duplicate, never an invented range.
        ranges=unique;n=len(ranges)
        valid=np.isfinite(ranges)&(ranges>=max(scan.range_min,.30))&(ranges<=scan.range_max)
    detail['duplicated_endpoint']=bool(duplicated_endpoint)
    # Both indexing and inference require a precise complete ring, including
    # canonical duplicate formats. Missing cropped directions never wrap.
    full_circle=abs(n*inc-2*math.pi)<=tolerance
    gap_full_circle=full_circle
    # Vectorize the all-clear case. Boundary/missing/occluded queries retain
    # the original scalar checks below, including their exact diagnostics.
    gx,gy=np.meshgrid(np.linspace(-.185-margin,.20+margin,7),
                     np.linspace(-.15-margin,.15+margin,7),indexing='ij')
    gx=gx.ravel();gy=gy.ravel()
    for sample_index,q in enumerate(samples):
        x,y=local(q,pose);h=wrap(q[2]-pose[2]);c,s=math.cos(h),math.sin(h)
        d=points-np.array([x,y]);bx=c*d[:,0]+s*d[:,1];by=-s*d[:,0]+c*d[:,1]
        if np.any((bx>=-.185-margin)&(bx<=.20+margin)&(abs(by)<=.15+margin)):
            return finish(False,'SWEPT_OBSTACLE',sample_index=sample_index)
        px=x+c*gx-s*gy;py=y+s*gx+c*gy
        rr=np.hypot(px,py);query=rr>.30
        rr=rr[query]
        kk=np.rint(((np.arctan2(py[query],px[query])-scan.angle_min)%(2*math.pi))/inc).astype(int)
        if full_circle:kk%=n
        if np.all((kk>=0)&(kk<n)) and np.all(valid[kk]) and np.all(ranges[kk]>=rr+.025+1e-9):
            used.update(int(k) for k in kk)
            continue
        for xx in np.linspace(-.185-margin,.20+margin,7):
            for yy in np.linspace(-.15-margin,.15+margin,7):
                px,py=x+c*xx-s*yy,y+s*xx+c*yy;r=math.hypot(px,py)
                if r<=.30:continue
                a=math.atan2(py,px)
                k=int(round(((a-scan.angle_min)%(2*math.pi))/inc))
                if full_circle:k%=n
                if not 0<=k<n:
                    # A cropped lidar scan can put a sampled body point just
                    # outside its first/last beam.  At the entry handoff only,
                    # clamp a one-beam edge miss to the nearest measured ray.
                    # This never infers an interior gap and never applies to
                    # the normal curve command checks.
                    raw=(a-scan.angle_min)/inc
                    edge=min(abs(raw),abs(raw-(n-1)))
                    if not allow_scan_edge or edge>1.05:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='SCAN_EDGE',
                                      bearing_deg=math.degrees(a),required_m=r+.025)
                    k=0 if raw<0 else n-1
                    detail['edge_rays']=int(detail.get('edge_rays',0))+1
                    if detail['edge_rays']>4:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='SCAN_EDGE_LIMIT',
                                      bearing_deg=math.degrees(a),required_m=r+.025)
                used.add(k)
                observed=ranges[k]
                ray=dict(ray_index=k,bearing_deg=math.degrees(scan.angle_min+k*inc),
                         required_m=r+.025,sample_index=sample_index,
                         check_xy_laser=[float(px),float(py)])
                if not valid[k]:
                    if not allow_small_gaps:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='STRICT_INVALID',**ray)
                    if k not in cache:cache[k]=_sweep_gap_support(ranges,valid,k,inc,gap_full_circle)
                    support,why=cache[k]
                    if support is None:return finish(False,'SWEPT_UNKNOWN',unknown_reason=why,**ray)
                    available,span,gap=support
                    if 2*r*math.sin(span/2)>.04+1e-12:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='QUERY_GAP_WIDTH',**ray)
                    if available<r+.025:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='SUPPORT_CLEARANCE',
                                      available_m=available,**ray)
                    inferred.update(gap)
                    if len(inferred)>3:
                        return finish(False,'SWEPT_UNKNOWN',unknown_reason='GAP_COUNT_LIMIT',**ray)
                elif min(observed,scan.range_max)<r+.025:
                    return finish(False,'SWEPT_OCCLUDED',observed_m=float(observed),**ray)
    if inferred and len(inferred)/max(1,len(used))>.05+1e-12:
        return finish(False,'SWEPT_UNKNOWN',unknown_reason='GAP_FRACTION_LIMIT')
    return finish(True,'CLEAR_GAP_TOLERATED' if inferred else 'CLEAR',
                  inferred_indices=sorted(inferred))


def constant_steer_horizon(pose,steer,gain,limit=.32,distance=.65,*,
                           speed=.9,initial_steer=None,steer_tau=.12):
    """Roll out a HELD steering command, including its remaining response lag.

    The commanded target is not evidence that the servo has reached it.
    Callers must supply the estimated current response after any stationary
    pre-steering wait. All three gain cases remain subject to the raw scan
    sweep and its existing body margin. This does not authorize propulsion.
    """
    initial=0. if initial_steer is None else initial_steer
    values=(*pose[:3],steer,gain,limit,distance,speed,initial,steer_tau)
    if (not all(math.isfinite(v) for v in values) or gain<=0. or limit<=0.
            or not 0.<distance<=2. or speed<0. or steer_tau<=0.):
        raise ValueError('CURVE_ROLLOUT_GEOMETRY')
    limit=min(limit,.32);target=clip(steer,-limit,limit)
    initial=clip(initial,-limit,limit);speed=clip(speed,.20,1.5)
    out=[tuple(pose[:3])]
    count=int(math.ceil(distance/.025));step=distance/count;dt=step/speed
    for factor in (.8,1.,1.2):
        x,y,h=pose[:3];applied=initial
        for _ in range(count):
            # Exact mean response on this substep preserves the integrated
            # turn of the exponential servo model, including slow motion.
            mean=target+(applied-target)*steer_tau/dt*(-math.expm1(-dt/steer_tau))
            applied=target+(applied-target)*math.exp(-dt/steer_tau)
            curvature=gain*factor*mean;angle=curvature*step
            if abs(curvature)<1e-9:
                x+=step*math.cos(h);y+=step*math.sin(h)
            else:
                x+=(math.sin(h+angle)-math.sin(h))/curvature
                y+=(math.cos(h)-math.cos(h+angle))/curvature
            h=wrap(h+angle);out.append((x,y,h))
    return out


def command_horizon(pose,follower,gain,limit=.32,distance=.65,*,speed=None,steer_tau=.12):
    """Short closed-loop rollout in addition to the desired-path envelope.

    Gain is nominal, not a certified braking model. Check several gains so
    a moderate response mismatch cannot hide behind a clear desired path.
    Feedback still updates every .05 m. Each .025 m geometry step uses the
    exact mean exponential steering response and a circular-arc displacement;
    rotating first and translating with the final heading cut inside a corner.
    """
    # Do not roll beyond the path endpoint while the upper-corridor observer
    # collects its confirmation frames; that used to create a false track fault.
    distance=min(distance,max(.05,float(follower.path.lengths[-1])-follower.progress))
    # .35 is a calibrated motor input, not m/s. Use measured speed when given;
    # the old fixed .10s per .05m assumed only .5m/s during a ~.9m/s approach.
    speed=clip(float(follower.speed if speed is None else speed),.20,1.5)
    step=.05;substep=step*.5
    step_time=step/speed
    steer_tau=max(.02,float(steer_tau))
    sub_time=step_time*.5
    response_change=-math.expm1(-sub_time/steer_tau)
    response_mean_weight=steer_tau/sub_time*response_change
    out=[tuple(pose)]
    for factor in (.8,1.,1.2):
        model=copy.copy(follower);x,y,h=pose
        applied=follower.response_output
        for j in range(int(math.ceil(distance/step))):
            # The first step retains the issued command; later steps include
            # path feedback rather than assuming a fixed turn for 0.65 metres.
            u=model.output if j==0 else model.command((x,y,h),follower.time+j*step_time,gain,limit)
            for _ in range(2):
                # The end response is state, not steering held for the whole
                # preceding interval. Mean response preserves the exact yaw
                # integral for a held target, including the first cold step.
                mean=u+(applied-u)*response_mean_weight
                applied+=response_change*(u-applied)
                angle=gain*mean*factor*substep;half=angle*.5
                sinc=math.sin(half)/half if abs(half)>1e-8 else 1.-half*half/6.
                travelled=substep*sinc
                middle=h+half
                x+=travelled*math.cos(middle);y+=travelled*math.sin(middle)
                h+=angle;out.append((x,y,h))
    return out

def nearby_wall(scan, side, entry=False, uneven=False):
    """Fit a LOCAL wall in the laser frame; never select the far open arena.

    Bin medians prevent dense near rays dominating the line. A robust slope
    across separated bins and residual/support checks reject cones and corners.
    Returns perpendicular distance, heading, bin count, span, RMS, or None.
    This is used inside the existing scan subscriber, not by a new ROS node.
    """
    # The assembled boards may be tilted or have small joints. A side wall
    # remains useful after the divider ends and the car drifts beyond .75 m.
    # Keep a long supported line, but allow centimetre-scale board unevenness.
    maximum=1.10 if entry or uneven else .75
    minimum_span=.45 if entry or uneven else .55
    minimum_bins=5 if entry or uneven else 6
    lateral_limit=1.30 if uneven else (1.20 if entry else .85)
    inlier_limit=.055 if uneven else .025
    support_ratio=.70 if uneven else .75
    heading_limit=math.radians(25.) if uneven else .35
    rms_limit=.040 if uneven else .018
    bins={}
    for i,r in enumerate(scan.ranges):
        if not math.isfinite(r) or not max(.30,scan.range_min)<=r<=min(1.6,scan.range_max):continue
        a=scan.angle_min+i*scan.angle_increment
        x,y=r*math.cos(a),r*math.sin(a)
        if -.25<=x<=.85 and .25<=side*y<=lateral_limit:
            bins.setdefault(int(math.floor((x+.25)/.10)),[]).append((x,y))
    points=[(float(median([p[0] for p in group])),float(median([p[1] for p in group])))
            for _,group in sorted(bins.items()) if len(group)>=2]
    if len(points)<minimum_bins or points[-1][0]-points[0][0]<minimum_span:return None
    slopes=[(b[1]-a[1])/(b[0]-a[0]) for i,a in enumerate(points) for b in points[i+1:] if b[0]-a[0]>=.30]
    if not slopes:return None
    slope=float(median(slopes));intercept=float(median([y-slope*x for x,y in points]))
    kept=[p for p in points if abs(p[1]-slope*p[0]-intercept)<=inlier_limit]
    if len(kept)<minimum_bins or len(kept)<support_ratio*len(points) or kept[-1][0]-kept[0][0]<minimum_span:return None
    xs=np.asarray([p[0] for p in kept]);ys=np.asarray([p[1] for p in kept])
    slope=float(np.sum((xs-xs.mean())*(ys-ys.mean()))/np.sum((xs-xs.mean())**2))
    intercept=float(ys.mean()-slope*xs.mean())
    heading=math.atan(slope);distance=abs(intercept)/math.hypot(1.,slope)
    rms=float(np.sqrt(np.mean((ys-slope*xs-intercept)**2)))
    if side*intercept<=0 or not .30<=distance<=maximum or abs(heading)>heading_limit or rms>rms_limit:return None
    return distance,heading,len(kept),float(xs.max()-xs.min()),rms


def local_wall_direction(scan, side, uneven=False):
    """Near-wall heading with separate rear/forward consistency checks.

    Allow modest differences between joined boards while requiring supported
    local segments. This estimator supplies only straight-driving direction,
    never an opening or obstacle-clearance authorization. Headings use the
    scan frame convention.
    """
    lateral_limit=1.30 if uneven else .85
    minimum_bins=5 if uneven else 6
    minimum_span=.25 if uneven else .30
    inlier_limit=.050 if uneven else .020
    support_ratio=.70 if uneven else .8
    maximum=1.10 if uneven else .75
    heading_limit=math.radians(25.) if uneven else .35
    rms_limit=.035 if uneven else .015
    agreement_limit=math.radians(8.0 if uneven else 5.0)
    points=[]
    for i,r in enumerate(scan.ranges):
        if not math.isfinite(r) or not max(.30,scan.range_min)<=r<=min(1.6,scan.range_max):
            continue
        angle=scan.angle_min+i*scan.angle_increment
        x,y=r*math.cos(angle),r*math.sin(angle)
        if -.25<=x<=.85 and .25<=side*y<=lateral_limit:
            points.append((x,y))

    def fit(lo,hi):
        bins={}
        for x,y in points:
            if lo<=x<=hi:
                bins.setdefault(int(math.floor((x-lo)/.05)),[]).append((x,y))
        samples=[(float(median([p[0] for p in group])),
                  float(median([p[1] for p in group])))
                 for _,group in sorted(bins.items()) if len(group)>=2]
        if len(samples)<minimum_bins or samples[-1][0]-samples[0][0]<minimum_span:
            return None
        slopes=[(b[1]-a[1])/(b[0]-a[0]) for i,a in enumerate(samples)
                for b in samples[i+1:] if b[0]-a[0]>=.20]
        if not slopes:
            return None
        slope=float(median(slopes))
        intercept=float(median([y-slope*x for x,y in samples]))
        kept=[p for p in samples if abs(p[1]-slope*p[0]-intercept)<=inlier_limit]
        if len(kept)<minimum_bins or len(kept)<support_ratio*len(samples) or kept[-1][0]-kept[0][0]<minimum_span:
            return None
        xs=np.asarray([p[0] for p in kept]);ys=np.asarray([p[1] for p in kept])
        slope=float(np.sum((xs-xs.mean())*(ys-ys.mean()))/np.sum((xs-xs.mean())**2))
        intercept=float(ys.mean()-slope*xs.mean())
        heading=math.atan(slope);distance=abs(intercept)/math.hypot(1.,slope)
        rms=float(np.sqrt(np.mean((ys-slope*xs-intercept)**2)))
        if side*intercept<=0 or not .30<=distance<=maximum or abs(heading)>heading_limit or rms>rms_limit:
            return None
        return distance,heading,len(kept),float(xs.max()-xs.min()),rms

    near,rear,ahead=fit(0.,.50),fit(-.25,.25),fit(.35,.85)
    if near is None:
        return dict(near=None,rear=rear,ahead=ahead,weight=0.,reason='NEAR_REJECTED')
    neighbours=[p for p in (rear,ahead) if p is not None]
    agree=sum(abs(wrap(p[1]-near[1]))<=agreement_limit for p in neighbours)
    if not neighbours:
        weight,reason=.25,'NEAR_ONLY'
    elif agree==len(neighbours):
        weight,reason=1.,'SEGMENTS_AGREE'
    elif agree:
        weight,reason=.25,'SEGMENT_BEND'
    else:
        weight,reason=0.,'SEGMENTS_DISAGREE'
    return dict(near=near,rear=rear,ahead=ahead,weight=weight,reason=reason)


def bridge_pose(map_pose, odom_then, odom_now):
    """SE(2) relative motion; all three poses must refer to the laser frame."""
    dx,dy=local(odom_now,odom_then)
    x,y=world((dx,dy),map_pose)
    return (x,y,wrap(map_pose[2]+wrap(odom_now[2]-odom_then[2])))


def interpolate_odom(samples, stamp, tolerance=.16):
    """Interpolate acquisition timestamps, never mix ROS and monotonic time."""
    if not samples:return None
    before=next((s for s in reversed(samples) if s[0]<=stamp),None)
    after=next((s for s in samples if s[0]>=stamp),None)
    if before is not None and after is not None:
        if max(stamp-before[0],after[0]-stamp)>tolerance:return None
        span=after[0]-before[0]
        if span<=1e-9:return tuple(before[1:4])
        f=(stamp-before[0])/span
        return (before[1]+f*(after[1]-before[1]),
                before[2]+f*(after[2]-before[2]),
                wrap(before[3]+f*wrap(after[3]-before[3])))
    nearest=before if before is not None else after
    return tuple(nearest[1:4]) if abs(nearest[0]-stamp)<=tolerance else None


def scan_geometry_valid(scan):
    """Apply the same metadata gate as scan_observes_body, without a rollout."""
    if scan is None:return False
    try:
        return (len(scan.ranges)>=60 and math.isfinite(scan.angle_increment)
            and scan.angle_increment>0 and math.isfinite(scan.angle_min)
            and math.isfinite(scan.range_min) and math.isfinite(scan.range_max)
            and scan.range_max>=max(scan.range_min,.30))
    except (AttributeError,TypeError,ValueError,OverflowError):
        return False


def scan_hits_body(scan,pose,samples,margin=.08,diagnostics=None):
    """Check ALL finite raw returns against every sampled future rectangle.

    Broadcast bounded blocks of poses and rays instead of allocating NumPy
    arrays once per pose. Duplicated/extra driver endpoints remain raw rays.
    A picometre boundary tolerance covers floating-point reassociation only.
    Optional diagnostics identify the earliest sampled-body/raw-ray collision;
    displacement is from the first pose, not arc length across rollout branches.
    """
    if diagnostics is not None:
        diagnostics.clear();diagnostics.update(result='CLEAR',hit=False)
    if scan is None:
        if diagnostics is not None:diagnostics.update(result='SCAN_MISSING',blocked=True)
        return True
    ranges=np.asarray(scan.ranges,dtype=float)
    valid=np.isfinite(ranges)&(ranges>=max(scan.range_min,.30))&(ranges<=scan.range_max)
    indices=np.flatnonzero(valid)
    angles=scan.angle_min+indices*scan.angle_increment
    points=np.column_stack((ranges[valid]*np.cos(angles),ranges[valid]*np.sin(angles)))
    if not len(points):return False
    poses=np.asarray(samples if isinstance(samples,np.ndarray) else list(samples),dtype=float)
    if not len(poses):return False
    pc,ps=math.cos(pose[2]),math.sin(pose[2])
    offset=poses[:,:2]-np.asarray(pose[:2],dtype=float)
    x=pc*offset[:,0]+ps*offset[:,1];y=-ps*offset[:,0]+pc*offset[:,1]
    heading=poses[:,2]-pose[2]
    heading=np.arctan2(np.sin(heading),np.cos(heading))
    cs=np.cos(heading);sn=np.sin(heading)
    # Eight poses kept the temporary matrices in the vehicle CPU's cache in
    # an offline sweep benchmark; also cap pairs for unusually dense scans.
    block=max(1,min(8,65536//len(points)))
    tolerance=1e-12
    for start in range(0,len(poses),block):
        stop=min(start+block,len(poses))
        dx=points[None,:,0]-x[start:stop,None]
        dy=points[None,:,1]-y[start:stop,None]
        c=cs[start:stop,None];s=sn[start:stop,None]
        bx=c*dx+s*dy;by=-s*dx+c*dy
        hits=((bx>=-.185-margin-tolerance)&(bx<=.20+margin+tolerance)
              &(np.abs(by)<=.15+margin+tolerance))
        if np.any(hits):
            if diagnostics is not None:
                row,ray=np.unravel_index(int(np.argmax(hits)),hits.shape)
                sample_index=start+int(row);ray=int(ray)
                px,py=points[ray];q=poses[sample_index]
                diagnostics.update(result='SWEPT_OBSTACLE',hit=True,
                    sample_index=sample_index,ray_index=int(indices[ray]),
                    hit_xy_laser=[float(px),float(py)],
                    hit_xy_world=[float(pose[0]+pc*px-ps*py),float(pose[1]+ps*px+pc*py)],
                    hit_xy_body=[float(bx[row,ray]),float(by[row,ray])],
                    future_pose=[float(v) for v in q[:3]],
                    scan_pose=[float(v) for v in pose[:3]],margin_m=float(margin),
                    sample_displacement_m=float(np.linalg.norm(q[:2]-poses[0,:2])),
                    samples=len(poses),valid_returns=len(points))
            return True
    return False
