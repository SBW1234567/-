#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""全国大学生智能汽车竞赛一体化总控制状态机。

正式模式下本节点是唯一发布 /car_cmd_vel 的节点。它根据实时视觉、雷达、
挡板边界和里程计，依次执行：人行道停车、两个锥桶绕行、红绿灯停车以及
终点区停车。不同赛段只接受对应事件，避免远处红色物体或挡板误判提前
改变任务状态。

这是实车标定框架；可选8x4预设布局用于驶出入弯区域和目标锥桶确认。锥桶绕行方向、转角、车速、
边界距离等参数必须在低速架空测试和真实赛道上逐项校准。
"""

import math
import json
import time
import copy
from concurrent.futures import ThreadPoolExecutor
from threading import Event
from collections import deque
from statistics import median

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from race_curve_core import register_scan, local_wall_direction, nearby_wall, WallLocalizer, ConeTracks, PathFollower, plan_path as make_path, scan_observes_body, command_horizon, local as curve_local, world as curve_world, body_clear as curve_body_clear
from race_curve_core import plan_entry_path, PlanningInterrupted, bridge_pose, interpolate_odom, scan_hits_body, scan_geometry_valid, constant_steer_horizon
from race_curve_core import path_body_clear as curve_path_body_clear
from rclpy.node import Node
from std_msgs.msg import Bool, Float32MultiArray, Int16MultiArray, String


def entry_wall_observation(scan, uneven=False):
    """Private worker: return observations only; never mutate controller state."""
    started=time.perf_counter()
    right=nearby_wall(scan,-1,uneven=uneven)
    left=nearby_wall(scan,1,uneven=uneven)
    direction=local_wall_direction(scan,-1,uneven=uneven)
    # Entrance observation has a wider range, never fed into straight steering.
    entry_right=right if right is not None else nearby_wall(scan,-1,entry=True)
    return right,left,direction,1000.*(time.perf_counter()-started),entry_right


def clamp(value, low, high):
    return max(low, min(high, value))


def normalize_angle(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


class RaceTaskController(Node):
    """完整赛道的一体化低速状态机与最终速度控制器。"""

    STARTUP = 'STARTUP'
    APPROACH_CROSSWALK = 'APPROACH_CROSSWALK'
    CROSSWALK_STOP = 'CROSSWALK_STOP'
    SEEK_CONE_1 = 'SEEK_CONE_1'
    CROSSWALK_EXIT_WAIT = 'CROSSWALK_EXIT_WAIT'
    ENTER_OBSTACLES = 'ENTER_OBSTACLES'
    ROUTE_FAULT = 'ROUTE_FAULT'
    ORBIT_CONE_1 = 'ORBIT_CONE_1'
    SEEK_CONE_2 = 'SEEK_CONE_2'
    ORBIT_CONE_2 = 'ORBIT_CONE_2'
    SEEK_LIGHT = 'SEEK_LIGHT'
    RED_WAIT = 'RED_WAIT'
    FINISH_APPROACH = 'FINISH_APPROACH'
    FINISHED = 'FINISHED'

    def __init__(self):
        super().__init__('race_task_controller')

        self.declare_parameter('entry_v32_enabled', False)
        self.entry_v32_enabled=bool(self.get_parameter('entry_v32_enabled').value)
        self.declare_parameter('entry_v33_enabled', False)
        self.entry_v33_enabled=bool(self.get_parameter('entry_v33_enabled').value)
        if self.entry_v33_enabled and not self.entry_v32_enabled:
            raise ValueError('V33 requires V32 entry support')
        self.declare_parameter('entry_v34_enabled',False)
        self.entry_v34_enabled=bool(self.get_parameter('entry_v34_enabled').value)
        if self.entry_v34_enabled and not self.entry_v33_enabled:
            raise ValueError('V34 requires V33 entry support')
        self.entry_v34_anchor=None
        self.entry_v34_anchor_stamp=0
        self.entry_v34_progress_reason='UNANCHORED'
        self.entry_v34_turn_stop=False
        self.entry_v34_recovery_since=None
        self.entry_v34_stop_trigger=''
        self.entry_v34_lane_job=None
        self.entry_v34_lane_executor=ThreadPoolExecutor(max_workers=1) if self.entry_v34_enabled else None
        self.entry_v34_wall_cache=deque(maxlen=8)
        self.entry_v34_lane_status='WAIT'
        self.entry_v34_async_since=-1e9
        self.entry_v33_started=None
        self.entry_v33_braked=False
        self.entry_v33_brake_since=None
        self.entry_v33_reason='PREOBSERVE'
        self.entry_v33_seed_reason='WAIT'
        self.entry_v33_relative_stamp=0
        self.entry_v33_relative_hits=0
        self.entry_v33_relative_time=-1e9
        self.entry_v33_relative_seed=None
        self.entry_v33_scans=deque(maxlen=8)
        self.entry_v33_max_unknown_travel=1.8
        self.entry_v33_max_unknown_seconds=3.0
        self.entry_pose_pairs=deque(maxlen=12)
        self.entry_pair_reason='WAIT'
        self.entry_recovery_since=None
        self.entry_recovery_reason=''
        self.entry_straight_sweep_stamp=0
        self.entry_straight_sweep_ok=False
        self.entry_straight_sweep_reason='WAIT'
        self.entry_fit_since=-1e9

        self.declare_parameter('relative_route', False)
        self.relative_route = bool(self.get_parameter('relative_route').value)
        self.declare_parameter('curve_route', False)
        self.curve_route = bool(self.get_parameter('curve_route').value)
        self.declare_parameter('curve_static_body_guard_enabled', False)
        self.curve_static_body_guard_enabled=bool(self.get_parameter('curve_static_body_guard_enabled').value)
        if self.curve_route and not self.relative_route:
            raise ValueError('curve_route requires relative_route')
        # Source-aligned V35.12 runs measured roughly 4.4--5.0 curvature per
        # steering unit, falling near 4.0 at high steering. The rollout's
        # 0.8/1.0/1.2 factors now cover 4.0--6.0 instead of 4.8--7.2.
        for key, default in [('curve_curvature_gain', 5.0), ('curve_min_radius', .55),
                             ('curve_min_drive', .28), ('curve_max_steer', .32)]:
            self.declare_parameter(key,default)
            value=float(self.get_parameter(key).value)
            if not math.isfinite(value) or value <= 0:raise ValueError('Invalid '+key)
            setattr(self,key,value)
        if not (3. <= self.curve_curvature_gain <= 12. and .50 <= self.curve_min_radius <= 1.5
                and .20 <= self.curve_min_drive <= .35 and .15 <= self.curve_max_steer <= .40):
            raise ValueError('Curve engineering limits out of range')
        if self.entry_v32_enabled:
            # .30 is a rolling trim, not a launch command. The measured-speed
            # helper retains .35 below launch speed so a low input cannot
            # strand this car at a standstill.
            self.curve_min_drive=.30
        self.corridor_samples=deque(maxlen=8)
        self.corridor_reference=None
        self.corridor_width=None
        self.corridor_filtered=None
        self.corridor_raw=None
        self.corridor_time=0.
        self.corridor_heading_term=0.
        self.corridor_request=0.
        self.corridor_reason='WAIT'
        # V20: the reference is the lane centre, never the stopped car pose.
        self.declare_parameter('lane_nominal_width', .90)
        self.declare_parameter('lane_laser_yaw_bias', 0.0)
        self.lane_width = float(self.get_parameter('lane_nominal_width').value)
        self.lane_yaw_bias = float(self.get_parameter('lane_laser_yaw_bias').value)
        if not (.80 <= self.lane_width <= 1.05 and math.isfinite(self.lane_yaw_bias)
                and abs(self.lane_yaw_bias) <= math.radians(10)):
            raise ValueError('Invalid lane width or calibrated laser yaw bias')
        self.lane_nominal_width = self.lane_width
        self.lane_observed_width = None
        self.lane_direction = dict(near=None, rear=None, ahead=None, weight=0., reason='WAIT')
        self.lane_heading_weight = 0.0
        self.lane_heading_gate = 'V21_WEIGHT'
        self.lane_right_hits = 0
        self.lane_ready = False
        self.lane_raw_previous = None
        self.lane_raw_time = None
        self.lane_fit_left = None
        self.lane_fit_reason = 'WAIT_SCAN'
        self.lane_source = 'WAIT'
        self.lane_lateral = self.lane_heading = 0.0
        self.lane_applied = 0.0
        self.lane_recovering = False
        self.declare_parameter('bounded_heading_control', False)
        self.bounded_heading_control = self.get_parameter('bounded_heading_control').value
        if type(self.bounded_heading_control) is not bool:
            raise ValueError('bounded_heading_control must be boolean')
        for key, default, low, high in (
                ('lane_heading_gain', .45, .20, .70),
                ('lane_target_heading_deg', 3., 1., 5.),
                ('lane_cautious_heading_deg', 1.5, .5, 3.),
                ('lane_straight_drive', .35, .28, .35)):
            self.declare_parameter(key, default)
            value = float(self.get_parameter(key).value)
            if not math.isfinite(value) or not low <= value <= high:
                raise ValueError('Invalid '+key)
            setattr(self, key, value)
        if self.lane_cautious_heading_deg > self.lane_target_heading_deg:
            raise ValueError('Cautious target heading must not exceed normal target')
        self.declare_parameter('lane_parallel_band_enabled', False)
        self.lane_parallel_band_enabled = self.get_parameter('lane_parallel_band_enabled').value
        if type(self.lane_parallel_band_enabled) is not bool:
            raise ValueError('lane_parallel_band_enabled must be boolean')
        for key, default, low, high in (
                ('lane_band_min_distance', .38, .32, .42),
                ('lane_band_max_distance', .50, .46, .58),
                ('lane_band_target_heading_deg', 1., .5, 1.5)):
            self.declare_parameter(key, default)
            value = float(self.get_parameter(key).value)
            if not math.isfinite(value) or not low <= value <= high:
                raise ValueError('Invalid '+key)
            setattr(self, key, value)
        if self.lane_parallel_band_enabled and not (self.bounded_heading_control and self.curve_route):
            raise ValueError('Parallel band requires bounded_heading_control and curve_route')
        if self.lane_band_max_distance-self.lane_band_min_distance < .04:
            raise ValueError('Parallel band must be at least 0.04 m wide')
        self.lane_band_width_samples = deque(maxlen=3)
        self.lane_band_upper = None
        self.lane_band_target = None
        self.lane_band_mode = 'OFF'
        self.lane_direction_hits = 0
        self.lane_target_heading = self.lane_heading_error = 0.
        self.lane_heading_quality = 'WAIT'
        self.lane_selected_heading = None
        self.lane_heading_source = 'NONE'
        self.lane_heading_observation = None
        self.curve_locator=WallLocalizer(entry_wide=self.entry_v33_enabled)
        # V35.11: keep driving from live RF2O between wall measurements.
        # A delayed wall fit is not itself a reason to brake mid-orbit.
        self.curve_odom_samples=deque(maxlen=200)
        self.curve_pose_odom=None
        self.curve_pose_odom_alignment='WAIT_ALIGNMENT'
        self.curve_pose_odom_stamp=None
        self.curve_odom_source_stamp=None
        self.curve_odom_source_gap=None
        self.curve_control_prediction_enabled=True
        self.curve_motion_samples=deque(maxlen=8)
        self.curve_motion_velocity=None
        self.curve_motion_clock_sample=None
        self.curve_motion_status={}
        self.curve_recovery_state=None
        self.curve_recovery_status={'state':'WAIT'}
        self.curve_prediction_pause=None
        # Covers .5 s source lag plus a .15 s control tick and sample phase.
        # Independent distance/turn caps still bound the extrapolation.
        # RF2O source lag plus .10--.16s callback time exceeded the previous
        # .75s limit in run 3. Keep independent distance/turn and raw-scan
        # bounds while allowing this observed latency through one second.
        self.curve_prediction_max_time=.95
        self.curve_prediction_max_distance=.80
        self.curve_prediction_max_turn=1.80
        self.curve_pose_estimate_reason='WAIT'
        self.curve_pose_ttl=10.0
        self.curve_prediction_distance=8.0
        self.curve_prediction_yaw=math.radians(270)
        self.curve_odom_max_age=.80
        self.curve_fit_result_ttl=1.20
        self.curve_registration_period=.30
        self.curve_pause_active=False
        self.curve_sweep_unknown_since=None
        self.curve_sweep_unknown_travel=0.
        self.curve_sweep_unknown_yaw=0.
        self.curve_sweep_unknown_stamp=0
        self.curve_sweep_clear_hits=0
        self.curve_tracks=ConeTracks(entry_relaxed=self.entry_v32_enabled,entry_wide=self.entry_v33_enabled)
        self.curve_follower=None
        # The last straight has its own fixed line in the live odometry frame.
        # Keep it through a red-light stop; the entrance wall fit is unrelated.
        self.final_straight_reference=None
        self.final_straight_status={'state':'INACTIVE'}
        self.curve_start=None
        self.curve_cones=None
        self.curve_second_locked=False
        self.curve_scan=None
        self.curve_scan_time=0.
        self.curve_scan_stamp=0
        self.curve_pose_stamp=0
        self.curve_pose_scan=None
        self.curve_executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='race_wall') if self.curve_route else None
        self.curve_job=None
        self.curve_generation=0
        self.curve_features=deque(maxlen=8)
        self.curve_registration_ms=0.
        self.curve_fit_ms=0.
        self.curve_registration_status='WAIT'
        self.curve_registration_submit_status='WAIT'
        self.curve_registration_pending=None
        # Registration observations only: one worker still processes at a time.
        # Current scan/command freshness uses curve_scan_time, never this cache.
        self.curve_registration_scans=deque(maxlen=16)
        self.curve_registration_pair_status={'state':'INACTIVE'}
        self.curve_job_strict_pair=None
        self.curve_scan_wait=False
        self.curve_scan_wait_since=None
        self.curve_pose_wait=False
        self.curve_pose_wait_since=None
        self.curve_pose_wait_reason='WAIT'
        self.curve_registration_late=False
        self.curve_scan_recovery_hits=0
        self.curve_reason='WAIT'
        self.curve_sweep='WAIT'
        self.curve_sweep_diagnostics={}
        # Timestamp of the initial curve handoff.  Entry-only lidar edge
        # tolerance expires quickly; subsequent curve safety checks stay strict.
        self.curve_handoff_time=None
        self.curve_last_process=0.
        self.curve_last_command=0.
        self.curve_drive=.35
        self.curve_prev_side=None
        self.curve_side_rate=0.
        self.curve_side_stamp=None
        self.curve_clearance_seen=0
        self.curve_ready_hits=0
        self.curve_last_plan=-1e9
        # V25: observation never grants motion before the crosswalk hold ends.
        for key, default in [('entry_prepare_x', 3.70), ('entry_hold_x', 4.50),
                             ('entry_align_limit_x', 4.80), ('entry_prepare_drive', .35),
                             ('entry_wait_budget', 5.0)]:
            self.declare_parameter(key, default)
            value = float(self.get_parameter(key).value)
            if not math.isfinite(value):raise ValueError('Invalid '+key)
            setattr(self, key, value)
        if not (3.2 <= self.entry_prepare_x < 4.40 <= self.entry_hold_x
                < self.entry_align_limit_x <= 4.85 and .20 <= self.entry_prepare_drive <= .35
                and 1. <= self.entry_wait_budget <= 5.):
            raise ValueError('Invalid entry preparation limits')
        self.entry_stage = 'PREOBSERVE'
        self.entry_hold = False
        self.entry_blockers = []
        self.entry_progress_x = None
        self.entry_wait_total = 0.0
        self.entry_wait_tick = None
        self.entry_was_waiting = False
        self.entry_plan_job = None
        self.entry_plan_ready = None
        self.entry_plan_anchor = None
        self.entry_plan_reference_reason = 'NO_REFERENCE'
        self.entry_plan_cancel = None
        self.entry_plan_compute_ms = 0.0
        # Only an already-confirmed stopped planning reference uses this gap.
        self.entry_plan_odom_gap = 2.0
        # Entry planning runs while the vehicle is held stopped.  These
        # limits are local to this planning phase; they do not change the
        # normal driving, crosswalk, or curve execution freshness limits.
        self.entry_plan_budget = 8.0
        self.entry_plan_reference_ttl = 60.0
        self.entry_plan_worker_state = 'IDLE'
        self.entry_plan_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='race_plan') if self.curve_route else None
        self.entry_plan_reason = 'WAIT'
        self.entry_plan_ms = 0.0
        self.entry_status_last = -1e9
        self.entry_status_key = None
        self.entry_status_pub = self.create_publisher(String, '/race/entry_status', 5)
        self.curve_pose_pub=self.create_publisher(String,'/race/curve_status',5)
        if self.curve_route:
            qos=QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,
                           history=HistoryPolicy.KEEP_LAST,depth=1)
            self.create_subscription(LaserScan,'/scan',self.curve_scan_callback,qos)
        self.rel_data = None
        self.rel_time = 0.0
        self.rel_stamp = 0
        self.rel_target = None
        self.rel_target_yaw = None
        self.rel_hits = 0
        self.rel_target_time = 0.0
        self.rel_second = None
        self.rel_leg = 1
        self.rel_second_hits = 0
        self.rel_ready_since = None
        self.rel_wait_since = None
        self.rel_corridor_hits = 0
        self.rel_boundary_seen = 0.0
        self.rel_start_yaw = None
        self.rel_yaw = 0.0
        self.rel_mode = 'WAIT'
        # V8: a stationary, multi-frame corridor reference; no absolute position.
        self.straight_samples = deque(maxlen=8)
        self.straight_reference = None
        self.straight_opening = False
        self.straight_open_hits = 0
        self.straight_boundary_seen = None
        self.straight_rate_samples = deque(maxlen=32)
        self.straight_yaw_rate = 0.0
        self.straight_error = 0.0
        self.straight_limit = 0.035
        # PID output retains this driver's dimensionless steering-command units.
        for key, default in [('center_pid_kp', .30), ('center_pid_ki', .02),
                             ('center_pid_kd', .04), ('center_pid_lookahead', .90),
                             ('center_pid_half_width', .45)]:
            self.declare_parameter(key, default)
            value = float(self.get_parameter(key).value)
            if not math.isfinite(value) or value < 0:
                raise ValueError('Invalid PID parameter: '+key)
            setattr(self, key, value)
        if not .50 <= self.center_pid_lookahead <= 1.50 or not .35 <= self.center_pid_half_width <= .60:
            raise ValueError('PID geometry outside supported straight corridor')
        self.reset_center_pid()
        # End-wall distance 2.0..2.5 m means approximately x=5.5..6.0
        # in the handbook's 8 m arena. It is a perception gate, not odom travel.
        self.entry_wall = None
        self.entry_wall_hits = 0
        self.entry_wall_time = 0.0
        self.entry_region_seen = False
        self.create_subscription(String, '/race/relative_features', self.relative_callback, 5)
        self.declare_parameter('layout_8x4', False)
        self.layout_enabled = bool(self.get_parameter('layout_8x4').value)
        self.declare_parameter('layout_auto_start', False)
        self.layout_auto_start = bool(self.get_parameter('layout_auto_start').value)
        self.auto_start_samples = deque(maxlen=128)
        self.auto_start_stamp = 0
        self.auto_start_time = 0.0
        self.auto_start_status = 'WAITING_FOR_THREE_WALLS'
        self.auto_start_started = None
        self.create_subscription(String, '/race/start_pose', self.auto_start_callback, 5)
        for key, default in [('layout_start_x', -1.0), ('layout_start_y', -1.0),
                             ('layout_start_yaw_deg', 0.0), ('layout_odom_sign', 0.0),
                             ('layout_odom_scale', 1.0), ('layout_rear_extent', 0.18),
                             ('layout_front_extent', 0.21), ('layout_half_width', 0.15)]:
            self.declare_parameter(key, default)
            setattr(self, key, float(self.get_parameter(key).value))
        # Handbook dimensions, in metres, measured at the inside faces.
        self.layout_length, self.layout_width = 8.0, 4.0
        self.layout_partition, self.layout_lane = 3.2, 0.9
        self.layout_cones = ((6.0, 2.0), (2.0, 2.0))  # encounter order, NOT labels C1/C2
        self.layout_margin = 0.10
        self.layout_anchor = None
        self.layout_pose = None
        self.layout_uncertainty = 0.15
        self.layout_error = ''
        if self.relative_route and self.layout_enabled:
            raise ValueError('relative_route must use layout_8x4=false; no absolute odometry configuration')
        if self.layout_enabled:
            values = [self.layout_start_x, self.layout_start_y, self.layout_start_yaw_deg,
                      self.layout_odom_sign, self.layout_odom_scale, self.layout_rear_extent,
                      self.layout_front_extent, self.layout_half_width]
            if not all(math.isfinite(v) for v in values):
                raise ValueError('Layout inputs must be finite')
            if (self.layout_odom_sign not in (-1.0, 1.0)
                    or not 0.5 <= self.layout_odom_scale <= 2.0
                    or (not self.layout_auto_start and abs(self.layout_start_yaw_deg) > 5.0)
                    or not all(0.05 <= v <= 0.50 for v in
                               (self.layout_rear_extent, self.layout_front_extent, self.layout_half_width))
                    or (not self.layout_auto_start and not self.layout_rear_extent+0.10 < self.layout_start_x < 1.5)
                    or (not self.layout_auto_start and not self.layout_half_width+0.10 < self.layout_start_y < 0.9-self.layout_half_width-0.10)):
                raise ValueError('Measure layout_start_x/y, odom sign/scale and laser-relative body extents; align at start')

        self.declare_parameter('final_cmd_topic', '/car_cmd_vel')
        self.declare_parameter('vision_topic', '/ican_vision')
        self.declare_parameter('lidar_topic', '/race/lidar_status')
        self.declare_parameter('boundary_topic', '/race/track_boundary')
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('startup_delay', 8.0)
        self.declare_parameter('sensor_timeout', 1.0)
        self.declare_parameter('crosswalk_stop_duration', 3.2)
        self.declare_parameter('crosswalk_confirm_frames', 1)
        self.declare_parameter('crosswalk_arm_travel', 0.80)
        self.declare_parameter('crosswalk_still_window', 0.5)
        self.declare_parameter('crosswalk_still_distance', 0.015)
        self.declare_parameter('crosswalk_still_yaw', 0.04)
        self.declare_parameter('crosswalk_odom_max_gap', 0.30)
        self.declare_parameter('red_confirm_frames', 2)
        self.declare_parameter('green_confirm_frames', 4)
        self.declare_parameter('traffic_light_max_gap', 0.35)
        self.declare_parameter('cone_confirm_frames', 12)
        self.declare_parameter('cone_trigger_distance', 1.45)
        self.declare_parameter('cone_min_lateral', 0.12)
        self.declare_parameter('cone_max_lateral', 1.10)
        self.declare_parameter('post_crosswalk_min_travel', 0.70)
        self.declare_parameter('post_crosswalk_straight_distance', 0.60)
        self.declare_parameter('post_crosswalk_clear_frames', 8)
        self.declare_parameter('post_crosswalk_max_straight_distance', 1.50)
        self.declare_parameter('entry_turn_angle_deg', 60.0)
        self.declare_parameter('entry_turn_angular', 0.22)
        self.declare_parameter('entry_max_travel', 1.8)
        self.declare_parameter('entry_left_clearance', 0.65)
        self.declare_parameter('entry_open_confirm_frames', 2)
        self.declare_parameter('test_stop_after_entry', False)
        self.declare_parameter('test_stop_after_exit', False)
        self.declare_parameter('dry_run', False)
        self.declare_parameter('side_distance_guard_enabled', True)
        self.declare_parameter('side_steering_guard_enabled', True)
        self.declare_parameter('exit_side_stop_distance', 0.40)
        self.declare_parameter('exit_front_stop_distance', 0.85)
        self.declare_parameter('exit_center_gain', 0.70)
        self.declare_parameter('exit_center_deadband', 0.02)
        self.declare_parameter('exit_maximum_angular', 0.08)
        # Opt in only through the bounded departure test launch.
        self.declare_parameter('exit_single_wall_control', False)
        self.exit_single_wall_control = bool(self.get_parameter('exit_single_wall_control').value)
        self.declare_parameter('exit_continuous', False)
        self.exit_continuous = bool(self.get_parameter('exit_continuous').value)
        self.exit_continuous_settling = False
        self.declare_parameter('exit_spatial_guard', False)
        self.exit_spatial_guard = bool(self.get_parameter('exit_spatial_guard').value)
        self.exit_spatial = []
        self.exit_spatial_status = 'WAIT'
        self.exit_risk_side = ''
        self.exit_risk_angular = 0.0
        self.exit_pulse_start_xy = None
        self.exit_pulse_cautious = False
        self.exit_width_samples = deque(maxlen=8)
        self.exit_reference_half_width = None
        self.exit_current_wall = [0.0, 0.0, False, False]
        self.exit_steering_mode = 'WAIT'
        self.exit_single_heading_gain = 0.70
        self.exit_single_heading_limit = math.radians(20.0)
        self.exit_center_gain = float(self.get_parameter('exit_center_gain').value)
        self.exit_center_deadband = float(self.get_parameter('exit_center_deadband').value)
        self.exit_maximum_angular = float(self.get_parameter('exit_maximum_angular').value)
        if not (math.isfinite(self.exit_center_gain) and self.exit_center_gain > 0
                and math.isfinite(self.exit_center_deadband) and self.exit_center_deadband >= 0
                and math.isfinite(self.exit_maximum_angular) and 0 < self.exit_maximum_angular <= 0.08):
            raise ValueError('Invalid departure steering parameters')
        self.test_stop_after_exit = bool(self.get_parameter('test_stop_after_exit').value)
        if self.relative_route and not self.exit_continuous:
            raise ValueError('relative_route requires continuous departure')
        if self.layout_enabled and not self.exit_continuous:
            raise ValueError('layout_8x4 requires exit_continuous=true')
        if self.exit_continuous and (self.exit_single_wall_control or self.exit_spatial_guard):
            raise ValueError('Continuous departure uses the original full-route guard, not commissioning guards')
        if self.exit_single_wall_control and not self.test_stop_after_exit:
            raise ValueError('Single-wall commissioning requires test_stop_after_exit=true')
        if self.exit_spatial_guard and not (self.test_stop_after_exit and self.exit_single_wall_control):
            raise ValueError('Spatial guard requires the bounded single-wall exit test')
        self.dry_run = bool(self.get_parameter('dry_run').value)
        self.side_distance_guard_enabled = self.get_parameter('side_distance_guard_enabled').value
        self.side_steering_guard_enabled = self.get_parameter('side_steering_guard_enabled').value
        if not all(type(v) is bool for v in (self.side_distance_guard_enabled, self.side_steering_guard_enabled)):
            raise ValueError('Side guard switches must be booleans')
        if self.exit_spatial_guard and not self.side_distance_guard_enabled:
            raise ValueError('Spatial commissioning requires side distance guards')
        self.exit_side_stop_distance = float(self.get_parameter('exit_side_stop_distance').value)
        self.exit_front_stop_distance = float(self.get_parameter('exit_front_stop_distance').value)
        if self.exit_spatial_guard and abs(self.exit_side_stop_distance - 0.40) > 1e-6:
            raise ValueError('Spatial guard requires the unchanged 0.40 m side threshold')
        if not all(math.isfinite(v) and v > 0 for v in
                   (self.exit_side_stop_distance, self.exit_front_stop_distance)):
            raise ValueError('Invalid departure stop distances')
        if not .50 <= self.exit_front_stop_distance <= 1.50:
            raise ValueError('exit_front_stop_distance must be within 0.50..1.50 metres')
        self.entry_open_confirm_frames = int(self.get_parameter('entry_open_confirm_frames').value)
        if self.entry_open_confirm_frames < 1:
            raise ValueError('entry_open_confirm_frames must be positive')
        self.test_stop_after_entry = bool(self.get_parameter('test_stop_after_entry').value)
        self.entry_open_count = 0
        self.entry_body_count = 0
        self.exit_pulse_mode = 'WAIT'
        self.exit_pulse_since = time.monotonic()
        self.exit_pulse_count = 0
        self.declare_parameter('entry_cone_offset', 0.90)
        self.declare_parameter('entry_cone_stop_distance', 0.80)
        self.entry_cone_offset = float(self.get_parameter('entry_cone_offset').value)
        self.entry_cone_stop_distance = float(self.get_parameter('entry_cone_stop_distance').value)
        if not (math.isfinite(self.entry_cone_offset) and
                math.isfinite(self.entry_cone_stop_distance) and
                0.65 < self.entry_cone_stop_distance < self.entry_cone_offset):
            raise ValueError('Invalid entry cone clearance parameters')
        self.entry_cone = None
        self.entry_cone_hits = 0
        self.entry_cone_time = 0.0
        self.entry_cone_limit = 0.0
        self.entry_angle = math.radians(float(self.get_parameter('entry_turn_angle_deg').value))
        self.entry_angular = float(self.get_parameter('entry_turn_angular').value)
        self.entry_max_travel = float(self.get_parameter('entry_max_travel').value)
        self.entry_left_clearance = float(self.get_parameter('entry_left_clearance').value)
        if not (0 < self.entry_angle < math.pi and self.entry_angular > 0
                and self.entry_max_travel > 0 and self.entry_left_clearance > 0):
            raise ValueError('Invalid obstacle entry parameters')
        self.entry_done = False
        self.exit_heading = None
        self.exit_origin_xy = None
        self.entry_yaw = 0.0
        self.entry_start_distance = 0.0
        self.route_fault = ''
        self.route_hold_reason = ''
        self.lidar_left_clearance = -1.0
        self.lidar_right_clearance = -1.0
        self.last_candidates_time = 0.0
        self.last_route_status_time = 0.0
        self.declare_parameter('cone_orbit_directions', [1, -1])
        self.declare_parameter('cone_orbit_angle_deg', 150.0)
        self.declare_parameter('cone_orbit_distance', 0.72)
        self.declare_parameter('cone_orbit_speed', 0.35)
        self.declare_parameter('cone_orbit_angular', 0.35)
        self.declare_parameter('cone_distance_gain', 0.25)
        self.declare_parameter('normal_speed', 0.35)
        self.declare_parameter('caution_speed', 0.35)
        self.declare_parameter('minimum_drive_speed', 0.35)
        self.declare_parameter('maximum_angular', 0.45)
        self.declare_parameter('lane_maximum_angular', 0.18)
        self.declare_parameter('lane_steering_slew_per_sec', 0.55)
        self.declare_parameter('safety_maximum_angular', 0.30)
        self.declare_parameter('safety_steering_slew_per_sec', 1.20)
        self.declare_parameter('steering_sign', 1.0)
        self.declare_parameter('boundary_heading_gain', 0.35)
        self.declare_parameter('boundary_center_gain', 0.70)
        self.declare_parameter('boundary_center_deadband', 0.05)
        self.declare_parameter('approach_center_gain', 0.35)
        self.declare_parameter('approach_center_deadband', 0.02)
        self.declare_parameter('approach_maximum_angular', 0.08)
        self.declare_parameter('wall_soft_distance', 0.80)
        self.declare_parameter('wall_soft_gain', 0.65)
        self.declare_parameter('side_guard_distance', 0.55)
        self.declare_parameter('side_guard_hard_distance', 0.30)
        self.declare_parameter('side_guard_gain', 0.80)
        self.declare_parameter('boundary_escape_hold_time', 0.15)
        self.declare_parameter('boundary_escape_switch_margin', 0.04)
        self.declare_parameter('wall_direction_guard_distance', 0.52)
        self.declare_parameter('wall_direction_guard_angular', 0.22)
        self.declare_parameter('wall_direction_guard_margin', 0.04)
        self.declare_parameter('obstacle_pulse_period', 0.0)
        self.declare_parameter('obstacle_pulse_on_time', 0.0)
        self.declare_parameter('start_straight_distance', 0.0)
        self.declare_parameter('start_steering_ramp_distance', 0.0)
        self.declare_parameter('single_boundary_distance', 0.38)
        self.declare_parameter('single_boundary_gain', 0.60)
        self.declare_parameter('front_turn_distance', 1.25)
        self.declare_parameter('front_turn_gain', 0.75)
        self.declare_parameter('finish_min_travel', 1.0)
        self.declare_parameter('finish_max_travel', 6.5)
        self.declare_parameter('finish_wall_distance', 0.72)

        self.final_cmd_topic = str(self.get_parameter('final_cmd_topic').value)
        if self.dry_run:
            self.final_cmd_topic = '/race/proposed_cmd_vel'
        self.startup_delay = float(self.get_parameter('startup_delay').value)
        self.sensor_timeout = float(self.get_parameter('sensor_timeout').value)
        self.crosswalk_stop_duration = float(
            self.get_parameter('crosswalk_stop_duration').value
        )
        self.crosswalk_confirm_frames = int(
            self.get_parameter('crosswalk_confirm_frames').value
        )
        self.crosswalk_arm_travel = float(
            self.get_parameter('crosswalk_arm_travel').value
        )
        if self.curve_route:
            if not math.isfinite(self.crosswalk_arm_travel):
                raise ValueError('crosswalk_arm_travel must be finite')
            self.crosswalk_arm_travel = max(.80, self.crosswalk_arm_travel)
        self.crosswalk_start_pose = None
        self.crosswalk_start_source = None
        self.crosswalk_arm_status = dict(active=False, reason='WAIT_APPROACH_START')
        self.still_window = float(self.get_parameter('crosswalk_still_window').value)
        self.still_distance = float(self.get_parameter('crosswalk_still_distance').value)
        self.still_yaw = float(self.get_parameter('crosswalk_still_yaw').value)
        self.odom_max_gap = float(self.get_parameter('crosswalk_odom_max_gap').value)
        if min(self.still_window, self.still_distance, self.still_yaw, self.odom_max_gap) <= 0:
            raise ValueError('Standstill thresholds must be positive')
        self.crosswalk_stop_duration = max(3.0, self.crosswalk_stop_duration)
        self.odom_still_samples = deque(maxlen=200)
        self.last_still_stamp = None
        self.still_since = None
        self.crosswalk_hold_started = None
        self.crosswalk_hold_source = None
        self.crosswalk_hold_anchor = None
        self.crosswalk_hold_last_sample = None
        self.crosswalk_source_samples = deque(maxlen=200)
        self.crosswalk_brake_source = None
        self.crosswalk_hold_clock = None
        self.crosswalk_hold_reason = 'WAIT_BRAKE'
        self.crosswalk_hold_reset_reason = 'WAIT_BRAKE'
        self.red_confirm_frames = int(self.get_parameter('red_confirm_frames').value)
        self.green_confirm_frames = int(
            self.get_parameter('green_confirm_frames').value
        )
        self.traffic_light_max_gap = float(self.get_parameter('traffic_light_max_gap').value)
        if not math.isfinite(self.traffic_light_max_gap) or not .05 <= self.traffic_light_max_gap <= .50:
            raise ValueError('Invalid traffic_light_max_gap')
        self.cone_confirm_frames = int(
            self.get_parameter('cone_confirm_frames').value
        )
        self.cone_trigger_distance = float(
            self.get_parameter('cone_trigger_distance').value
        )
        self.cone_min_lateral = float(
            self.get_parameter('cone_min_lateral').value
        )
        self.cone_max_lateral = float(
            self.get_parameter('cone_max_lateral').value
        )
        self.post_crosswalk_min_travel = float(
            self.get_parameter('post_crosswalk_min_travel').value
        )
        self.post_crosswalk_straight_distance = float(
            self.get_parameter('post_crosswalk_straight_distance').value
        )
        self.post_crosswalk_clear_frames = int(
            self.get_parameter('post_crosswalk_clear_frames').value
        )
        self.post_crosswalk_max_straight_distance = float(
            self.get_parameter('post_crosswalk_max_straight_distance').value
        )
        self.cone_orbit_directions = [
            1 if int(value) >= 0 else -1
            for value in self.get_parameter('cone_orbit_directions').value
        ]
        self.cone_orbit_angle = math.radians(
            float(self.get_parameter('cone_orbit_angle_deg').value)
        )
        self.cone_orbit_distance = float(
            self.get_parameter('cone_orbit_distance').value
        )
        self.cone_orbit_speed = float(
            self.get_parameter('cone_orbit_speed').value
        )
        self.cone_orbit_angular = float(
            self.get_parameter('cone_orbit_angular').value
        )
        self.cone_distance_gain = float(
            self.get_parameter('cone_distance_gain').value
        )
        self.normal_speed = float(self.get_parameter('normal_speed').value)
        self.caution_speed = float(self.get_parameter('caution_speed').value)
        self.minimum_drive_speed = float(
            self.get_parameter('minimum_drive_speed').value
        )
        self.maximum_angular = float(
            self.get_parameter('maximum_angular').value
        )
        self.lane_maximum_angular = float(
            self.get_parameter('lane_maximum_angular').value
        )
        self.lane_steering_slew_per_sec = float(
            self.get_parameter('lane_steering_slew_per_sec').value
        )
        self.safety_maximum_angular = float(
            self.get_parameter('safety_maximum_angular').value
        )
        self.safety_steering_slew_per_sec = float(
            self.get_parameter('safety_steering_slew_per_sec').value
        )
        self.steering_sign = 1.0 if float(
            self.get_parameter('steering_sign').value
        ) >= 0.0 else -1.0
        self.boundary_heading_gain = float(
            self.get_parameter('boundary_heading_gain').value
        )
        self.boundary_center_gain = float(
            self.get_parameter('boundary_center_gain').value
        )
        self.boundary_center_deadband = float(
            self.get_parameter('boundary_center_deadband').value
        )
        self.approach_center_gain = float(
            self.get_parameter('approach_center_gain').value
        )
        self.approach_center_deadband = float(
            self.get_parameter('approach_center_deadband').value
        )
        self.approach_maximum_angular = float(
            self.get_parameter('approach_maximum_angular').value
        )
        self.wall_soft_distance = float(
            self.get_parameter('wall_soft_distance').value
        )
        self.wall_soft_gain = float(
            self.get_parameter('wall_soft_gain').value
        )
        self.side_guard_distance = float(
            self.get_parameter('side_guard_distance').value
        )
        self.side_guard_hard_distance = float(
            self.get_parameter('side_guard_hard_distance').value
        )
        self.side_guard_gain = float(
            self.get_parameter('side_guard_gain').value
        )
        self.boundary_escape_hold_time = float(
            self.get_parameter('boundary_escape_hold_time').value
        )
        self.boundary_escape_switch_margin = float(
            self.get_parameter('boundary_escape_switch_margin').value
        )
        self.wall_direction_guard_distance = float(
            self.get_parameter('wall_direction_guard_distance').value
        )
        self.wall_direction_guard_angular = float(
            self.get_parameter('wall_direction_guard_angular').value
        )
        self.wall_direction_guard_margin = float(
            self.get_parameter('wall_direction_guard_margin').value
        )
        self.obstacle_pulse_period = float(
            self.get_parameter('obstacle_pulse_period').value
        )
        self.obstacle_pulse_on_time = float(
            self.get_parameter('obstacle_pulse_on_time').value
        )
        self.start_straight_distance = float(
            self.get_parameter('start_straight_distance').value
        )
        self.start_steering_ramp_distance = max(
            self.start_straight_distance,
            float(self.get_parameter('start_steering_ramp_distance').value),
        )
        self.single_boundary_distance = float(
            self.get_parameter('single_boundary_distance').value
        )
        self.single_boundary_gain = float(
            self.get_parameter('single_boundary_gain').value
        )
        self.front_turn_distance = float(
            self.get_parameter('front_turn_distance').value
        )
        self.front_turn_gain = float(
            self.get_parameter('front_turn_gain').value
        )
        self.finish_min_travel = float(
            self.get_parameter('finish_min_travel').value
        )
        self.finish_max_travel = float(
            self.get_parameter('finish_max_travel').value
        )
        self.finish_wall_distance = float(
            self.get_parameter('finish_wall_distance').value
        )

        self.create_subscription(
            Int16MultiArray,
            str(self.get_parameter('vision_topic').value),
            self.vision_callback,
            10,
        )
        self.create_subscription(
            Float32MultiArray,
            str(self.get_parameter('lidar_topic').value),
            self.lidar_callback,
            10,
        )
        self.create_subscription(
            Float32MultiArray,
            str(self.get_parameter('boundary_topic').value),
            self.boundary_callback,
            10,
        )
        self.create_subscription(
            Odometry,
            str(self.get_parameter('odom_topic').value),
            self.odom_callback,
            1,
        )

        self.cmd_pub = self.create_publisher(Twist, self.final_cmd_topic, 10)
        self.state_pub = self.create_publisher(String, '/race/control_state', 10)
        self.phase_pub = self.create_publisher(String, '/race/task_phase', 10)
        self.finished_pub = self.create_publisher(Bool, '/race/mission_finished', 10)
        self.route_status_pub = self.create_publisher(String, '/race/route_status', 10)
        self.create_subscription(Float32MultiArray, '/race/cone_candidates', self.cones_callback, 5)
        self.create_timer(0.05, self.control_loop)

        now = time.monotonic()
        self.started_at = now
        self.phase = self.STARTUP
        self.phase_started_at = now
        self.last_published_state = ''
        self.last_vision_time = 0.0
        self.last_lidar_time = 0.0
        self.last_boundary_time = 0.0
        self.last_odom_time = 0.0

        self.red = False
        self.green = False
        self.crosswalk = False
        self.crosswalk_present = False
        self.red_count = 0
        self.green_count = 0
        self.crosswalk_count = 0
        self.crosswalk_clear_count = 0
        self.crosswalk_stop_until = 0.0

        self.cone_detected = False
        self.cone_x = -1.0
        self.cone_y = 0.0
        self.cone_distance = -1.0
        self.raw_cone = None
        self.cone_confirm_count = 0
        self.front_clearance = 0.0
        self.lidar_caution = False
        self.lidar_emergency = False
        self.preferred_side = 0

        self.left_distance = -1.0
        self.right_distance = -1.0
        self.boundary_front = 0.0
        self.center_error = 0.0
        self.heading_error = 0.0
        self.exit_side_detail = [-1.0, 0.0, -1.0, -1.0, 0.0, -1.0]
        self.exit_fault_detail = ''
        self.left_proximity = -1.0
        self.right_proximity = -1.0
        self.initial_heading_sum = 0.0
        self.initial_heading_count = 0
        self.initial_heading_bias = 0.0
        self.left_valid = False
        self.right_valid = False

        self.travel_distance = 0.0
        self.last_odom_xy = None
        self.last_yaw = None
        self.orbit_yaw = 0.0
        self.finish_start_distance = 0.0
        self.approach_start_distance = 0.0
        self.first_cone_seek_start_distance = 0.0
        self.last_lane_angular = 0.0
        self.last_lane_command_time = time.monotonic()
        self.boundary_escape_latch = 0
        self.boundary_escape_until = 0.0

        self.get_logger().warn(
            '国赛总控状态机已启动：不读取旧地图，不接受人工路点，等待传感器'
        )

    def curve_observation_active(self):
        return self.curve_route and (self.phase in (self.APPROACH_CROSSWALK, self.CROSSWALK_STOP)
                                     or self.relative_active())

    def curve_odom_at(self, stamp):
        # Match odom_callback arithmetic so exact source stamps stay exact.
        return interpolate_odom(self.curve_odom_samples,stamp//1000000000+(stamp%1000000000)*1e-9)

    @staticmethod
    def curve_integrate_motion(pose, velocity, dt):
        """Integrate a measured, constant body twist in the laser frame."""
        vx,vy,w=velocity;angle=w*dt
        if abs(w)<1e-8:a,b=dt,0.
        else:a,b=math.sin(angle)/w,(1.-math.cos(angle))/w
        dx,dy=a*vx-b*vy,b*vx+a*vy
        c,s=math.cos(pose[2]),math.sin(pose[2])
        return (pose[0]+c*dx-s*dy,pose[1]+s*dx+c*dy,normalize_angle(pose[2]+angle))

    def curve_source_now(self):
        try:return int(self.get_clock().now().nanoseconds)
        except (AttributeError,TypeError,ValueError):return None

    def curve_update_motion(self, source_stamp, pose, now, msg):
        """Keep real samples separate from all short-horizon predictions."""
        if not hasattr(self,'curve_motion_samples'):self.curve_motion_samples=deque(maxlen=8)
        samples=self.curve_motion_samples;previous_velocity=getattr(self,'curve_motion_velocity',None)
        self.curve_motion_velocity=None
        ros_now=self.curve_source_now()
        self.curve_motion_clock_sample=(now,ros_now) if ros_now is not None else None
        samples.append((source_stamp,*pose))
        status=getattr(self,'curve_motion_status',{})
        status.update(odom_source_stamp=source_stamp,velocity_policy='WAIT_SOURCE_PAIR',
            speed=None,speed_mps=None,vx_mps=None,vy_mps=None,yaw_rate_rad_s=None,
            velocity_span_s=None,velocity_change_mps=None,yaw_rate_change_rad_s=None,
            rejected_speed_mps=None,rejected_yaw_rate_rad_s=None)
        # RF2O also publishes twist. Keep it as a diagnostic: its linear.x is
        # the laser increment, whereas the source poses provide a full SE(2)
        # laser-frame velocity including the 0.07 m base/laser offset.
        try:
            rv,rw=float(msg.twist.twist.linear.x),float(msg.twist.twist.angular.z)
            if math.isfinite(rv) and math.isfinite(rw):status.update(rf2o_twist_mps=rv,rf2o_twist_rad_s=rw)
        except (AttributeError,TypeError,ValueError):pass
        if len(samples)>=2:
            a,b=samples[-2],samples[-1];dt=(b[0]-a[0])*1e-9
            if .035<=dt<=.50:
                c,s=math.cos(a[3]),math.sin(a[3]);dx,dy=b[1]-a[1],b[2]-a[2]
                dx,dy=c*dx+s*dy,-s*dx+c*dy
                angle=normalize_angle(b[3]-a[3])
                aa=math.sin(angle)/angle if abs(angle)>1e-8 else 1.
                bb=(1.-math.cos(angle))/angle if abs(angle)>1e-8 else 0.
                denominator=(aa*aa+bb*bb)*dt
                velocity=((aa*dx+bb*dy)/denominator,(-bb*dx+aa*dy)/denominator,angle/dt)
                speed=math.hypot(*velocity[:2])
                status['velocity_span_s']=dt
                if all(math.isfinite(v) for v in velocity) and speed<=3. and abs(velocity[2])<=5.:
                    self.curve_motion_velocity=velocity;status['velocity_policy']='SOURCE_SE2'
                    status.update(speed=speed,speed_mps=speed,vx_mps=velocity[0],vy_mps=velocity[1],
                                  yaw_rate_rad_s=velocity[2])
                    if previous_velocity is not None:
                        status.update(velocity_change_mps=math.hypot(velocity[0]-previous_velocity[0],velocity[1]-previous_velocity[1]),
                                      yaw_rate_change_rad_s=abs(velocity[2]-previous_velocity[2]))
                else:
                    status.update(velocity_policy='SOURCE_VELOCITY_REJECTED',
                        rejected_speed_mps=speed,rejected_yaw_rate_rad_s=velocity[2])
            else:status['velocity_policy']='SOURCE_SPAN_REJECTED'
        self.curve_motion_status=status

    def curve_motion_at(self, stamp, now):
        """Return a source-time pose and its policy, without changing history."""
        samples=getattr(self,'curve_motion_samples',())
        # ``now`` may be the start of a costly control callback. Compare the
        # current ROS clock with its contemporaneous monotonic clock, rather
        # than mistaking callback computation time for a ROS clock jump.
        clock_before=time.monotonic();ros_now=self.curve_source_now()
        clock_after=time.monotonic();clock_now=.5*(clock_before+clock_after)
        # Receipt and pause ages use the same current clock as ROS validation;
        # an earlier callback-start ``now`` must not renew or shorten evidence.
        now=max(now,clock_now)
        detail=dict(policy='WAIT_SOURCE_MOTION',prediction_dt_s=0.,prediction_distance_m=0.,prediction_yaw_rad=0.)
        if not samples or ros_now is None:return None,detail
        latest=samples[-1];source_age=(ros_now-latest[0])*1e-9
        detail.update(odom_source_stamp=latest[0],odom_source_age_s=source_age,target_source_stamp=stamp)
        if not 0<=now-self.last_odom_time<=self.curve_odom_max_age:
            detail['policy']='ODOM_RECEIPT_STALE';return None,detail
        clock_sample=getattr(self,'curve_motion_clock_sample',None)
        if clock_sample is not None:
            error=(ros_now-clock_sample[1])*1e-9-(clock_now-clock_sample[0]);detail['clock_error_s']=error
            detail['clock_read_span_s']=max(0.,clock_after-clock_before)
            if abs(error)>.15:
                detail['policy']='SOURCE_CLOCK_CHANGED';return None,detail
        if source_age<-.02:
            detail['policy']='SOURCE_CLOCK_FUTURE';return None,detail
        # A future/exact real sample must not bypass a physically rejected
        # source increment, or feed its invalid speed into the body rollout.
        if getattr(self,'curve_motion_status',{}).get('velocity_policy')=='SOURCE_VELOCITY_REJECTED':
            detail['policy']='SOURCE_VELOCITY_REJECTED';return None,detail
        if getattr(self,'curve_pause_active',False):
            if getattr(self,'curve_prediction_pause',None) is None:self.curve_prediction_pause=(now,ros_now)
        else:self.curve_prediction_pause=None
        before=next((a for a in reversed(samples) if a[0]<=stamp),None)
        after=next((a for a in samples if a[0]>=stamp),None)
        if before is not None and after is not None:
            if max(stamp-before[0],after[0]-stamp)>160000000:
                detail['policy']='SOURCE_INTERPOLATION_GAP';return None,detail
            if before[0]==after[0]:result=tuple(before[1:4])
            else:
                f=(stamp-before[0])/(after[0]-before[0])
                result=(before[1]+f*(after[1]-before[1]),before[2]+f*(after[2]-before[2]),
                        normalize_angle(before[3]+f*normalize_angle(after[3]-before[3])))
            detail['policy']='SOURCE_MEASURED';return result,detail
        if stamp<latest[0]:
            detail['policy']='SOURCE_HISTORY_MISSING';return None,detail
        dt=(stamp-latest[0])*1e-9;detail['prediction_dt_s']=dt
        pause=getattr(self,'curve_prediction_pause',None)
        if pause is not None and now-pause[0]>.60 and latest[0]<pause[1]:
            detail['policy']='PRE_STOP_SOURCE_EXPIRED';return None,detail
        velocity=getattr(self,'curve_motion_velocity',None)
        if velocity is None:
            detail['policy']='WAIT_SOURCE_VELOCITY';return None,detail
        distance=math.hypot(*velocity[:2])*dt;turn=abs(velocity[2])*dt
        detail.update(prediction_distance_m=distance,prediction_yaw_rad=turn)
        if (dt>getattr(self,'curve_prediction_max_time',.95)+1e-9
                or distance>getattr(self,'curve_prediction_max_distance',.80)+1e-9
                or turn>getattr(self,'curve_prediction_max_turn',1.80)+1e-9):
            detail['policy']='SOURCE_PREDICTION_LIMIT';return None,detail
        detail['policy']='SOURCE_PREDICTED'
        return self.curve_integrate_motion(tuple(latest[1:4]),velocity,dt),detail

    def curve_odom_estimate(self, stamp, now):
        pose,detail=self.curve_motion_at(stamp,now)
        if not hasattr(self,'curve_motion_status'):self.curve_motion_status={}
        self.curve_motion_status.update(detail)
        return pose

    def curve_scan_pose(self, now, fallback_pose):
        active=(getattr(self,'curve_control_prediction_enabled',False) and self.curve_follower is not None)
        if not active:
            at_scan=self.curve_odom_at(self.curve_scan_stamp)
            return (bridge_pose(fallback_pose,tuple(self.curve_odom_samples[-1][1:4]),at_scan)
                    if at_scan is not None and self.curve_odom_samples else fallback_pose)
        if self.curve_pose_odom is None or self.curve_locator.pose is None:return None
        odom,detail=self.curve_motion_at(self.curve_scan_stamp,now)
        self.curve_motion_status.update(scan_pose_policy=detail['policy'],
            scan_prediction_dt_s=detail['prediction_dt_s'],scan_source_stamp=self.curve_scan_stamp)
        if odom is None:return None
        # Both scan and control use the SAME real wall-fit anchor. In particular
        # do not inverse-bridge a predicted control pose from a real, older odom.
        result=bridge_pose(self.curve_locator.pose,self.curve_pose_odom,odom)
        self.curve_motion_status['scan_pose']=result
        return result

    def curve_pose_estimate(self, now):
        loc=self.curve_locator
        if loc.pose is None or loc.time is None or loc.hits<1:
            self.curve_pose_estimate_reason='WAIT_OBSERVATION';return None
        age=now-loc.time
        if not 0<=age<=self.curve_pose_ttl:
            self.curve_pose_estimate_reason='OBSERVATION_EXPIRED';return None
        if self.curve_pose_odom is not None and self.curve_odom_samples:
            if not 0<=now-self.last_odom_time<=self.curve_odom_max_age:
                self.curve_pose_estimate_reason='ODOM_STALE';return None
            current=tuple(self.curve_odom_samples[-1][1:4])
            delta=math.hypot(current[0]-self.curve_pose_odom[0],current[1]-self.curve_pose_odom[1])
            dyaw=abs(normalize_angle(current[2]-self.curve_pose_odom[2]))
            if delta>self.curve_prediction_distance or dyaw>self.curve_prediction_yaw:
                self.curve_pose_estimate_reason='PREDICTION_LIMIT';return None
            if (getattr(self,'curve_control_prediction_enabled',False) and self.curve_follower is not None):
                source_now=self.curve_source_now()
                predicted=self.curve_odom_estimate(source_now,now) if source_now is not None else None
                if predicted is None:
                    self.curve_pose_estimate_reason=self.curve_motion_status.get('policy','SOURCE_CLOCK_UNAVAILABLE');return None
                result=bridge_pose(loc.pose,self.curve_pose_odom,predicted)
                self.curve_motion_status['control_pose']=result
                self.curve_pose_estimate_reason='ODOM_'+self.curve_motion_status['policy']
                return result
            self.curve_pose_estimate_reason='ODOM_BRIDGED'
            return bridge_pose(loc.pose,self.curve_pose_odom,current)
        if (getattr(self,'curve_control_prediction_enabled',False) and self.curve_follower is not None):
            self.curve_pose_estimate_reason='WAIT_ODOM_ALIGNMENT';return None
        # Missing frame alignment is not permission to propagate a moving car.
        measured_while_stopped=(self.phase==self.SEEK_CONE_1 and self.entry_hold
            and self.curve_follower is None and self.entry_v33_brake_since is not None
            and loc.time>=self.entry_v33_brake_since+.35 and self.entry_is_stopped(now))
        if age<=.25 or (age<=2.0 and measured_while_stopped):
            self.curve_pose_estimate_reason='OBSERVED_OR_STOPPED';return loc.pose
        self.curve_pose_estimate_reason='WAIT_ODOM_ALIGNMENT';return None

    def curve_registration_seed(self, stamp):
        loc=self.curve_locator;at_scan=self.curve_odom_at(stamp)
        if loc.pose is None:return None
        now=time.monotonic()
        stopped=(self.odom_is_still(now) or getattr(self,'entry_is_stopped',lambda t:False)(now))
        if at_scan is None:
            if not stopped or not 0<=now-self.last_odom_time<=.80:return None
            # This is initialization for a NEW complete measured wall fit,
            # never a synthetic observation or a fabricated odom anchor. Once
            # stopped, RF2O matching lag must not starve localization forever.
            if self.curve_pose_odom is not None and self.curve_odom_samples:
                latest=self.curve_odom_samples[-1]
                current=tuple(latest[1:4])
                gap=abs(latest[0]-(stamp//1000000000+(stamp%1000000000)*1e-9))
                distance=math.hypot(current[0]-self.curve_pose_odom[0],current[1]-self.curve_pose_odom[1])
                dyaw=abs(normalize_angle(current[2]-self.curve_pose_odom[2]))
                if gap<=.80 and distance<=8. and dyaw<=math.radians(270):
                    return bridge_pose(loc.pose,self.curve_pose_odom,current)
            # Without an odom anchor its global yaw drift is not a measured
            # change of wall heading. Let the new full fit measure heading.
            return tuple(loc.pose)
        # A stopped fit may complete before RF2O publishes the corresponding
        # scan's odometry. Recover that anchor from its ORIGINAL source stamp;
        # missing callback ordering must not permanently disable reseeding.
        if (self.curve_pose_stamp>0 and (self.curve_pose_odom is None
                or getattr(self,'curve_pose_odom_alignment','')=='STOPPED_ODOM_ANCHOR')):
            original_anchor=self.curve_odom_at(self.curve_pose_stamp)
            if original_anchor is not None:
                self.curve_pose_odom=original_anchor
                self.curve_pose_odom_stamp=self.curve_pose_stamp
                self.curve_pose_odom_alignment='SCAN_ALIGNED'
        if self.curve_pose_odom is None:
            if not 0<=now-self.last_odom_time<=.80 or not stopped:return None
            # After a real odom history gap this is initialization of a NEW
            # measured fit only. The .30 m/.14 rad fit correction limits stay
            # in WallLocalizer; no stale pose timestamp or movement is granted.
            return tuple(loc.pose)
        delta=math.hypot(at_scan[0]-self.curve_pose_odom[0],at_scan[1]-self.curve_pose_odom[1])
        if delta>8. or abs(normalize_angle(at_scan[2]-self.curve_pose_odom[2]))>math.radians(270):return None
        return bridge_pose(loc.pose,self.curve_pose_odom,at_scan)

    def curve_check_sweep(self, scan, pose, samples, now):
        # Transform returns from the scan's acquisition frame when RF2O has
        # that sample; the rollout remains in the current world frame.
        scan_pose=pose
        if (scan is self.curve_scan and self.curve_follower is not None
                and hasattr(self,'curve_scan_pose')):
            scan_pose=self.curve_scan_pose(now,pose)
            if scan_pose is None:
                self.curve_sweep_diagnostics={'result':'SCAN_ODOM_ALIGNMENT'}
                return False,'SCAN_ODOM_ALIGNMENT'
        elif scan is self.curve_scan and self.curve_odom_samples:
            at_scan=self.curve_odom_at(self.curve_scan_stamp)
            if at_scan is not None:
                scan_pose=bridge_pose(pose,tuple(self.curve_odom_samples[-1][1:4]),at_scan)
        # A missing early ray must never hide a later real collision.
        collision_detail={}
        if scan_hits_body(scan,scan_pose,samples,diagnostics=collision_detail):
            self.curve_sweep_diagnostics=collision_detail
            return False,'SWEPT_OBSTACLE'
        # In the relaxed entry profile, healthy raw scans already permit both
        # clear and occluded/missing free-space rays after the full return/body
        # intersection check. Avoid repeating that decision with thousands of
        # polar grid queries in the single-threaded control callback.
        n=len(scan.ranges);geometry=scan_geometry_valid(scan)
        valid=sum(math.isfinite(r) and max(scan.range_min,.30)<=r<=scan.range_max
                  for r in scan.ranges)
        fraction=valid/max(1,n);d=self.rel_data
        fresh_body=not self.curve_body_stop_reason(now)
        usable=(geometry and scan is self.curve_scan and 0<=now-self.curve_scan_time<=.35
                and valid>=45 and fraction>=.25 and fresh_body and not self.lidar_emergency)
        if usable:
            self.curve_sweep_diagnostics=dict(result='CLEAR_RAW',policy='ALL_FINITE_RETURNS',
                raw_valid_fraction=fraction,samples=len(samples),scan_pose=tuple(scan_pose))
            self.curve_sweep_unknown_since=None
            return True,'CLEAR_RAW'
        ok,reason=scan_observes_body(scan,scan_pose,samples,allow_small_gaps=True,
            allow_scan_edge=True,diagnostics=self.curve_sweep_diagnostics)
        if ok:
            if self.curve_scan_stamp!=self.curve_sweep_unknown_stamp:
                self.curve_sweep_unknown_stamp=self.curve_scan_stamp
                self.curve_sweep_clear_hits+=1
            if self.curve_sweep_clear_hits>=2:self.curve_sweep_unknown_since=None
            return True,reason
        self.curve_sweep_clear_hits=0
        if reason not in ('SWEPT_UNKNOWN','SWEPT_OCCLUDED'):return False,reason
        if self.curve_sweep_unknown_since is None:
            self.curve_sweep_unknown_since=now
            self.curve_sweep_unknown_travel=self.travel_distance
            self.curve_sweep_unknown_yaw=self.last_yaw or 0.
        # An unreturned/occluded ray is not a measured obstacle. A healthy
        # current scan and the full finite-return sweep replace the old
        # .45-second/.20-metre/15-degree missing-ray stop budget.
        valid=sum(math.isfinite(r) and max(scan.range_min,.30)<=r<=scan.range_max
                  for r in scan.ranges)
        fraction=valid/max(1,len(scan.ranges))
        self.curve_sweep_diagnostics['raw_valid_fraction']=fraction
        d=self.rel_data
        fresh_body=not self.curve_body_stop_reason(now)
        usable=(scan is self.curve_scan and 0<=now-self.curve_scan_time<=.35
                and valid>=45 and fraction>=.25 and fresh_body and not self.lidar_emergency)
        return (True,reason+'_RAW_CLEAR') if usable else (False,reason)

    def entry_v32_active(self):
        return self.entry_v32_enabled and self.curve_route and self.phase==self.SEEK_CONE_1 and self.curve_follower is None

    def entry_v33_active(self):
        return self.entry_v33_enabled and self.entry_v32_active()

    def entry_v34_poll_lane(self, now):
        job=self.entry_v34_lane_job
        if job is None or not job[0].done():return
        self.entry_v34_lane_job=None
        future,scan,received,stamp=job
        try:observations=future.result()
        except Exception as exc:
            self.entry_v34_lane_status='ERROR_'+type(exc).__name__;return
        if not self.curve_observation_active() or self.curve_follower is not None:return
        if not 0<=now-received<=.30:
            self.entry_v34_lane_status='TOO_OLD';return
        self.entry_v34_lane_status='CURRENT'
        self.curve_fit_ms=observations[3]
        self.entry_v34_wall_cache.append((stamp,received,observations))
        # Use acquisition time, never completion time, for freshness checks.
        self.observe_departure_corridor(scan,received,observations)
        self.curve_submit_registration(scan,received,stamp)

    def entry_v34_local_ready(self, now):
        return (self.lane_ready and self.corridor_filtered is not None
                and 0<=now-self.corridor_time<=.35
                and self.lane_selected_heading is not None
                and self.lane_heading_observation is not None
                and 0<=now-self.lane_heading_observation<=.35
                and self.lane_direction_hits>=3)

    def entry_wall_current(self, now):
        # A distant side wall is useful for stopped entrance localization even
        # when the narrow-lane steering fit is unavailable. Never permits cruise.
        if not self.entry_v33_active() or not self.entry_v33_braked:return False
        for stamp,received,observations in reversed(self.entry_v34_wall_cache):
            if not 0<=now-received<=.30:continue
            right=observations[4] if len(observations)>4 else observations[0]
            if right is not None and .30<=right[0]<=1.05:return True
        return False

    def entry_v34_progress(self, now):
        """Bounded straight-only progress; never authorizes curve handoff.

        A verified pose/end wall anchors at current travel. Short subsequent
        travel is conservatively added, so ageing never resets progress to
        unknown and grants a fresh allowance. Raw safety inputs stay mandatory.
        """
        loc=self.curve_locator;travel=self.travel_distance
        measured=[];stamp=0
        pose=self.curve_pose_estimate(now)
        if pose is not None and self.curve_pose_scan is not None:
            measured.append(pose[0]);stamp=max(stamp,self.curve_pose_stamp)
        if self.entry_wall_ready(now):
            measured.append(8.-self.entry_wall[0]);stamp=max(stamp,self.rel_stamp)
        if measured and stamp>self.entry_v34_anchor_stamp:
            self.entry_v34_anchor=(max(measured),travel,now)
            self.entry_v34_anchor_stamp=stamp
        # Coarse cone seed may request braking, but cannot extend travel.
        coarse=(self.entry_v33_relative_seed[0] if self.entry_v33_relative_seed is not None
                and self.entry_v33_relative_hits>=3 and 0<=now-self.entry_v33_relative_time<=.30 else None)
        if self.entry_v34_anchor is not None:
            ax,at,when=self.entry_v34_anchor;delta=travel-at
            x=ax+max(0.,delta)*1.15
            if coarse is not None:x=max(x,coarse)
            self.entry_progress_x=x
            ok=0<=delta<=.80 and 0<=now-when<=2.0 and x<4.40
            self.entry_v34_progress_reason='ANCHORED_STRAIGHT' if ok else 'ANCHOR_LIMIT_OR_TURN'
            return x,ok
        distance=self.departure_distance()
        self.entry_v34_progress_reason='INITIAL_DISTANCE_BOUND'
        if coarse is not None:self.entry_progress_x=coarse
        # No wall-clock timer: waiting does not consume the motion budget.
        return coarse,distance<self.entry_v33_max_unknown_travel and (coarse is None or coarse<4.40)

    def entry_v34_prepare_update(self, now):
        x,progress_ok=self.entry_v34_progress(now)
        safety=self.entry_v33_safety_reason(now)
        local=self.entry_v34_local_ready(now)
        if x is not None and x>=4.40:self.entry_v34_turn_stop=True
        # The steering controller itself outputs zero while the local wall
        # estimate warms up. Do not latch the entry recovery state for that
        # ordinary startup condition; a latch would clear the straight anchor
        # and cause the stop/reseed loop seen in V33.
        transient_body=safety in ('REL_BODY_OBSTRUCTION','REL_LIDAR_EMERGENCY','REL_BODY_CLEARING')
        reason=('BRAKE_BEFORE_TURN' if self.entry_v34_turn_stop else
                ('' if transient_body else safety) or ('PROGRESS_LIMIT' if not progress_ok else ''))
        if reason:
            self.entry_v33_brake(now,reason)
            self.entry_v34_recovery_since=None
        elif self.entry_v33_braked:
            if self.entry_v34_recovery_since is None:self.entry_v34_recovery_since=now
            # Fresh live steering/safety must remain stable before releasing
            # an observation stop. No repeated clear/reseed of localization.
            if now-self.entry_v34_recovery_since>=.35 and self.odom_is_still(now):
                self.entry_v33_braked=False;self.entry_v33_brake_since=None
                self.entry_v34_recovery_since=None
        self.entry_hold=self.entry_v33_braked
        gates=self.entry_gate_snapshot(now)
        self.entry_blockers=[k for k,v in gates.items() if not v]
        if not self.entry_hold:self.entry_v33_reason='CONTINUOUS_LOCAL_STRAIGHT'
        elif not self.entry_is_stopped(now):self.entry_v33_reason='WAIT_ACTUAL_STOP'
        elif self.entry_v34_turn_stop:
            self.entry_v33_reason='PLAN_FROM_STOPPED_POSE' if all(gates.values()) else 'REACQUIRE_POSE_AND_CONE'
        else:self.entry_v33_reason=reason or 'STABILIZE_STRAIGHT_RECOVERY'
        self.entry_stage=self.entry_v33_reason
        self.entry_wait_total=now-self.entry_v33_brake_since if self.entry_v33_brake_since is not None else 0.
        self.entry_was_waiting=self.entry_hold;self.entry_wait_tick=now

    def entry_v33_brake(self, now, reason):
        if not self.entry_v33_braked:
            self.entry_v33_braked=True
            self.entry_v33_brake_since=now
            if not self.entry_v34_enabled:self.curve_reset_entry_pose()
            self.entry_v34_recovery_since=None
            self.entry_v34_stop_trigger=reason
        self.entry_v33_reason=reason
        self.entry_hold=True

    def entry_v33_prepare_update(self, now):
        if self.entry_v34_enabled:
            self.entry_v34_prepare_update(now);return
        if self.curve_body_stop_reason(now):return
        if self.entry_v33_started is None:self.entry_v33_started=now
        gates=self.entry_gate_snapshot(now)
        self.entry_blockers=[k for k,v in gates.items() if not v]
        estimates=[]
        if gates['POSE']:estimates.append(self.curve_locator.pose[0])
        if self.entry_wall_ready(now):estimates.append(8.-self.entry_wall[0])
        # A coarse cone-relative estimate is allowed to request a stop, never
        # to authorize turning. The rigid-wall registration must still pass.
        if (self.entry_v33_relative_hits>=3 and now-self.entry_v33_relative_time<=.30
                and self.entry_v33_relative_seed is not None):
            estimates.append(self.entry_v33_relative_seed[0])
        x=max(estimates) if estimates else None
        if x is not None:self.entry_progress_x=x
        inputs=all(gates[k] for k in ('SENSORS','RAW_SCAN','FEATURES','COVERAGE','LANE'))
        self.entry_hold=False
        unknown_bound=(x is None and (self.departure_distance()>=self.entry_v33_max_unknown_travel
                          or now-self.entry_v33_started>=self.entry_v33_max_unknown_seconds))
        if not inputs or self.curve_scan_wait or self.curve_pose_wait:
            self.entry_v33_brake(now,'REACQUIRE_DATA')
        elif unknown_bound:
            self.entry_v33_brake(now,'UNKNOWN_PROGRESS_LIMIT')
        elif x is not None and x>=4.40:
            self.entry_v33_brake(now,'BRAKE_BEFORE_TURN')
        if self.entry_v33_braked:
            self.entry_hold=True
            # After an early uncertainty stop, verified live pose can permit
            # more straight travel, but not past the braking threshold.
            if (x is not None and x<4.40 and gates['POSE'] and inputs
                    and not self.curve_scan_wait and not self.curve_pose_wait
                    and self.entry_is_stopped(now)):
                self.entry_v33_braked=False;self.entry_v33_brake_since=None
                self.entry_hold=False;self.entry_v33_reason='RESUME_LOCALIZED_STRAIGHT'
            elif not self.entry_is_stopped(now):self.entry_v33_reason='WAIT_ACTUAL_STOP'
            elif all(self.entry_gate_snapshot(now).values()):self.entry_v33_reason='PLAN_FROM_STOPPED_POSE'
            elif x is not None and x>6.:self.entry_v33_reason='OUTSIDE_PLANNING_RANGE'
            else:self.entry_v33_reason='REACQUIRE_POSE_AND_CONE'
        else:self.entry_v33_reason='OBSERVE_AND_ALIGN'
        self.entry_stage=self.entry_v33_reason
        self.entry_wait_total=(now-self.entry_v33_brake_since if self.entry_v33_brake_since is not None else 0.)
        self.entry_was_waiting=self.entry_hold
        self.entry_wait_tick=now

    def entry_v33_safety_reason(self, now):
        body=self.curve_body_stop_reason(now)
        if body:return body
        if not self.sensors_ready(now):return 'REL_SENSOR_STALE'
        if self.curve_scan is None or not 0<=now-self.curve_scan_time<=.35:return 'CURVE_RAW_SCAN_STALE'
        # Derived feature timing/coverage is diagnostic. The live raw scan
        # checks the actual commanded body, including cones outside this sector.
        # Side opening/coverage is not a second turn authorization system. The
        # actual planned/commanded swept body is checked at handoff and each scan.
        return ''

    def entry_v33_seed(self, scan, now, stamp):
        # All seed geometry comes from the scan being registered. Late feature
        # arrival is retried from relative_callback; no unrelated-frame seed.
        matched=next(((t,d) for s,t,d in reversed(self.curve_features) if s==stamp),None)
        if matched is None or not 0<=now-matched[0]<=.30:
            self.entry_v33_seed_reason='WAIT_SAME_SCAN_FEATURES';return None
        if self.entry_v34_enabled:
            cached=next((v for st,t,v in reversed(self.entry_v34_wall_cache) if st==stamp and 0<=now-t<=.30),None)
            if cached is None:
                self.entry_v33_seed_reason='WAIT_SAME_SCAN_WALL';return None
            right=cached[4] if len(cached)>4 else cached[0]
        else:right=nearby_wall(scan,-1,entry=True)
        if right is None or not .30<=right[0]<=1.05 or abs(right[1])>math.radians(20):
            self.entry_v33_seed_reason='WAIT_RIGHT_WALL';return None
        rd,rh=right[:2];data=matched[1];wall=data['entry_end_wall']
        # This is a seed, not a motion permit. The full map registration,
        # multi-frame pose confirmation and body/path checks remain mandatory.
        if (wall is not None and self.entry_wall_ready(now)
                and 1.80<=wall[0]<=6.5 and abs(wall[1]-rh)<math.radians(12)):
            self.entry_v33_seed_reason='END_AND_RIGHT_SAME_SCAN'
            return (8.-wall[0],rd,-rh)
        choices=[]
        for c in data['cones']:
            wx,wy=curve_world(c,(0.,rd,-rh))
            if .30<=wx<=5.0 and abs(wy-2.)<.75:
                choices.append((6.-wx,rd,-rh))
        if stamp>self.entry_v33_relative_stamp:
            self.entry_v33_relative_stamp=stamp
            if len(choices)==1:
                seed=choices[0];old=self.entry_v33_relative_seed
                consistent=(old is not None and now-self.entry_v33_relative_time<.35
                            and math.hypot(seed[0]-old[0],seed[1]-old[1])<.40
                            and abs(normalize_angle(seed[2]-old[2]))<math.radians(8))
                self.entry_v33_relative_hits=self.entry_v33_relative_hits+1 if consistent else 1
                self.entry_v33_relative_seed=seed;self.entry_v33_relative_time=now
            else:self.entry_v33_relative_hits=0
        if self.entry_v33_relative_hits>=2 and len(choices)==1:
            self.entry_v33_seed_reason='CONE_AND_RIGHT_SEED_ONLY'
            return choices[0]
        self.entry_v33_seed_reason='WAIT_UNIQUE_RELATIVE_CONE'
        return None

    def entry_can_cruise_without_pose(self, now):
        # Use live right-wall steering and a confirmed transverse end wall.
        # Never cross the turn window on odometry or a remembered pose alone.
        if self.entry_v34_enabled and self.entry_v33_active():
            return (not self.entry_v34_turn_stop and self.entry_v34_progress(now)[1]
                    and self.entry_v34_local_ready(now) and not self.entry_v33_safety_reason(now))
        if self.entry_v33_active() and self.entry_v33_braked:return False
        if not self.entry_v32_active() or not self.entry_wall_ready(now):return False
        if self.entry_progress_x is not None and self.entry_progress_x>=4.40:return False
        d=self.rel_data
        return (self.entry_wall[0]>3.60 and self.sensors_ready(now)
                and self.curve_scan is not None and 0<=now-self.curve_scan_time<=.25
                and d is not None and 0<=now-self.rel_time<=.35
                and all(d[k]>=.95 for k in ('front_coverage','exit_path_coverage','entry_side_coverage'))
                and not self.curve_body_stop_reason(now)
                and d['exit_path_front']>self.exit_front_stop_distance
                and self.lane_ready and 0<=now-self.corridor_time<=.35)

    def entry_side_allows_straight(self, now):
        # The old 30 cm side rectangle includes future turning space. A narrow
        # straight passage may instead be certified by a full swept footprint.
        if not self.entry_v32_active():return False
        if (self.curve_scan is None or not 0<=now-self.curve_scan_time<=.25
                or not self.lane_ready or not 0<=now-self.corridor_time<=.35
                or self.rel_data is None or not 0<=now-self.rel_time<=.35
                or self.curve_body_stop_reason(now)):return False
        if self.entry_straight_sweep_stamp!=self.curve_scan_stamp:
            samples=[]
            # Cover both steering signs at the bounded straight-command limit,
            # including moderate model error; do not authorize a left turn.
            for k in (-1.2*self.curve_curvature_gain*self.straight_limit,0.,
                       1.2*self.curve_curvature_gain*self.straight_limit):
                x=y=h=0.;samples.append((x,y,h))
                for _ in range(13):
                    h+=k*.05;x+=.05*math.cos(h);y+=.05*math.sin(h)
                    samples.append((x,y,h))
            ok,reason=scan_observes_body(self.curve_scan,(0.,0.,0.),samples)
            self.entry_straight_sweep_stamp=self.curve_scan_stamp
            self.entry_straight_sweep_ok=ok;self.entry_straight_sweep_reason=reason
        return self.entry_straight_sweep_ok

    def entry_recoverable_stop(self, reason, now):
        if self.route_fault or not self.relative_active():return False
        body_reason=reason in ('REL_BODY_OBSTRUCTION','REL_LIDAR_EMERGENCY','REL_BODY_CLEARING','REL_BODY_OR_EMERGENCY')
        if not self.curve_route and not (self.relative_route and body_reason):return False
        recoverable={'REL_SENSOR_STALE','REL_SCAN_STALE','REL_FRONT_UNKNOWN',
            'REL_EXIT_PATH_UNKNOWN','REL_EXIT_SIDE_UNKNOWN','REL_EXIT_SIDE_NEAR_BODY',
            'CURVE_POSE_UNCONFIRMED','CURVE_RAW_SCAN_STALE','REL_EXIT_PATH_BLOCKED',
            'REL_BODY_OBSTRUCTION','REL_LIDAR_EMERGENCY','REL_BODY_CLEARING','REL_BODY_OR_EMERGENCY'}
        if reason not in recoverable:return False
        if self.entry_recovery_since is None:self.entry_recovery_since=now
        self.entry_recovery_reason=reason
        if self.curve_route and self.curve_follower is None and not body_reason:
            self.entry_v33_brake(now,'REACQUIRE_'+reason)
        return True

    def entry_gate_snapshot(self, now):
        pose=self.curve_pose_estimate(now)
        data=self.rel_data if self.rel_data is not None and 0<=now-self.rel_time<=.35 else None
        gates=dict(SENSORS=self.sensors_ready(now),
            RAW_SCAN=self.curve_scan is not None and 0<=now-self.curve_scan_time<=.35,
            FEATURES=True,
            COVERAGE=not self.curve_body_stop_reason(now),
            LANE=pose is not None,
            POSE=pose is not None and self.curve_pose_scan is not None,
            ENTRY_X=pose is not None and 3.80<=pose[0]<=6.30,
            ENTRY_Y=pose is not None and .15<=pose[1]<=1.50,
            ENTRY_YAW=pose is not None and abs(pose[2])<=math.radians(55),
            PAPER_CLEAR=self.phase==self.SEEK_CONE_1,
            FIRST_CONE=True)
        # Stillness and localization are independent checks; no circular requirement
        # that a successful fit must have arrived after the braking transition.
        gates['STOPPED']=(self.entry_v33_braked and self.entry_is_stopped(now)
            and self.entry_v33_brake_since is not None and now-self.entry_v33_brake_since>=.35)
        return gates

    def entry_prepare_update(self, now):
        if self.entry_v33_active():
            self.entry_v33_prepare_update(now);return
        if self.phase != self.SEEK_CONE_1 or self.curve_follower is not None:
            self.entry_hold = False
            self.entry_wait_tick = None
            self.entry_was_waiting = False
            if self.curve_follower is None:self.entry_stage = 'PREOBSERVE'
            return
        if self.entry_wait_tick is not None and self.entry_was_waiting:
            self.entry_wait_total += max(0.,now-self.entry_wait_tick)
        self.entry_wait_tick = now
        gates = self.entry_gate_snapshot(now)
        self.entry_blockers = [key for key, ok in gates.items() if not ok]
        loc = self.curve_locator
        estimates = []
        if gates['POSE']:estimates.append(loc.pose[0])
        if self.entry_wall_ready(now):estimates.append(8.-self.entry_wall[0])
        if estimates:
            self.entry_progress_x = max(estimates + ([self.entry_progress_x] if self.entry_progress_x is not None else []))
        x = self.entry_progress_x
        inputs_ok = all(gates[k] for k in ('SENSORS','RAW_SCAN','FEATURES','COVERAGE','LANE'))
        self.entry_hold = False
        self.entry_stage = 'OBSERVE'
        if not inputs_ok or self.curve_scan_wait or self.curve_pose_wait:
            self.entry_hold = True;self.entry_stage = 'DATA_WAIT'
        elif self.entry_plan_job is not None or all(gates.values()):
            self.entry_hold = True;self.entry_stage = 'PLAN_WAIT'
        elif x is not None and x >= self.entry_prepare_x:
            self.entry_stage = 'ALIGN'
            if x >= self.entry_hold_x:
                # Only fresh pose evidence can permit further moving alignment.
                # No pose, missing cone/paper/rear evidence: hold rather than
                # spend the remaining handoff window while waiting for data.
                aligned = gates['ENTRY_Y'] and gates['ENTRY_YAW']
                if not gates['POSE'] or aligned:
                    self.entry_hold = True;self.entry_stage = 'CONFIRM_WAIT'
                elif x >= self.entry_align_limit_x:
                    self.entry_hold = True;self.entry_stage = 'ALIGN_LIMIT'
                    self.fail_route('CURVE_ENTRY_ALIGNMENT_LIMIT')
        self.entry_was_waiting = self.entry_hold
        if self.entry_v32_active() and not self.entry_hold and not self.curve_pose_wait and not self.curve_scan_wait:
            self.entry_wait_total=0.
        if self.entry_wait_total >= (8. if self.entry_v32_active() else self.entry_wait_budget):
            self.fail_route('CURVE_ENTRY_WAIT_TIMEOUT')

    def publish_entry_status(self, now):
        if (not self.curve_observation_active() and self.phase != self.ROUTE_FAULT
                and self.phase not in (self.SEEK_LIGHT,self.RED_WAIT,self.FINISH_APPROACH,self.FINISHED)):return
        if self.curve_route and self.phase in (self.SEEK_LIGHT,self.RED_WAIT,self.FINISH_APPROACH,self.FINISHED):
            # Entry/curve observations stop here. Do not refresh the timestamp
            # of their old pose or evaluate their inactive gates as live data.
            if now-self.entry_status_last<.10:return
            self.entry_status_last=now;self.entry_status_key=('FINAL_STRAIGHT',self.phase)
            source_now=self.curve_source_now();stamp=self.curve_odom_source_stamp
            status=dict(self.final_straight_status,reference=self.final_straight_reference,
                phase=self.phase,active=self.final_straight_active(),
                odom_receipt_age_s=now-self.last_odom_time,
                odom_source_age_s=((source_now-stamp)*1e-9 if source_now is not None and stamp else None))
            msg=String();msg.data=json.dumps(dict(version='SECOND_CONE_1002_V35_21',
                monotonic_time=now,phase=self.phase,status_scope='FINAL_STRAIGHT',
                final_straight=status,traffic_light=dict(getattr(self,'traffic_light_status',{}),
                    receipt_age_s=now-self.last_vision_time,receipt_fresh=self.traffic_light_fresh(now)),
                fault=self.route_fault))
            self.entry_status_pub.publish(msg);return
        gates = self.entry_gate_snapshot(now)
        key = (self.phase,self.entry_stage,tuple(gates.values()),self.entry_plan_reason,self.route_fault)
        # At most 20 Hz on changes, 10 Hz heartbeat. Recorded by a separate
        # diagnostic node; no disk writes inside the control callback.
        if now-self.entry_status_last < .05:return
        if key == self.entry_status_key and now-self.entry_status_last < .10:return
        self.entry_status_last=now;self.entry_status_key=key
        msg=String()
        crosswalk_started=getattr(self,'crosswalk_hold_started',None)
        crosswalk_source=getattr(self,'crosswalk_hold_source',None)
        crosswalk_latest=getattr(self,'crosswalk_hold_last_sample',None)
        crosswalk_active=self.phase==self.CROSSWALK_STOP
        msg.data=json.dumps(dict(version='SECOND_CONE_1002_V35_21',monotonic_time=now,
            phase=self.phase,stage=self.entry_stage,hold=self.entry_hold,gates=gates,
            blockers=[k for k,v in gates.items() if not v],progress_x=self.entry_progress_x,
            pose=self.curve_locator.pose,pose_hits=self.curve_locator.hits,
            pose_age=now-self.curve_locator.time if self.curve_locator.time is not None else None,
            scan_stamp=self.curve_scan_stamp,pose_stamp=self.curve_pose_stamp,
            scan_age=now-self.curve_scan_time,features_stamp=self.rel_stamp,
            features_age=now-self.rel_time,cone_hits=self.curve_tracks.hits,
            cone_reason=self.curve_tracks.reason,wait_total=self.entry_wait_total,
            entry_v32=self.entry_v32_enabled,pair_reason=self.entry_pair_reason,
            entry_v34=self.entry_v34_enabled,entry_v34_stop_trigger=self.entry_v34_stop_trigger,
            entry_v34_progress_reason=self.entry_v34_progress_reason,
            entry_v34_lane_status=self.entry_v34_lane_status,
            entry_v33=self.entry_v33_enabled,braked=self.entry_v33_braked,
            brake_reason=self.entry_v33_reason,seed_reason=self.entry_v33_seed_reason,
            relative_seed_hits=self.entry_v33_relative_hits,
            recovery_reason=self.entry_recovery_reason,straight_sweep=self.entry_straight_sweep_reason,
            prepare_drive=min(self.normal_speed,self.entry_prepare_drive),
            plan=self.entry_plan_reason,plan_ms=self.entry_plan_ms,
            plan_worker=self.entry_plan_worker_state,
            plan_reference_reason=self.entry_plan_reference_reason,
            plan_compute_ms=self.entry_plan_compute_ms,
            curve_gain=self.curve_curvature_gain,
            curve_cones=getattr(self,'curve_cones',None),
            plan_family=getattr(getattr(self.curve_follower,'path',None),'entry_family',None),
            plan_first_half_curvature=getattr(getattr(self.curve_follower,'path',None),'first_half_max_curvature',None),
            plan_first_half_min_curvature=getattr(getattr(self.curve_follower,'path',None),'first_half_min_curvature',None),
            stopped_plan_odom_gap=self.entry_plan_odom_gap,
            plan_reference_age=(now-self.entry_plan_anchor['started']
                                if self.entry_plan_anchor is not None else None),
            registration_ms=self.curve_registration_ms,fit_ms=self.curve_fit_ms,
            registration_submission=self.curve_registration_submit_status,
            odom_source_stamp=self.curve_odom_source_stamp,
            odom_source_gap=self.curve_odom_source_gap,
            pose_odom_alignment=self.curve_pose_odom_alignment,
            pose_odom_stamp=self.curve_pose_odom_stamp,
            registration_pair=dict(self.curve_registration_pair_status,
                active=self.curve_follower is not None and self.curve_observation_active(),
                snapshot_time=now,history_count=len(self.curve_registration_scans),
                record_age_s=(now-self.curve_registration_pair_status['updated']
                    if 'updated' in self.curve_registration_pair_status else None)),
            motion=getattr(self,'curve_motion_status',{}),
            control=getattr(self,'curve_control_status',{}),
            approach_speed=dict(getattr(self,'approach_speed_status',{}),
                active=self.phase==self.APPROACH_CROSSWALK,
                historical=self.phase!=self.APPROACH_CROSSWALK),
            crosswalk=dict(active=crosswalk_active,
                arm=dict(getattr(self,'crosswalk_arm_status',{}),
                    active=self.curve_route and self.phase==self.APPROACH_CROSSWALK,
                    historical=self.phase!=self.APPROACH_CROSSWALK),
                hold_reason=getattr(self,'crosswalk_hold_reason','WAIT_BRAKE'),
                reset_reason=getattr(self,'crosswalk_hold_reset_reason','WAIT_BRAKE'),
                hold_elapsed=(max(0.,now-crosswalk_started)
                    if crosswalk_active and crosswalk_started is not None
                    and crosswalk_started<=now else None),
                source_elapsed=(max(0.,crosswalk_latest[1]-crosswalk_source)
                    if crosswalk_active and crosswalk_latest is not None
                    and crosswalk_latest[0]<=now and crosswalk_source is not None else None)),
            body_guard=getattr(self,'curve_body_guard_status',{}),
            curve_recovery=getattr(self,'curve_recovery_status',{}),
            registration_pending_age=(now-self.curve_registration_pending[1]
                if self.curve_registration_pending is not None else None),
            sweep=self.curve_sweep,sweep_detail=self.curve_sweep_diagnostics,fault=self.route_fault))
        self.entry_status_pub.publish(msg)

    def curve_remember_registration_scan(self, scan, received, stamp):
        """Retain original receipts while real source odometry catches up."""
        if self.curve_follower is None or not self.curve_observation_active():return
        history=self.curve_registration_scans
        while history and (history[0][3]!=self.curve_generation
                           or received-history[0][1]>1.10):history.popleft()
        if stamp<=self.curve_pose_stamp or stamp<=0:return
        if history and stamp<=history[-1][2]:return
        history.append((scan,received,stamp,self.curve_generation))

    def curve_select_registration_scan(self, now):
        """Newest bounded observation bracketed by actual odometry samples.

        Unlike the legacy nearest-sample fallback, this delayed path requires
        both sides of the source time (or one exact sample). It never predicts
        odometry, changes scan receipts, or queues extra worker tasks.
        """
        history=self.curve_registration_scans
        if self.curve_follower is None or not self.curve_observation_active():
            history.clear();self.curve_registration_pair_status={'state':'INACTIVE'}
            return None
        retained=[item for item in history if item[3]==self.curve_generation
                  and item[2]>self.curve_pose_stamp and 0<=now-item[1]<=1.10]
        history.clear();history.extend(retained)
        detail=dict(state='WAIT_REAL_ODOM_PAIR',history_count=len(history),
                    max_history=16,max_receipt_age_s=1.10,updated=now)
        applied=self.curve_registration_pair_status.get('last_applied')
        if applied is not None:detail['last_applied']=applied
        samples=self.curve_odom_samples
        source_now=self.curve_source_now()
        if samples:
            detail['latest_odom_source_stamp']=round(samples[-1][0]*1e9)
            for scan,received,stamp,generation in reversed(history):
                source=stamp//1000000000+(stamp%1000000000)*1e-9
                if not samples[0][0]<=source<=samples[-1][0]:continue
                if source_now is not None and stamp>source_now:continue
                odom=self.curve_odom_at(stamp)
                if odom is None:continue
                before=next(s[0] for s in reversed(samples) if s[0]<=source)
                after=next(s[0] for s in samples if s[0]>=source)
                detail.update(state='REAL_SOURCE_PAIR',scan_stamp=stamp,
                    scan_receipt_age_s=now-received,
                    bracket_before_s=source-before,bracket_after_s=after-source)
                self.curve_registration_pair_status=detail
                return scan,received,stamp,generation,tuple(odom)
        self.curve_registration_pair_status=detail
        return None

    def curve_scan_callback(self, scan):
        now=time.monotonic()
        stamp=scan.header.stamp.sec*1000000000+scan.header.stamp.nanosec
        if stamp<=self.curve_scan_stamp or stamp<=0:return
        gap=now-self.curve_scan_time
        self.curve_scan_stamp=stamp
        self.curve_scan,self.curve_scan_time=scan,now
        if self.entry_v33_enabled and self.curve_follower is None:
            self.entry_v33_scans.append((stamp,now,scan))
        # Hold one acquisition until its odometry arrives, not a work queue.
        # Replacing it on every faster lidar callback would starve alignment
        # whenever RF2O stays more than .16 s behind the newest scan.
        if self.curve_observation_active():
            self.curve_remember_registration_scan(scan,now,stamp)
            pending=getattr(self,'curve_registration_pending',None)
            pending_ttl=1.10 if self.curve_follower is not None else .35
            if pending is None or self.curve_job is not None or now-pending[1]>pending_ttl:
                self.curve_registration_pending=(scan,now,stamp,self.curve_generation)
        if self.curve_scan_wait:
            self.curve_scan_recovery_hits=min(3,self.curve_scan_recovery_hits+1) if 0<gap<=.25 else 1
        if (self.entry_v34_enabled and self.curve_observation_active()
                and self.curve_follower is None):
            self.entry_v34_poll_lane(now)
            lane_period=.50 if self.entry_v33_braked else .07
            if self.entry_v34_lane_job is None and now-self.entry_v34_async_since>=lane_period:
                self.entry_v34_async_since=now
                future=(self.entry_v34_lane_executor.submit(entry_wall_observation,scan,True)
                        if self.phase==self.SEEK_CONE_1 else
                        self.entry_v34_lane_executor.submit(entry_wall_observation,scan))
                self.entry_v34_lane_job=(future,scan,now,stamp)
            self.curve_poll_registration(now)
            self.curve_submit_registration(scan,now,stamp)
            return
        # Entry registration starts with the new scan, before the independent
        # lane fit can consume its freshness budget. No task queue is added.
        self.curve_poll_registration(time.monotonic())
        self.curve_submit_registration(scan,now,stamp)
        # Once the curve owns steering, local straight-wall fitting is unused.
        # Keep scan delivery cheap so odometry/features can reach their callbacks.
        if self.curve_follower is not None:return
        # Preserve V31's pre-crosswalk controller exactly. After release, bound
        # expensive synchronous wall fitting to 5 Hz so other callbacks can run.
        if self.entry_v32_active() and now-self.entry_fit_since<.20:
            self.curve_poll_registration(time.monotonic())
            return
        self.entry_fit_since=now
        started=time.perf_counter()
        self.observe_departure_corridor(scan,now)
        self.curve_fit_ms=1000.*(time.perf_counter()-started)
        self.curve_poll_registration(time.monotonic())

    def curve_submit_registration(self, scan, now, stamp):
        current=time.monotonic()
        if not self.curve_observation_active():
            self.curve_registration_pending=None
            self.curve_registration_scans.clear()
            self.curve_registration_pair_status={'state':'INACTIVE'}
            self.curve_registration_submit_status='INACTIVE';return
        historical=self.curve_follower is not None
        self.curve_remember_registration_scan(scan,now,stamp)
        if stamp<=self.curve_pose_stamp:return
        if self.curve_job is not None and stamp<=self.curve_job[3]:return
        pending=getattr(self,'curve_registration_pending',None)
        pending_ttl=1.10 if historical else .35
        if (pending is None or current-pending[1]>pending_ttl
                or (self.curve_job is not None and stamp>=pending[2])):
            self.curve_registration_pending=(scan,now,stamp,self.curve_generation)
        if not 0<=current-now<=pending_ttl:
            if getattr(self,'curve_registration_pending',None)[2]==stamp:self.curve_registration_pending=None
            self.curve_registration_submit_status='SCAN_RETRY_EXPIRED';return
        if getattr(self,'curve_pending_fit',None) is not None:
            # Retain the newest raw retry scan while the already measured fit
            # waits for its source pair. Chasing newer unpaired fits can starve
            # same-scan alignment when RF2O lags the scan callbacks.
            self.curve_registration_submit_status='WAIT_FIT_ODOM_ALIGNMENT';return
        if self.last_yaw is None:
            self.curve_registration_submit_status='WAIT_ODOM';return
        # Single running task, no backlog. New scans still update safety and
        # V21 lane feedback while a private locator is being processed.
        if self.curve_job is not None:
            self.curve_registration_submit_status='RUNNING';return
        interval=getattr(self,'curve_registration_period',.30)
        if self.entry_plan_job is not None:interval=max(.50,interval)
        if current-self.curve_last_process<interval:
            self.curve_registration_submit_status='RATE_LIMIT';return
        selected=self.curve_select_registration_scan(current) if historical else None
        if selected is not None:
            scan,now,stamp,generation,scan_odom=selected
            self.curve_registration_pending=(scan,now,stamp,generation)
        else:
            scan_odom=None if historical else self.curve_odom_at(stamp)
        stopped_fit=(scan_odom is None and self.curve_locator.pose is not None
                     and (not historical or 0<=current-now<=.35)
                     and 0<=current-self.last_odom_time<=.80
                     and (self.odom_is_still(current)
                          or getattr(self,'entry_is_stopped',lambda t:False)(current)))
        if scan_odom is None and not stopped_fit:
            self.curve_registration_submit_status='WAIT_SCAN_ODOM';return
        seed=self.curve_registration_seed(stamp)
        expired=(self.curve_locator.time is not None and now-self.curve_locator.time>.4)
        if seed is None and (self.curve_locator.pose is None or expired):
            if self.curve_follower is not None:
                self.curve_registration_submit_status='WAIT_TRACKING_SEED';return
            if self.entry_v33_enabled and self.curve_observation_active():
                # A stopped reference may seed a NEW fit, never reuse an old
                # result or manufacture fresh timestamps/hits. Normal fitting,
                # same-scan cone association and handoff checks remain required.
                if self.entry_plan_anchor_valid(current):
                    seed=self.entry_plan_anchor['pose']
                else:seed=self.entry_v33_seed(scan,current,stamp)
                if seed is None:
                    self.curve_registration_submit_status=self.entry_v33_seed_reason;return
            else:
                if (not self.entry_wall_ready(now)
                        or now-self.last_boundary_time>.25 or len(self.exit_spatial)!=21):
                    self.curve_registration_submit_status='WAIT_ENTRY_WALL';return
                lh,rh,lf,rf=self.exit_current_wall
                rd=self.exit_spatial[16]
                distance,h=self.entry_wall[:2]
                if not (rf and .30<rd<.65 and abs(rh-h)<.08 and abs(h)<.12
                        and 2.8<distance<5.5):
                    self.curve_registration_submit_status='WAIT_ENTRY_SEED';return
                seed=(8.-distance,rd,-h)
        self.curve_last_process=current
        scan_yaw=scan_odom[2] if scan_odom is not None else self.last_yaw
        future=self.curve_executor.submit(register_scan,copy.copy(self.curve_locator),scan,now,scan_yaw,seed)
        self.curve_job=(future,scan,now,stamp,self.curve_generation)
        # Keep this job's immutable source-matched anchor. Callback history can
        # roll over while the worker runs; a known pairing must not be lost.
        self.curve_job_odom=((stamp,self.curve_generation,tuple(scan_odom))
                             if scan_odom is not None else None)
        self.curve_job_strict_pair=((stamp,self.curve_generation)
                                    if historical and selected is not None else None)
        if self.curve_registration_pending[2]==stamp:self.curve_registration_pending=None
        self.curve_registration_submit_status='SUBMITTED_STOPPED_FULL_FIT' if stopped_fit else 'SUBMITTED'

    def curve_registration_stopped_anchor(self, stamp, received, now):
        """Pair a real fit to a measured stationary source window, if needed.

        The RF2O stamp remains separate from the scan stamp. A zero command or
        fresh receipt of pre-stop poses alone cannot prove a stationary frame.
        """
        source_now=self.curve_source_now();samples=list(getattr(self,'curve_motion_samples',()))
        if (source_now is None or len(samples)<3
                or not 0<=now-self.last_odom_time<=.35):return None
        if self.curve_follower is not None:
            if not self.curve_recovery_stopped(now):return None
            stopped_after=getattr(self,'curve_last_drive_time',-1e9)+.15
        else:
            if (not self.entry_v33_braked or self.entry_v33_brake_since is None
                    or not self.entry_is_stopped(now)):return None
            stopped_after=self.entry_v33_brake_since+.35
        latest=samples[-1]
        if not 0<=(source_now-latest[0])*1e-9<=.75:return None
        samples=[s for s in samples if 0<=latest[0]-s[0]<=500000000]
        if (len(samples)<3 or (latest[0]-samples[0][0])*1e-9<.30
                or received<stopped_after
                or now-(source_now-samples[0][0])*1e-9<stopped_after
                or stamp<samples[0][0]-50000000
                or not 0<=stamp-latest[0]<=400000000):return None
        if not all(math.hypot(a[1]-b[1],a[2]-b[2])<=.04
                   and abs(normalize_angle(a[3]-b[3]))<=.10
                   for a in samples for b in samples):return None
        return tuple(latest[1:4]),latest[0]

    def curve_pair_registration(self, candidate, now):
        """Commit an accepted observation and its source anchor together."""
        locator,scan,received,stamp,generation,job_odom=candidate[:6]
        strict_pair=len(candidate)>6 and candidate[6]
        if generation!=self.curve_generation or not self.curve_observation_active():
            self.curve_registration_status='DISCARDED_PHASE_OR_RESET';return 'DROP'
        stopped=(self.odom_is_still(now) or self.entry_is_stopped(now))
        ttl=2. if stopped else getattr(self,'curve_fit_result_ttl',1.2)
        if not 0<=now-received<=ttl or stamp<=self.curve_pose_stamp:
            self.curve_registration_status='RESULT_TOO_OLD';return 'DROP'
        # Historical selection already captured an exact/bracketed real pose.
        # Later history rollover or a one-sided nearest fallback cannot replace it.
        if strict_pair and job_odom is None:
            self.curve_registration_status='STRICT_PAIR_MISSING';return 'DROP'
        at_scan=job_odom if strict_pair else self.curve_odom_at(stamp)
        if at_scan is None:at_scan=job_odom
        alignment='SCAN_ALIGNED';odom_stamp=stamp
        if at_scan is None:
            pair=self.curve_registration_stopped_anchor(stamp,received,now)
            if pair is None:
                self.curve_registration_status='WAIT_FIT_ODOM_ALIGNMENT';return 'WAIT'
            at_scan,odom_stamp=pair;alignment='STOPPED_ODOM_ANCHOR'
        # locator.time remains the original scan receipt time. No half-adopted
        # fit may erase the previous valid moving anchor or renew old evidence.
        self.curve_locator=locator;self.curve_pose_odom=tuple(at_scan)
        self.curve_pose_odom_alignment=alignment;self.curve_pose_odom_stamp=odom_stamp
        self.curve_pose_stamp,self.curve_pose_scan=stamp,scan
        self.curve_registration_late=False;self.curve_registration_status=locator.reason
        if strict_pair:
            self.curve_registration_pair_status.update(state='APPLIED_REAL_SOURCE_PAIR',
                updated=now,scan_stamp=stamp,scan_receipt_age_s=now-received,
                last_applied=dict(scan_stamp=stamp,fit_received=received,applied_at=now,
                    scan_receipt_age_at_apply_s=now-received,captured_odom_anchor=list(at_scan)))
        self.entry_pose_pairs.append((stamp,received,tuple(locator.pose)))
        self.curve_observe_clusters(now)
        return 'COMMIT'

    def curve_poll_registration(self, now):
        def retry_pending():
            # A source callback may pair a retained scan after the latest raw
            # scan has advanced. Select it before applying the pending deadline.
            if self.curve_follower is not None and self.curve_job is None:
                selected=self.curve_select_registration_scan(now)
                if selected is not None:self.curve_registration_pending=selected[:4]
            pending=getattr(self,'curve_registration_pending',None)
            if pending is None or self.curve_job is not None:return
            scan,received,stamp,generation=pending
            if (generation!=self.curve_generation or not self.curve_observation_active()
                    or stamp<=self.curve_pose_stamp):
                self.curve_registration_pending=None;return
            pending_ttl=1.10 if self.curve_follower is not None else .35
            if not 0<=now-received<=pending_ttl:
                self.curve_registration_pending=None
                self.curve_registration_submit_status='SCAN_RETRY_EXPIRED';return
            self.curve_submit_registration(scan,received,stamp)
        candidate=getattr(self,'curve_pending_fit',None)
        if candidate is not None:
            outcome=self.curve_pair_registration(candidate,now)
            if outcome!='WAIT':self.curve_pending_fit=None
        if self.curve_job is None:
            retry_pending();return
        if not self.curve_job[0].done():return
        future,scan,received,stamp,generation=self.curve_job
        self.curve_job=None
        captured=getattr(self,'curve_job_odom',None)
        job_odom=(captured[2] if captured is not None
                  and captured[0]==stamp and captured[1]==generation else None)
        strict_pair=getattr(self,'curve_job_strict_pair',None)==(stamp,generation)
        if strict_pair:self.curve_job_strict_pair=None
        if captured is not None and captured[0]==stamp:self.curve_job_odom=None
        try:locator,accepted,seconds=future.result()
        except Exception as exc:
            self.curve_registration_status='ERROR_'+type(exc).__name__;retry_pending();return
        self.curve_registration_ms=1000.*seconds
        if generation!=self.curve_generation or not self.curve_observation_active():
            self.curve_registration_status='DISCARDED_PHASE_OR_RESET';retry_pending();return
        # A rejected fit never overwrites the last successful observation.
        if not accepted:
            self.curve_registration_status=locator.reason
            retry_pending();return
        candidate=(locator,scan,received,stamp,generation,job_odom,strict_pair)
        outcome=self.curve_pair_registration(candidate,now)
        if outcome=='WAIT' and getattr(self,'curve_pending_fit',None) is None:
            self.curve_pending_fit=candidate
        retry_pending()

    def curve_reset_entry_pose(self):
        # Explicit reset invalidates only localization, not feature/cone history.
        self.curve_generation+=1
        self.curve_pending_fit=None
        self.curve_registration_pending=None
        self.curve_registration_scans.clear()
        self.curve_registration_pair_status={'state':'RESET'}
        self.curve_job_strict_pair=None
        self.curve_locator=WallLocalizer(entry_wide=self.entry_v33_enabled)
        self.curve_pose_odom=None
        self.curve_pose_odom_alignment='WAIT_ALIGNMENT';self.curve_pose_odom_stamp=None
        self.curve_pose_stamp=0;self.curve_pose_scan=None
        self.entry_pose_pairs.clear()
        self.curve_registration_late=False

    def curve_update_pose_wait(self, now):
        if not self.curve_route or not self.relative_active():return
        if self.curve_follower is None and self.entry_v34_enabled and not self.entry_v34_turn_stop:
            self.curve_pose_wait=False;self.curve_pose_wait_since=None
            self.curve_pose_wait_reason='LOCAL_STRAIGHT_CONTINUOUS';return
        pose=self.curve_pose_estimate(now)
        self.curve_pose_wait=pose is None
        if pose is None:
            if self.curve_pose_wait_since is None:self.curve_pose_wait_since=now
            self.curve_pose_wait_reason=self.curve_pose_estimate_reason
        else:
            self.curve_pose_wait_since=None
            self.curve_pose_wait_reason='RECOVERED_'+self.curve_pose_estimate_reason

    def curve_update_scan_wait(self, now):
        if not self.curve_route or not self.relative_active():return
        self.curve_scan_wait=self.curve_scan is None or not 0<=now-self.curve_scan_time<=.35
        if self.curve_scan_wait:
            if self.curve_scan_wait_since is None:self.curve_scan_wait_since=now
        else:self.curve_scan_wait_since=None

    def curve_wait_fault(self, now):
        if self.entry_v33_active():return self.entry_v33_safety_reason(now)
        if now-self.curve_scan_time>=2.:return 'CURVE_RAW_SCAN_LOST'
        if self.curve_scan_wait_since is not None and now-self.curve_scan_wait_since>=5.:
            return 'CURVE_SCAN_RECOVERY_TIMEOUT'
        if self.curve_pose_wait_since is not None and now-self.curve_pose_wait_since>=(8. if self.entry_v32_active() else 5.):
            return 'CURVE_POSE_RECOVERY_TIMEOUT'
        # Fresh collision evidence remains a fault even during a data wait.
        body=self.curve_body_stop_reason(now)
        if body:return body
        if self.rel_data is not None and 0<=now-self.rel_time<=.35:
            d=self.rel_data
            if d['front_coverage']<.95 and not self.entry_hold:return 'REL_FRONT_UNKNOWN'
            if d['exit_path_coverage']<.95 and not self.entry_hold:return 'REL_EXIT_PATH_UNKNOWN'
            if d['exit_path_front']<=self.exit_front_stop_distance:return 'REL_EXIT_PATH_BLOCKED'
            if d['entry_side_coverage']<.95 and not self.entry_hold:return 'REL_EXIT_SIDE_UNKNOWN'
            if not d['entry_side_clear'] and not self.entry_side_allows_straight(now):return 'REL_EXIT_SIDE_NEAR_BODY'
        if self.entry_wait_total >= (8. if self.entry_v32_active() else self.entry_wait_budget):return 'CURVE_ENTRY_WAIT_TIMEOUT'
        if self.entry_wall_ready(now) and self.entry_wall[0]<2.90:return 'CURVE_ENTRY_REGION_MISSED'
        if now-self.phase_started_at>35.:return 'CURVE_ENTRY_TIMEOUT'
        return ''

    def close_curve_worker(self):
        if self.entry_plan_cancel is not None:self.entry_plan_cancel.set()
        if self.entry_v34_lane_executor is not None:
            self.entry_v34_lane_executor.shutdown(wait=False,cancel_futures=True)
        if self.curve_executor is not None:
            self.curve_executor.shutdown(wait=False,cancel_futures=True)
        if self.entry_plan_executor is not None:
            self.entry_plan_executor.shutdown(wait=False,cancel_futures=True)

    def curve_observe_clusters(self, now):
        # Both entry and moving tracking use EXACT acquisition-frame association.
        features={stamp:(received,data) for stamp,received,data in self.curve_features}
        if self.rel_data is not None:features[self.rel_stamp]=(self.rel_time,self.rel_data)
        self.entry_pair_reason='WAIT_SAME_SCAN'
        for stamp,received,pose in sorted(self.entry_pose_pairs):
            if stamp<=self.curve_tracks.stamp or not 0<=now-received<=self.curve_pose_ttl:continue
            if stamp not in features:continue
            feature_time,data=features[stamp]
            if not 0<=now-feature_time<=self.curve_pose_ttl:continue
            self.curve_tracks.update(data['cones'],pose,stamp,min(received,feature_time))
            self.entry_pair_reason='MATCHED_SAME_SCAN'

    def curve_body_stop_reason(self, now):
        """Pause for real emergency, optionally for static near-body candidates.

        This state never changes route_fault or the stopped-planning latch.
        The lidar's real emergency signal remains an unconditional pause.
        Two distinct fresh clear feature scans reject a one-frame flicker;
        repeated calls for the same scan cannot manufacture confirmation.
        Curve candidates inside the existing radial self filter are diagnostic
        by default. A debug parameter explicitly enables that static check.
        """
        d=getattr(self,'rel_data',None)
        static_enforced=(not getattr(self,'curve_route',False)
                         or bool(getattr(self,'curve_static_body_guard_enabled',False)))
        lidar_emergency=bool(getattr(self,'lidar_emergency',False))
        lidar_fresh=0<=now-getattr(self,'last_lidar_time',-1e9)<=getattr(self,'sensor_timeout',.35)
        feature_fresh=d is not None and 0<=now-getattr(self,'rel_time',-1e9)<=.35
        reason=('REL_LIDAR_EMERGENCY' if lidar_fresh and lidar_emergency else
                'REL_BODY_OBSTRUCTION' if static_enforced and feature_fresh and not d['body_clear'] else '')
        if reason:
            self.curve_body_guard_active=True
            self.curve_body_guard_clear_hits=0
            self.curve_body_guard_clear_stamp=None
            self.curve_body_guard_reason=reason
        elif getattr(self,'curve_body_guard_active',False):
            if (lidar_fresh and not lidar_emergency and feature_fresh
                    and (not static_enforced or d['body_clear'])):
                stamp=int(d.get('stamp_ns',getattr(self,'rel_stamp',0)))
                if stamp>max(0,getattr(self,'curve_body_guard_clear_stamp',None) or 0):
                    self.curve_body_guard_clear_stamp=stamp
                    self.curve_body_guard_clear_hits=getattr(self,'curve_body_guard_clear_hits',0)+1
                if getattr(self,'curve_body_guard_clear_hits',0)>=2:
                    self.curve_body_guard_active=False
                    self.curve_body_guard_reason=''
                else:reason='REL_BODY_CLEARING'
            else:
                # A fresh clear scan before a sensor gap is not confirmation
                # of the scene after it. Recovery needs two current frames.
                self.curve_body_guard_clear_hits=0
                self.curve_body_guard_clear_stamp=None
                reason='REL_BODY_CLEARING'
        self.curve_body_guard_status=dict(reason=reason,active=getattr(self,'curve_body_guard_active',False),
            enabled=static_enforced,static_enforced=static_enforced,
            clear_hits=getattr(self,'curve_body_guard_clear_hits',0),feature_fresh=feature_fresh,
            lidar_fresh=lidar_fresh,lidar_emergency=lidar_emergency,
            geometry=d.get('body_guard') if d is not None else None)
        return reason

    def curve_stop_reason(self, now):
        if self.curve_follower is None:return self.entry_v33_safety_reason(now)
        if not self.sensors_ready(now):return 'REL_SENSOR_STALE'
        if self.curve_scan is None or now-self.curve_scan_time>.35:return 'CURVE_RAW_SCAN_STALE'
        body=self.curve_body_stop_reason(now)
        if body:return body
        pose=self.curve_pose_estimate(now)
        if pose is None:return 'CURVE_POSE_UNCONFIRMED'
        # Nominal board padding is not a second emergency system. Planning
        # retains map clearance; the raw sweep checks each actual command.
        return ''

    def invalidate_entry_plan(self, reason):
        self.entry_plan_anchor=None
        self.entry_plan_reference_reason=reason
        if self.entry_plan_cancel is not None:self.entry_plan_cancel.set()

    def entry_is_stopped(self, now):
        """Entry-only standstill evidence tolerant of RF2O noise and brief gaps.

        Crosswalk timing keeps its original stricter independent test. These
        measurements only permit stopped planning; fresh pose/scan and the
        current swept path still authorize the eventual driving command.
        """
        if (not self.entry_v33_braked or self.entry_v33_brake_since is None
                or now-self.entry_v33_brake_since<.35
                or self.last_odom_xy is None or self.last_yaw is None
                or not 0<=now-self.last_odom_time<=.80):return False
        samples=getattr(self,'entry_stopped_samples',None)
        if samples is None:
            samples=self.entry_stopped_samples=deque(maxlen=80)
        # Retain entry evidence separately: the crosswalk sampler intentionally
        # clears its deque for a >.30s callback gap.
        for t,x,y,yaw in self.odom_still_samples:
            if (t>=self.entry_v33_brake_since and 0<=now-t<=2.0
                    and (not samples or t>samples[-1][0])):
                samples.append((t,x,y,yaw))
        t=self.last_odom_time
        if not samples or t>samples[-1][0]:
            samples.append((t,*self.last_odom_xy,self.last_yaw))
        while samples and (samples[0][0]<self.entry_v33_brake_since or now-samples[0][0]>2.0):
            samples.popleft()
        while len(samples)>2 and samples[1][0]<=now-.50:samples.popleft()
        if len(samples)<2 or samples[-1][0]-samples[0][0]<.35:return False
        return all(math.hypot(a[1]-b[1],a[2]-b[2])<=.15
                   and abs(normalize_angle(a[3]-b[3]))<=math.radians(12.)
                   for a in samples for b in samples)

    def entry_plan_observe_odom(self, now, stamp, x, y, yaw):
        """Reject substantial movement; callback gaps alone do not cancel work."""
        a=self.entry_plan_anchor
        if a is None:return
        samples=a['samples']
        if (not all(math.isfinite(v) for v in (now,stamp,x,y,yaw))
                or stamp<=0):
            self.invalidate_entry_plan('INVALID_ODOMETRY');return
        if (stamp<=a['stamp'] or (samples and now<=samples[-1][0])):return
        if (math.hypot(x-a['odom'][0],y-a['odom'][1])>.50
                or abs(normalize_angle(yaw-a['odom'][2]))>math.radians(35.)):
            self.invalidate_entry_plan('ODOM_MOVED');return
        samples.append((now,x,y,yaw));a['stamp']=stamp
        while len(samples)>2 and samples[1][0]<=now-.50:samples.popleft()

    def entry_plan_anchor_valid(self, now):
        """Preserve planned work through RF2O noise; driving uses current gates."""
        a=self.entry_plan_anchor
        if a is None:return False
        reason=''
        if not (self.entry_v33_active() and self.phase==self.SEEK_CONE_1
                and self.curve_follower is None and self.entry_v33_braked and self.entry_hold):
            reason='NOT_STOPPED_PLANNING'
        elif self.route_fault or self.lidar_emergency:reason='FAULT_OR_EMERGENCY'
        elif not 0<=now-a['started']<=self.entry_plan_reference_ttl:reason='REFERENCE_TTL'
        elif not 0<=now-self.last_odom_time<=2.0:reason='ODOM_STALE'
        elif self.last_odom_xy is None or self.last_yaw is None:reason='ODOM_MISSING'
        elif (math.hypot(self.last_odom_xy[0]-a['odom'][0],self.last_odom_xy[1]-a['odom'][1])>.50
              or abs(normalize_angle(self.last_yaw-a['odom'][2]))>math.radians(35.)):
            reason='ODOM_DRIFT'
        else:
            loc=self.curve_locator;reference=a.get('pose')
            if (reference is not None and loc.pose is not None and loc.time is not None
                    and loc.hits>=1 and 0<=now-loc.time<=self.curve_pose_ttl
                    and (math.hypot(loc.pose[0]-reference[0],loc.pose[1]-reference[1])>.30
                         or abs(normalize_angle(loc.pose[2]-reference[2]))>math.radians(20.))):
                reason='WALL_POSE_MOVED'
        if reason:
            self.invalidate_entry_plan(reason);return False
        a['checked']=now
        self.entry_plan_reference_reason=('HELD_WAIT_FRESH_ODOM' if now-self.last_odom_time>self.odom_max_gap
                                          else 'VALID')
        return True

    def curve_poll_entry_plan(self, now):
        # Poll even during pose recovery. No gates or motion are authorized here.
        anchor_ok=self.entry_plan_anchor_valid(now)
        if self.entry_plan_ready is not None:
            _,_,_,started,generation=self.entry_plan_ready
            ready_ttl=self.entry_plan_reference_ttl if self.entry_v33_active() else self.entry_plan_budget
            if (now-started>ready_ttl or self.phase!=self.SEEK_CONE_1
                    or (self.entry_v33_active() and not anchor_ok)
                    or generation!=self.curve_generation):
                self.entry_plan_ready=None
                self.entry_plan_reason='REPLAN_REFERENCE_EXPIRED'
                self.entry_plan_worker_state='DISCARDED'
        if self.entry_plan_job is None:return
        future,pose,cones,started,generation=self.entry_plan_job
        invalid=(now-started>self.entry_plan_budget or self.phase!=self.SEEK_CONE_1
                 or (self.entry_v33_active() and not anchor_ok)
                  or generation!=self.curve_generation)
        if not future.done():
            self.entry_plan_worker_state='RUNNING'
            if invalid:
                if self.entry_plan_cancel is not None:self.entry_plan_cancel.set()
                self.entry_plan_reason='PLAN_REFERENCE_EXPIRED'
                self.entry_plan_worker_state='DISCARD_PENDING'
                if future.cancel():self.entry_plan_job=None
            return
        self.entry_plan_job=None
        self.entry_plan_ms=1000.*(now-started)
        try:
            path=future.result()
            self.entry_plan_compute_ms=getattr(path,'planning_ms',0.0)
        except PlanningInterrupted as exc:
            self.entry_plan_compute_ms=exc.elapsed_ms
            self.entry_plan_reason=exc.reason
            self.entry_plan_worker_state='DISCARDED'
            return
        except ValueError as exc:
            self.entry_plan_reason=str(exc) if not invalid else 'PLAN_REFERENCE_EXPIRED'
            self.entry_plan_worker_state='FAILED' if not invalid else 'DISCARDED'
            return
        except Exception as exc:
            self.entry_plan_worker_state='FAILED'
            self.entry_plan_reason='CURVE_PLAN_ERROR_'+type(exc).__name__
            if not invalid:self.fail_route(self.entry_plan_reason)
            return
        if invalid:
            self.entry_plan_reason='REPLAN_REFERENCE_EXPIRED'
            self.entry_plan_worker_state='DISCARDED'
            return
        self.entry_plan_ready=(path,pose,cones,started,generation)
        self.entry_plan_worker_state='READY'
        self.entry_plan_reason='PLAN_READY_WAIT_FRESH_GATES'

    def curve_update(self, now):
        self.curve_poll_entry_plan(now)
        loc=self.curve_locator
        control_pose=self.curve_pose_estimate(now)
        if control_pose is None:return
        if self.curve_follower is None:
            if self.phase != self.SEEK_CONE_1:return
            gates = self.entry_gate_snapshot(now)
            self.entry_blockers = [key for key, ok in gates.items() if not ok]
            if self.entry_blockers:
                self.curve_reason = '|'.join(self.entry_blockers)
                return
            # Planning runs while stopped, outside the control callback. Its
            # result must be rechecked against CURRENT observations below.
            self.entry_hold = True
            self.entry_stage = 'PLAN_WAIT'
            if self.entry_plan_ready is None:
                if self.entry_plan_job is not None:return
                if now-self.curve_last_plan < .25:return
                self.curve_last_plan = now
                # Static landmarks remain useful after their observation ages.
                # Missing tracks use the handbook layout, never block entry.
                cones = tuple(tuple(self.curve_tracks.xy[i])
                    if self.curve_tracks.seen[i]>-1e8 else nominal
                    for i,nominal in enumerate(((6.,2.),(2.,2.))))
                pose = tuple(control_pose)
                if self.entry_v33_active():
                    # Capture only after all original gates, including stop, pass.
                    if (self.last_odom_xy is None or self.last_yaw is None
                            or not 0<=now-self.last_odom_time<=self.curve_odom_max_age):return
                    self.entry_plan_anchor=dict(pose=pose,started=now,checked=now,
                        odom=(*self.last_odom_xy,self.last_yaw),
                        samples=deque(self.odom_still_samples),stamp=self.last_still_stamp)
                    self.entry_plan_reference_reason='VALID'
                planner=plan_entry_path if self.entry_v33_active() else make_path
                self.entry_plan_cancel=Event()
                self.entry_plan_compute_ms=0.0
                self.entry_plan_ms=0.0
                options=dict(min_radius=self.curve_min_radius)
                if self.entry_v33_active():
                    options.update(cancel=self.entry_plan_cancel,
                                   deadline=time.monotonic()+self.entry_plan_budget)
                future = self.entry_plan_executor.submit(planner, pose, cones, **options)
                self.entry_plan_job = (future, pose, cones, now, self.curve_generation)
                self.entry_plan_worker_state='RUNNING'
                self.entry_plan_reason = self.curve_reason = 'PLANNING'
                return
            path,pose,cones,started,generation=self.entry_plan_ready
            anchor_ok=self.entry_plan_anchor_valid(now)
            self.entry_plan_ready=None
            self.entry_plan_worker_state='VALIDATING' 
            if ((self.entry_v33_active() and not anchor_ok)
                    or (generation != self.curve_generation and not anchor_ok)
                    or now-started > self.entry_plan_reference_ttl
                    or math.hypot(control_pose[0]-pose[0],control_pose[1]-pose[1]) > .35
                    or abs(normalize_angle(control_pose[2]-pose[2])) > math.radians(25)):
                self.entry_plan_reason = self.curve_reason = 'REPLAN_CURRENT_POSE';return
            follower=PathFollower(path,enable_integral=True)
            follower.locate(control_pose)
            ok,self.curve_sweep=self.curve_check_sweep(
                self.curve_scan,control_pose,follower.horizon(),now)
            self.curve_sweep_diagnostics['scope']='ENTRY'
            self.curve_sweep_diagnostics['checked_at']=time.monotonic()
            if not ok:
                self.entry_plan_reason = self.curve_reason = 'ENTRY_'+self.curve_sweep
                self.entry_plan_ready=(path,pose,cones,started,generation)
                return
            # Sweep processing may take time; never authorize from an expired
            # pose just because it was fresh at the beginning of the callback.
            finished = time.monotonic()
            if not all(self.entry_gate_snapshot(finished).values()):
                self.entry_plan_ready=(path,pose,cones,started,generation)
                self.entry_plan_reason = self.curve_reason = 'RECHECK_FRESH_GATES';return
            if self.test_stop_after_entry:
                self.fail_route('TEST_ENTRY_READY');return
            self.entry_plan_anchor=None
            self.curve_start=pose;self.curve_cones=cones
            self.curve_handoff_time=finished
            self.curve_second_locked=self.curve_tracks.ready(1,finished)
            self.curve_follower=follower
            follower.output=self.last_lane_angular;follower.time=finished
            self.curve_last_command=finished
            self.entry_plan_worker_state='HANDOFF'
            self.entry_hold=False;self.entry_stage='HANDOFF'
            self.entry_v33_braked=False;self.entry_v33_brake_since=None
            if hasattr(self,'entry_stopped_samples'):self.entry_stopped_samples.clear()
            self.entry_plan_reason=self.curve_reason='FIRST_CURVE'
            self.set_phase(self.ENTER_OBSTACLES)
            return
        f=self.curve_follower
        try:f.locate(control_pose)
        except ValueError as exc:
            self.curve_reason='RECOVERING_'+str(exc);self.publish_stop();return
        # The fixed handbook layout supplies the second cone until observed.
        # Do not stop the route for a missing frame or synchronously replan
        # its entire remainder inside the control callback.
        if self.curve_tracks.ready(1,now):self.curve_second_locked=True
        # Fresh, unambiguous observations also validate locked identities.
        for i in range(2):
            if (self.curve_tracks.ready(i,now) and
                    math.hypot(self.curve_tracks.xy[i][0]-self.curve_cones[i][0],
                               self.curve_tracks.xy[i][1]-self.curve_cones[i][1])>.35):
                self.curve_tracks.reason='LANDMARK_SHIFT_DIAGNOSTIC'
        g=f.path.gates
        phase=(self.ENTER_OBSTACLES if f.progress<g[0] else
               self.ORBIT_CONE_1 if f.progress<g[1] else
               self.SEEK_CONE_2 if f.progress<g[2] else
               self.ORBIT_CONE_2 if f.progress<g[4] else 'REL_UPPER_APPROACH')
        self.set_phase(phase)
        self.curve_reason='FOLLOW_'+phase
        if phase=='REL_UPPER_APPROACH' and control_pose[0]>5.05 and abs(control_pose[1]-3.55)<.30 and abs(control_pose[2])<.35:
            if self.last_boundary_time!=self.rel_boundary_seen:
                self.rel_boundary_seen=self.last_boundary_time
                self.rel_corridor_hits=self.rel_corridor_hits+1 if self.relative_upper_pair(now) else 0
            if self.rel_corridor_hits>=2 or f.progress>=f.path.lengths[-1]-.12:
                self.entry_done=True;self.curve_reason='HANDOFF_TO_LIGHT'
                self.set_phase(self.SEEK_LIGHT)
        if f.progress>=f.path.lengths[-1]-.08 and self.phase!='SEEK_LIGHT':
            self.curve_reason='UPPER_CORRIDOR_POSE_RECOVERY'

    def curve_recovery_stopped(self, now):
        """Measured standstill after braking, for steering with zero propulsion."""
        source_now=self.curve_source_now()
        samples=list(getattr(self,'curve_motion_samples',()))
        last_drive=getattr(self,'curve_last_drive_time',-1e9)
        if (source_now is None or len(samples)<3 or now-last_drive<.50
                or not 0<=now-self.last_odom_time<=.35):return False
        latest=samples[-1][0]
        if not 0<=(source_now-latest)*1e-9<=.75:return False
        # RF2O commonly delivers one source pose every .2--.4 s under load.
        # A hard .5 s crop alternates between two and three samples, falsely
        # undoing a confirmed stop on each .3/.4 s update. Retain the boundary
        # sample and at least three real poses, with a bounded history/gap.
        samples=[a for a in samples if 0<=latest-a[0]<=1200000000]
        while len(samples)>3 and latest-samples[1][0]>=500000000:
            samples.pop(0)
        if len(samples)<3 or (samples[-1][0]-samples[0][0])*1e-9<.30:return False
        if any(not 0<b[0]-a[0]<=600000000 for a,b in zip(samples,samples[1:])):return False
        # Delayed measurements before the last drive cannot prove a stop now.
        if now-(source_now-samples[0][0])*1e-9<last_drive+.15:return False
        return all(math.hypot(a[1]-b[1],a[2]-b[2])<=.04
                   and abs(normalize_angle(a[3]-b[3]))<=.10
                   for a in samples for b in samples)

    def curve_recovery_hold_command(self, now):
        """Keep an established stopped pre-steer through a short data wait.

        This can only return zero drive. It cannot renew scan clearance or
        establish a stopped state, and a previous positive drive invalidates it.
        Fresh geometry still has to pass before the recovery may move again.
        """
        state=getattr(self,'curve_recovery_state',None)
        if (state is None or not state.get('preposition_required',True)
                or state.get('started') is None
                or not 0<=now-state.get('checked_at',-1e9)<=.50
                or getattr(self,'curve_last_drive_time',-1e9)>=state['started']
                or self.route_fault or self.lidar_emergency
                or self.curve_body_stop_reason(now)
                or not self.curve_recovery_stopped(now)):
            return None
        f=self.curve_follower
        if f is None or abs(self.last_lane_angular-state['steer'])>1e-6:return None
        cmd=Twist();cmd.angular.z=self.steering_sign*state['steer']
        self.curve_issued_steering(state['steer'],now)
        f.reset_feedback(preserve_output=True)
        self.curve_pause_active=True;self.curve_drive=0.
        state['clear_hits']=0;state['clear_stamp']=self.curve_scan_stamp
        self.curve_recovery_status=dict(state='PREPOSITION_WAIT_FRESH_SCAN',
            steering=state['steer'],elapsed_s=now-state['started'],
            last_check_age_s=now-state['checked_at'],issued_drive=0.)
        self.curve_control_status=dict(getattr(self,'curve_control_status',{}),
            pause=True,held_steering=True,issued_steering=cmd.angular.z,issued_drive=0.)
        return cmd

    def curve_second_recovery_scope(self, follower):
        """Local recovery from cone two's approach through its exit bend."""
        gates=follower.path.gates
        return len(gates)>4 and gates[2]-1.25<=follower.progress<gates[4]

    def curve_second_recovery_geometry(self, pose, follower, samples):
        """Keep complete map, forward progress and path-offset bounds."""
        detail=dict(map_clear=False,margin_m=.08,endpoints=[])
        self.curve_recovery_geometry_status=detail
        cones=self.curve_cones or ((6.,2.),(2.,2.))
        if not curve_path_body_clear(samples,cones=cones,margin=.08):
            return False,'SECOND_RECOVERY_MAP'
        detail['map_clear']=True
        count=(len(samples)-1)//3
        if count<1:return False,'SECOND_RECOVERY_GEOMETRY'
        maximum_offset=max(.30,min(.45,abs(follower.lateral)+.08))
        detail['maximum_offset_m']=maximum_offset
        for endpoint in (samples[count],samples[2*count],samples[3*count]):
            future=copy.copy(follower)
            try:index=future.locate(endpoint)
            except ValueError:return False,'SECOND_RECOVERY_TRACK'
            advance=future.progress-follower.progress
            reference=future.path.samples[index]
            offset=math.hypot(reference[0]-endpoint[0],reference[1]-endpoint[1])
            heading=abs(normalize_angle(reference[2]-endpoint[2]))
            detail['endpoints'].append(dict(advance_m=advance,offset_m=offset,heading_error_rad=heading))
            if not .10<=advance<=1.15:return False,'SECOND_RECOVERY_PROGRESS'
            if offset>maximum_offset:
                return False,'SECOND_RECOVERY_OFFSET'
            # locate already requires a forward-compatible path tangent, and
            # advance/offset bound reconnectability. A second arbitrary 37deg
            # veto rejected the map-clear clockwise escape beside the divider.
            # Heading remains diagnostic; the full raw sweep is still required.
        return True,'SECOND_RECOVERY_GEOMETRY_CLEAR'

    def curve_obstacle_recovery(self, pose, follower, started):
        """Pre-position steering, then use only a freshly checked constant arc.

        The normal feedback rollout must become clear before taking steering
        back. Resetting the wheels to centre on every rejected rollout used to
        prevent any departure from an otherwise recoverable stopped pose.
        """
        now=time.monotonic();f=follower
        state=getattr(self,'curve_recovery_state',None)
        detail=dict(state='WAIT_STANDSTILL',normal_sweep=dict(self.curve_sweep_diagnostics))
        self.curve_recovery_status=detail
        if self.route_fault:return None
        if self.curve_stop_reason(now) or not scan_geometry_valid(self.curve_scan):
            return self.curve_recovery_hold_command(now)
        requested=f.ff+f.p+f.i+f.d
        second=self.curve_second_recovery_scope(f)
        detail['second_scope']=second
        if not math.isfinite(requested) or (abs(requested)<.02 and not second) or abs(f.lateral)>.45:return None
        direction=1. if requested>0. else -1.
        alternative=state is not None and state.get('second_approach',False)
        if alternative:
            if (f.progress-state['origin_progress']>1.0
                    or math.hypot(pose[0]-state['origin_pose'][0],pose[1]-state['origin_pose'][1])>1.0):
                detail['state']='SECOND_RECOVERY_DISTANCE_BOUND';return None
        elif state is not None and state['steer']*direction<=0:state=None
        stopped=self.curve_recovery_stopped(now)
        measured_speed=getattr(self,'curve_motion_status',{}).get('speed_mps')
        continuing=(measured_speed is not None and math.isfinite(measured_speed)
                    and measured_speed>.10
                    and 0<=now-getattr(self,'curve_last_drive_time',-1e9)<=.35)
        if state is None and not stopped and not continuing:return None
        scan_pose=self.curve_scan_pose(now,pose)
        if scan_pose is None:return self.curve_recovery_hold_command(now)
        if scan_hits_body(self.curve_scan,scan_pose,[pose]):return None
        # Continuing motion uses its actual speed. Pre-positioning checks the
        # subsequent launch at a nominal .9 m/s, not the current zero speed.
        moving_arc=continuing or (state is not None and not state.get('preposition_required',True))
        if moving_arc and (measured_speed is None or not math.isfinite(measured_speed)):return None
        speed=max(.20,min(1.5,measured_speed)) if moving_arc else max(.9,min(1.5,measured_speed or 0.))
        horizon=.65 if measured_speed is None else max(.65,min(1.10,.35+.65*measured_speed))
        checked_arc=None
        if state is None:
            # A moving car may continue on a different, fully checked arc.
            # Its current servo response, not hypothetical full lock, must
            # clear every gain case. A stopped car first pre-positions at zero
            # drive; only that branch uses hypothetical settled selection.
            if second:
                correction=f.heading+math.atan2(1.3*f.lateral,.65)
                sign=(1. if correction>0. else -1.) if abs(correction)>.12 else direction
                candidates=[sign*.16,sign*.24,sign*.28,sign*.08,0.,
                    -sign*.08,-sign*.16,-sign*.24,-sign*.28,sign*.32,-sign*.32]
                if f.progress>=f.path.gates[3]:
                    # Beside the upper board, choosing the weakest clear arc
                    # can spend the remaining turning room before the next
                    # tick. Prefer a complete, checked turn toward the path.
                    candidates=[sign*.32,sign*.28,sign*.24,sign*.16,sign*.08,0.,
                        -sign*.08,-sign*.16,-sign*.24,-sign*.28,-sign*.32]
            else:
                candidates=[direction*magnitude for magnitude in ((.32,.28,.24) if continuing else (.24,.28,.32))]
            detail['candidates']=[]
            for candidate in candidates:
                steer=clamp(candidate,-self.curve_max_steer,self.curve_max_steer)
                samples=constant_steer_horizon(pose,steer,self.curve_curvature_gain,
                    self.curve_max_steer,distance=horizon,speed=speed,
                    initial_steer=f.response_output if continuing else steer)
                candidate_detail=dict(steer=steer)
                if second:
                    geometry_ok,geometry_reason=self.curve_second_recovery_geometry(pose,f,samples)
                    candidate_detail['geometry']=dict(self.curve_recovery_geometry_status)
                    if not geometry_ok:
                        candidate_detail['reason']=geometry_reason
                        detail['candidates'].append(candidate_detail);continue
                clear,why=self.curve_check_sweep(self.curve_scan,pose,samples,now)
                candidate_detail['reason']=why
                detail['candidates'].append(candidate_detail)
                if clear:
                    state=dict(steer=steer,started=None,preposition_required=not continuing)
                    if second:state.update(second_approach=True,origin_progress=f.progress,origin_pose=tuple(pose))
                    if continuing:checked_arc=(clear,why)
                    break
            if state is None:
                detail['state']='NO_CLEAR_ARC';return None
        steer=state['steer']
        # The response estimate follows commands actually issued on preceding
        # ticks. A just-published full-lock request is not assumed to be applied.
        if checked_arc is None:
            samples=constant_steer_horizon(pose,steer,self.curve_curvature_gain,
                self.curve_max_steer,distance=horizon,speed=speed,initial_steer=f.response_output)
            clear,why=self.curve_check_sweep(self.curve_scan,pose,samples,now)
        else:clear,why=checked_arc
        raw_why=why
        if state.get('second_approach',False):
            geometry_ok,geometry_reason=self.curve_second_recovery_geometry(pose,f,samples)
            detail['actual_response_geometry']=dict(self.curve_recovery_geometry_status)
            if not geometry_ok:clear=False;why=geometry_reason
        finished=time.monotonic()
        reason=self.curve_stop_reason(finished)
        detail.update(finished_at=finished,compute_ms=1000.*(finished-started),
            raw_reason=raw_why,arc_reason=why,final_check_reason=reason)
        self.curve_control_status.update(finished=finished,compute_ms=1000.*(finished-started))
        if reason:
            detail['state']='RECOVERY_FINAL_CHECK_WAIT'
            return self.curve_recovery_hold_command(finished)
        # Count dwell from issuing the first zero-drive steering request,
        # excluding the time spent searching and checking candidate arcs.
        if state['started'] is None:state['started']=finished
        if raw_why in ('CLEAR_RAW','SWEPT_OBSTACLE'):state['checked_at']=finished
        preposition=state.get('preposition_required',True)
        ready=clear and (not preposition or finished-state['started']>=.60) and finished-started<=.20
        # While moving, do not replace an obstructed arc with a new blind turn.
        if not ready and not stopped:
            detail.update(state='BRAKE_ARC_BLOCKED',arc_reason=why);return None
        cmd=Twist();cmd.angular.z=self.steering_sign*steer
        if ready:cmd.linear.x=self.curve_running_drive(finished,f)
        self.curve_recovery_state=state
        self.curve_sweep=why
        self.curve_pause_active=False
        checked_response=f.response_output
        # The previous issued steering remains active while this callback
        # computes. Account for that interval before moving the response clock
        # to the new issue time; otherwise each recovery tick loses .08--.15 s
        # of servo motion and repeatedly predicts that the wheels stayed near
        # centre. The newly selected steering has NOT been sent yet.
        self.curve_issued_steering(steer,finished)
        f.time=finished;f.integral=f.derivative=0.;f.reprime=True
        self.curve_drive=cmd.linear.x
        if ready:self.curve_last_drive_time=finished
        self.curve_reason='CHECKED_ARC_RECOVERY' if ready else 'STOPPED_STEERING_PREPOSITION'
        detail.update(state=self.curve_reason,steering=steer,response_at_check=checked_response,response_estimate=f.response_output,
            stopped=stopped,preposition_required=preposition,arc_clear=clear,arc_reason=why,
            horizon_m=horizon,elapsed_s=finished-state['started'],second_approach=state.get('second_approach',False))
        self.curve_sweep_diagnostics.update(scope='RECOVERY_ARC',checked_at=now,finished_at=finished,horizon_m=horizon)
        self.curve_control_status.update(finished=finished,compute_ms=1000.*(finished-started),
            pause=not ready,issued_steering=cmd.angular.z,issued_drive=cmd.linear.x,recovery=dict(detail),
            drive_control=dict(getattr(self,'curve_speed_status',{})))
        return cmd

    def curve_running_drive(self, now, follower):
        """Retain launch torque; reduce PWM only while measured motion exists.

        Motor input is not velocity. A bounded proportional trim uses measured
        speed rather than assuming .30 will launch this car. Collision and
        freshness gates must pass before this helper is used.
        """
        normal=min(.35,self.normal_speed)
        motion=getattr(self,'curve_motion_status',{})
        speed=motion.get('speed_mps');age=motion.get('odom_source_age_s')
        fresh=(speed is not None and age is not None
               and math.isfinite(speed) and math.isfinite(age)
               and 0<=age<=self.curve_prediction_max_time
               and 0<=now-self.last_odom_time<=self.curve_odom_max_age)
        demand=max(min(1.,abs(follower.curvature)/1.35),
                   min(1.,abs(follower.lateral)/.20),min(1.,abs(follower.heading)/.40))
        target=.65-.15*demand
        if follower.progress>=follower.path.gates[-2]-.50:target=min(target,.50)
        drive=normal;mode='LAUNCH_OR_NO_SPEED_FEEDBACK'
        if fresh and speed>=.22:
            drive=clamp(.325+.10*(target-speed),min(self.curve_min_drive,normal),normal)
            mode='MEASURED_RUNNING_TRIM'
        self.curve_speed_status=dict(mode=mode,target_mps=target,measured_mps=speed,
                                     source_age_s=age,drive_input=drive)
        return drive

    def curve_issued_steering(self, steering, now):
        """Advance the servo under the previous issued command until NOW."""
        f=self.curve_follower
        if f is not None:
            response_time=getattr(f,'response_time',None)
            if response_time is None:response_time=f.time
            dt=max(0.,now-response_time) if response_time is not None else 0.
            f.response_output+=(-math.expm1(-dt/f.response_tau))*(self.last_lane_angular-f.response_output)
            f.response_time=now;f.output=steering
        self.last_lane_angular=steering;self.last_lane_command_time=now
        self.lane_applied=steering

    def curve_command(self, now):
        if self.curve_follower is None:return self.relative_straight_command(now)
        # Planning/registration polling earlier in this callback can consume
        # time. Predict and check from the actual command start, not tick start.
        now=max(now,time.monotonic());started=now
        f=self.curve_follower;pose=self.curve_pose_estimate(now)
        if pose is None:return self.curve_pause_command(now)
        if f.progress>=f.path.lengths[-1]-.08:
            self.curve_reason='UPPER_CORRIDOR_POSE_RECOVERY';self.publish_stop();return Twist()
        if self.curve_pause_active:
            # Feedback resumes from the steering actually requested during the
            # pause, with its real elapsed time. No artificial 50 ms ramp reset.
            f.reset_feedback(preserve_output=True)
            f.output=self.last_lane_angular
            self.curve_pause_active=False
        try:
            f.command(pose,now,self.curve_curvature_gain,self.curve_max_steer)
        except ValueError as exc:
            finished=time.monotonic()
            self.curve_sweep='CURRENT_TRACK_ERROR'
            self.curve_sweep_diagnostics=dict(result='CURRENT_TRACK_ERROR',error=str(exc),
                scope='CURRENT',checked_at=started,finished_at=finished)
            self.curve_control_status=dict(command_pose=tuple(pose),started=started,finished=finished,
                compute_ms=1000.*(finished-started),tracking_error=str(exc),tracking_error_scope='CURRENT')
            self.curve_recovery_status=dict(state='CURRENT_TRACK_ERROR',error=str(exc))
            self.curve_reason='RECOVERING_'+str(exc);self.publish_stop();return Twist()
        # A valid current pose and a failed FUTURE rollout are distinct. The
        # latter may still have a locally checked constant-steering escape.
        motion=getattr(self,'curve_motion_status',{})
        measured_speed=motion.get('speed_mps')
        # Keep the nominal launch envelope despite a delayed near-zero sample.
        rollout_speed=max(.9,measured_speed or 0.)
        horizon=max(.65,min(1.10,.35+.65*rollout_speed))
        tracking_error=None
        try:
            samples=command_horizon(pose,f,self.curve_curvature_gain,self.curve_max_steer,
                distance=horizon,speed=rollout_speed)
            ok,self.curve_sweep=self.curve_check_sweep(self.curve_scan,pose,samples,now)
            self.curve_sweep_diagnostics['scope']='COMMAND'
            self.curve_sweep_diagnostics['checked_at']=now
            self.curve_sweep_diagnostics['horizon_m']=horizon
            self.curve_sweep_diagnostics['rollout_speed_mps']=rollout_speed
        except ValueError as exc:
            tracking_error=str(exc)
            self.curve_sweep_diagnostics=dict(result='FUTURE_TRACK_ERROR',error=tracking_error,
                scope='FUTURE',checked_at=now,horizon_m=horizon,rollout_speed_mps=rollout_speed)
            self.curve_sweep='FUTURE_TRACK_ERROR';ok=False
        finished=max(now,time.monotonic())
        self.curve_control_status=dict(command_pose=tuple(pose),started=started,finished=finished,
            compute_ms=1000.*(finished-started),requested_steering=f.output,
            source_motion=dict(getattr(self,'curve_motion_status',{})),horizon_m=horizon)
        self.curve_sweep_diagnostics['finished_at']=finished
        if tracking_error is not None:
            self.curve_control_status.update(tracking_error=tracking_error,tracking_error_scope='FUTURE')
            if tracking_error!='CURVE_TRACK_ERROR' or not self.curve_second_recovery_scope(f):
                self.curve_recovery_status=dict(state='FUTURE_TRACK_ERROR',error=tracking_error,
                    local_recovery_allowed=False)
                self.curve_reason='RECOVERING_'+tracking_error;self.publish_stop();return Twist()
        recovery=getattr(self,'curve_recovery_state',None)
        if recovery is not None:
            if not ok:
                recovery['clear_hits']=0
            elif self.curve_scan_stamp!=recovery.get('clear_stamp'):
                recovery['clear_stamp']=self.curve_scan_stamp
                recovery['clear_hits']=recovery.get('clear_hits',0)+1
            if ok and recovery.get('clear_hits',0)<2:
                command=self.curve_obstacle_recovery(pose,f,started)
                if command is not None:return command
                self.publish_stop();return Twist()
        if not ok:
            if self.curve_sweep in ('SWEPT_OBSTACLE','FUTURE_TRACK_ERROR'):
                command=self.curve_obstacle_recovery(pose,f,started)
                if command is not None:return command
            if self.curve_sweep in ('SWEPT_UNKNOWN','SWEPT_OCCLUDED','SCAN_ODOM_ALIGNMENT'):
                self.curve_reason='RECOVERABLE_'+self.curve_sweep
                return self.curve_pause_command(finished)
            self.curve_reason='RECOVERING_'+self.curve_sweep;self.publish_stop();return Twist()
        # A check that was fresh before computation is insufficient. Slow or
        # stale ticks issue no propulsion and can recover on the next new scan.
        reason=self.curve_stop_reason(finished)
        if not reason and finished-started>.20:reason='CURVE_CONTROL_OVERRUN'
        if reason:
            self.curve_reason='RECOVERING_'+reason
            return self.curve_pause_command(finished)
        self.curve_recovery_state=None
        self.curve_recovery_status={'state':'NORMAL_PATH_CLEAR'}
        self.curve_issued_steering(f.output,finished)
        self.curve_last_drive_time=finished
        self.rel_mode='SMOOTH_CURVE';self.exit_steering_mode='CURVE_PID'
        self.curve_drive=self.curve_running_drive(finished,f)
        cmd=Twist();cmd.linear.x=self.curve_drive;cmd.angular.z=self.steering_sign*f.output
        self.curve_control_status.update(pause=False,held_steering=False,
            issued_steering=cmd.angular.z,issued_drive=cmd.linear.x,
            drive_control=dict(self.curve_speed_status))
        if now-self.last_route_status_time>=.5:
            msg=String();msg.data=json.dumps(dict(pose=pose,observation_pose=self.curve_locator.pose,
                pose_policy=self.curve_pose_estimate_reason,progress=f.progress,target=f.target,
                lateral=f.lateral,heading=f.heading,curvature=f.curvature,ff=f.ff,p=f.p,i=f.i,d=f.d,
                command=f.output,speed=self.curve_drive,clusters=self.curve_tracks.hits,
                sweep=self.curve_sweep,sweep_detail=self.curve_sweep_diagnostics,
                registration_rms=self.curve_locator.residual))
            self.curve_pose_pub.publish(msg)
        return cmd

    def curve_feedback_status(self):
        f=self.curve_follower
        if f is None:return 'WAIT'
        return str([round(v,4) for v in (f.lateral,f.heading,f.curvature,f.ff,f.p,f.i,f.d,f.output,self.curve_drive)])

    def observe_departure_corridor(self, scan, now, observations=None):
        """Configured lane width and segmented near-wall direction.

        Pair width is diagnostic only. The same right-wall distance reference
        survives the left divider ending; forward bends cannot define heading.
        """
        if self.phase not in (self.STARTUP, self.APPROACH_CROSSWALK,
                              self.CROSSWALK_STOP, self.SEEK_CONE_1):
            return
        if self.curve_follower is not None:
            return
        # Count only distinct, ordered scan observations. A control tick must
        # not turn one measurement into several confirmations.
        if self.lane_raw_time is not None and now <= self.lane_raw_time:
            return
        uneven = self.phase == self.SEEK_CONE_1
        right = nearby_wall(scan, -1, uneven=uneven) if observations is None else observations[0]
        left = nearby_wall(scan, 1, uneven=uneven) if observations is None else observations[1]
        self.corridor_raw, self.lane_fit_left = right, left
        self.lane_observed_width = left[0]+right[0] if left is not None and right is not None else None
        if right is None:
            self.lane_fit_reason = 'RIGHT_FIT_REJECTED'
            self.lane_right_hits = 0
            return
        # Geometry confirmation can survive a brief processing gap. Driving
        # still requires a result at most .35 s old in bounded_corridor_request.
        fresh = (self.lane_raw_time is not None and
                 0 < now-self.lane_raw_time <= .65)
        if fresh:
            dt = now-self.lane_raw_time
            previous = self.lane_raw_previous
            distance_jump = (.05+.65*min(dt,.25)) if uneven else (.025+.40*min(dt,.25))
            heading_jump = (math.radians(8)+.8*min(dt,.25)) if uneven else (.035+.8*min(dt,.25))
            if (abs(right[0]-previous[0]) > distance_jump or
                    abs(normalize_angle(right[1]-previous[1])) > heading_jump):
                self.lane_fit_reason = 'RIGHT_FIT_JUMP'
                self.lane_right_hits = 0
                return
        else:
            self.lane_right_hits = 0
            self.lane_ready = False
            self.corridor_filtered = None
            self.lane_heading_weight = 0.0
        self.lane_raw_previous, self.lane_raw_time = right, now
        self.lane_right_hits = min(3, self.lane_right_hits+1)
        self.lane_fit_reason = 'RIGHT_ONLY'
        if left is not None:
            width = left[0]+right[0]
            if abs(normalize_angle(left[1]-right[1])) > math.radians(6):
                self.lane_fit_reason = 'PAIR_HEADING_REJECTED'
            elif not self.lane_nominal_width-.10 <= width <= self.lane_nominal_width+.15:
                self.lane_fit_reason = 'PAIR_WIDTH_REJECTED'
            else:
                self.lane_fit_reason = 'PAIR_OK'
        if self.parallel_band_active():
            # Establish the permitted strip from THREE current consistent wall
            # pairs. A narrow observed corridor can shrink it, never widen it.
            # Retain that upper limit when the left divider ends or at the zebra.
            if not fresh or self.lane_fit_reason != 'PAIR_OK':
                self.lane_band_width_samples.clear()
            if self.lane_fit_reason == 'PAIR_OK':
                self.lane_band_width_samples.append(left[0]+right[0])
                widths = self.lane_band_width_samples
                if len(widths) == 3 and max(widths)-min(widths) <= .03:
                    upper = min(self.lane_band_max_distance,
                                median(widths)-self.lane_band_min_distance)
                    self.lane_band_upper = (upper if self.lane_band_upper is None
                                            else min(self.lane_band_upper, upper))
        direction = local_wall_direction(scan, -1, uneven=uneven) if observations is None else observations[2]
        self.lane_direction = direction
        if self.bounded_heading_control:
            selected, source = self.select_corridor_heading(direction, right, left, uneven=uneven)
            previous_heading = self.lane_selected_heading
            continuous = (fresh and source == self.lane_heading_source
                          and previous_heading is not None and selected is not None
                          and abs(normalize_angle(selected-previous_heading)) <= math.radians(8.0 if uneven else 4.0))
            self.lane_direction_hits = (min(3, self.lane_direction_hits+1)
                                        if continuous else int(selected is not None))
            self.lane_selected_heading, self.lane_heading_source = selected, source
            self.lane_heading_observation = now
        previous = self.corridor_filtered
        a = 1.0 if previous is None else clamp((now-self.corridor_time)/(.10+now-self.corridor_time),0.,1.)
        weight = direction['weight']
        self.lane_heading_weight = (weight if weight <= self.lane_heading_weight else
                                    self.lane_heading_weight+a*(weight-self.lane_heading_weight))
        heading = direction['near'][1] if direction['near'] is not None else self.lane_yaw_bias
        self.corridor_filtered = (right[0],heading) if previous is None else (
            previous[0]+a*(right[0]-previous[0]),
            previous[1]+a*normalize_angle(heading-previous[1]))
        self.corridor_time = now
        self.corridor_width = self.lane_width
        self.corridor_reference = (.5*self.lane_width, self.lane_yaw_bias)
        if self.lane_right_hits >= 3:
            self.lane_ready = True
        self.lane_source = 'CONFIGURED_CENTRE'
        self.corridor_reason = 'LIVE_CENTRE' if self.lane_ready else 'FIT_CONFIRMING'

    def departure_corridor_request(self, now):
        if self.bounded_heading_control:
            return self.bounded_corridor_request(now)
        if (not self.lane_ready or self.corridor_filtered is None or
                not 0 <= now-self.corridor_time <= .35):
            self.corridor_reason = 'WAIT_CURRENT_WALL'
            self.lane_heading_gate = 'WAIT_CURRENT_WALL'
            self.lane_ready = False
            self.lane_recovering = True
            self.reset_center_pid()
            self.corridor_request = self.corridor_heading_term = 0.0
            return None
        self.lane_recovering = False
        target,bias = self.corridor_reference
        distance,heading = self.corridor_filtered
        self.lane_lateral = target-distance
        self.lane_heading = normalize_angle(heading-bias)
        error = math.copysign(max(0.,abs(self.lane_lateral)-.005),self.lane_lateral)
        lateral = self.lateral_pid(error,'LIVE_CENTRE',.35,.035,
                                   sample_time=self.corridor_time)
        h = math.copysign(max(0.,abs(self.lane_heading)-math.radians(.5)),self.lane_heading)
        self.corridor_heading_term = self.lane_heading_weight*clamp(.22*h,-.025,.025)
        self.lane_heading_gate = 'V21_WEIGHT'
        # At the start, small lateral errors must not be reinforced by a
        # direction estimate whose local wall segments disagree. Preserve the
        # lateral PID and mirror behavior; never insert a fixed right offset.
        if (self.phase == self.APPROACH_CROSSWALK and abs(self.lane_lateral)<=.02
                and (self.lane_direction['weight']<1. or self.lane_heading_weight<.75)):
            self.corridor_heading_term = 0.0
            self.lane_heading_gate = 'NEAR_CENTRE_LOW_CONFIDENCE'
        self.straight_error = error
        self.corridor_request = clamp(lateral+self.corridor_heading_term,
                                      -self.straight_limit,self.straight_limit)
        self.corridor_reason = ('LIVE_CENTRE' if now-self.corridor_time <= .20
                                else 'BRIEF_FIT_HOLD')
        return self.corridor_request

    @staticmethod
    def select_corridor_heading(direction, right, left, uneven=False):
        """Current near segment first; never trust a lone forward segment.

        When near fitting fails, a long, clean opposite wall can corroborate
        the right forward segment. Width and same-frame overall wall checks
        prevent selecting an unrelated surface after the left divider ends.
        """
        near = direction['near']
        if near is not None:
            if any(p is not None and abs(normalize_angle(p[1]-near[1])) <= math.radians(8.0 if uneven else 5.0)
                   for p in (direction['rear'], direction['ahead'])):
                return near[1], 'RIGHT_NEAR'
            return None, 'NONE'
        ahead = direction['ahead']
        if right is None or left is None or ahead is None:
            return None, 'NONE'
        if (not .80 <= right[0]+left[0] <= 1.05
                or abs(normalize_angle(right[1]-left[1])) > math.radians(10. if uneven else 6.)
                or left[2] < (6 if uneven else 8) or left[3] < (.55 if uneven else .75) or left[4] > (.025 if uneven else .008)
                or ahead[2] < 6 or ahead[3] < .30 or ahead[4] > (.025 if uneven else .006)
                or abs(normalize_angle(ahead[1]-left[1])) > math.radians(6. if uneven else 2.5)):
            return None, 'NONE'
        rear = direction['rear']
        if rear is not None and abs(normalize_angle(rear[1]-ahead[1])) > math.radians(6. if uneven else 2.5):
            return None, 'NONE'
        return (left[1]+ahead[1])*.5, 'LEFT_AND_RIGHT_AHEAD'

    def parallel_band_active(self):
        return (self.lane_parallel_band_enabled and self.curve_follower is None
                and self.phase in (self.STARTUP, self.APPROACH_CROSSWALK,
                                   self.CROSSWALK_STOP, self.SEEK_CONE_1))

    def bounded_corridor_request(self, now):
        """Lateral PID sets a bounded desired yaw; local yaw closes the inner loop.

        Do not weaken yaw damping alone when the forward wall bends. A near
        segment needs independent rear/ahead support; otherwise stop/reacquire.
        """
        current = (self.corridor_filtered is not None and 0 <= now-self.corridor_time <= .35)
        fresh = self.lane_ready and current
        heading_fresh = (self.lane_selected_heading is not None
                         and self.lane_heading_observation is not None
                         and 0 <= now-self.lane_heading_observation <= .35)
        if not fresh or not heading_fresh or self.lane_direction_hits < 3:
            self.corridor_reason = self.lane_heading_gate = (
                'WAIT_CURRENT_WALL' if not fresh else 'WAIT_LOCAL_HEADING')
            self.lane_heading_quality = 'WAIT'
            self.lane_band_mode = 'WAIT_OBSERVATION' if self.parallel_band_active() else 'OFF'
            self.lane_band_target = None
            self.lane_recovering = True
            if not current:
                self.lane_ready = False
                # Stop on the unchanged .35 s drive deadline, but do not erase
                # geometric evidence on every timer tick. observe_departure_corridor
                # expires/restarts the sequence after .65 s between observations,
                # or immediately on unsupported/inconsistent headings.
            self.reset_center_pid()
            self.corridor_request = self.corridor_heading_term = 0.
            self.lane_target_heading = self.lane_heading_error = 0.
            return None
        self.lane_recovering = False
        target, bias = self.corridor_reference
        self.lane_lateral = target-self.corridor_filtered[0]
        # Current supported near-wall angle avoids the filtered yaw's reversal lag.
        self.lane_heading = normalize_angle(self.lane_selected_heading-bias)
        band = self.parallel_band_active()
        if band:
            lower, upper = self.lane_band_min_distance, self.lane_band_upper
            if upper is None or upper-lower < .02:
                self.corridor_reason = self.lane_heading_gate = (
                    'WAIT_BAND_WIDTH' if upper is None else 'BAND_TOO_NARROW')
                self.lane_band_mode = self.corridor_reason
                self.lane_band_target = None
                self.lane_recovering = True
                self.reset_center_pid()
                self.corridor_request = self.corridor_heading_term = 0.
                self.lane_lateral = self.straight_error = 0.
                self.lane_target_heading = self.lane_heading_error = 0.
                return None
            distance = self.corridor_filtered[0]
            self.lane_band_target = clamp(distance, lower, upper)
            self.lane_lateral = error = self.lane_band_target-distance
            self.lane_band_mode = ('PARALLEL' if error == 0. else
                                   'RETURN_FROM_RIGHT' if error > 0. else 'RETURN_FROM_LEFT')
            if error == 0.:
                # Do not retain a centring integral or derivative inside the band.
                self.reset_center_pid()
                lateral = 0.
            else:
                lateral = self.lateral_pid(error, self.lane_band_mode, .35, .035,
                                           sample_time=self.corridor_time)
        else:
            self.lane_band_mode = 'OFF'
            self.lane_band_target = None
            error = math.copysign(max(0., abs(self.lane_lateral)-.005), self.lane_lateral)
            lateral = self.lateral_pid(error, 'BOUNDED_HEADING', .35, .035,
                                       sample_time=self.corridor_time)
        confident = (self.lane_heading_source == 'RIGHT_NEAR'
                     and self.lane_direction['weight'] >= 1. and self.lane_heading_weight >= .75)
        limit = math.radians(self.lane_target_heading_deg if confident else self.lane_cautious_heading_deg)
        if band:
            limit = min(limit, math.radians(self.lane_band_target_heading_deg))
        self.lane_heading_quality = ('CROSS_WALL_SUPPORTED' if self.lane_heading_source == 'LEFT_AND_RIGHT_AHEAD'
                                     else 'FULL' if confident else 'LOCAL_SUPPORTED')
        self.lane_target_heading = clamp(lateral*(.65/.35), -limit, limit)
        self.lane_heading_error = self.lane_heading+self.lane_target_heading
        combined = math.copysign(max(0., abs(self.lane_heading_error)-math.radians(.5)), self.lane_heading_error)
        if band and error != 0.:
            # Outside the strip, preserve even a small boundary-return target.
            # Inside, retain the existing half-degree heading noise deadband.
            combined = self.lane_heading_error
        self.corridor_heading_term = self.lane_heading_gain*self.lane_heading
        self.corridor_request = clamp(self.lane_heading_gain*combined,
                                      -self.straight_limit, self.straight_limit)
        if (self.corridor_request*self.lane_lateral > 0
                and abs(self.lane_heading) <= math.radians(6.)):
            # Enter a centring manoeuvre gently; retain the existing full
            # authority for countersteering once the target yaw is reached,
            # and for recovery from yaw beyond six degrees on either side.
            entry_limit = min(self.straight_limit, .020)
            self.corridor_request = clamp(self.corridor_request, -entry_limit, entry_limit)
        self.straight_error = error
        self.lane_heading_gate = 'PARALLEL_BAND' if band else 'BOUNDED_HEADING'
        self.corridor_reason = ('LIVE_'+self.lane_band_mode) if band else 'LIVE_BOUNDED_HEADING'
        return self.corridor_request

    def centre_heading_command(self, now, speed):
        requested = self.departure_corridor_request(now)
        if requested is None:
            self.last_lane_angular = self.lane_applied = 0.0
            self.last_lane_command_time = now
            return Twist()
        # Optional scalar-distance steering clamp; body and swept checks remain.
        left,right = self.exit_side_detail[0],self.exit_side_detail[3]
        if self.side_steering_guard_enabled and ((left>0 and left<.38 and requested>0) or (right>0 and right<.38 and requested<0)):
            requested = 0.0
        retract = abs(requested)<abs(self.last_lane_angular) or requested*self.last_lane_angular<0
        if self.bounded_heading_control and requested*self.last_lane_angular <= 0:
            # A fresh return-to-heading request must never keep the previous turn
            # alive through the slew limiter. Remove it before ramping countersteer.
            self.last_lane_angular = 0.
        delta = (.18 if retract else .12)*clamp(now-self.last_lane_command_time,0.,.15)
        angular = clamp(requested,self.last_lane_angular-delta,self.last_lane_angular+delta)
        if self.side_steering_guard_enabled and ((left>0 and left<.38 and angular>0) or (right>0 and right<.38 and angular<0)):
            angular = 0.0
            self.pid_integral = self.pid_i = 0.0
        self.last_lane_angular = self.lane_applied = angular
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x,cmd.angular.z = speed,self.steering_sign*angular
        if self.bounded_heading_control:
            cmd.linear.x = min(speed, self.lane_straight_drive)
        return cmd

    def entry_pose_straight_command(self, now, speed, previous=None):
        """Bridge an uneven-wall gap in the open departure region using live pose."""
        if (self.phase != self.SEEK_CONE_1 or self.curve_follower is not None
                or self.entry_hold or self.entry_v34_turn_stop
                or self.entry_v33_safety_reason(now)):
            return None
        pose=self.curve_pose_estimate(now)
        if (pose is None or not 3.55<=pose[0]<4.40 or not .30<=pose[1]<=1.05
                or abs(pose[2])>math.radians(20)):
            return None
        requested=clamp(-self.lane_heading_gain*pose[2],-self.straight_limit,self.straight_limit)
        # Preserve the measured drive input and the same bounded steering slew.
        last_angular,last_time=previous if previous is not None else (self.last_lane_angular,self.last_lane_command_time)
        delta=.12*clamp(now-last_time,0.,.15)
        angular=clamp(requested,last_angular-delta,last_angular+delta)
        samples=[pose];x,y,h=pose
        for _ in range(13):
            h+=self.curve_curvature_gain*angular*.05
            x+=.05*math.cos(h);y+=.05*math.sin(h);samples.append((x,y,h))
        cones=self.curve_cones or ((6.,2.),(2.,2.))
        if not all(curve_body_clear(p,cones) for p in samples):return None
        ok,self.curve_sweep=self.curve_check_sweep(self.curve_scan,pose,samples,now)
        self.curve_sweep_diagnostics['scope']='ENTRY_POSE_STRAIGHT'
        if not ok:return None
        finished=time.monotonic()
        if self.curve_pose_estimate(finished) is None or self.entry_v33_safety_reason(finished):return None
        self.last_lane_angular=self.lane_applied=angular;self.last_lane_command_time=now
        self.lane_recovering=False
        self.lane_heading_gate=self.corridor_reason='ENTRY_POSE_STRAIGHT'
        self.rel_mode='ENTRY_POSE_STRAIGHT';self.exit_steering_mode='ENTRY_POSE_STRAIGHT'
        self.curve_drive=min(speed,self.lane_straight_drive)
        cmd=Twist();cmd.linear.x=self.curve_drive;cmd.angular.z=self.steering_sign*angular
        return cmd

    def curve_straight_command(self, now):
        if self.entry_hold:
            self.last_lane_angular = 0.0
            self.last_lane_command_time = now
            self.reset_center_pid()
            return Twist()
        speed = self.normal_speed
        if self.entry_progress_x is not None and self.entry_progress_x >= self.entry_prepare_x:
            speed = min(speed, self.entry_prepare_drive)
        previous=(self.last_lane_angular,self.last_lane_command_time)
        cmd = self.centre_heading_command(now, speed)
        if self.lane_recovering:
            fallback=self.entry_pose_straight_command(now,speed,previous)
            if fallback is not None:return fallback
            self.rel_mode = 'WAIT_CURRENT_WALL'
            return cmd
        # Keep the known running command (configured normal_speed=0.35).
        # Safety gates still stop with zero; never floor a stopped command.
        # Curve following retains its separate curvature-based speed control.
        if cmd.linear.x>0 and self.phase==self.SEEK_CONE_1:
            pose=self.curve_pose_estimate(now) or (0.,0.,0.)
            angular=cmd.angular.z/self.steering_sign
            samples=[pose]
            for factor in (.8,1.,1.2):
                x,y,h=pose
                for _ in range(13):
                    h+=factor*self.curve_curvature_gain*angular*.05
                    x+=.05*math.cos(h);y+=.05*math.sin(h);samples.append((x,y,h))
            ok,self.curve_sweep=self.curve_check_sweep(self.curve_scan,pose,samples,now)
            self.curve_sweep_diagnostics['scope']='ENTRY_LOCAL_STRAIGHT'
            if not ok or self.entry_v33_safety_reason(time.monotonic()):
                self.curve_reason='RECOVERING_'+self.curve_sweep
                self.publish_stop();return Twist()
        self.curve_drive=cmd.linear.x
        self.exit_pulse_mode='CONTINUOUS';self.exit_steering_mode='LOCAL_WALL_V21'
        self.rel_mode='STRAIGHT_TO_CURVE'
        cmd.linear.x=self.curve_drive
        return cmd

    def relative_active(self):
        return self.phase in (self.SEEK_CONE_1, self.ENTER_OBSTACLES, self.ORBIT_CONE_1,
                              self.SEEK_CONE_2, self.ORBIT_CONE_2, 'REL_UPPER_APPROACH')

    def relative_callback(self, msg):
        if not self.relative_route:
            return
        now = time.monotonic()
        try:
            data = json.loads(msg.data)
            stamp = int(data['stamp_ns'])
            if data['schema'] != 3 or data['valid'] is not True or stamp <= self.rel_stamp:
                raise ValueError('FRAME')
            cones = data['cones']
            if not all(len(c) == 5 and all(math.isfinite(v) for v in c) and
                       abs(math.hypot(c[0], c[1])-c[2]) < .02 and (.06 if self.entry_v33_enabled else .10) <= c[3] <= (.34 if self.entry_v33_enabled else .32)
                       and c[4] >= 4 for c in cones):
                raise ValueError('CANDIDATES')
            if (not math.isfinite(data['front']) or data['front'] <= 0 or
                    not 0 <= data['front_coverage'] <= 1 or type(data['body_clear']) is not bool):
                raise ValueError('COVERAGE')
            if (not math.isfinite(data['exit_path_front']) or data['exit_path_front'] <= 0
                    or not 0 <= data['exit_path_coverage'] <= 1
                    or not math.isfinite(data['exit_path_half_width'])
                    or not math.isfinite(data['exit_path_body_front'])
                    or abs(data['exit_path_half_width']-(self.layout_half_width+.10)) > .001
                    or abs(data['exit_path_body_front']-self.layout_front_extent) > .001):
                raise ValueError('EXIT_PATH_GEOMETRY')
            wall = data['entry_end_wall']
            if wall is not None and (len(wall) != 5 or not all(math.isfinite(v) for v in wall)
                    or not 1.0 <= wall[0] <= 8.6 or abs(wall[1]) > math.radians(12)
                    or wall[2] < .70 or not 0 <= wall[3] <= .04 or wall[4] < 10):
                raise ValueError('END_WALL')
            geometry = data['entry_side_geometry']
            expected = [self.layout_rear_extent, self.layout_front_extent,
                        self.layout_half_width, .10, .50]
            if (len(geometry) != 5 or any(not math.isfinite(v) or abs(v-e) > .001
                    for v,e in zip(geometry, expected))
                    or type(data['entry_side_clear']) is not bool
                    or not 0 <= data['entry_side_coverage'] <= 1):
                raise ValueError('SIDE_GEOMETRY')
            if now-self.rel_time > .35:
                self.rel_hits = self.rel_second_hits = 0
            self.rel_stamp, self.rel_time, self.rel_data = stamp, now, data
        except (ValueError, TypeError, KeyError):
            self.rel_data = None
            self.rel_hits = self.rel_second_hits = 0
            self.entry_wall_hits = 0
            return
        if self.curve_route:
            self.curve_features.append((self.rel_stamp,self.rel_time,self.rel_data))
            if self.curve_observation_active() and self.curve_follower is None:self.observe_entry_wall(now)
            if self.entry_v33_enabled and self.curve_observation_active() and self.curve_follower is None and self.curve_job is None:
                cached=next(((t,s) for stamp,t,s in reversed(self.entry_v33_scans) if stamp==self.rel_stamp),None)
                if cached is not None and 0<=now-cached[0]<=.25:
                    self.curve_submit_registration(cached[1],cached[0],self.rel_stamp)
            self.curve_observe_clusters(now)
            return
        if not self.relative_active() or self.phase == 'REL_UPPER_APPROACH':
            return
        if self.phase == self.SEEK_CONE_1:
            self.observe_entry_wall(now)
            # Reacquire only in the expected first-cone region after a sustained
            # loss; never let an old divider-end candidate monopolise identity.
            if now-self.rel_target_time > .50:
                self.rel_target = None
                self.rel_hits = 0
            cones = [c for c in cones if self.entry_cone_matches(c, now)]
        choices = []
        if self.rel_target is None:
            choices = [c for c in cones if .4 < c[0] < 3.5 and .2 < c[1] < 2.5
                       and 1.1 < c[2] < 3.5]
            choices.sort(key=lambda c:c[2])
        elif self.last_yaw is not None and self.rel_target_yaw is not None:
            delta = normalize_angle(self.last_yaw-self.rel_target_yaw)
            px = math.cos(delta)*self.rel_target[0]+math.sin(delta)*self.rel_target[1]
            py = -math.sin(delta)*self.rel_target[0]+math.cos(delta)*self.rel_target[1]
            choices = [c for c in cones if math.hypot(c[0]-px,c[1]-py) <= .30]
            choices.sort(key=lambda c:math.hypot(c[0]-px,c[1]-py))
        # Ambiguous clusters must not switch the tracked identity.
        if len(choices) > 1:
            self.rel_hits = 0
            self.rel_second_hits = 0
            return
        if choices:
            self.rel_target = tuple(choices[0][:3])
            self.rel_target_yaw = self.last_yaw
            self.rel_target_time = now
            self.rel_hits = min(8,self.rel_hits+1)
        else:
            self.rel_hits = 0
            self.rel_second_hits = 0
        if self.phase == self.SEEK_CONE_2 and self.rel_leg == 1 and self.rel_hits >= 5:
            # Both observed at once: 4 m is a pairing prior, never a drive distance.
            second = [c for c in cones if c[0] > .3 and c[2] > 1.2 and
                      abs(math.hypot(c[0]-self.rel_target[0],c[1]-self.rel_target[1])-4.) <= .60]
            if len(second) == 1:
                c = tuple(second[0][:3])
                self.rel_second_hits = (self.rel_second_hits+1 if self.rel_second is not None
                    and math.hypot(c[0]-self.rel_second[0],c[1]-self.rel_second[1]) < .25 else 1)
                self.rel_second = c
                if self.rel_second_hits >= 5:
                    self.rel_target, self.rel_leg = c, 2
                    self.rel_target_yaw, self.rel_target_time = self.last_yaw, now
                    self.rel_hits = 5
            else:
                self.rel_second_hits = 0

    def relative_stop_reason(self, now):
        if self.curve_route and self.relative_active():return self.curve_stop_reason(now)
        if not self.relative_route or not self.relative_active():
            return ''
        body=self.curve_body_stop_reason(now)
        if body:return body
        if not self.sensors_ready(now):
            return 'REL_SENSOR_STALE'
        if self.rel_data is None or now-self.rel_time > .35:
            return 'REL_SCAN_STALE'
        if self.rel_data['front_coverage'] < .95:
            return 'REL_FRONT_UNKNOWN'
        if self.lidar_left_clearance < 0 or self.lidar_right_clearance < 0:
            return 'REL_SIDE_UNKNOWN'
        if self.phase == self.SEEK_CONE_1:
            if self.straight_reference is None:
                return 'EXIT_REFERENCE_UNCONFIRMED'
            if self.rel_data['exit_path_coverage'] < .95:
                return 'REL_EXIT_PATH_UNKNOWN'
            if self.rel_data['exit_path_front'] <= self.exit_front_stop_distance:
                return 'REL_EXIT_PATH_BLOCKED'
        elif self.rel_data['front'] <= .65:
            return 'REL_FRONT_TOO_CLOSE'
        if self.phase == self.SEEK_CONE_1:
            if self.rel_data['entry_side_coverage'] < .95:
                return 'REL_EXIT_SIDE_UNKNOWN'
            if not self.rel_data['entry_side_clear']:
                return 'REL_EXIT_SIDE_NEAR_BODY'
            if self.entry_wall is not None and now-self.entry_wall_time <= .35 and self.entry_wall[0] < 2.0:
                return 'REL_ENTRY_REGION_PASSED'
            if self.entry_region_seen and now-self.entry_wall_time > .35:
                return 'REL_ENTRY_WALL_LOST'
        elif self.side_distance_guard_enabled and any(0 < d <= .30 for d in (self.left_proximity,self.right_proximity)):
            return 'REL_SIDE_TOO_CLOSE' 
        if now-self.phase_started_at > (20. if self.phase == self.SEEK_CONE_1 else 30.):
            return 'REL_STAGE_TIMEOUT'
        if self.last_yaw is None or self.rel_start_yaw is None:
            return 'REL_YAW_MISSING'
        if self.phase == self.SEEK_CONE_1 and abs(normalize_angle(self.last_yaw-self.rel_start_yaw)) > math.radians(20):
            return 'REL_EXIT_HEADING_DEVIATION'
        if self.phase in (self.ENTER_OBSTACLES,self.ORBIT_CONE_1) and self.rel_yaw < -math.radians(15):
            return 'REL_WRONG_LEFT_TURN'
        if self.phase == self.ORBIT_CONE_2 and self.rel_yaw > math.radians(15):
            return 'REL_WRONG_RIGHT_TURN'
        if abs(self.rel_yaw) > math.radians(220):
            return 'REL_TURN_LIMIT'
        return ''

    def observe_entry_wall(self, now):
        wall = self.rel_data['entry_end_wall']
        consistent = (wall is not None and self.entry_wall is not None
                      and now-self.entry_wall_time <= .35
                      and abs(wall[0]-self.entry_wall[0]) <= .25
                      and abs(normalize_angle(wall[1]-self.entry_wall[1])) <= math.radians(3))
        self.entry_wall_hits = min(8, self.entry_wall_hits+1) if consistent else (1 if wall else 0)
        if wall is not None:
            self.entry_wall = wall
            self.entry_wall_time = now
        if self.entry_wall_ready(now) and self.entry_wall[0] <= 2.70:
            self.entry_region_seen = True

    def entry_wall_ready(self, now):
        return (self.entry_wall is not None and self.entry_wall_hits >= (3 if self.entry_v33_active() else 5)
                and now-self.entry_wall_time <= .35 and self.rel_data is not None
                and now-self.rel_time <= .35)

    def entry_region_status(self, now):
        if self.curve_route:return self.curve_reason
        if not self.relative_route or self.phase != self.SEEK_CONE_1:
            return 'OFF'
        if not self.entry_wall_ready(now):
            return 'END_WALL_UNCONFIRMED'
        distance = self.entry_wall[0]
        if distance > 2.50:
            return 'BEFORE_REGION'
        return 'IN_REGION' if distance >= 2.0 else 'PAST_REGION'

    def entry_cone_matches(self, cone, now):
        if not self.entry_wall_ready(now):
            return False
        distance, heading = self.entry_wall[:2]
        x = math.cos(heading)*cone[0]+math.sin(heading)*cone[1]
        y = -math.sin(heading)*cone[0]+math.cos(heading)*cone[1]
        # First encountered cone is 2 m before the end board, on the centreline.
        # Broad lateral tolerance allows small drift within the 0.9 m corridor.
        return abs(x-(distance-2.0)) <= .35 and 1.10 <= y <= 2.0

    def relative_target_ready(self, now):
        return self.rel_target is not None and self.rel_hits >= 5 and now-self.rel_target_time <= .30

    def relative_exit_ready(self, now):
        return (self.entry_region_status(now) == 'IN_REGION'
                and self.rel_target is not None and self.entry_cone_matches(self.rel_target, now)
                and self.crosswalk_clear_count >= self.post_crosswalk_clear_frames
                and self.entry_body_count >= self.entry_open_confirm_frames
                and self.lidar_left_clearance >= .65 and self.relative_target_ready(now)
                and self.rel_target[0] > .2 and self.rel_target[1] > .2
                and .90 < self.rel_target[2] < 3.5
                and self.straight_reference is not None and self.last_yaw is not None
                and abs(normalize_angle(self.straight_reference-self.last_yaw)) < math.radians(6)
                and abs(self.straight_yaw_rate) < .15)

    def relative_hold(self, now, reason):
        self.rel_mode = reason
        if self.rel_wait_since is None:
            self.rel_wait_since = now
        if now-self.rel_wait_since >= 5.:
            self.fail_route('REL_CONFIRM_TIMEOUT:'+reason)
        self.last_lane_angular = 0.
        self.last_lane_command_time = now
        return Twist()

    def relative_update(self, now):
        if self.curve_route:return self.curve_update(now)
        if self.phase == self.SEEK_CONE_1:
            if self.relative_exit_ready(now):
                # Paper/body/target already require distinct fresh frames.
                # Continue into the turn; there is no commissioning settle stop.
                if self.test_stop_after_exit:
                    self.fail_route('TEST_EXIT_COMPLETE')
                else:
                    self.set_phase(self.ENTER_OBSTACLES)
            return
        total = normalize_angle(self.last_yaw-self.rel_start_yaw)
        if self.phase == self.ENTER_OBSTACLES:
            if self.relative_target_ready(now) and self.rel_yaw >= math.radians(50):
                if self.test_stop_after_entry:
                    self.fail_route('TEST_ENTRY_COMPLETE')
                else:
                    self.set_phase(self.ORBIT_CONE_1)
            return
        if self.phase == self.ORBIT_CONE_1:
            if (self.relative_target_ready(now) and self.rel_yaw > math.radians(60)
                    and abs(normalize_angle(total-math.pi)) < math.radians(15)
                    and self.rel_target[1] > .5):
                self.set_phase(self.SEEK_CONE_2)
            return
        if self.phase == self.SEEK_CONE_2:
            if (self.rel_leg == 2 and self.relative_target_ready(now) and
                    self.rel_target[2] <= 1.5 and self.rel_target[1] < -.4
                    and abs(normalize_angle(total-math.pi)) < math.radians(50)):
                self.set_phase(self.ORBIT_CONE_2)
            return
        if self.phase == self.ORBIT_CONE_2:
            if (self.relative_target_ready(now) and self.rel_yaw < -math.radians(90)
                    and abs(total) < math.radians(15) and self.rel_target[1] < -.5):
                self.set_phase('REL_UPPER_APPROACH')
            return
        if self.phase == 'REL_UPPER_APPROACH':
            if self.last_boundary_time != self.rel_boundary_seen:
                self.rel_boundary_seen = self.last_boundary_time
                valid = self.relative_upper_pair(now) and abs(total) < math.radians(15)
                self.rel_corridor_hits = self.rel_corridor_hits+1 if valid else 0
            if self.rel_corridor_hits >= 5:
                self.entry_done = True
                self.set_phase(self.SEEK_LIGHT)

    def relative_upper_pair(self, now):
        if len(self.exit_spatial) != 21 or now-self.last_boundary_time > .35:
            return False
        lh,rh,lf,rf = self.exit_current_wall
        ld,rd = self.exit_spatial[15:17]
        return (bool(lf and rf) and abs(ld+rd-.9) <= .08 and min(ld,rd) > .30
                and max(abs(lh),abs(rh)) < math.radians(10) and abs(lh-rh) < math.radians(5))

    def relative_drive(self, now, angular, limit=.22):
        self.rel_wait_since = None
        angular = clamp(angular,-limit,limit)
        delta = self.lane_steering_slew_per_sec*clamp(now-self.last_lane_command_time,0.,.2)
        command = clamp(angular,self.last_lane_angular-delta,self.last_lane_angular+delta)
        if command*angular < 0: command=0.
        self.last_lane_angular,self.last_lane_command_time = command,now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign*command
        return cmd

    def relative_command(self, now):
        if self.curve_route:return self.curve_command(now)
        if self.phase == self.SEEK_CONE_1:
            # Before the preset region, missing cones must not cause a pause.
            # Within it keep scanning continuously; crossing its far edge faults
            # instead of driving blindly towards the end board or turning early.
            return self.relative_straight_command(now)
        if self.phase == 'REL_UPPER_APPROACH':
            if len(self.exit_spatial) != 21 or now-self.last_boundary_time > .35:
                return self.relative_hold(now,'UPPER_BOUNDARY_MISSING')
            lh,rh,lf,rf = self.exit_current_wall
            ld = self.exit_spatial[15]
            total = normalize_angle(self.last_yaw-self.rel_start_yaw)
            if not lf or not .30 < ld < 1.6 or abs(lh) > math.radians(25) or abs(total) > math.radians(30):
                return self.relative_hold(now,'UPPER_WALL_UNCONFIRMED')
            self.rel_mode = 'UPPER_WALL_APPROACH'
            return self.relative_drive(now,.7*(lh+clamp(.5*(ld-.45),-.15,.15)),.16)
        if not self.relative_target_ready(now):
            return self.relative_hold(now,'CONE_LOST_OR_AMBIGUOUS')
        x,y,distance = self.rel_target
        if distance <= .75:
            self.fail_route('REL_CONE_TOO_CLOSE')
            return Twist()
        bearing = math.atan2(y,x)
        if self.phase == self.SEEK_CONE_2:
            if self.rel_leg != 2:
                return self.relative_hold(now,'SECOND_CONE_PAIR_UNCONFIRMED')
            # Aim south of the second cone in the departure-aligned frame, forming the S transfer.
            yaw = normalize_angle(self.last_yaw-self.rel_start_yaw)
            gx,gy = x-1.0*math.sin(yaw),y-1.0*math.cos(yaw)
            if gx <= .10:
                return self.relative_hold(now,'SECOND_APPROACH_GEOMETRY')
            self.rel_mode = 'SECOND_CONE_APPROACH'
            return self.relative_drive(now,.7*math.atan2(gy,gx))
        direction = -1 if self.phase == self.ORBIT_CONE_2 else 1
        if self.phase == self.ENTER_OBSTACLES:
            if y <= 0 or self.lidar_left_clearance < .65:
                return self.relative_hold(now,'ENTRY_LEFT_UNCONFIRMED')
            tangent = bearing-math.asin(min(1.,.90/distance))
            if tangent <= .01:
                return self.relative_hold(now,'ENTRY_TANGENT_BLOCKED')
            angular = clamp(.8*tangent,.04,.22)
        else:
            if y*direction <= .15:
                return self.relative_hold(now,'ORBIT_TARGET_WRONG_SIDE')
            angular = direction*(.18+.30*(distance-.95))+.35*normalize_angle(bearing-direction*math.pi/2)
            angular = direction*clamp(direction*angular,.04,.25)
        self.rel_mode = 'FIRST_CONE' if direction > 0 else 'SECOND_CONE'
        limit = (min(.22, self.straight_limit+.10*max(0.,now-self.phase_started_at))
                 if self.phase == self.ENTER_OBSTACLES else .25)
        return self.relative_drive(now,angular,limit)

    def begin_relative_straight(self):
        """Freeze the observed corridor direction, not a manually supplied pose."""
        self.straight_reference = None
        if not self.curve_route:
            self.entry_wall = None
            self.entry_wall_hits = 0
            self.entry_wall_time = 0.0
        self.entry_region_seen = False
        self.straight_opening = False
        self.straight_open_hits = 0
        self.straight_boundary_seen = None
        self.straight_rate_samples.clear()
        self.reset_center_pid()
        self.straight_yaw_rate = 0.0
        self.straight_error = 0.0
        self.last_lane_angular = 0.0
        self.last_lane_command_time = time.monotonic()
        if self.last_yaw is None or len(self.straight_samples) < 5:
            return
        offsets = [normalize_angle(value-self.last_yaw) for value in self.straight_samples]
        if max(offsets)-min(offsets) > math.radians(3):
            return
        self.straight_reference = normalize_angle(self.last_yaw+median(offsets))
        # The later cone turns use the corridor direction as their zero heading.
        self.rel_start_yaw = self.straight_reference

    def update_straight_yaw_rate(self, now, yaw):
        """Slope over several accepted odometry samples suppresses single-frame noise."""
        samples = self.straight_rate_samples
        if samples and (now <= samples[-1][0] or now-samples[-1][0] > self.odom_max_gap):
            samples.clear()
            self.straight_yaw_rate = 0.0
        unwrapped = (samples[-1][1]+normalize_angle(yaw-samples[-1][1]) if samples else yaw)
        samples.append((now,unwrapped))
        while len(samples) > 2 and now-samples[0][0] > .40:
            samples.popleft()
        if len(samples) < 4 or samples[-1][0]-samples[0][0] < .20:
            return
        mt = sum(t for t,_ in samples)/len(samples)
        my = sum(y for _,y in samples)/len(samples)
        variance = sum((t-mt)**2 for t,_ in samples)
        slope = sum((t-mt)*(y-my) for t,y in samples)/max(variance,1e-9)
        self.straight_yaw_rate = clamp(slope,-.60,.60)

    def reset_center_pid(self):
        self.pid_seen = None
        self.pid_sample_time = None
        self.pid_error = None
        self.pid_integral = 0.0
        self.pid_derivative = 0.0
        self.pid_p = self.pid_i = self.pid_d = 0.0
        self.pid_requested = 0.0
        self.pid_target = None
        self.pid_source = 'WAIT'
        self.pid_phase = None

    def lateral_pid(self, error, source, kp, limit, sample_time=None):
        """Metres -> steering command, sampled once per existing boundary frame.

        Positive error means more space on the left. Raw wall heading is NOT
        an additive steering target. I/D cannot reverse the lateral P command.
        """
        stamp=self.last_boundary_time if sample_time is None else sample_time
        if self.pid_seen==stamp and self.pid_source==source and self.pid_phase==self.phase:
            return clamp(self.pid_requested,-limit,limit)
        dt=0. if self.pid_sample_time is None else stamp-self.pid_sample_time
        prime=(self.pid_error is None or self.pid_source!=source or
               self.pid_phase!=self.phase or not 0.<dt<=self.sensor_timeout)
        p=kp*error
        if prime or error==0. or error*self.pid_error<=0.:
            self.pid_integral=self.pid_derivative=0.
        else:
            a=dt/(.20+dt)
            self.pid_derivative+=a*((error-self.pid_error)/dt-self.pid_derivative)
            # Falling error releases I; saturated/slew-limited output cannot wind up.
            if abs(error)<abs(self.pid_error):
                self.pid_integral=0.
            elif (abs(error)<.10 and abs(self.pid_requested)<limit*.8 and
                  abs(self.last_lane_angular-self.pid_requested)<.002):
                self.pid_integral=clamp(self.pid_integral+.008*error*dt,-.002,.002)
        self.pid_p=p
        self.pid_i=self.pid_integral
        d_limit=min(.006,abs(p)*.5)
        self.pid_d=clamp(.04*self.pid_derivative,-d_limit,d_limit)
        requested=p+self.pid_i+self.pid_d
        # Inside the deadband: neutral. Outside: I/D may brake but not reverse P.
        self.pid_requested=(clamp(requested,0.,limit) if error>0. else
                            clamp(requested,-limit,0.) if error<0. else 0.)
        self.pid_error=error;self.pid_source=source;self.pid_phase=self.phase
        self.pid_seen=self.pid_sample_time=stamp
        self.pid_target=(0.,error)
        return self.pid_requested

    def centerline_observation(self):
        """Return a target in the laser frame using CURRENT confirmed walls.

        Wall distances are perpendicular distances, not y intercepts. After
        the left divider ends, the right outer board defines the extension of
        the 0.9 m corridor centreline; we never centre the full open arena.
        """
        if len(self.exit_current_wall) != 4 or len(self.exit_spatial) != 21:
            return None
        lh,rh,lf,rf = self.exit_current_wall
        ld,rd = self.exit_spatial[15:17]
        if not all(math.isfinite(v) for v in (lh,rh,ld,rd)):
            return None
        if not (rf and self.right_valid and .25 <= rd <= .90
                and abs(rh) <= math.radians(25)):
            return None
        half = self.center_pid_half_width
        pair = (lf and self.left_valid and .25 <= ld <= .90
                and abs(lh) <= math.radians(25)
                and abs(lh-rh) <= math.radians(8)
                and abs(ld+rd-2*half) <= .15)
        opening = not lf or (ld > half+.15 and ld+rd > 2*half+.15)
        if pair and not self.straight_opening:
            heading = .5*(lh+rh)
            offset = .5*(ld-rd)
            source = 'TWO_WALLS'
        else:
            heading = rh
            offset = half-rd
            source = 'RIGHT_WALL'
        # Two centimetres of lateral tolerance prevents chasing tiny fit noise.
        offset = math.copysign(max(0.0,abs(offset)-.02),offset)
        x = self.center_pid_lookahead
        y = x*math.tan(heading)+offset/math.cos(heading)
        return source, x, y, bool(opening)

    def relative_straight_command(self, now):
        """Track live centreline lookahead bearing with filtered time-based PID."""
        if len(self.exit_spatial) != 21 or not 0 <= now-self.last_boundary_time <= self.sensor_timeout:
            self.reset_center_pid()
            self.fail_route('EXIT_STRAIGHT_BOUNDARY_STALE')
            return Twist()
        if self.curve_route:return self.curve_straight_command(now)
        observation = self.centerline_observation()
        if observation is None:
            self.reset_center_pid()
            self.fail_route('EXIT_STRAIGHT_WALL_LOST')
            return Twist()
        if self.pid_seen != self.last_boundary_time:
            source,x,y,opening = observation
            stamp = self.last_boundary_time
            self.straight_open_hits = self.straight_open_hits+1 if opening else 0
            if self.straight_open_hits >= 2:
                self.straight_opening = True
            raw = math.atan2(y,x)
            dt = stamp-self.pid_sample_time if self.pid_sample_time is not None else 0.0
            prime = (self.pid_error is None or source != self.pid_source or not 0 < dt <= .35)
            if prime:
                self.pid_error = raw
                self.pid_integral = self.pid_derivative = 0.0
            else:
                alpha = dt/(.15+dt)
                filtered = self.pid_error+alpha*(raw-self.pid_error)
                derivative = (filtered-self.pid_error)/dt
                self.pid_derivative += alpha*(derivative-self.pid_derivative)
                self.pid_error = filtered
            self.pid_source = source
            self.pid_seen = self.pid_sample_time = stamp
            self.pid_target = (x,y)
            self.straight_error = self.pid_error
            self.pid_p = self.center_pid_kp*self.pid_error
            self.pid_d = self.center_pid_kd*self.pid_derivative
            # Store integral as its output contribution (maximum +/-0.008).
            # Suppress windup under amplitude, startup ramp AND slew limiting.
            candidate = self.pid_integral
            if not prime:
                if abs(self.pid_error) < .01:
                    candidate *= max(0.,1.-dt/.5)
                else:
                    candidate = clamp(candidate+self.center_pid_ki*self.pid_error*dt,-.008,.008)
            proposal = self.pid_p+candidate+self.pid_d
            ramp = clamp(now-self.phase_started_at,0.,1.)
            delta = .05*clamp(now-self.last_lane_command_time,0.,.20)
            realizable = clamp(clamp(proposal*ramp,-self.straight_limit,self.straight_limit),
                                self.last_lane_angular-delta,self.last_lane_angular+delta)
            if (candidate-self.pid_integral)*(proposal-realizable) <= 1e-12:
                self.pid_integral = candidate
            self.pid_i = self.pid_integral
            self.pid_requested = self.pid_p+self.pid_i+self.pid_d
        # Repeated controller ticks do not integrate or differentiate the same
        # boundary sample twice; only output ramp/slew evolves between samples.
        ramp = clamp(now-self.phase_started_at,0.,1.)
        desired = clamp(self.pid_requested*ramp,-self.straight_limit,self.straight_limit)
        delta = .05*clamp(now-self.last_lane_command_time,0.,.20)
        angular = clamp(desired,self.last_lane_angular-delta,self.last_lane_angular+delta)
        self.last_lane_angular,self.last_lane_command_time = angular,now
        self.exit_pulse_mode = 'CONTINUOUS'
        self.exit_steering_mode = 'CENTERLINE_PID'
        self.rel_mode = 'ENTRY_REGION_CONFIRM' if self.entry_region_status(now) == 'IN_REGION' else 'EXIT_TO_REGION'
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign*angular
        return cmd

    def relative_exit_pending(self, now):
        if self.curve_route:return self.curve_reason
        pending = []
        region = self.entry_region_status(now)
        if region != 'IN_REGION':
            pending.append(region)
        if self.rel_target is not None and not self.entry_cone_matches(self.rel_target, now):
            pending.append('CONE_POSITION')
        if self.crosswalk_clear_count < self.post_crosswalk_clear_frames:
            pending.append('PAPER_CLEAR')
        if self.entry_body_count < self.entry_open_confirm_frames:
            pending.append('DIVIDER_REAR_CLEAR')
        if self.lidar_left_clearance < .65:
            pending.append('LEFT_SPACE')
        if not self.relative_target_ready(now):
            pending.append('FIRST_CONE')
        elif not (self.rel_target[0] > .2 and self.rel_target[1] > .2
                  and .90 < self.rel_target[2] < 3.5):
            pending.append('CONE_GEOMETRY')
        if (self.straight_reference is None or self.last_yaw is None
                or abs(normalize_angle(self.straight_reference-self.last_yaw)) >= math.radians(6)
                or abs(self.straight_yaw_rate) >= .15):
            pending.append('HEADING_SETTLING')
        return '|'.join(pending) if pending else 'READY'

    def auto_start_callback(self, msg):
        if not (self.layout_enabled and self.layout_auto_start) or self.phase != self.STARTUP:
            return  # Once anchored, never relocalise or change origin while driving.
        now = time.monotonic()
        try:
            data = json.loads(msg.data)
            stamp = int(data.get('stamp_ns', 0))
            if data.get('schema') != 1 or stamp <= self.auto_start_stamp or stamp <= 0:
                raise ValueError('SCAN_STAMP_NOT_ADVANCING')
            self.auto_start_stamp = stamp
            if data.get('valid') is not True:
                raise ValueError(str(data.get('reason', 'INVALID_OBSERVATION')))
            x, y, yaw = (float(data[k]) for k in ('x', 'y', 'yaw'))
            if not all(math.isfinite(v) for v in (x, y, yaw)):
                raise ValueError('NONFINITE_POSE')
            rear = self.layout_rear_extent*math.cos(yaw)+self.layout_half_width*abs(math.sin(yaw))
            side = self.layout_half_width*math.cos(yaw)+max(self.layout_front_extent,self.layout_rear_extent)*abs(math.sin(yaw))
            if (not rear+.10 < x < 1.5 or not side+.10 < y < .9-side-.10
                    or abs(yaw) > math.radians(10)):
                raise ValueError('START_BODY_CLEARANCE_OR_POSE')
            if not self.odom_is_still(now) or now-self.last_odom_time > self.odom_max_gap:
                raise ValueError('WAIT_FOR_STANDSTILL')
            if now-self.auto_start_time > .35:
                self.auto_start_samples.clear()
            self.auto_start_time = now
            self.auto_start_samples.append((now, x, y, yaw))
            self.auto_start_status = 'COLLECTING'
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            self.auto_start_samples.clear()
            self.auto_start_status = str(exc).replace(' ', '_')[:100]

    def auto_start_anchor(self, now):
        samples = list(self.auto_start_samples)
        if not self.sensors_ready(now) or not self.odom_is_still(now):
            self.auto_start_samples.clear()
            self.auto_start_status = 'WAIT_FOR_STATIONARY_SENSORS'
            return False
        if self.last_odom_xy is None or self.last_yaw is None or now-self.auto_start_time > .35:
            self.auto_start_samples.clear()
            self.auto_start_status = 'START_POSE_STALE'
            return False
        if len(samples) < 8 or samples[-1][0]-samples[0][0] < .70:
            self.auto_start_status = 'COLLECTING'
            return False
        for index, tolerance in [(1,.04),(2,.04),(3,math.radians(2))]:
            values = [v[index] for v in samples]
            if max(values)-min(values) > tolerance:
                self.auto_start_status = 'UNSTABLE_THREE_WALLS'
                return False
        self.layout_start_x = median(v[1] for v in samples)
        self.layout_start_y = median(v[2] for v in samples)
        self.layout_start_yaw_deg = math.degrees(median(v[3] for v in samples))
        self.layout_anchor = (*self.last_odom_xy, self.last_yaw, self.travel_distance)
        self.layout_update_pose()
        self.auto_start_status = 'LOCKED'
        self.layout_error = ''
        return True

    def layout_anchor_start(self):
        """Anchor measured laser centre while stationary, before approach motion."""
        now = time.monotonic()
        if self.layout_auto_start:
            return self.auto_start_anchor(now)
        if (self.last_odom_xy is None or self.last_yaw is None
                or not self.sensors_ready(now) or not self.odom_is_still(now)):
            self.layout_error = 'LAYOUT_START_NOT_STILL'
            return False
        if len(self.exit_spatial) != 21 or self.exit_spatial[0] != 2:
            self.layout_error = 'LAYOUT_START_DATA_MISSING'
            return False
        lh, rh, lf, rf = self.exit_current_wall
        ld, rd = self.exit_spatial[15:17]
        if (not lf or not rf or abs(ld+rd-self.layout_lane) > 0.10
                or abs(rd-self.layout_start_y) > 0.10
                or abs(ld-(self.layout_lane-self.layout_start_y)) > 0.10
                or max(abs(lh), abs(rh)) > math.radians(7)):
            self.layout_error = 'LAYOUT_START_GEOMETRY_MISMATCH'
            return False
        self.layout_anchor = (*self.last_odom_xy, self.last_yaw, self.travel_distance)
        self.layout_error = ''
        self.layout_update_pose()
        return True

    def layout_update_pose(self):
        if self.layout_anchor is None or self.last_odom_xy is None or self.last_yaw is None:
            return
        ax, ay, ayaw, distance0 = self.layout_anchor
        initial = math.radians(self.layout_start_yaw_deg)
        angle = initial-ayaw
        dx, dy = self.last_odom_xy[0]-ax, self.last_odom_xy[1]-ay
        scale = self.layout_odom_sign*self.layout_odom_scale
        x = self.layout_start_x + scale*(math.cos(angle)*dx-math.sin(angle)*dy)
        y = self.layout_start_y + scale*(math.sin(angle)*dx+math.cos(angle)*dy)
        yaw = normalize_angle(initial+self.last_yaw-ayaw)
        self.layout_pose = (x, y, yaw)
        # Engineering margin, NOT a statistically calibrated localisation bound.
        self.layout_uncertainty = 0.15 + 0.03*max(0., self.travel_distance-distance0)*self.layout_odom_scale

    def layout_window(self):
        # Rear must pass the partition with margin; stop short of expected right cone.
        return (self.layout_partition+self.layout_rear_extent+self.layout_margin+self.layout_uncertainty,
                self.layout_cones[0][0]-self.entry_cone_offset-self.layout_margin-self.layout_uncertainty)

    def layout_entry_candidate(self, candidate):
        if self.layout_pose is None or self.layout_uncertainty > 0.40:
            return False
        x, y, yaw = self.layout_pose
        cx, cy = candidate[:2]
        gx = x+math.cos(yaw)*cx-math.sin(yaw)*cy
        gy = y+math.sin(yaw)*cx+math.cos(yaw)*cy
        # Real cluster centroid need not coincide with the measured cone base centre.
        return math.hypot(gx-self.layout_cones[0][0], gy-self.layout_cones[0][1]) <= 0.35+self.layout_uncertainty

    def layout_gate_status(self, now):
        if not self.layout_enabled:
            return 'OFF'
        if self.layout_pose is None:
            return 'NO_POSE'
        x, y, yaw = self.layout_pose
        lo, hi = self.layout_window()
        if x < lo:
            return 'BEFORE_ENTRY_REGION'
        if x > hi:
            return 'PAST_ENTRY_REGION'
        if self.crosswalk_clear_count < self.post_crosswalk_clear_frames:
            return 'PAPER_NOT_CLEAR'
        if abs(yaw) > math.radians(10):
            return 'HEADING_NOT_ALIGNED'
        # Include yaw projection of the rear corner, not just the laser point.
        rear = self.layout_rear_extent*math.cos(yaw)+self.layout_half_width*abs(math.sin(yaw))
        if x-rear-self.layout_uncertainty < self.layout_partition+self.layout_margin:
            return 'REAR_NOT_PAST_PARTITION'
        if self.entry_body_count < self.entry_open_confirm_frames:
            return 'BODY_CLEAR_UNCONFIRMED'
        if self.lidar_left_clearance < self.entry_left_clearance:
            return 'LEFT_BLOCKED'
        if (self.entry_cone is None or self.entry_cone_hits < 3 or now-self.entry_cone_time > .35
                or not self.layout_entry_candidate(self.entry_cone)):
            return 'EXPECTED_CONE_UNCONFIRMED'
        if math.hypot(*self.entry_cone[:2]) <= self.entry_cone_stop_distance:
            return 'CONE_TOO_CLOSE'
        if not self.sensors_ready(now) or self.lidar_emergency:
            return 'SENSOR_OR_OBSTACLE'
        return 'READY'

    def layout_entry_ready(self, now):
        return self.layout_gate_status(now) == 'READY'

    def layout_stop_reason(self, now):
        if (not self.layout_enabled or self.phase in (self.STARTUP, self.ROUTE_FAULT, self.FINISHED)
                or self.entry_done):
            return ''
        if self.layout_pose is None:
            return 'LAYOUT_POSE_MISSING'
        if now-self.last_odom_time > self.sensor_timeout:
            return 'LAYOUT_ODOM_STALE'
        if self.layout_uncertainty > .40:
            return 'LAYOUT_POSITION_UNCERTAIN'
        x, y, yaw = self.layout_pose
        if not all(math.isfinite(v) for v in (x, y, yaw)):
            return 'LAYOUT_POSE_INVALID'
        if x < self.layout_start_x-.10:
            return 'LAYOUT_ODOM_DIRECTION_MISMATCH'
        if not (0 < x < self.layout_length and 0 < y < self.layout_width):
            return 'LAYOUT_OUTSIDE_TRACK'
        if self.phase != self.ENTER_OBSTACLES:
            if abs(y-.45) > .25 or abs(yaw) > math.radians(20):
                return 'LAYOUT_CORRIDOR_DEVIATION'
            if x > self.layout_window()[1]:
                return 'LAYOUT_ENTRY_REGION_MISSED'
        return ''

    def set_phase(self, phase):
        if phase == self.phase:
            return
        if phase == self.APPROACH_CROSSWALK and self.layout_enabled:
            if not self.layout_anchor_start():
                if self.layout_auto_start:
                    self.publish_stop()
                else:
                    self.fail_route(self.layout_error)
                return
        old_phase = self.phase
        self.reset_center_pid()
        if self.relative_route:
            self.rel_wait_since = None
            self.rel_ready_since = None
            self.rel_yaw = 0.0
            if phase == self.SEEK_CONE_1 and old_phase == self.CROSSWALK_STOP:
                self.rel_start_yaw = self.last_yaw
            if phase == 'REL_UPPER_APPROACH':
                self.rel_corridor_hits = 0
                self.rel_boundary_seen = 0.0
        self.phase = phase
        self.phase_started_at = time.monotonic()
        if phase == self.CROSSWALK_STOP:
            # Keep observed lane geometry across the stop. Never reanchor
            # the desired centre or parallel direction to the stopped car.
            self.corridor_heading_term=self.corridor_request=0.
            self.exit_width_samples.clear()
            self.straight_samples.clear()
            self.exit_reference_half_width = None
        if phase == self.CROSSWALK_EXIT_WAIT:
            # The distance cap can interrupt a pulse before its command timer runs.
            self.exit_pulse_mode = 'WAIT'
            self.exit_pulse_since = self.phase_started_at
            self.crosswalk_clear_count = 0
        self.red_count = 0
        self.green_count = 0
        self.crosswalk_count = 0
        self.cone_confirm_count = 0
        self.raw_cone = None
        if phase in (self.ORBIT_CONE_1, self.ORBIT_CONE_2):
            self.orbit_yaw = 0.0
        if phase == self.ENTER_OBSTACLES:
            self.entry_yaw = 0.0
            self.entry_start_distance = self.travel_distance
        if phase == self.SEEK_CONE_1 and old_phase == self.CROSSWALK_STOP:
            # Freeze the corridor width before either wall can disappear.
            widths = list(self.exit_width_samples)
            if len(widths) >= 5 and max(widths) - min(widths) <= 0.06:
                self.exit_reference_half_width = median(widths) * 0.5
            self.exit_pulse_mode = 'WAIT'
            self.exit_pulse_since = time.monotonic()
            self.exit_pulse_count = 0
            self.exit_heading = self.last_yaw
            self.exit_origin_xy = self.last_odom_xy
            self.first_cone_seek_start_distance = self.travel_distance
            self.crosswalk_clear_count = 0
            if self.relative_route:
                self.begin_relative_straight()
        if phase == self.APPROACH_CROSSWALK:
            self.approach_start_distance = self.travel_distance
            self.crosswalk_start_pose = None
            self.crosswalk_start_source = None
            self.crosswalk_stop_armed(self.phase_started_at, initialize=True)
            if self.initial_heading_count > 0:
                self.initial_heading_bias = (
                    self.initial_heading_sum / self.initial_heading_count
                )
            self.get_logger().warn(
                '发车航向校零: %.1fdeg，前%.2fm直行、%.2fm内渐入转向'
                % (
                    math.degrees(self.initial_heading_bias),
                    self.start_straight_distance,
                    self.start_steering_ramp_distance,
                )
            )
        if phase == self.FINISH_APPROACH:
            self.finish_start_distance = self.travel_distance
        if phase == self.SEEK_LIGHT and self.curve_route:
            self.final_straight_anchor(self.phase_started_at)
        msg = String()
        msg.data = phase
        self.phase_pub.publish(msg)
        self.get_logger().warn(f'任务阶段: {old_phase} -> {phase}')

    def traffic_light_fresh(self, now):
        # Int16MultiArray has no capture stamp. This checks receipt age only.
        return 0. <= now-self.last_vision_time <= self.traffic_light_max_gap

    def vision_callback(self, msg):
        if len(msg.data) < 4:
            self.last_vision_time = 0.0
            self.red_count = self.green_count = 0
            self.traffic_light_status = dict(state='INVALID_VISION', receipt_fresh=False,
                red_hits=0, green_hits=0, red_required=self.red_confirm_frames,
                green_required=self.green_confirm_frames, timestamp_policy='CALLBACK_RECEIPT')
            return
        now = time.monotonic()
        gap = now-self.last_vision_time
        continuous = 0. < gap <= self.traffic_light_max_gap
        if not continuous:
            self.red_count = self.green_count = 0
        data = list(msg.data) + [0, 0, 0, 0]
        self.red = bool(data[0])
        self.green = bool(data[1])
        self.crosswalk = bool(data[2])
        self.crosswalk_present = bool(msg.data[4]) if len(msg.data) >= 5 else self.crosswalk
        self.last_vision_time = now

        if self.phase == self.APPROACH_CROSSWALK:
            armed = self.crosswalk_stop_armed(self.last_vision_time)
            self.crosswalk_count = self.crosswalk_count + 1 if self.crosswalk and armed else 0
            if self.crosswalk_count >= self.crosswalk_confirm_frames:
                self.begin_crosswalk_stop()
        else:
            self.crosswalk_count = 0

        if self.phase in (self.SEEK_CONE_1, self.CROSSWALK_EXIT_WAIT):
            self.crosswalk_clear_count = (
                0 if self.crosswalk_present else self.crosswalk_clear_count + 1
            )
        else:
            self.crosswalk_clear_count = 0

        if self.phase == self.SEEK_LIGHT:
            self.red_count = self.red_count + 1 if self.red else 0
            self.green_count = 0
            light_state = 'RED_CONFIRMING' if self.red else 'WAIT_RED'
            red_hits = self.red_count
            if self.red_count >= self.red_confirm_frames:
                # Confirm and brake in this callback. A following missed frame
                # must not erase the event before the control timer observes it.
                self.set_phase(self.RED_WAIT)
                self.publish_stop()
                light_state = 'RED_CONFIRMED_STOP'
        elif self.phase == self.RED_WAIT:
            self.red_count = 0
            # Treat simultaneous red/green evidence as red, including while
            # confirming release. Sparse callbacks cannot accumulate green.
            self.green_count = self.green_count + 1 if self.green and not self.red else 0
            light_state = ('RED_PRIORITY' if self.red else
                ('GREEN_CONFIRMING' if self.green else 'WAIT_GREEN'))
            red_hits = 0
        else:
            self.red_count = 0
            self.green_count = 0
            light_state = 'INACTIVE'
            red_hits = 0
        self.traffic_light_status = dict(state=light_state, phase=self.phase,
            red=self.red, green=self.green, red_hits=red_hits, green_hits=self.green_count,
            red_required=self.red_confirm_frames, green_required=self.green_confirm_frames,
            receipt_time=now, receipt_gap_s=gap, continuous=continuous, receipt_fresh=True,
            max_gap_s=self.traffic_light_max_gap, timestamp_policy='CALLBACK_RECEIPT')

    def lidar_callback(self, msg):
        if len(msg.data) < 8 or not all(math.isfinite(float(v)) for v in msg.data):
            self.entry_open_count = 0
            self.entry_body_count = 0
            self.last_lidar_time = 0.0
            return
        if time.monotonic() - self.last_lidar_time > self.sensor_timeout:
            self.entry_open_count = 0
            self.entry_body_count = 0
        data = list(msg.data) + [0.0] * 8
        detected = bool(data[0])
        candidate = (float(data[1]), float(data[2]), float(data[3]))
        self.front_clearance = float(data[4])
        self.lidar_caution = bool(data[5])
        self.lidar_emergency = bool(data[6])
        self.preferred_side = int(round(float(data[7])))
        self.last_lidar_time = time.monotonic()
        self.lidar_left_clearance = float(data[8]) if len(msg.data) >= 10 else -1.0
        self.lidar_right_clearance = float(data[9]) if len(msg.data) >= 10 else -1.0
        if self.phase in (self.SEEK_CONE_1, self.CROSSWALK_EXIT_WAIT) and not self.entry_done:
            is_open = len(msg.data) >= 11 and msg.data[10] == 1.0
            self.entry_open_count = min(self.entry_open_count + 1, self.entry_open_confirm_frames) if is_open else 0
            body_clear = len(msg.data) >= 12 and msg.data[11] == 1.0
            self.entry_body_count = min(self.entry_body_count + 1, self.entry_open_confirm_frames) if body_clear else 0
        else:
            self.entry_open_count = 0
            self.entry_body_count = 0
        # New guard publishes all candidates; legacy fallback is only for old guards.
        if time.monotonic() - self.last_candidates_time > self.sensor_timeout:
            self.accept_cone(detected, candidate)

    def cones_callback(self, msg):
        data = list(msg.data)
        if len(data) % 5 or not all(math.isfinite(float(v)) for v in data):
            self.entry_cone_hits = 0
            self.entry_cone_time = 0.0
            return
        self.last_candidates_time = time.monotonic()
        self.update_entry_cone([tuple(data[i:i+3]) for i in range(0, len(data), 5)])
        number = 1 if self.phase in (self.SEEK_CONE_1, self.ORBIT_CONE_1) else 2
        side = self.cone_orbit_directions[number - 1]
        candidates = [tuple(data[i:i+3]) for i in range(0, len(data), 5)]
        candidates = [c for c in candidates if 0.15 < c[0] <= self.cone_trigger_distance
                      and self.cone_min_lateral <= c[1] * side <= self.cone_max_lateral]
        if self.raw_cone is not None:
            candidates.sort(key=lambda c: math.hypot(c[0]-self.raw_cone[0], c[1]-self.raw_cone[1]))
        else:
            candidates.sort(key=lambda c: c[2])
        self.accept_cone(bool(candidates), candidates[0] if candidates else (-1., -1., -1.))

    def update_entry_cone(self, candidates):
        """Track an entry candidate separately from the later orbit state.

        These are geometry candidates, not color-confirmed cone identities.
        A lost lock during entry must not silently switch to another object.
        """
        active = (self.phase in (self.SEEK_CONE_1, self.CROSSWALK_EXIT_WAIT,
                                self.ENTER_OBSTACLES) and not self.entry_done)
        if not active:
            self.entry_cone = None
            self.entry_cone_hits = 0
            self.entry_cone_time = 0.0
            return
        now = time.monotonic()
        if self.layout_enabled:
            candidates = [c for c in candidates if self.layout_entry_candidate(c)]
        if now - self.entry_cone_time > 0.35:
            self.entry_cone_hits = 0
        candidates = [c for c in candidates if 0.05 < c[0] <= 2.5 and 0.15 < c[1] <= 2.5]
        if self.entry_cone is not None:
            candidates = sorted(candidates, key=lambda c: math.hypot(
                c[0] - self.entry_cone[0], c[1] - self.entry_cone[1]))
            if candidates and math.hypot(candidates[0][0] - self.entry_cone[0],
                                         candidates[0][1] - self.entry_cone[1]) > 0.35:
                if self.phase == self.ENTER_OBSTACLES:
                    candidates = []
                else:
                    self.entry_cone_hits = 0
        else:
            candidates = sorted(candidates, key=lambda c: c[2])
        if not candidates:
            self.entry_cone_hits = 0
            self.entry_cone_time = 0.0
            return
        self.entry_cone = candidates[0]
        self.entry_cone_hits = min(3, self.entry_cone_hits + 1)
        self.entry_cone_time = now

    def entry_tangent_limit(self):
        """Steer no farther left than a tangent to the candidate clearance circle.

        The offset is measured from the laser cluster centroid, not the body or
        cone base. The command remains legacy PWM-scaled, not angular velocity.
        """
        x, y, _ = self.entry_cone
        distance = math.hypot(x, y)
        tangent = math.atan2(y, x) - math.asin(min(1.0, self.entry_cone_offset / distance))
        return clamp(0.8 * tangent, 0.0, self.entry_angular)

    def accept_cone(self, detected, candidate):

        seek_phase = self.phase in (self.SEEK_CONE_1, self.SEEK_CONE_2)
        orbit_phase = self.phase in (self.ORBIT_CONE_1, self.ORBIT_CONE_2)
        cone_number = 1 if self.phase in (self.SEEK_CONE_1, self.ORBIT_CONE_1) else 2
        expected_side = self.cone_orbit_directions[cone_number - 1]
        first_cone_travel = self.departure_distance()
        first_cone_ready = (
            self.phase != self.SEEK_CONE_1
            or (
                self.entry_done and first_cone_travel >= self.post_crosswalk_min_travel
                and self.post_crosswalk_clearance_complete()
            )
        )
        valid_candidate = (
            detected
            and first_cone_ready
            and 0.15 < candidate[0] <= self.cone_trigger_distance
            and self.cone_min_lateral
            <= candidate[1] * expected_side
            <= self.cone_max_lateral
        )
        if self.phase == self.SEEK_CONE_1 and detected and not first_cone_ready:
            self.get_logger().info(
                '离开斑马线 %.2f/%.2fm，暂不接受锥桶候选'
                % (first_cone_travel, self.post_crosswalk_min_travel),
                throttle_duration_sec=1.0,
            )
        if seek_phase and valid_candidate:
            if self.raw_cone is None:
                self.cone_confirm_count = 1
            else:
                movement = math.hypot(
                    candidate[0] - self.raw_cone[0],
                    candidate[1] - self.raw_cone[1],
                )
                self.cone_confirm_count = (
                    self.cone_confirm_count + 1 if movement < 0.30 else 1
                )
            self.raw_cone = candidate
            self.cone_detected = True
            self.cone_x, self.cone_y, self.cone_distance = candidate
        elif orbit_phase and valid_candidate:
            # 绕桶期间继续使用距离反馈修正圆弧半径，但不再累计确认帧。
            self.cone_detected = True
            self.cone_x, self.cone_y, self.cone_distance = candidate
        else:
            self.raw_cone = None
            self.cone_confirm_count = 0
            self.cone_detected = False

    def boundary_callback(self, msg):
        if len(msg.data) < 9 or not all(math.isfinite(float(v)) for v in msg.data):
            self.exit_width_samples.clear()
            self.straight_samples.clear()
            self.last_boundary_time = 0.0
            return
        if time.monotonic() - self.last_boundary_time > self.sensor_timeout:
            self.exit_width_samples.clear()
            self.straight_samples.clear()
        data = list(msg.data) + [0.0] * 9
        self.left_distance = float(data[0])
        self.right_distance = float(data[1])
        self.boundary_front = float(data[2])
        self.center_error = float(data[3])
        self.heading_error = float(data[4])
        self.left_valid = bool(data[5])
        self.right_valid = bool(data[6])
        self.left_proximity = float(data[7])
        self.right_proximity = float(data[8])
        self.exit_side_detail = (list(msg.data[9:15]) if len(msg.data) >= 15
                                 else [-1.0, 0.0, -1.0, -1.0, 0.0, -1.0])
        # Appended fields describe THIS scan, not the retained/filtered wall.
        self.exit_current_wall = (list(msg.data[15:19]) if len(msg.data) >= 19
                                  else [0.0, 0.0, False, False])
        self.exit_spatial = list(msg.data[19:40]) if len(msg.data) >= 40 else []
        if self.phase == self.CROSSWALK_STOP:
            lh, rh, lf, rf = self.exit_current_wall
            width = self.left_distance + self.right_distance
            if (self.left_valid and self.right_valid and lf and rf
                    and time.monotonic() - self.last_odom_time <= self.sensor_timeout
                    and self.odom_is_still(time.monotonic())
                    and 0.80 <= width <= 2.40
                    and max(abs(lh), abs(rh)) <= self.exit_single_heading_limit
                    and abs(lh - rh) <= math.radians(10.0)):
                self.exit_width_samples.append(width)
                if self.relative_route and self.last_yaw is not None:
                    self.straight_samples.append(normalize_angle(self.last_yaw+(lh+rh)*.5))
            else:
                self.exit_width_samples.clear()
                self.straight_samples.clear()
        if self.phase == self.STARTUP and self.left_valid and self.right_valid:
            self.initial_heading_sum += self.heading_error
            self.initial_heading_count += 1
        self.last_boundary_time = time.monotonic()

    def odom_callback(self, msg):
        now = time.monotonic()
        x = float(msg.pose.pose.position.x)
        y = float(msg.pose.pose.position.y)
        q = msg.pose.pose.orientation
        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z),
        )
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        source_stamp=msg.header.stamp.sec*1000000000+msg.header.stamp.nanosec
        if not all(math.isfinite(v) for v in (x, y, yaw, q.x, q.y, q.z, q.w)):
            self.invalidate_entry_plan('INVALID_ODOMETRY')
            self.last_odom_time = 0.0
            return
        previous_stamp = getattr(self, 'last_motion_stamp', None)
        if stamp <= 0 or (previous_stamp is not None and stamp <= previous_stamp):
            self.invalidate_entry_plan('INVALID_ODOMETRY')
            self.last_odom_time = 0.0
            return
        self.last_motion_stamp = stamp
        # Receipt freshness and source alignment are distinct. Keep the real
        # source stamp so callback backlog is visible in the next CSV log.
        self.curve_odom_source_stamp=source_stamp
        self.curve_odom_source_gap=((self.curve_scan_stamp-source_stamp)*1e-9
                                   if self.curve_scan_stamp>0 else None)
        curve_motion=self.curve_route and self.relative_active()
        source_dt=stamp-previous_stamp if previous_stamp is not None else 0.
        position_bound=max(.40,3.0*min(source_dt,1.0)+.10) if curve_motion else .40
        yaw_bound=max(.35,5.0*min(source_dt,1.0)+.10) if curve_motion else .35
        if self.last_odom_xy is not None:
            if math.hypot(x-self.last_odom_xy[0], y-self.last_odom_xy[1]) >= position_bound:
                self.fail_route('ODOM_POSITION_JUMP')
                self.invalidate_entry_plan('INVALID_ODOMETRY')
                self.last_odom_time = 0.0
                return
        if self.last_yaw is not None and abs(normalize_angle(yaw-self.last_yaw)) > yaw_bound:
            self.fail_route('ODOM_HEADING_JUMP')
            self.invalidate_entry_plan('INVALID_ODOMETRY')
            self.last_odom_time = 0.0
            return
        if not self.curve_route and self.phase == self.ENTER_OBSTACLES and self.last_yaw is not None:
            dyaw = normalize_angle(yaw - self.last_yaw)
            if now - self.last_odom_time > self.sensor_timeout or abs(dyaw) > 0.35:
                self.fail_route('ENTRY_ODOM_DISCONTINUITY')
            else:
                self.entry_yaw += dyaw
        if self.relative_route and self.last_yaw is not None and self.relative_active():
            self.rel_yaw += normalize_angle(yaw-self.last_yaw)
        self.entry_plan_observe_odom(now, stamp, x, y, yaw)
        # RF2O poses stay in the same absolute frame across callback gaps.
        # Retain measured anchors; interpolation still rejects unobserved gaps,
        # while current receipt freshness controls whether driving is allowed.
        # RF2O publishes base_footprint; verified launch TF puts laser_link
        # 0.07 m ahead. Transform the history into the geometry's laser frame.
        laser_pose=(x+.07*math.cos(yaw),y+.07*math.sin(yaw),yaw)
        self.curve_odom_samples.append((stamp,*laser_pose))
        self.curve_update_motion(source_stamp,laser_pose,now,msg)
        self.record_still_sample(now, stamp, x, y, yaw)
        if self.relative_route:
            self.update_straight_yaw_rate(now,yaw)
        if self.last_odom_xy is not None:
            step = math.hypot(x - self.last_odom_xy[0], y - self.last_odom_xy[1])
            if step < position_bound:
                self.travel_distance += step
        if self.last_yaw is not None and self.phase in (
            self.ORBIT_CONE_1,
            self.ORBIT_CONE_2,
        ):
            self.orbit_yaw += normalize_angle(yaw - self.last_yaw)
        self.last_odom_xy = (x, y)
        self.last_yaw = yaw
        self.last_odom_time = now
        if self.curve_observation_active() and (getattr(self,'curve_registration_pending',None) is not None
                or self.curve_registration_scans):
            # Retry immediately after the matching source arrives; an expensive
            # plan/control tick must not consume the pending scan's age budget.
            self.curve_poll_registration(now)
        if self.layout_enabled:
            self.layout_update_pose()

    def record_still_sample(self, now, stamp, x, y, yaw):
        samples = self.odom_still_samples
        valid = all(math.isfinite(v) for v in (now, stamp, x, y, yaw))
        if not valid or stamp <= 0 or (self.last_still_stamp is not None and stamp <= self.last_still_stamp):
            samples.clear()
            self.still_since = None
            self.last_still_stamp = None
            if getattr(self, 'phase', None) == self.CROSSWALK_STOP:
                self.crosswalk_reset_hold('INVALID_STILL_SAMPLE', clear_window=True)
            return
        if getattr(self, 'phase', None) == self.CROSSWALK_STOP:
            self.crosswalk_record_sample(now, stamp, x, y, yaw)
        if samples and (now - samples[-1][0] > self.odom_max_gap
                        or stamp - self.last_still_stamp > self.odom_max_gap):
            samples.clear()
            self.still_since = None
        self.last_still_stamp = stamp
        samples.append((now, x, y, yaw))
        # Retain one sample just before the window boundary.
        while len(samples) > 2 and samples[1][0] <= now - self.still_window:
            samples.popleft()

    def odom_is_still(self, now):
        samples = self.odom_still_samples
        if len(samples) < 3 or now - samples[-1][0] > self.odom_max_gap:
            return False
        if samples[-1][0] - samples[0][0] < self.still_window:
            return False
        # All pairs, rather than first/last alone: out-and-back motion is not still.
        return all(
            math.hypot(a[1] - b[1], a[2] - b[2]) <= self.still_distance
            and abs(normalize_angle(a[3] - b[3])) <= self.still_yaw
            for a in samples for b in samples
        )

    def crosswalk_reset_hold(self, reason, clear_window=False):
        self.crosswalk_hold_started = None
        self.crosswalk_hold_source = None
        self.crosswalk_hold_anchor = None
        self.crosswalk_hold_reason = reason
        self.crosswalk_hold_reset_reason = reason
        if clear_window:
            samples = getattr(self, 'crosswalk_source_samples', None)
            if samples is not None:
                samples.clear()

    def crosswalk_record_sample(self, now, stamp, x, y, yaw):
        """Observe real motion independently of the short receipt window."""
        if not hasattr(self, 'crosswalk_source_samples'):
            self.crosswalk_source_samples = deque(maxlen=200)
        previous = getattr(self, 'crosswalk_hold_last_sample', None)
        if previous is not None:
            if now < previous[0] or stamp <= previous[1]:
                self.crosswalk_reset_hold('STILL_CLOCK_REVERSED', clear_window=True)
            elif now - previous[0] > 1.0 or stamp - previous[1] > 1.0:
                self.crosswalk_reset_hold('LONG_ODOM_GAP', clear_window=True)
        anchor = getattr(self, 'crosswalk_hold_anchor', None)
        reference_points=([anchor]+[sample[2:5] for sample in self.crosswalk_source_samples]
                          if anchor is not None else [])
        if any(math.hypot(x-point[0], y-point[1]) > self.still_distance
                or abs(normalize_angle(yaw-point[2])) > self.still_yaw
                for point in reference_points):
            # Check every accepted source sample: a move away and back must
            # not disappear when the rolling stillness window advances. Two
            # opposite points can both be close to the anchor yet move too far.
            self.crosswalk_reset_hold('ACTUAL_MOTION', clear_window=True)
        self.crosswalk_hold_last_sample = (now, stamp, x, y, yaw)
        samples = self.crosswalk_source_samples
        samples.append((now, stamp, x, y, yaw))
        while len(samples) > 2 and samples[1][0] <= now-self.still_window:
            samples.popleft()

    def crosswalk_hold_ready(self, now):
        """Keep a confirmed stop across bounded gaps; release on real data."""
        current = time.monotonic()
        ros_now = self.curve_source_now()
        if not math.isfinite(now) or not math.isfinite(current) or ros_now is None:
            self.crosswalk_reset_hold('WAIT_STILL_CLOCK', clear_window=True)
            return False
        # Other work in this callback can make its original ``now`` old.
        now = max(now, current)
        source_now = ros_now*1e-9
        clock = getattr(self, 'crosswalk_hold_clock', None)
        self.crosswalk_hold_clock = (current, source_now)
        if clock is not None and (current < clock[0]
                or abs((source_now-clock[1])-(current-clock[0])) > .15):
            self.crosswalk_reset_hold('STILL_CLOCK_CHANGED', clear_window=True)
            return False
        latest = getattr(self, 'crosswalk_hold_last_sample', None)
        if latest is None:
            self.crosswalk_hold_reason = 'WAIT_REAL_ODOM'
            return False
        source_age = source_now-latest[1]
        if now-latest[0] > 1.0 or source_age > 1.0:
            self.crosswalk_reset_hold('LONG_ODOM_GAP', clear_window=True)
            return False
        if now < latest[0] or source_age < -.02:
            self.crosswalk_reset_hold('STILL_CLOCK_FUTURE', clear_window=True)
            return False
        if not self.sensors_ready(now) or not self.odom_is_still(now):
            self.crosswalk_hold_reason = 'WAIT_FRESH_STILL_WINDOW'
            return False
        samples = getattr(self, 'crosswalk_source_samples', ())
        brake_source = getattr(self, 'crosswalk_brake_source', None)
        if (len(samples) < 3 or brake_source is None
                or samples[0][1] < brake_source
                or samples[-1][1]-samples[0][1] < self.still_window):
            self.crosswalk_hold_reason = 'WAIT_POST_BRAKE_SOURCE_WINDOW'
            return False
        if getattr(self, 'crosswalk_hold_started', None) is None:
            self.crosswalk_hold_started = now
            self.crosswalk_hold_source = latest[1]
            self.crosswalk_hold_anchor = latest[2:5]
            self.get_logger().warn('CROSSWALK_HOLD: standstill confirmed; hold %.1fs' % self.crosswalk_stop_duration)
        self.crosswalk_hold_reason = 'CONFIRMED_HOLD'
        # Both clocks must cover the hold: queued/duplicate old source poses
        # cannot turn a fresh callback receipt into elapsed physical time.
        return (now-self.crosswalk_hold_started >= self.crosswalk_stop_duration
                and latest[1]-self.crosswalk_hold_source >= self.crosswalk_stop_duration)

    def begin_crosswalk_stop(self):
        self.still_since = None
        self.odom_still_samples.clear()
        self.crosswalk_reset_hold('WAIT_REAL_STOP', clear_window=True)
        self.crosswalk_hold_last_sample = None
        self.crosswalk_hold_clock = None
        source_now = self.curve_source_now()
        self.crosswalk_brake_source = source_now*1e-9 if source_now is not None else None
        self.set_phase(self.CROSSWALK_STOP)
        self.publish_stop()
        self.get_logger().warn('CROSSWALK_BRAKE: zero command; waiting for fresh stationary odometry')

    def crosswalk_stop_armed(self, now, initialize=False):
        """Require net forward travel beyond the start zone in full-route mode.

        Origin and progress use accepted real source odometry, never predicted
        poses or accumulated jitter. A current visual callback is still needed;
        this method does not remember a trigger observed inside the start zone.
        """
        if not self.curve_route:
            return True
        before = time.monotonic()
        source_now = self.curve_source_now()
        current = max(now, .5 * (before + time.monotonic()))
        status = dict(active=self.phase == self.APPROACH_CROSSWALK,
            updated=current, threshold_m=self.crosswalk_arm_travel,
            armed=False, progress_m=None, reason='WAIT_SOURCE_ODOM',
            origin=self.crosswalk_start_pose, origin_source=self.crosswalk_start_source)
        self.crosswalk_arm_status = status
        samples = self.curve_motion_samples
        if not samples or source_now is None:
            return False
        sample = samples[-1]
        stamp = sample[0]
        source_age = (source_now - stamp) * 1e-9
        receipt_age = current - self.last_odom_time
        status.update(source_stamp=stamp, source_age_s=source_age, receipt_age_s=receipt_age)
        clock = self.curve_motion_clock_sample
        if (clock is None or clock[1] is None
                or abs((source_now-clock[1])*1e-9-(current-clock[0])) > .15):
            status['reason'] = 'SOURCE_CLOCK_CHANGED'
            return False
        if (not 0. <= source_age <= .50
                or not 0. <= receipt_age <= self.curve_odom_max_age):
            status['reason'] = 'STALE_SOURCE_ODOM'
            return False
        motion = self.curve_motion_status
        if (motion.get('odom_source_stamp') != stamp
                or motion.get('velocity_policy') not in ('SOURCE_SE2', 'WAIT_SOURCE_PAIR')
                or not all(math.isfinite(v) for v in sample)):
            status['reason'] = 'REJECTED_SOURCE_ODOM'
            return False
        # Stored samples use the laser frame, 0.07 m ahead of base_footprint.
        # Remove that offset so rotation alone cannot count as forward travel.
        heading = sample[3]
        pose = (sample[1]-.07*math.cos(heading),
                sample[2]-.07*math.sin(heading), heading)
        if self.crosswalk_start_pose is None:
            if not initialize:
                status['reason'] = 'WAIT_APPROACH_ORIGIN'
                return False
            self.crosswalk_start_pose = pose
            self.crosswalk_start_source = stamp
            status.update(origin=pose, origin_source=stamp)
        if stamp < self.crosswalk_start_source:
            status['reason'] = 'SOURCE_BEFORE_ORIGIN'
            return False
        origin = self.crosswalk_start_pose
        progress = ((pose[0]-origin[0])*math.cos(origin[2])
                    + (pose[1]-origin[1])*math.sin(origin[2]))
        armed = progress >= self.crosswalk_arm_travel
        status.update(progress_m=progress, armed=armed,
            reason='ARMED' if armed else 'INSIDE_START_ZONE')
        return armed

    def sensors_ready(self, now):
        if self.curve_route and self.relative_active():
            return (0<=now-self.last_lidar_time<=self.sensor_timeout
                    and 0<=now-self.last_odom_time<=self.curve_odom_max_age)
        return (
            now - self.last_vision_time <= self.sensor_timeout
            and now - self.last_lidar_time <= self.sensor_timeout
            and now - self.last_boundary_time <= self.sensor_timeout
            and now - self.last_odom_time <= self.sensor_timeout
        )

    def curve_pause_command(self, now):
        """Zero propulsion for a brief data wait without straightening a coast.

        Retain only a recently ISSUED steering command, for at most 350 ms.
        Actual collision evidence, a route fault, and long waits always use
        the ordinary neutral command. This is not an assertion of standstill.
        """
        stopped_presteer=self.curve_recovery_hold_command(now)
        if stopped_presteer is not None:return stopped_presteer
        f=self.curve_follower;cmd=Twist()
        last_drive=getattr(self,'curve_last_drive_time',-1e9)
        body_blocked=bool(self.curve_body_stop_reason(now))
        retain=(f is not None and self.relative_active() and not self.route_fault
                and not self.lidar_emergency and not body_blocked
                and self.curve_sweep!='SWEPT_OBSTACLE' and 0<=now-last_drive<=.35)
        steering=clamp(self.last_lane_angular,-self.curve_max_steer,self.curve_max_steer) if retain else 0.
        cmd.angular.z=self.steering_sign*steering
        recovery=getattr(self,'curve_recovery_state',None)
        if not retain:self.curve_recovery_state=None
        elif recovery is not None:
            recovery['clear_hits']=0;recovery['clear_stamp']=self.curve_scan_stamp
        if f is not None:
            self.curve_issued_steering(steering,now)
            # Feedback restarts; the physical actuator still follows the last
            # issued target. Never rewind its response clock on a short pause.
            f.reset_feedback(preserve_output=True)
            self.curve_pause_active=True
        self.curve_drive=0.
        self.reset_center_pid()
        self.last_lane_angular=steering;self.last_lane_command_time=now
        self.lane_applied=steering
        self.curve_control_status=dict(getattr(self,'curve_control_status',{}),
            pause=True,held_steering=retain,issued_steering=cmd.angular.z,issued_drive=0.)
        return cmd

    def publish_stop(self):
        # Neutral interrupts the actual pre-steering/held-arc command. A later
        # attempt must obtain a new stopped window and start its own dwell.
        now=time.monotonic()
        self.curve_recovery_state=None
        if self.curve_follower is not None:
            # A neutral command does not make the physical servo jump to
            # centre. Retain and decay its response under actually sent input.
            self.curve_issued_steering(0.,now)
            self.curve_follower.reset_feedback(preserve_output=True)
            self.curve_pause_active=True
        self.reset_center_pid()
        self.cmd_pub.publish(Twist())
        if self.curve_follower is not None:
            self.curve_drive=0.
            self.curve_control_status=dict(getattr(self,'curve_control_status',{}),
                pause=True,held_steering=False,issued_steering=0.,issued_drive=0.)
        self.lane_applied = 0.0
        self.last_lane_angular = 0.0
        self.last_lane_command_time = now
        if (self.curve_route and self.phase in
                (self.SEEK_LIGHT,self.RED_WAIT,self.FINISH_APPROACH,self.FINISHED,self.ROUTE_FAULT)):
            self.final_straight_status=dict(getattr(self,'final_straight_status',{}),
                state=('RED_WAIT' if self.phase==self.RED_WAIT else 'CONTROL_STOP'),
                updated=now,issued_drive=0.,issued_steering=0.)

    def fail_route(self, reason):
        self.route_fault = reason
        self.set_phase(self.ROUTE_FAULT)
        self.publish_stop()
        self.get_logger().error('ROUTE_FAULT: ' + reason)

    def entry_command(self):
        """A left route entry cannot silently turn right because of a side vote."""
        self.route_hold_reason = ''
        if self.lidar_left_clearance < 0:
            self.route_hold_reason = 'ENTRY_LIDAR_FIELDS_MISSING'
        elif self.lidar_left_clearance < self.entry_left_clearance:
            self.route_hold_reason = 'ENTRY_LEFT_BLOCKED'
        elif 0 < self.left_proximity < self.side_guard_hard_distance:
            self.route_hold_reason = 'ENTRY_LEFT_BODY_CLEARANCE'
        if self.route_hold_reason:
            return Twist()
        now = time.monotonic()
        if self.entry_cone is None or self.entry_cone_hits < 3 or now - self.entry_cone_time > 0.35:
            self.route_hold_reason = 'ENTRY_CONE_UNCONFIRMED'
            return Twist()
        if math.hypot(*self.entry_cone[:2]) <= self.entry_cone_stop_distance:
            self.route_hold_reason = 'ENTRY_CONE_TOO_CLOSE'
            return Twist()
        remaining = max(0.0, self.entry_angle - self.entry_yaw)
        angular = clamp(remaining * 0.8, 0.08, min(self.entry_angular, self.maximum_angular))
        self.entry_cone_limit = self.entry_tangent_limit()
        angular = min(angular, self.entry_cone_limit)
        delta = self.lane_steering_slew_per_sec * clamp(now-self.last_lane_command_time, 0., .2)
        angular = clamp(angular, max(0., self.last_lane_angular-delta), max(0., self.last_lane_angular+delta))
        # Reducing steering away from a near cone must not wait for the slew ramp.
        angular = min(angular, self.entry_cone_limit)
        self.last_lane_angular = angular
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def post_crosswalk_clearance_complete(self):
        """Confirm departure; entry_command separately checks the left turn."""
        if self.entry_done:
            return True
        if self.layout_enabled:
            now = time.monotonic()
            return (self.layout_entry_ready(now) and self.exit_pulse_mode == 'WAIT'
                    and now-self.exit_pulse_since >= 1.5 and self.odom_is_still(now))
        travelled = self.departure_distance()
        return (
            travelled >= self.post_crosswalk_straight_distance
            and self.crosswalk_clear_count >= self.post_crosswalk_clear_frames
            and time.monotonic() - self.last_lidar_time <= self.sensor_timeout
            and self.exit_pulse_mode == 'WAIT'
            and time.monotonic() - self.exit_pulse_since >= 1.5
            and self.odom_is_still(time.monotonic())
            and (self.entry_open_count >= self.entry_open_confirm_frames
                 or self.entry_body_count >= self.entry_open_confirm_frames)
        )

    def departure_distance(self):
        """Net displacement along the departure heading, not accumulated jitter.

        Absolute projection tolerates a laser translation axis reversed relative
        to the physical car; this metric alone cannot certify forward motion.
        Fresh sensors, visible-paper clearance and side opening remain required.
        """
        if self.exit_origin_xy is None or self.last_odom_xy is None or self.exit_heading is None:
            return 0.0
        dx = self.last_odom_xy[0] - self.exit_origin_xy[0]
        dy = self.last_odom_xy[1] - self.exit_origin_xy[1]
        return abs(dx * math.cos(self.exit_heading) + dy * math.sin(self.exit_heading))

    def boundary_escape_state(self):
        """返回左右挡板危险状态，以及基于实际间隙的逃逸方向。"""
        now = time.monotonic()
        if now - self.last_boundary_time > self.sensor_timeout:
            self.boundary_escape_latch = 0
            self.boundary_escape_until = 0.0
            return False, False, 0, False

        if self.phase == self.APPROACH_CROSSWALK:
            left_limit = self.side_guard_hard_distance
            right_limit = self.side_guard_hard_distance
        else:
            left_limit = (
                self.side_guard_hard_distance
                if self.left_valid
                else self.side_guard_distance
            )
            right_limit = (
                self.side_guard_hard_distance
                if self.right_valid
                else self.side_guard_distance
            )
        fitted_wall_limit = (
            self.side_guard_hard_distance
            if self.phase == self.APPROACH_CROSSWALK
            else self.single_boundary_distance
        )
        left_hazard = (
            self.left_valid
            and 0.0 < self.left_distance < fitted_wall_limit
        ) or (0.0 < self.left_proximity < left_limit)
        right_hazard = (
            self.right_valid
            and 0.0 < self.right_distance < fitted_wall_limit
        ) or (0.0 < self.right_proximity < right_limit)

        left_values = [
            value
            for value in (self.left_distance, self.left_proximity)
            if value > 0.0
        ]
        right_values = [
            value
            for value in (self.right_distance, self.right_proximity)
            if value > 0.0
        ]
        left_clearance = min(left_values) if left_values else float('inf')
        right_clearance = min(right_values) if right_values else float('inf')

        candidate_side = 0
        if left_hazard and right_hazard:
            if right_clearance + 0.03 < left_clearance:
                candidate_side = 1
            elif left_clearance + 0.03 < right_clearance:
                candidate_side = -1
        elif right_hazard:
            candidate_side = 1
        elif left_hazard:
            candidate_side = -1

        if candidate_side != 0:
            should_switch = (
                self.boundary_escape_latch == 0
                or candidate_side == self.boundary_escape_latch
                or now >= self.boundary_escape_until
            )
            if (
                not should_switch
                and candidate_side != self.boundary_escape_latch
            ):
                new_obstacle_clearance = (
                    right_clearance if candidate_side > 0 else left_clearance
                )
                old_obstacle_clearance = (
                    right_clearance
                    if self.boundary_escape_latch > 0
                    else left_clearance
                )
                should_switch = (
                    new_obstacle_clearance
                    + self.boundary_escape_switch_margin
                    < old_obstacle_clearance
                )
            if should_switch:
                self.boundary_escape_latch = candidate_side
                self.boundary_escape_until = now + self.boundary_escape_hold_time

        latch_active = (
            self.boundary_escape_latch != 0
            and now < self.boundary_escape_until
        )
        if not latch_active:
            self.boundary_escape_latch = 0
        return (
            left_hazard,
            right_hazard,
            self.boundary_escape_latch,
            latch_active,
        )

    def wall_direction_guard(self, boundary_fresh):
        """Return the mandatory turn direction when one fitted wall is too close."""
        if not boundary_fresh:
            return 0
        guard_distance = (
            self.side_guard_hard_distance
            if self.phase == self.APPROACH_CROSSWALK
            else self.wall_direction_guard_distance
        )
        left_close = (
            self.left_valid
            and 0.0 < self.left_distance < guard_distance
        )
        right_close = (
            self.right_valid
            and 0.0 < self.right_distance < guard_distance
        )
        if right_close and (
            not left_close
            or self.right_distance + self.wall_direction_guard_margin
            < self.left_distance
        ):
            return 1
        if left_close and (
            not right_close
            or self.left_distance + self.wall_direction_guard_margin
            < self.right_distance
        ):
            return -1
        return 0

    def final_straight_active(self):
        return self.curve_route and self.phase in (self.SEEK_LIGHT,self.FINISH_APPROACH)

    def final_straight_anchor(self, now):
        """Freeze the terminal path line, not the car's current imperfect yaw.

        Wall localization stops after the curve. Transform its measured anchor
        into odometry once; subsequent fresh odometry remains valid across a
        long red-light stop without renewing any old wall observation.
        """
        if self.final_straight_reference is not None:return True
        follower=self.curve_follower;loc=self.curve_locator
        if (follower is None or self.curve_pose_odom is None or loc.pose is None
                or loc.time is None or loc.hits<1 or not 0<=now-loc.time<=self.curve_pose_ttl):
            self.final_straight_status={'state':'WAIT_TERMINAL_LINE'};return False
        terminal=tuple(float(v) for v in follower.path.samples[-1,:3])
        if not all(math.isfinite(v) for p in (terminal,loc.pose,self.curve_pose_odom) for v in p):
            self.final_straight_status={'state':'INVALID_TERMINAL_LINE'};return False
        # bridge_pose composes destination_anchor * inverse(source_anchor) * pose.
        reference=bridge_pose(self.curve_pose_odom,loc.pose,terminal)
        self.final_straight_reference=tuple(reference)
        self.final_straight_status=dict(state='ANCHORED',anchored=now,
            track_reference=terminal,reference_source_stamp=self.curve_pose_stamp)
        self.curve_scan_wait=self.curve_pose_wait=False
        self.curve_pause_active=False;self.curve_prediction_pause=None
        return True

    def final_straight_command(self, now):
        """Continue the exit tangent with bounded heading and lateral feedback.

        Side distances may gently refine centring; they never choose a turn
        direction. A board ahead requests a stop, never an avoidance swerve.
        """
        def stop(reason):
            self.last_lane_angular=self.lane_applied=0.
            self.last_lane_command_time=now
            self.final_straight_status=dict(self.final_straight_status,state=reason,
                updated=now,issued_drive=0.,issued_steering=0.)
            return Twist()
        if not self.final_straight_active():return stop('INACTIVE')
        if not self.final_straight_anchor(now):return stop('WAIT_TERMINAL_LINE')
        if self.lidar_emergency:return stop('LIDAR_EMERGENCY')
        if not 0<=now-self.last_lidar_time<=min(.50,self.sensor_timeout):
            return stop('WAIT_FRESH_LIDAR')
        source_now=self.curve_source_now()
        if source_now is None:return stop('WAIT_SOURCE_CLOCK')
        odom,detail=self.curve_motion_at(source_now,now)
        self.final_straight_status=dict(self.final_straight_status,motion=detail)
        if odom is None:return stop(detail['policy'])
        if not -.02<=detail.get('odom_source_age_s',float('inf'))<=.50:
            return stop('WAIT_FRESH_ODOM')
        front=self.front_clearance
        if not math.isfinite(front) or front<=0:return stop('WAIT_FRONT_RANGE')
        if 0<=now-self.last_boundary_time<=.35 and 0<self.boundary_front<front:
            front=self.boundary_front
        if front<=self.exit_front_stop_distance:
            self.final_straight_status=dict(self.final_straight_status,front_m=front)
            return stop('FRONT_STANDOFF')
        rx,ry,rh=self.final_straight_reference
        dx,dy=odom[0]-rx,odom[1]-ry
        lateral=-math.sin(rh)*dx+math.cos(rh)*dy
        heading=normalize_angle(odom[2]-rh)
        lateral_used=lateral;wall_source='ODOM_LINE'
        # Only same-scan paired walls may refine the cross-track error. Their
        # angles must agree with each other AND the path heading; entrance/
        # corner fits cannot change the frozen target direction.
        if 0<=now-self.last_boundary_time<=.25 and len(self.exit_spatial)==21:
            lh,wh,lf,rf=self.exit_current_wall
            ld,rd=self.exit_spatial[15:17]
            wall_lateral=.5*(rd-ld)
            if (lf and rf and .25<=ld<=.85 and .25<=rd<=.85
                    and .65<=ld+rd<=1.20 and abs(normalize_angle(lh-wh))<=math.radians(8)
                    and abs(normalize_angle(.5*(lh+wh)+heading))<=math.radians(10)
                    and abs(wall_lateral-lateral)<=.15):
                lateral_used=.5*(lateral+wall_lateral);wall_source='PAIRED_WALL_CENTRE'
        # A bounded desired yaw prevents lateral error from overpowering the
        # return to parallel. No centring demand within a two-centimetre band.
        offset=math.copysign(max(0.,abs(lateral_used)-.02),lateral_used)
        target=clamp(-math.atan2(offset,1.20),-math.radians(3),math.radians(3))
        error=normalize_angle(target-heading)
        error=math.copysign(max(0.,abs(error)-math.radians(.4)),error)
        requested=clamp(self.lane_heading_gain*error,-.08,.08)
        delta=.18*clamp(now-self.last_lane_command_time,0.,.15)
        angular=clamp(requested,self.last_lane_angular-delta,self.last_lane_angular+delta)
        angular=clamp(angular,-.08,.08)
        self.last_lane_angular=self.lane_applied=angular;self.last_lane_command_time=now
        self.curve_pause_active=False;self.curve_prediction_pause=None
        cmd=Twist();cmd.linear.x=min(self.normal_speed,self.lane_straight_drive)
        cmd.angular.z=self.steering_sign*angular
        self.final_straight_status=dict(self.final_straight_status,state='TRACKING',updated=now,
            odom_pose=odom,lateral_m=lateral,lateral_used_m=lateral_used,wall_source=wall_source,
            heading_error_rad=heading,target_heading_rad=target,requested_steering=requested,
            front_m=front,issued_drive=cmd.linear.x,issued_steering=cmd.angular.z)
        return cmd

    def lane_command(self):
        if self.final_straight_active():
            return self.final_straight_command(time.monotonic())
        angular = 0.0
        safety_hazard = False
        approach_mode = self.phase == self.APPROACH_CROSSWALK
        (
            left_side_hazard,
            right_side_hazard,
            boundary_escape_side,
            boundary_escape_active,
        ) = (
            self.boundary_escape_state()
        )
        safety_hazard = boundary_escape_active
        boundary_fresh = (
            time.monotonic() - self.last_boundary_time <= self.sensor_timeout
        )
        if boundary_fresh and self.left_valid and self.right_valid:
            center_error = self.center_error
            if abs(center_error) <= self.boundary_center_deadband:
                center_error = 0.0
            else:
                center_error -= math.copysign(
                    self.boundary_center_deadband, center_error
                )
            center_gain = (
                self.approach_center_gain
                if approach_mode
                else self.boundary_center_gain
            )
            angular += self.lateral_pid(center_error,'LANE_TWO_WALLS',center_gain,
                                        self.lane_maximum_angular)
        elif boundary_fresh and (self.left_valid != self.right_valid):
            center_error=(self.left_distance-self.center_pid_half_width if self.left_valid
                          else self.center_pid_half_width-self.right_distance)
            center_error=math.copysign(max(0.,abs(center_error)-self.boundary_center_deadband),center_error)
            source='LANE_LEFT_WALL' if self.left_valid else 'LANE_RIGHT_WALL'
            angular+=self.lateral_pid(center_error,source,self.boundary_center_gain,
                                      self.lane_maximum_angular)
        else:
            self.reset_center_pid()

        # Continuous centering uses the fitted wall lines.  A single near scan
        # point is too noisy for steering and is handled by the hard guard below.
        left_soft = self.left_distance if self.left_valid else -1.0
        right_soft = self.right_distance if self.right_valid else -1.0
        if not approach_mode and 0.0 < left_soft < self.wall_soft_distance:
            angular -= self.wall_soft_gain * (
                self.wall_soft_distance - left_soft
            )
        if not approach_mode and 0.0 < right_soft < self.wall_soft_distance:
            angular += self.wall_soft_gain * (
                self.wall_soft_distance - right_soft
            )

        left_close = (
            boundary_fresh
            and self.left_valid
            and 0.0 < self.left_distance < self.single_boundary_distance
        )
        right_close = (
            boundary_fresh
            and self.right_valid
            and 0.0 < self.right_distance < self.single_boundary_distance
        )
        if not approach_mode and (left_close or right_close):
            safety_hazard = True
        if not approach_mode and left_close:
            angular -= self.single_boundary_gain * (
                self.single_boundary_distance - self.left_distance
            )
        if not approach_mode and right_close:
            angular += self.single_boundary_gain * (
                self.single_boundary_distance - self.right_distance
            )

        if boundary_fresh:
            if approach_mode:
                left_limit = self.side_guard_hard_distance
                right_limit = self.side_guard_hard_distance
            else:
                left_limit = (
                    self.side_guard_hard_distance
                    if self.left_valid
                    else self.side_guard_distance
                )
                right_limit = (
                    self.side_guard_hard_distance
                    if self.right_valid
                    else self.side_guard_distance
                )
            if 0.0 < self.left_proximity < left_limit:
                safety_hazard = True
                angular -= self.side_guard_gain * (
                    left_limit - self.left_proximity
                )
            if 0.0 < self.right_proximity < right_limit:
                safety_hazard = True
                angular += self.side_guard_gain * (
                    right_limit - self.right_proximity
                )

        front = self.front_clearance
        if self.boundary_front > 0.0:
            front = min(front, self.boundary_front) if front > 0.0 else self.boundary_front
        if not approach_mode and 0.0 < front < self.front_turn_distance:
            safety_hazard = True
            turn_side = boundary_escape_side or self.preferred_side
            if turn_side == 0:
                turn_side = 1
            closeness = (self.front_turn_distance - front) / self.front_turn_distance
            angular += turn_side * self.front_turn_gain * closeness

        if boundary_escape_active and boundary_escape_side != 0:
            # 挡板实测间隙优先，禁止前方选边或航向项把方向反向覆盖。
            angular = boundary_escape_side * self.safety_maximum_angular

        wall_guard_side = self.wall_direction_guard(boundary_fresh)
        if wall_guard_side != 0:
            safety_hazard = True
            angular = wall_guard_side * min(
                self.wall_direction_guard_angular,
                self.safety_maximum_angular,
            )

        if (
            self.phase == self.APPROACH_CROSSWALK
            and self.start_steering_ramp_distance > 0.0
        ):
            start_travel = max(
                0.0, self.travel_distance - self.approach_start_distance
            )
            if start_travel <= self.start_straight_distance:
                angular = 0.0
            elif start_travel < self.start_steering_ramp_distance:
                ramp_span = max(
                    0.01,
                    self.start_steering_ramp_distance
                    - self.start_straight_distance,
                )
                angular *= (
                    start_travel - self.start_straight_distance
                ) / ramp_span

        if safety_hazard:
            self.reset_center_pid()
        if safety_hazard:
            angular_limit = self.safety_maximum_angular
        elif approach_mode:
            angular_limit = self.approach_maximum_angular
        else:
            angular_limit = self.lane_maximum_angular
        angular = clamp(angular, -angular_limit, angular_limit)
        now = time.monotonic()
        elapsed = clamp(now - self.last_lane_command_time, 0.0, 0.20)
        slew_per_sec = (
            self.safety_steering_slew_per_sec
            if safety_hazard
            else self.lane_steering_slew_per_sec
        )
        if not boundary_escape_active:
            max_change = slew_per_sec * elapsed
            angular = clamp(
                angular,
                self.last_lane_angular - max_change,
                self.last_lane_angular + max_change,
            )
        self.last_lane_angular = angular
        self.last_lane_command_time = now
        speed = self.caution_speed if self.lidar_caution else self.normal_speed
        speed *= max(0.45, 1.0 - 0.65 * abs(angular) / self.maximum_angular)
        # 该底盘以 1500 为电机中位，过小的正速度会落在电调死区中：
        # 节点虽然收到前进命令，但车辆只鸣响而无法起步。
        speed = max(speed, self.minimum_drive_speed)
        if (
            safety_hazard
            and self.obstacle_pulse_period > 0.0
            and time.monotonic() % self.obstacle_pulse_period
            >= self.obstacle_pulse_on_time
        ):
            # 保持 0.35 越过电调死区，通过启停占空比降低近障平均速度。
            speed = 0.0
        cmd = Twist()
        cmd.linear.x = speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def crosswalk_exit_command(self):
        """Bound each departure pulse and confirm standstill before advancing."""
        now = time.monotonic()
        if now - self.last_odom_time > self.sensor_timeout:
            self.last_lane_angular = 0.0
            self.last_lane_command_time = now
            return Twist()
        if self.exit_continuous:
            return self.continuous_exit_command(now)
        if self.exit_pulse_mode == 'DRIVE':
            cautious = self.exit_spatial_guard and (self.exit_pulse_cautious or bool(self.exit_risk_side))
            pulse_limit = 0.20 if cautious else 0.5
            distance_limit = False
            if cautious:
                if self.exit_pulse_start_xy is None or self.last_odom_xy is None:
                    self.fail_route('EXIT_PULSE_ODOM_UNKNOWN')
                    return Twist()
                distance_limit = math.hypot(self.last_odom_xy[0] - self.exit_pulse_start_xy[0],
                                            self.last_odom_xy[1] - self.exit_pulse_start_xy[1]) >= 0.05
                self.exit_pulse_cautious = True
            if now - self.exit_pulse_since >= pulse_limit or distance_limit:
                self.exit_pulse_mode = 'WAIT'
                self.exit_pulse_since = now
                self.last_lane_angular = 0.0
                self.last_lane_command_time = now
                return Twist()
        else:
            elapsed = now - self.exit_pulse_since
            if elapsed >= 5.0:
                self.fail_route('EXIT_SETTLE_TIMEOUT')
                return Twist()
            if elapsed < 1.5 or not self.odom_is_still(now):
                return Twist()
            if self.exit_pulse_count >= 20:
                self.fail_route('EXIT_PULSE_LIMIT')
                return Twist()
            self.exit_pulse_count += 1
            self.exit_pulse_mode = 'DRIVE'
            self.exit_pulse_since = now
            self.exit_pulse_start_xy = self.last_odom_xy
            self.exit_pulse_cautious = bool(self.exit_risk_side) if self.exit_spatial_guard else False
            if self.exit_pulse_cautious and self.exit_pulse_start_xy is None:
                self.fail_route('EXIT_PULSE_ODOM_UNKNOWN')
                return Twist()
        if self.exit_spatial_guard and self.exit_risk_side:
            return self.exit_forward_correction_command(now)
        boundary_fresh = (
            now - self.last_boundary_time <= self.sensor_timeout
        )
        if boundary_fresh and self.left_valid and self.right_valid:
            self.exit_steering_mode = 'DUAL_CENTER'
            return self.exit_center_command(now)
        if self.exit_single_wall_control:
            return self.exit_single_wall_command(now)
        self.last_lane_angular = 0.0
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = 0.0
        return cmd

    def continuous_exit_command(self, now):
        """Drive continuously, then stop once for the existing entry release gate."""
        ready_to_settle = (
            self.departure_distance() >= self.post_crosswalk_straight_distance
            and self.crosswalk_clear_count >= self.post_crosswalk_clear_frames
            and (self.entry_open_count >= self.entry_open_confirm_frames
                 or self.entry_body_count >= self.entry_open_confirm_frames)
        )
        if self.layout_enabled:
            ready_to_settle = self.layout_entry_ready(now)
        if ready_to_settle or self.exit_continuous_settling:
            if not self.exit_continuous_settling:
                self.exit_continuous_settling = True
                self.exit_pulse_mode = 'WAIT'
                self.exit_pulse_since = now
            self.last_lane_angular = 0.0
            self.last_lane_command_time = now
            if now - self.exit_pulse_since >= 5.0:
                self.fail_route('EXIT_CONTINUOUS_CONFIRM_TIMEOUT')
            return Twist()
        self.exit_pulse_mode = 'CONTINUOUS'
        return self.continuous_heading_command(now)

    def continuous_heading_input(self, now):
        """Use current wall geometry, never retained validity alone at an opening."""
        if now - self.last_boundary_time > self.sensor_timeout:
            return 0.0, 0.0, 'EXIT_HEADING_STALE'
        target = self.exit_reference_half_width
        if target is None or not math.isfinite(target) or target <= 0:
            return 0.0, 0.0, 'EXIT_WIDTH_UNCONFIRMED'
        if len(self.exit_spatial) != 21 or self.exit_spatial[0] != 2:
            return 0.0, 0.0, 'EXIT_HEADING_DATA_MISSING'
        lh, rh, lf, rf = self.exit_current_wall
        ld, rd = self.exit_spatial[15:17]
        if not all(math.isfinite(v) for v in (lh, rh, ld, rd)):
            return 0.0, 0.0, 'EXIT_HEADING_INVALID'
        left = self.left_valid and bool(lf)
        right = self.right_valid and bool(rf)
        if not left and not right:
            return 0.0, 0.0, 'EXIT_HEADING_WALL_LOST'
        if self.side_distance_guard_enabled and ((left and ld <= self.exit_side_stop_distance) or (right and rd <= self.exit_side_stop_distance)):
            return 0.0, 0.0, 'EXIT_HEADING_SIDE_TOO_CLOSE'
        if (left and abs(lh) > math.radians(20)) or (right and abs(rh) > math.radians(20)):
            return 0.0, 0.0, 'EXIT_HEADING_LIMIT'
        if left and right:
            if abs(lh-rh) > math.radians(10) or abs(ld+rd-2*target) > 0.15:
                return 0.0, 0.0, 'EXIT_HEADING_GEOMETRY_CHANGED'
            return (ld-rd)*0.5, (lh+rh)*0.5, ''
        distance, heading = (ld, lh) if left else (rd, rh)
        if abs(distance-target) > 0.20:
            return 0.0, 0.0, 'EXIT_HEADING_SINGLE_CHANGED'
        return (distance-target if left else target-distance), heading, ''

    def continuous_heading_command(self, now):
        """Limit lateral correction to a 3-degree heading offset from the wall."""
        error, heading, reason = self.continuous_heading_input(now)
        if reason:
            self.exit_steering_mode = reason
            self.fail_route(reason)
            return Twist()
        error = math.copysign(max(0.0, abs(error)-self.exit_center_deadband), error)
        offset = clamp(self.exit_center_gain*error, -math.radians(3), math.radians(3))
        desired = heading + offset
        limit = min(self.exit_maximum_angular, self.maximum_angular)
        angular = clamp(0.70*desired, -limit, limit)
        delta = self.lane_steering_slew_per_sec * clamp(now-self.last_lane_command_time, 0.0, 0.20)
        angular = clamp(angular, self.last_lane_angular-delta, self.last_lane_angular+delta)
        # Cancel a previous steering sign immediately when feedback asks to reverse.
        if angular*desired < 0:
            angular = 0.0
        self.last_lane_angular = clamp(angular, -limit, limit)
        self.last_lane_command_time = now
        self.exit_steering_mode = 'HEADING_CENTER'
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign*self.last_lane_angular
        return cmd

    def exit_single_wall_input(self, now):
        """Return center error and current wall heading, or an explicit stop reason.

        A wall heading is measured in the scan frame. A positive heading means
        the corridor points left relative to the car. Retained wall validity
        alone cannot authorize motion when its current fit is missing.
        """
        if now - self.last_boundary_time > self.sensor_timeout:
            return 0.0, 0.0, 'EXIT_SINGLE_BOUNDARY_STALE'
        if self.left_valid == self.right_valid:
            return 0.0, 0.0, 'EXIT_NO_SINGLE_WALL'
        target = self.exit_reference_half_width
        if target is None or not math.isfinite(target):
            return 0.0, 0.0, 'EXIT_WIDTH_UNCONFIRMED'
        lh, rh, lf, rf = self.exit_current_wall
        left = self.left_valid
        distance = self.left_distance if left else self.right_distance
        heading = lh if left else rh
        current_fit = lf if left else rf
        if not current_fit or not all(math.isfinite(v) for v in (distance, heading)):
            return 0.0, 0.0, 'EXIT_SINGLE_FIT_MISSING'
        if distance <= 0 or abs(distance - target) > 0.25:
            return 0.0, 0.0, 'EXIT_SINGLE_DISTANCE_CHANGED'
        if abs(heading) > self.exit_single_heading_limit:
            return 0.0, 0.0, 'EXIT_SINGLE_HEADING_LIMIT'
        error = distance - target if left else target - distance
        return error, heading, ''

    def exit_single_wall_command(self, now):
        error, heading, reason = self.exit_single_wall_input(now)
        if reason:
            self.exit_steering_mode = reason
            self.fail_route(reason)
            return Twist()
        self.exit_steering_mode = 'LEFT_WALL' if self.left_valid else 'RIGHT_WALL'
        error = math.copysign(max(0.0, abs(error) - self.exit_center_deadband), error)
        limit = min(self.exit_maximum_angular, self.maximum_angular)
        angular = clamp(self.exit_center_gain * error + self.exit_single_heading_gain * heading,
                        -limit, limit)
        elapsed = clamp(now - self.last_lane_command_time, 0.0, 0.20)
        delta = self.lane_steering_slew_per_sec * elapsed
        angular = clamp(angular, self.last_lane_angular - delta, self.last_lane_angular + delta)
        angular = clamp(angular, -limit, limit)
        self.last_lane_angular = angular
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def exit_release_pending(self, now):
        """Explain the existing release gate without relaxing its conditions."""
        if self.phase not in (self.SEEK_CONE_1, self.CROSSWALK_EXIT_WAIT) or self.entry_done:
            return 'NA'
        pending = []
        if self.departure_distance() < self.post_crosswalk_straight_distance:
            pending.append('MIN_TRAVEL')
        if self.crosswalk_clear_count < self.post_crosswalk_clear_frames:
            pending.append('PAPER_VISIBLE_OR_UNCONFIRMED')
        if not self.sensors_ready(now):
            pending.append('SENSOR_STALE')
        if self.lidar_emergency:
            pending.append('LIDAR_EMERGENCY')
        if self.exit_pulse_mode != 'WAIT' or now - self.exit_pulse_since < 1.5:
            pending.append('PULSE_SETTLING')
        if not self.odom_is_still(now):
            pending.append('NOT_STILL')
        if (self.entry_open_count < self.entry_open_confirm_frames
                and self.entry_body_count < self.entry_open_confirm_frames):
            pending.append('SIDE_OPEN_UNCONFIRMED')
        if (self.phase == self.CROSSWALK_EXIT_WAIT
                and self.lidar_left_clearance < self.entry_left_clearance):
            pending.append('LEFT_CLEARANCE')
        return '|'.join(pending) if pending else 'READY'

    def exit_center_command(self, now):
        """Tune departure independently from the validated crosswalk approach."""
        error = self.center_error
        if not math.isfinite(error):
            self.last_lane_angular = 0.0
            self.last_lane_command_time = now
            return Twist()
        error = math.copysign(max(0.0, abs(error) - self.exit_center_deadband), error)
        limit = min(self.exit_maximum_angular, self.maximum_angular)
        angular = clamp(self.exit_center_gain * error, -limit, limit)
        elapsed = clamp(now - self.last_lane_command_time, 0.0, 0.20)
        delta = self.lane_steering_slew_per_sec * elapsed
        angular = clamp(angular, self.last_lane_angular - delta,
                        self.last_lane_angular + delta)
        angular = clamp(angular, -limit, limit)
        self.last_lane_angular = angular
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def exit_spatial_stop_reason(self):
        """Separate local side protection from verified wall convergence ahead.

        This does not predict a swept path from the uncalibrated PWM input.
        Distant side points only permit a short correction if a CURRENT wall
        fit explains the nearest point and the command points away from it.
        """
        self.exit_risk_side = ''
        self.exit_risk_angular = 0.0
        self.exit_spatial_status = 'CHECK'
        s = self.exit_spatial
        if len(s) != 21 or not all(math.isfinite(v) for v in s) or s[0] != 2.0:
            return 'EXIT_SPATIAL_DATA_MISSING'
        if any(abs(a-b) > 1e-6 for a, b in zip(s[17:21], [0.30, 0.50, 0.40, 1.80])):
            return 'EXIT_SPATIAL_SCHEMA_MISMATCH'
        local = s[1:3]
        ahead = [s[7:9], s[9:11]]
        self.exit_spatial_status = f'local={local};ahead={ahead};coverage={s[3:5] + s[11:13]}'
        # A near point always stops, even if coverage is simultaneously poor.
        if any(0 <= value <= self.exit_side_stop_distance for value in local):
            return 'EXIT_LOCAL_SIDE_TOO_CLOSE'
        for distance, valid in [(self.left_distance, self.left_valid),
                                (self.right_distance, self.right_valid)]:
            if valid and 0 < distance <= self.exit_side_stop_distance:
                return 'EXIT_FITTED_SIDE_TOO_CLOSE'
        if any(value < 0 and value != -1 for value in local):
            return 'EXIT_SPATIAL_DATA_INVALID'
        if any(value < 0.95 or value > 1 for value in s[3:5]) or any(n < 6 for n in s[5:7]):
            return 'EXIT_LOCAL_COVERAGE_UNKNOWN'
        if any(value < 0.95 or value > 1 for value in s[11:13]) or any(n < 6 for n in s[13:15]):
            return 'EXIT_FORWARD_COVERAGE_UNKNOWN'
        risks = []
        for side, (x, y) in enumerate(ahead):
            if x == -1 and y == -1:
                continue
            if not (0.50 < x <= 1.80 and 0 < y <= 0.40):
                return 'EXIT_SPATIAL_DATA_INVALID'
            if x <= 0.65:
                return 'EXIT_FORWARD_SIDE_TOO_CLOSE'
            risks.append(side)
        if len(risks) > 1:
            return 'EXIT_FORWARD_BOTH_SIDES'
        if not risks:
            return ''
        side = risks[0]
        heading = self.exit_current_wall[side]
        fit_present = self.exit_current_wall[2 + side]
        valid = self.left_valid if side == 0 else self.right_valid
        raw_distance = s[15 + side]
        if not valid or not fit_present or raw_distance <= 0:
            return 'EXIT_FORWARD_WALL_UNCONFIRMED'
        if abs(heading) > self.exit_single_heading_limit:
            return 'EXIT_FORWARD_HEADING_LIMIT'
        x, y = ahead[side]
        wall_y = raw_distance / math.cos(heading) + (1 if side == 0 else -1) * x * math.tan(heading)
        if abs(wall_y - y) > 0.08:
            return 'EXIT_FORWARD_OBJECT_UNEXPLAINED'
        if self.left_valid and self.right_valid:
            error = self.center_error
        else:
            error, _, reason = self.exit_single_wall_input(time.monotonic())
            if reason:
                return reason
        error = math.copysign(max(0.0, abs(error) - self.exit_center_deadband), error)
        angular = self.exit_center_gain * error + self.exit_single_heading_gain * heading
        away = -1 if side == 0 else 1
        if not math.isfinite(angular) or away * heading <= 0 or away * angular <= 0:
            return 'EXIT_FORWARD_CORRECTION_CONFLICT'
        self.exit_risk_side = 'LEFT' if side == 0 else 'RIGHT'
        self.exit_risk_angular = angular
        return ''

    def exit_forward_correction_command(self, now):
        limit = min(self.exit_maximum_angular, self.maximum_angular)
        angular = clamp(self.exit_risk_angular, -limit, limit)
        delta = self.lane_steering_slew_per_sec * clamp(now - self.last_lane_command_time, 0.0, 0.20)
        angular = clamp(angular, self.last_lane_angular - delta, self.last_lane_angular + delta)
        angular = clamp(angular, -limit, limit)
        away = 1 if self.exit_risk_side == 'RIGHT' else -1
        if away * angular <= 0:
            self.fail_route('EXIT_FORWARD_STEERING_NOT_READY')
            return Twist()
        self.exit_steering_mode = 'AHEAD_' + self.exit_risk_side + '_CORRECTION'
        self.last_lane_angular = angular
        self.last_lane_command_time = now
        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def departure_stop_reason(self, now):
        if self.relative_route and self.relative_active():
            return self.relative_stop_reason(now)
        """Latch departure hazards before a phase change can bypass the guard."""
        if self.entry_done or self.phase not in (self.SEEK_CONE_1, self.CROSSWALK_EXIT_WAIT):
            return ''
        if not self.sensors_ready(now):
            return 'EXIT_SENSOR_STALE'
        if self.lidar_emergency:
            return 'EXIT_LIDAR_EMERGENCY'
        if self.front_clearance <= 0:
            return 'EXIT_FRONT_UNKNOWN'
        front = self.front_clearance
        if self.boundary_front > 0:
            front = min(front, self.boundary_front)
        if front <= self.exit_front_stop_distance:
            return 'EXIT_FRONT_TOO_CLOSE'
        if self.exit_spatial_guard:
            reason = self.exit_spatial_stop_reason()
            if reason:
                self.exit_fault_detail = self.exit_spatial_status
            return reason
        sides = [self.left_proximity, self.right_proximity]
        if self.left_valid:
            sides.append(self.left_distance)
        if self.right_valid:
            sides.append(self.right_distance)
        if self.side_distance_guard_enabled and any(0 < distance <= self.exit_side_stop_distance for distance in sides):
            self.exit_fault_detail = (
                f'wall={self.left_distance:.3f}/{self.right_distance:.3f},'
                f'valid={int(self.left_valid)}/{int(self.right_valid)},'
                f'wide={self.left_proximity:.3f}/{self.right_proximity:.3f},'
                f'local={self.exit_side_detail},'
                f'age={now-self.last_boundary_time:.3f}')
            return 'EXIT_SIDE_TOO_CLOSE'
        return ''

    def approach_crosswalk_drive(self, now):
        """Slow the zebra approach using measured speed, not PWM as m/s.

        Keep the known launch input. Once moving, trim it; if even the lowest
        rolling input is too fast, coast until a NEW measured speed is low.
        This helper is used only before the first zebra crossing.
        """
        normal=min(.35,self.normal_speed)
        motion=getattr(self,'curve_motion_status',{})
        speed=motion.get('speed_mps');stamp=motion.get('odom_source_stamp')
        source_now=self.curve_source_now()
        age=(source_now-stamp)*1e-9 if source_now is not None and stamp else None
        clock=getattr(self,'curve_motion_clock_sample',None)
        clock_ok=(clock is not None and clock[1] is not None and source_now is not None
                  and abs((source_now-clock[1])*1e-9-(now-clock[0]))<=.15)
        fresh=(motion.get('velocity_policy')=='SOURCE_SE2' and speed is not None
               and math.isfinite(speed) and 0<=speed<=3. and age is not None
               and 0<=age<=.75 and 0<=now-self.last_odom_time<=self.curve_odom_max_age
               and clock_ok)
        coasting=getattr(self,'approach_speed_coasting',False)
        if fresh:
            if speed>=.65:coasting=True
            elif speed<=.35:coasting=False
        self.approach_speed_coasting=coasting
        drive=normal;mode='LAUNCH_OR_NO_SPEED_FEEDBACK'
        if coasting:
            # A delayed/missing sample cannot turn an overspeed coast into a
            # full-power restart. Fresh low-speed evidence releases the latch.
            drive=0.;mode='OVERSPEED_COAST' if fresh else 'COAST_WAIT_FRESH_SPEED'
        elif fresh and speed>=.22:
            drive=clamp(.325+.10*(.50-speed),min(.30,normal),normal)
            mode='MEASURED_RUNNING_TRIM'
        self.approach_speed_status=dict(updated=now,active=self.phase==self.APPROACH_CROSSWALK,
            mode=mode,target_mps=.50,coast_above_mps=.65,resume_below_mps=.35,
            measured_mps=speed,source_age_s=age,fresh=fresh,drive_input=drive)
        return drive

    def approach_crosswalk_command(self):
        """Full-route mode uses live centre and heading; retain legacy fallback."""
        if self.curve_route:
            now=time.monotonic()
            if self.crosswalk_start_pose is None:
                self.crosswalk_stop_armed(now, initialize=True)
                if self.crosswalk_start_pose is None:
                    return Twist()
            return self.centre_heading_command(now, self.approach_crosswalk_drive(now))
        angular = 0.0
        boundary_fresh = (
            time.monotonic() - self.last_boundary_time <= self.sensor_timeout
        )
        if boundary_fresh and self.left_valid and self.right_valid:
            center_error = self.center_error
            if abs(center_error) <= self.approach_center_deadband:
                center_error = 0.0
            else:
                center_error -= math.copysign(
                    self.approach_center_deadband, center_error
                )
            angular = self.lateral_pid(center_error,'APPROACH_TWO_WALLS',
                                       self.approach_center_gain,self.approach_maximum_angular)
        else:
            self.reset_center_pid()

        angular = clamp(
            angular,
            -self.approach_maximum_angular,
            self.approach_maximum_angular,
        )
        now = time.monotonic()
        elapsed = clamp(now - self.last_lane_command_time, 0.0, 0.20)
        max_change = self.lane_steering_slew_per_sec * elapsed
        angular = clamp(
            angular,
            self.last_lane_angular - max_change,
            self.last_lane_angular + max_change,
        )
        self.last_lane_angular = angular
        self.last_lane_command_time = now

        cmd = Twist()
        cmd.linear.x = self.normal_speed
        cmd.angular.z = self.steering_sign * angular
        return cmd

    def orbit_command(self, cone_number):
        direction = self.cone_orbit_directions[cone_number - 1]
        angular = direction * self.cone_orbit_angular
        if self.cone_detected and self.cone_distance > 0.0:
            distance_error = self.cone_distance - self.cone_orbit_distance
            angular += direction * self.cone_distance_gain * distance_error

        # 绕桶时也必须服从挡板安全约束，否则靠近挡板触发急停后会原地锁住。
        boundary_fresh = (
            time.monotonic() - self.last_boundary_time <= self.sensor_timeout
        )
        if boundary_fresh:
            # Keep orbit corrections stable: line distance supplies the smooth
            # correction, while proximity points remain hard-safety inputs.
            left_clearance = self.left_distance if self.left_valid else -1.0
            right_clearance = self.right_distance if self.right_valid else -1.0
            if 0.0 < left_clearance < self.wall_soft_distance:
                angular -= self.wall_soft_gain * (
                    self.wall_soft_distance - left_clearance
                )
            if 0.0 < right_clearance < self.wall_soft_distance:
                angular += self.wall_soft_gain * (
                    self.wall_soft_distance - right_clearance
                )
        avoidance = 0.0
        safety_hazard = False
        (
            left_hazard,
            right_hazard,
            boundary_escape_side,
            boundary_escape_active,
        ) = (
            self.boundary_escape_state()
        )
        if boundary_fresh and boundary_escape_active:
            safety_hazard = True
            avoidance = boundary_escape_side * self.safety_maximum_angular

        front = self.front_clearance
        if self.boundary_front > 0.0:
            front = min(front, self.boundary_front) if front > 0.0 else self.boundary_front
        if 0.0 < front < self.front_turn_distance:
            safety_hazard = True
            turn_side = boundary_escape_side or self.preferred_side
            if turn_side == 0:
                turn_side = direction
            closeness = (self.front_turn_distance - front) / self.front_turn_distance
            front_avoidance = turn_side * max(
                0.35, self.front_turn_gain * closeness
            )
            if boundary_escape_side != 0:
                avoidance = boundary_escape_side * max(
                    abs(avoidance), abs(front_avoidance)
                )
            else:
                avoidance += front_avoidance

        if safety_hazard:
            if abs(avoidance) < 0.20:
                fallback_side = boundary_escape_side or self.preferred_side or direction
                avoidance = fallback_side * 0.35
            angular = clamp(
                avoidance,
                -self.safety_maximum_angular,
                self.safety_maximum_angular,
            )
        wall_guard_side = self.wall_direction_guard(boundary_fresh)
        if wall_guard_side != 0:
            safety_hazard = True
            angular = wall_guard_side * min(
                self.wall_direction_guard_angular,
                self.safety_maximum_angular,
            )
        speed = self.cone_orbit_speed
        if (
            safety_hazard
            and self.obstacle_pulse_period > 0.0
            and time.monotonic() % self.obstacle_pulse_period
            >= self.obstacle_pulse_on_time
        ):
            speed = 0.0
        cmd = Twist()
        cmd.linear.x = speed
        cmd.angular.z = self.steering_sign * clamp(
            angular, -self.maximum_angular, self.maximum_angular
        )
        return cmd

    def finish_now(self, reason):
        self.set_phase(self.FINISHED)
        msg = Bool()
        msg.data = True
        self.finished_pub.publish(msg)
        self.get_logger().warn(f'任务完成并锁停：{reason}')

    def update_phase(self, now):
        if self.phase == self.STARTUP:
            if now - self.started_at >= self.startup_delay and self.sensors_ready(now):
                self.set_phase(self.APPROACH_CROSSWALK)
            return

        if self.phase == self.APPROACH_CROSSWALK:
            if self.curve_route and (not self.crosswalk_stop_armed(now)
                    or not 0. <= now - self.last_vision_time <= self.sensor_timeout):
                self.crosswalk_count = 0
                return
            if (now - self.last_vision_time <= self.sensor_timeout
                    and self.crosswalk_count >= self.crosswalk_confirm_frames):
                self.begin_crosswalk_stop()
            return

        if self.phase == self.CROSSWALK_STOP:
            if not self.crosswalk_hold_ready(now):
                self.get_logger().info('CROSSWALK_BRAKE: waiting for standstill/data (%s)' % self.crosswalk_hold_reason,
                                       throttle_duration_sec=1.0)
                return
            self.set_phase(self.SEEK_CONE_1)
            return

        if self.relative_route and self.relative_active():
            self.relative_update(now)
            return

        if self.phase == self.SEEK_CONE_1:
            if not self.entry_done:
                if self.post_crosswalk_clearance_complete() and self.sensors_ready(now) and not self.lidar_emergency:
                    if self.test_stop_after_exit:
                        self.fail_route('TEST_EXIT_COMPLETE')
                    else:
                        self.set_phase(self.ENTER_OBSTACLES)
                elif not self.layout_enabled and self.departure_distance() >= self.post_crosswalk_max_straight_distance:
                    self.set_phase(self.CROSSWALK_EXIT_WAIT)
                return
            if self.cone_confirm_count >= self.cone_confirm_frames:
                self.set_phase(self.ORBIT_CONE_1)
            return

        if self.phase == self.CROSSWALK_EXIT_WAIT:
            # Hard distance limit still stops motion. Only fresh, stationary
            # clearance confirmation can release this bounded waiting state.
            if now - self.phase_started_at >= 5.0:
                self.fail_route('CROSSWALK_EXIT_CONFIRM_TIMEOUT')
            elif not self.sensors_ready(now) or not self.odom_is_still(now) or self.lidar_emergency:
                self.crosswalk_clear_count = 0
            elif (self.post_crosswalk_clearance_complete()
                  and self.lidar_left_clearance >= self.entry_left_clearance):
                if self.test_stop_after_exit:
                    self.fail_route('TEST_EXIT_COMPLETE')
                else:
                    self.set_phase(self.ENTER_OBSTACLES)
            return

        if self.phase == self.ENTER_OBSTACLES:
            if self.entry_yaw < -math.radians(15):
                self.fail_route('ENTRY_WRONG_TURN_DIRECTION')
            elif self.travel_distance - self.entry_start_distance > self.entry_max_travel:
                self.fail_route('ENTRY_TRAVEL_LIMIT')
            elif self.sensors_ready(now) and self.entry_yaw >= self.entry_angle:
                self.entry_done = True
                if self.test_stop_after_entry:
                    self.fail_route('TEST_ENTRY_COMPLETE')
                else:
                    self.set_phase(self.SEEK_CONE_1)
            return

        if self.phase == self.ORBIT_CONE_1:
            if self.orbit_yaw * self.cone_orbit_directions[0] <= -math.radians(20):
                self.fail_route('ORBIT_1_WRONG_TURN_DIRECTION')
            elif self.orbit_yaw * self.cone_orbit_directions[0] >= self.cone_orbit_angle:
                self.set_phase(self.SEEK_CONE_2)
            return

        if self.phase == self.SEEK_CONE_2:
            if self.cone_confirm_count >= self.cone_confirm_frames:
                self.set_phase(self.ORBIT_CONE_2)
            return

        if self.phase == self.ORBIT_CONE_2:
            if self.orbit_yaw * self.cone_orbit_directions[1] <= -math.radians(20):
                self.fail_route('ORBIT_2_WRONG_TURN_DIRECTION')
            elif self.orbit_yaw * self.cone_orbit_directions[1] >= self.cone_orbit_angle:
                self.set_phase(self.SEEK_LIGHT)
            return

        if self.phase == self.SEEK_LIGHT:
            if self.red and self.red_count >= self.red_confirm_frames and self.traffic_light_fresh(now):
                self.set_phase(self.RED_WAIT)
            return

        if self.phase == self.RED_WAIT:
            if not self.traffic_light_fresh(now):
                self.green_count = 0
                self.traffic_light_status = dict(getattr(self,'traffic_light_status',{}),
                    state='WAIT_FRESH_GREEN', receipt_fresh=False, green_hits=0,
                    receipt_age_s=now-self.last_vision_time)
            elif self.green_count >= self.green_confirm_frames and self.green and not self.red:
                self.traffic_light_status = dict(getattr(self,'traffic_light_status',{}),
                    state='GREEN_CONFIRMED', receipt_fresh=True,
                    receipt_age_s=now-self.last_vision_time)
                self.set_phase(self.FINISH_APPROACH)
            return

        if self.phase == self.FINISH_APPROACH:
            travelled = self.travel_distance - self.finish_start_distance
            front = self.front_clearance
            if self.boundary_front > 0.0:
                front = min(front, self.boundary_front) if front > 0.0 else self.boundary_front
            if travelled >= self.finish_min_travel and 0.0 < front <= self.finish_wall_distance:
                self.finish_now('检测到终点端部挡板')
            elif travelled >= self.finish_max_travel:
                self.finish_now('达到终点段最大安全行驶距离')

    def control_loop(self):
        now = time.monotonic()
        if self.curve_route:
            if self.entry_v34_enabled:self.entry_v34_poll_lane(now)
            self.curve_poll_registration(now)
            self.curve_poll_entry_plan(now)
            self.curve_update_scan_wait(now)
            self.curve_update_pose_wait(now)
            self.entry_prepare_update(now)
        if self.layout_enabled and self.layout_auto_start and self.phase == self.STARTUP:
            if self.auto_start_started is None:
                self.auto_start_started = now
            if now-self.auto_start_started > 45.0:
                self.fail_route('AUTO_START_TIMEOUT:' + self.auto_start_status)
        reason = self.relative_stop_reason(now) or self.layout_stop_reason(now) or self.departure_stop_reason(now)
        if reason:
            if not self.entry_recoverable_stop(reason,now):self.fail_route(reason)
        elif not (self.curve_scan_wait or self.curve_pose_wait):
            self.entry_recovery_since=None;self.entry_recovery_reason=''
            self.update_phase(now)
            if self.curve_route:
                self.curve_update_scan_wait(now)
                self.curve_update_pose_wait(now)
                self.entry_prepare_update(now)
            # CROSSWALK_STOP can become SEEK_CONE_1 in this same tick.
            reason = self.relative_stop_reason(now) or self.layout_stop_reason(now) or self.departure_stop_reason(now)
            if reason:
                if not self.entry_recoverable_stop(reason,now):self.fail_route(reason)

        state = self.phase
        if self.phase == self.STARTUP and self.layout_enabled and self.layout_auto_start:
            state = 'AUTO_START_WAIT'
        if self.phase in (self.FINISHED, self.ROUTE_FAULT):
            self.publish_stop()
        elif self.entry_recovery_reason and self.relative_active():
            state='ENTRY_RECOVERING'
            self.rel_mode=self.entry_recovery_reason
            self.cmd_pub.publish(self.curve_pause_command(time.monotonic()))
        elif self.curve_scan_wait:
            state='CURVE_SCAN_RECOVERING'
            self.rel_mode='WAIT_FRESH_SCAN'
            self.cmd_pub.publish(self.curve_pause_command(time.monotonic()))
        elif self.curve_pose_wait:
            state='CURVE_POSE_RECOVERING'
            self.rel_mode='WAIT_FRESH_POSE'
            self.cmd_pub.publish(self.curve_pause_command(time.monotonic()))
        elif self.entry_hold and self.phase == self.SEEK_CONE_1:
            state = 'ENTRY_'+self.entry_stage
            self.rel_mode = 'ENTRY_WAIT'
            self.publish_stop()
        elif not self.sensors_ready(now):
            state = 'SENSOR_WAIT'
            self.publish_stop()
        elif self.lidar_emergency:
            state = 'LIDAR_EMERGENCY'
            self.publish_stop()
        elif self.phase in (self.STARTUP, self.CROSSWALK_STOP, self.CROSSWALK_EXIT_WAIT, self.RED_WAIT):
            self.publish_stop()
        elif self.phase == self.APPROACH_CROSSWALK:
            self.cmd_pub.publish(self.approach_crosswalk_command())
        elif self.relative_route and self.relative_active():
            self.cmd_pub.publish(self.relative_command(now))
        elif self.phase == self.ENTER_OBSTACLES:
            cmd = self.entry_command()
            if self.route_hold_reason:
                state = self.route_hold_reason
                self.fail_route(self.route_hold_reason)
            else:
                self.cmd_pub.publish(cmd)
        elif (
            self.phase == self.SEEK_CONE_1
            and not self.entry_done
        ):
            # Departure cannot fall through to lane steering while entry is pending.
            self.cmd_pub.publish(self.crosswalk_exit_command())
        elif self.phase == self.ORBIT_CONE_1:
            self.cmd_pub.publish(self.orbit_command(1))
        elif self.phase == self.ORBIT_CONE_2:
            self.cmd_pub.publish(self.orbit_command(2))
        else:
            self.cmd_pub.publish(self.lane_command())

        if now - self.last_route_status_time >= 0.5:
            self.last_route_status_time = now
            msg = String()
            ages = [now-t for t in (self.last_vision_time, self.last_lidar_time,
                                    self.last_boundary_time, self.last_odom_time)]
            exit_travel = self.departure_distance()
            msg.data = (f'phase={self.phase} state={state} '
                        f'patch=SECOND_CONE_1002_V35_21 pose_policy={self.curve_pose_estimate_reason} entry_v33={int(self.entry_v33_enabled)} entry_v32={int(self.entry_v32_enabled)} continuous={int(self.exit_continuous)} '
                        f'lane_band_enabled={int(self.lane_parallel_band_enabled)} '
                        f'lane_band_active={int(self.parallel_band_active())} '
                        f'lane_band_mode={self.lane_band_mode} lane_band_min={self.lane_band_min_distance:.3f} '
                        f'lane_band_upper={self.lane_band_upper} lane_band_target={self.lane_band_target} '
                        f'lane_heading_source={self.lane_heading_source} '
                        f'bounded_heading={int(self.bounded_heading_control)} lane_heading_quality={self.lane_heading_quality} '
                        f'lane_target_heading_deg={math.degrees(self.lane_target_heading):.3f} '
                        f'lane_heading_error_deg={math.degrees(self.lane_heading_error):.3f} '
                        f'lane_direction_hits={self.lane_direction_hits}/3 lane_straight_drive={self.lane_straight_drive:.3f} '
                        f'side_distance_guard={int(self.side_distance_guard_enabled)} '
                        f'side_steering_guard={int(self.side_steering_guard_enabled)} '
                        f'exit_front_stop_distance={self.exit_front_stop_distance:.3f} '
                        f'entry_stage={self.entry_stage} entry_hold={int(self.entry_hold)} '
                        f'entry_blockers={self.entry_blockers} entry_wait_total={self.entry_wait_total:.3f} '
                        f'entry_plan={self.entry_plan_reason} entry_plan_ms={self.entry_plan_ms:.1f} '
                        f'lane_heading_gate={self.lane_heading_gate} exit_cruise_cmd={self.normal_speed:.3f} '
                        f'scan_wait={int(self.curve_scan_wait)} scan_recovery_hits={self.curve_scan_recovery_hits}/3 '
                        f'pose_wait={int(self.curve_pose_wait)} pose_wait_reason={self.curve_pose_wait_reason} '
                        f'pose_hits={self.curve_locator.hits}/5 '
                        f'pose_age={now-self.curve_locator.time if self.curve_locator.time is not None else -1.:.3f} '
                        f'raw_scan_age={now-self.curve_scan_time:.3f} lane_fit_ms={self.curve_fit_ms:.1f} '
                        f'registration_ms={self.curve_registration_ms:.1f} registration_status={self.curve_registration_status} '
                        f'registration_submission={self.curve_registration_submit_status} registration_job={int(self.curve_job is not None)} '
                        f'registration_pending_age={now-self.curve_registration_pending[1] if self.curve_registration_pending is not None else -1.:.3f} '
                        f'lane_source={self.lane_source} lane_fit={self.lane_fit_reason} '
                        f'lane_ready={int(self.lane_ready)} lane_recovering={int(self.lane_recovering)} '
                        f'lane_width={self.lane_width:.3f} lane_width_mode=CONFIGURED lane_observed_width={self.lane_observed_width} '
                        f'lane_heading_weight={self.lane_heading_weight:.3f} lane_direction={self.lane_direction} '
                        f'lane_left_fit={self.lane_fit_left} lane_lateral={self.lane_lateral:.4f} '
                        f'lane_heading_deg={math.degrees(self.lane_heading):.3f} '
                        f'lane_applied={self.lane_applied:.4f} '
                        f'corridor_ref={self.corridor_reference} corridor_width={self.corridor_width} '
                        f'corridor_local={self.corridor_filtered} corridor_raw={self.corridor_raw} '
                        f'corridor_reason={self.corridor_reason} corridor_age={now-self.corridor_time:.3f} '
                        f'corridor_heading={self.corridor_heading_term:.4f} corridor_request={self.corridor_request:.4f} '
                        f'curve={int(self.curve_route)} curve_reason={self.curve_reason} curve_sweep={self.curve_sweep} '
                        f'curve_progress={self.curve_follower.progress if self.curve_follower else 0.:.3f} '
                        f'curve_pose={self.curve_locator.pose} curve_clusters={self.curve_tracks.hits} '
                        f'relative={int(self.relative_route)} rel_mode={self.rel_mode} '
                        f'rel_target={self.rel_target} rel_hits={self.rel_hits} rel_yaw={math.degrees(self.rel_yaw):.1f} '
                        f'rel_corridor={self.rel_corridor_hits}/5 '
                        f'layout={int(self.layout_enabled)} auto_start={int(self.layout_auto_start)} '
                        f'auto_start_status={self.auto_start_status if self.layout_enabled and self.layout_auto_start else "OFF"} layout_pose={self.layout_pose} '
                        f'layout_uncertainty={self.layout_uncertainty:.3f} '
                        f'layout_gate={self.layout_gate_status(now)} '
                        f'spatial_guard={int(self.exit_spatial_guard)} '
                        f'exit_risk={self.exit_risk_side or "NONE"} '
                        f'exit_spatial=({self.exit_spatial_status}) '
                        f'exit_pulse_cautious={int(self.exit_pulse_cautious)} '
                        f'test_exit={int(self.test_stop_after_exit)} test_entry={int(self.test_stop_after_entry)} '
                        f'single_wall={int(self.exit_single_wall_control)} '
                        f'exit_gain={.35 if self.relative_route else self.exit_center_gain:.3f} '
                        f'exit_limit={self.straight_limit if self.relative_route else self.exit_maximum_angular:.3f} '
                        f'exit_mode={self.exit_steering_mode} '
                        f'exit_half_width={self.exit_reference_half_width} '
                        f'exit_current_wall={self.exit_current_wall} '
                        f'exit_pending={self.relative_exit_pending(now) if self.relative_route and self.phase == self.SEEK_CONE_1 else self.exit_release_pending(now)} '
                        f'straight_limit={self.straight_limit:.3f} straight_ref={self.straight_reference} '
                        f'straight_rate={self.straight_yaw_rate:.3f} straight_error={self.straight_error:.3f} '
                        f'straight_opening={int(self.straight_opening)} '
                        f'pid_source={self.pid_source} pid_target={self.pid_target} '
                        f'pid_error={self.pid_error} pid_p={self.pid_p:.4f} '
                        f'pid_i={self.pid_i:.4f} pid_d={self.pid_d:.4f} '
                        f'pid_requested={self.pid_requested:.4f} '
                        f'pid_gains=lateral_kp_by_phase,ki:0.008,kd:0.04 straight_heading:0 '
                        f'curve_feedback={self.curve_feedback_status()} ' 
                        f'entry_region={self.entry_region_status(now)} '
                        f'end_wall={self.entry_wall} end_wall_hits={self.entry_wall_hits}/5 '
                        f'exit_side_nearest={self.rel_data.get("entry_side_nearest") if self.rel_data else None} '
                        f'exit_side_clear={self.rel_data.get("entry_side_clear") if self.rel_data else None} ' 
                        f'exit_path={self.rel_data.get("exit_path_front") if self.rel_data else None} '
                        f'dry_run={int(self.dry_run)} exit_center=1 '
                        f'exit_pulse={self.exit_pulse_mode}:{self.exit_pulse_count} '
                        f'exit_side_detail={self.exit_side_detail} '
                        f'exit_fault_detail=({self.exit_fault_detail}) '
                        f'exit_m={exit_travel:.3f} clear={self.crosswalk_clear_count}/{self.post_crosswalk_clear_frames} '
                        f'present={int(self.crosswalk_present)} trigger={int(self.crosswalk)} '
                        f'front={self.front_clearance:.3f} '
                        f'left={self.lidar_left_clearance:.3f} right={self.lidar_right_clearance:.3f} '
                        f'entry_yaw={math.degrees(self.entry_yaw):.1f} '
                        f'entry_open={self.entry_open_count}/{self.entry_open_confirm_frames} '
                        f'body_clear={self.entry_body_count}/{self.entry_open_confirm_frames} '
                        f'entry_cone={self.entry_cone} entry_hits={self.entry_cone_hits} '
                        f'entry_cone_age={now-self.entry_cone_time:.2f} '
                        f'entry_steer_limit={self.entry_cone_limit:.3f} '
                        f'cone_hits={self.cone_confirm_count} fault={self.route_fault} '
                        f'ages_vision_lidar_boundary_odom={ages}')
            self.route_status_pub.publish(msg)
        if self.curve_route:self.publish_entry_status(time.monotonic())
        if state != self.last_published_state:
            self.last_published_state = state
            msg = String()
            msg.data = state
            self.state_pub.publish(msg)
            self.get_logger().warn(f'控制状态 -> {state}')


def main(args=None):
    rclpy.init(args=args)
    node = RaceTaskController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # ROS SIGINT may already have closed the publishing context.
        if rclpy.ok():node.publish_stop()
        node.close_curve_worker()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
