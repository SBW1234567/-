"""Crosswalk stop timing with actual odometry callbacks and source clocks.

These tests do not replace the stillness predicate or phase transition. They
drive the delivered controller with source-stamped base poses, including the
short controller receipt gaps seen in the 21:12:49 run.
"""
import json
import math
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers

cm, ros = helpers.cm, helpers.ros


class CrosswalkTimingTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.
        self.ros_time = 1000.
        self.clock = patch.object(cm.time, 'monotonic', side_effect=lambda: self.now)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        previous = ros.FakeNode.overrides
        self.addCleanup(setattr, ros.FakeNode, 'overrides', previous)
        ros.FakeNode.overrides = dict(curve_route=True, relative_route=True,
            exit_continuous=True, entry_v32_enabled=True, entry_v33_enabled=True,
            entry_v34_enabled=True, dry_run=True)
        self.c = cm.RaceTaskController()
        self.addCleanup(self.c.close_curve_worker)
        self.c.get_clock = lambda: NS(now=lambda: NS(nanoseconds=round(self.ros_time*1e9)))
        self.c.phase = self.c.APPROACH_CROSSWALK
        self.c.begin_crosswalk_stop()

    def advance(self, now):
        self.now = float(now)
        self.ros_time = 1000.+self.now-100.
        self.c.last_vision_time = self.c.last_lidar_time = self.c.last_boundary_time = self.now

    def message(self, source, pose):
        ns = round(source*1e9)
        return NS(header=NS(stamp=NS(sec=ns//1000000000, nanosec=ns%1000000000)),
            pose=NS(pose=NS(position=NS(x=pose[0], y=pose[1]),
                orientation=NS(x=0., y=0., z=math.sin(pose[2]/2), w=math.cos(pose[2]/2)))),
            twist=NS(twist=NS(linear=NS(x=0.), angular=NS(z=0.))))

    def tick(self, now, pose=(1.475, .065, .005), source=None, receive=True):
        self.advance(now)
        if receive:
            source = self.ros_time if source is None else source
            self.c.odom_callback(self.message(source, pose))
        self.c.update_phase(self.now)
        return self.c.phase

    def feed(self, start, stop, pose=(1.475, .065, .005), delay=0.):
        count = round((stop-start)/.1)
        for i in range(count+1):
            now = round(start+.1*i, 6)
            self.tick(now, pose, source=1000.+now-100.-delay)

    def confirm(self):
        self.feed(100., 100.6)
        self.assertIsNotNone(self.c.crosswalk_hold_started)
        return self.c.crosswalk_hold_started

    def test_zero_command_precedes_real_stop_and_hold_is_at_least_3_2_seconds(self):
        command = self.c.cmd_pub.messages[-1]
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))
        started = self.confirm()
        self.feed(100.7, round(started+3.1, 6))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertEqual(self.tick(started+3.200001), self.c.SEEK_CONE_1)
        self.assertGreaterEqual(self.now-started, 3.2)

    def test_logged_short_gaps_do_not_restart_confirmed_hold(self):
        started = self.confirm()
        # First loss just after initial HOLD, then another close to its end.
        # Generic .30s stillness-window resets remain unchanged.
        missing = {101.0, 101.1, 101.2, 101.3, 103.4, 103.5, 103.6, 103.7}
        released = None
        for i in range(7, 49):
            now = round(100.+i*.1, 6)
            phase = self.tick(now, receive=now not in missing)
            if phase == self.c.SEEK_CONE_1:
                released = now
                break
            self.assertEqual(self.c.crosswalk_hold_started, started)
        self.assertIsNotNone(released)
        self.assertLess(released, 104.8, 'Recovery must not add another complete 3.2s hold')
        self.assertGreaterEqual(released-started, 3.2)

    def test_mature_hold_cannot_release_on_first_new_sample_after_gap(self):
        started = self.confirm()
        self.feed(100.7, 103.4)
        for now in (103.5, 103.6, 103.7, 103.8):
            self.tick(now, receive=False)
        self.assertEqual(self.tick(103.9), self.c.CROSSWALK_STOP)
        self.assertEqual(self.c.crosswalk_hold_started, started)
        self.assertFalse(self.c.odom_is_still(103.9))
        self.feed(104.0, 104.5)
        self.assertEqual(self.c.phase, self.c.SEEK_CONE_1)

    def test_initial_coast_is_not_part_of_stationary_hold(self):
        for i in range(11):
            self.tick(100.+i*.1, pose=(.08*i, 0., 0.))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.feed(101.1, 101.7, pose=(.8, 0., 0.))
        started = self.c.crosswalk_hold_started
        self.assertIsNotNone(started)
        self.assertGreaterEqual(started, 101.5)
        self.feed(101.8, round(started+3.1, 6), pose=(.8, 0., 0.))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertEqual(self.tick(started+3.200001, pose=(.8, 0., 0.)), self.c.SEEK_CONE_1)

    def test_out_and_back_motion_restarts_hold_even_before_control_observes_return(self):
        first = self.confirm()
        self.advance(101.)
        self.c.odom_callback(self.message(1001., (1.5, .065, .005)))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reason, 'ACTUAL_MOTION')
        self.advance(101.1)
        self.c.odom_callback(self.message(1001.1, (1.475, .065, .005)))
        self.c.update_phase(self.now)
        self.feed(101.2, 101.8)
        second = self.c.crosswalk_hold_started
        self.assertIsNotNone(second)
        self.assertGreater(second, first)
        self.feed(101.9, round(second+3.1, 6))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_slow_drift_against_stop_anchor_restarts_hold(self):
        self.confirm()
        for i in range(1, 6):
            self.tick(100.6+i*.2, pose=(1.475+.004*i, .065, .005))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_opposite_positions_inside_anchor_radius_still_restart_hold(self):
        first = self.confirm()
        self.feed(100.7, 101.9)
        self.tick(102., pose=(1.489, .065, .005))
        self.assertEqual(self.c.crosswalk_hold_started, first)
        self.tick(102.1, pose=(1.461, .065, .005))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reset_reason, 'ACTUAL_MOTION')
        self.tick(102.2)
        self.feed(102.3, 103.8)
        second = self.c.crosswalk_hold_started
        self.assertIsNotNone(second)
        self.assertGreaterEqual(second, 102.6)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.feed(103.9, round(second+3.1, 6))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertEqual(self.tick(second+3.200001), self.c.SEEK_CONE_1)

    def test_opposite_yaws_inside_anchor_limit_still_restart_hold(self):
        first = self.confirm()
        self.tick(100.8, pose=(1.475, .065, .040))
        self.assertEqual(self.c.crosswalk_hold_started, first)
        self.tick(100.9, pose=(1.475, .065, -.030))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reset_reason, 'ACTUAL_MOTION')

    def test_yaw_motion_restarts_hold(self):
        self.confirm()
        self.tick(100.8, pose=(1.475, .065, .05))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_small_recorded_stationary_noise_preserves_hold(self):
        started = self.confirm()
        for i in range(7, 38):
            self.tick(100.+i*.1, pose=(1.475+.002*math.sin(i),
                .065+.001*math.cos(i), .005+math.radians(.4)*math.sin(i)))
        self.assertEqual(self.c.crosswalk_hold_started, started)
        self.assertEqual(self.tick(started+3.200001), self.c.SEEK_CONE_1)

    def test_long_receipt_loss_resets_hold_and_requires_new_full_hold(self):
        old = self.confirm()
        self.tick(101.7, receive=False)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reason, 'LONG_ODOM_GAP')
        self.feed(101.8, 102.4)
        restarted = self.c.crosswalk_hold_started
        self.assertIsNotNone(restarted)
        self.assertGreater(restarted, old)
        self.feed(102.5, round(restarted+3.1, 6))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_long_missing_gap_is_detected_even_without_control_tick_during_gap(self):
        self.confirm()
        self.tick(101.8)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(len(self.c.crosswalk_source_samples), 1)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_pre_brake_source_backlog_cannot_confirm_stop(self):
        self.feed(100., 100.7, delay=.8)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.feed(100.8, 101.5, delay=.8)
        self.assertIsNotNone(self.c.crosswalk_hold_started)
        self.assertGreaterEqual(self.c.crosswalk_hold_started, 101.3)

    def test_old_source_cannot_be_refreshed_by_fresh_callbacks(self):
        self.feed(100., 104., delay=1.2)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_source_span_is_required_in_addition_to_receipt_window(self):
        for i in range(7):
            self.tick(100.+i*.1, source=1000.+i*.02)
        self.assertTrue(self.c.odom_is_still(self.now))
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reason, 'WAIT_POST_BRAKE_SOURCE_WINDOW')

    def test_wall_clock_hold_cannot_replace_elapsed_source_stop_time(self):
        started = self.confirm()
        self.feed(100.7, 101.4)
        # Grow source latency smoothly, keeping real windows and receipts.
        for i in range(15, 39):
            now = round(100.+i*.1, 6)
            delay = min(.75, (now-101.4)*.4)
            self.tick(now, source=1000.+now-100.-delay)
        self.assertGreaterEqual(self.now-started, 3.2)
        self.assertLess(self.c.crosswalk_hold_last_sample[1]-self.c.crosswalk_hold_source, 3.2)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.feed(103.9, 104.7, delay=.75)
        self.assertEqual(self.c.phase, self.c.SEEK_CONE_1)

    def test_duplicate_source_callbacks_do_not_refresh_stillness_or_release(self):
        self.confirm()
        source = self.c.last_still_stamp
        receipt = self.c.crosswalk_hold_last_sample[0]
        for i in range(7, 42):
            self.tick(100.+i*.1, source=source)
        self.assertEqual(self.c.crosswalk_hold_last_sample[0], receipt)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertIsNone(self.c.crosswalk_hold_started)

    def test_bad_odometry_cannot_finish_hold(self):
        self.confirm()
        for i in range(7, 42):
            self.tick(100.+i*.1, pose=(math.nan, .065, .005))
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertIsNone(self.c.crosswalk_hold_started)

    def test_monotonic_reversal_and_ros_clock_jump_require_new_confirmation(self):
        self.confirm()
        self.tick(100.4, source=1000.7)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.feed(100.8, 101.5)
        self.assertIsNotNone(self.c.crosswalk_hold_started)
        self.advance(101.6)
        self.ros_time += .5
        self.c.update_phase(self.now)
        self.assertIsNone(self.c.crosswalk_hold_started)
        self.assertEqual(self.c.crosswalk_hold_reason, 'STILL_CLOCK_CHANGED')

    def test_general_strict_stillness_window_remains_unchanged_outside_crosswalk(self):
        self.c.phase = self.c.SEEK_CONE_1
        self.c.odom_still_samples.clear()
        self.c.last_still_stamp = None
        for now in (100., 100.2, 100.4, 100.6):
            self.c.record_still_sample(now, now+900., 0., 0., 0.)
        self.assertTrue(self.c.odom_is_still(100.6))
        self.c.record_still_sample(101., 1001., 0., 0., 0.)
        self.assertEqual(len(self.c.odom_still_samples), 1)
        self.assertFalse(self.c.odom_is_still(101.))

    def test_legal_three_and_three_point_one_second_parameters_are_preserved(self):
        for duration in (3., 3.1):
            with self.subTest(duration=duration):
                ros.FakeNode.overrides['crosswalk_stop_duration'] = duration
                self.advance(100.)
                self.c = cm.RaceTaskController()
                self.addCleanup(self.c.close_curve_worker)
                self.c.get_clock = lambda: NS(now=lambda: NS(nanoseconds=round(self.ros_time*1e9)))
                self.assertEqual(self.c.crosswalk_stop_duration, duration)
                self.c.phase = self.c.APPROACH_CROSSWALK
                self.c.begin_crosswalk_stop()
                started = self.confirm()
                self.feed(100.7, round(started+duration-.1, 6))
                self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
                self.assertEqual(self.tick(started+duration+.000001), self.c.SEEK_CONE_1)

    def test_entry_status_exports_actual_hold_and_source_elapsed_without_mutation(self):
        started = self.confirm()
        self.feed(100.7, 101.4)
        before = (self.c.crosswalk_hold_started, self.c.crosswalk_hold_source,
            self.c.crosswalk_hold_clock, tuple(self.c.crosswalk_source_samples))
        self.c.publish_entry_status(self.now)
        data = json.loads(self.c.entry_status_pub.messages[-1].data)['crosswalk']
        self.assertTrue(data['active'])
        self.assertEqual(data['hold_reason'], 'CONFIRMED_HOLD')
        self.assertAlmostEqual(data['hold_elapsed'], self.now-started)
        self.assertAlmostEqual(data['source_elapsed'],
            self.c.crosswalk_hold_last_sample[1]-self.c.crosswalk_hold_source)
        self.assertEqual(before, (self.c.crosswalk_hold_started, self.c.crosswalk_hold_source,
            self.c.crosswalk_hold_clock, tuple(self.c.crosswalk_source_samples)))
        self.tick(101.6, pose=(1.5, .065, .005))
        self.c.publish_entry_status(self.now)
        data = json.loads(self.c.entry_status_pub.messages[-1].data)['crosswalk']
        self.assertEqual(data['reset_reason'], 'ACTUAL_MOTION')
        self.assertIsNone(data['hold_elapsed'])
        self.assertIsNone(data['source_elapsed'])

    def test_entry_status_old_timestamp_does_not_read_future_hold_evidence(self):
        started = self.confirm()
        before = self.c.crosswalk_hold_clock
        self.c.publish_entry_status(started-.1)
        data = json.loads(self.c.entry_status_pub.messages[-1].data)['crosswalk']
        self.assertIsNone(data['hold_elapsed'])
        self.assertIsNone(data['source_elapsed'])
        self.assertEqual(self.c.crosswalk_hold_clock, before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
