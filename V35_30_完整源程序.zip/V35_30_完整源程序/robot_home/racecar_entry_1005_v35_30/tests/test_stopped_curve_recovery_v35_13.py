"""Stopped first-cone recovery using the second V35.12 run's actual pose.

The CSV lacks raw scans and the planner's tracked cone coordinates. Ray casts
therefore use the handbook walls and nominal cones, explicitly an approximation.
The command/pose/source timing below is recorded evidence; simulated dynamics
and the reconstructed path are not new vehicle measurements.
"""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import unittest
import numpy as np
import test_continuous as helpers

core=helpers.core
PACKAGE=Path(__file__).resolve().parents[1]
# Freeze the recorded V35.12 geometry independently of package rollback.
# V35.14 rollback is V35.13; a sibling checkout must not select test inputs.
LEGACY_PATH=PACKAGE/'tests/baselines/race_curve_core_v35_12.py'
LEGACY_SHA256='3e46670fc4a0169febaeafc9833c9c6050f04168d72b47df2a73c86f9f0611b2'
_spec=importlib.util.spec_from_file_location('stopped_curve_v35_12_geometry',LEGACY_PATH)
legacy_core=importlib.util.module_from_spec(_spec)
import sys
sys.modules[_spec.name]=legacy_core
_spec.loader.exec_module(legacy_core)
PLAN_START=(5.5052962364195634,.9203651544694624,.13961014245675843)
STOP_POSE=(6.738060505435078,2.654870122482625,2.4004394474411725)
OBSERVED_FRONT=.476
RECORDED_PROGRESS=3.006
SOURCE_EVIDENCE=dict(csv='race_control_20261001_183721.csv',
    first_drive_elapsed_s=24.485,first_persistent_stop_elapsed_s=29.383,
    first_stop_reason='SWEPT_OBSTACLE',first_stop_front_m=.748,
    first_stop_body_clear=True,first_stop_emergency=False,first_stop_fault='',
    first_stop_command_pose=(6.953,2.441,2.052),
    first_stop_prediction_dt_s=.303450118,first_stop_prediction_distance_m=.2018,
    first_stop_requested_steer=.32,first_stop_issued_steer=0.,
    odom_at_stop=(6.7548,2.0413,111.817),
    odom_after_coast=(6.4412,2.3938,143.244),
    stopped_front_range_m=(.476,.493),
    repeated_recovery_requested_steer=.15,repeated_recovery_issued_steer=0.)


def follower_at_stop(path,pose=STOP_POSE):
    f=core.PathFollower(path)
    f.index=int(np.searchsorted(path.lengths,RECORDED_PROGRESS))
    f.progress=float(path.lengths[f.index])
    return f


def advance(pose,speed,steer,gain_factor,dt):
    curvature=6.*gain_factor*steer;length=speed*dt;angle=curvature*length
    x,y,h=pose
    if abs(curvature)<1e-9:return x+length*math.cos(h),y+length*math.sin(h),h
    return (x+(math.sin(h+angle)-math.sin(h))/curvature,
            y+(math.cos(h)-math.cos(h+angle))/curvature,core.wrap(h+angle))


def maximum_padded_y(samples,margin=.08):
    return max(core.world(p,q)[1] for q in samples
        for p in ((-.185-margin,-.15-margin),(.20+margin,-.15-margin),
                  (.20+margin,.15+margin),(-.185-margin,.15+margin)))


def recovery_geometry_case(gain_factor=1.,tau=.12):
    """Integrate the body; hold .32 until a normal future sweep is clear.

    Fresh perfect ray casts and current pose isolate the recovery geometry.
    This does not simulate source delay or prove the controller's stop detector.
    """
    path=legacy_core.plan_entry_path(PLAN_START);f=follower_at_stop(path)
    pose=STOP_POSE;actual=.32*(1.-math.exp(-.60/tau));speed=0.;target=.32
    travelled=0.;handoff=None;min_wall_gap=math.inf;blocking=[];normal=False;normal_clear_hits=0
    for tick in range(1,401):
        now=tick*.01
        scan=helpers.scan_at(pose)
        if tick%10==1:
            if not normal:
                candidate=copy.copy(f);candidate.output=.32;candidate.response_output=actual
                candidate.time=now-.10;candidate.reset_feedback(preserve_output=True)
                candidate.command(pose,now)
                samples=core.command_horizon(pose,candidate,6.,distance=.65,speed=.9,steer_tau=tau)
                normal_clear_hits=(normal_clear_hits+1 if not core.scan_hits_body(scan,pose,samples) else 0)
                # A single coarse ordinary forecast can clear too early while
                # real low-gain steering still needs the held tight arc.
                if normal_clear_hits>=2:
                    f=candidate;normal=True;target=f.output;handoff=travelled
                else:
                    held=core.constant_steer_horizon(pose,.32,6.,distance=.65,
                        speed=max(.9,speed),initial_steer=actual,steer_tau=tau)
                    if core.scan_hits_body(scan,pose,held):
                        blocking.append('CONSTANT_SWEEP');break
            else:
                target=f.command(pose,now)
                samples=core.command_horizon(pose,f,6.,distance=.65,speed=.9,steer_tau=tau)
                if core.scan_hits_body(scan,pose,samples):
                    blocking.append('NORMAL_SWEEP');break
        speed+=.01/.30*(.9-speed)
        actual+=(1.-math.exp(-.01/tau))*(target-actual)
        pose=advance(pose,speed,actual,gain_factor,.01);travelled+=speed*.01
        if not core.body_clear(pose,margin=.08):
            blocking.append('PADDED_BODY');break
        min_wall_gap=min(min_wall_gap,3.1-maximum_padded_y([pose],margin=0.))
        if pose[0]<5.85 and 2.35<pose[1]<2.95 and abs(core.wrap(pose[2]-math.pi))<.6:
            return dict(reached=True,blocking=blocking,handoff_after_m=handoff,
                final_pose=pose,min_upper_wall_body_gap_m=min_wall_gap,time_s=now)
    return dict(reached=False,blocking=blocking,handoff_after_m=handoff,
        final_pose=pose,min_upper_wall_body_gap_m=min_wall_gap,time_s=now)


class StoppedCurveRecoveryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.path=legacy_core.plan_entry_path(PLAN_START)

    def test_recorded_v35_12_geometry_is_an_exact_packaged_fixture(self):
        self.assertEqual(LEGACY_PATH.parent,PACKAGE/'tests/baselines')
        digest=hashlib.sha256(LEGACY_PATH.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
        self.assertEqual(digest,LEGACY_SHA256)

    def test_reconstruction_matches_recorded_path_tangent_approximately(self):
        f=follower_at_stop(self.path);f.command(STOP_POSE,100.)
        self.assertAlmostEqual(f.heading,.5303,delta=.02)
        self.assertAlmostEqual(f.curvature,.6636,delta=.025)
        self.assertEqual(core.CONES,((6.,2.),(2.,2.)))

    def test_cold_reset_and_instant_presteer_both_fail_normal_feedback_rollout(self):
        scan=helpers.scan_at(STOP_POSE)
        for initial in (0.,.32):
            with self.subTest(initial=initial):
                f=follower_at_stop(self.path)
                f.output=f.response_output=initial;f.time=99.9
                f.reset_feedback(preserve_output=True);f.command(STOP_POSE,100.)
                samples=core.command_horizon(STOP_POSE,f,6.,distance=.65,speed=.9)
                self.assertTrue(core.scan_hits_body(scan,STOP_POSE,samples))
        self.assertTrue(core.body_clear(STOP_POSE,margin=.08))
        self.assertGreater(OBSERVED_FRONT,.35)

    def test_weak_held_steer_cannot_pass_all_gain_sweeps(self):
        scan=helpers.scan_at(STOP_POSE)
        for steer in (.24,.28):
            samples=core.constant_steer_horizon(STOP_POSE,steer,6.,distance=.65,
                speed=.9,initial_steer=steer)
            self.assertTrue(core.scan_hits_body(scan,STOP_POSE,samples))

    def test_observed_weak_gain_cannot_be_hidden_by_nominal_gain_assumption(self):
        scan=helpers.scan_at(STOP_POSE)
        for gain in (4.,4.4,5.):
            samples=core.constant_steer_horizon(STOP_POSE,.32,gain,distance=.65,
                speed=.9,initial_steer=.32)
            self.assertTrue(core.scan_hits_body(scan,STOP_POSE,samples,margin=.08))

    def test_settled_032_held_steer_passes_raw_and_map_checks_without_smaller_margin(self):
        actual=.32*(1.-math.exp(-.60/.12));scan=helpers.scan_at(STOP_POSE)
        samples=core.constant_steer_horizon(STOP_POSE,.32,6.,distance=.65,
            speed=.9,initial_steer=actual)
        self.assertFalse(core.scan_hits_body(scan,STOP_POSE,samples,margin=.08))
        self.assertTrue(all(core.body_clear(q,margin=.08) for q in samples))
        self.assertLess(maximum_padded_y(samples),3.1)

    def test_a_sent_target_is_not_a_settled_servo(self):
        scan=helpers.scan_at(STOP_POSE)
        for dwell in (0.,.30):
            actual=.32*(1.-math.exp(-dwell/.12))
            samples=core.constant_steer_horizon(STOP_POSE,.32,6.,distance=.65,
                speed=.9,initial_steer=actual)
            self.assertTrue(core.scan_hits_body(scan,STOP_POSE,samples))

    def test_real_new_obstacle_blocks_held_arc(self):
        scan=helpers.scan_at(STOP_POSE)
        samples=core.constant_steer_horizon(STOP_POSE,.32,6.,initial_steer=.32)
        x,y=core.local(samples[16],STOP_POSE);distance=math.hypot(x,y)
        self.assertGreater(distance,.30)
        k=int(round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment))%len(scan.ranges)
        scan.ranges[k]=distance
        self.assertTrue(core.scan_hits_body(scan,STOP_POSE,samples,margin=.08))

    def test_constant_arc_integration_matches_exact_geometry(self):
        pose=(5.,1.,0.);steer=.32;length=.65
        samples=core.constant_steer_horizon(pose,steer,6.,distance=length,initial_steer=steer)
        count=int(math.ceil(length/.025))
        for j,factor in enumerate((.8,1.,1.2)):
            q=samples[(j+1)*count];k=6.*factor*steer
            expected=(pose[0]+math.sin(k*length)/k,pose[1]+(1.-math.cos(k*length))/k,k*length)
            np.testing.assert_allclose(q,expected,atol=1e-12)

    def test_constant_rollout_bounds_and_opposite_sign(self):
        with self.assertRaises(ValueError):core.constant_steer_horizon(STOP_POSE,float('nan'),6.)
        a=core.constant_steer_horizon((5.,1.,0.),-.32,6.,initial_steer=-.32)
        self.assertLess(a[-1][1],1.)
        b=core.constant_steer_horizon((5.,1.,0.),.8,6.,limit=.8,initial_steer=.8)
        c=core.constant_steer_horizon((5.,1.,0.),.32,6.,initial_steer=.32)
        np.testing.assert_allclose(b,c,atol=1e-12)

    def test_integrated_recovery_returns_to_normal_tracking_with_all_gains(self):
        for factor in (.8,1.,1.2):
            with self.subTest(gain=factor):
                result=recovery_geometry_case(factor)
                self.assertTrue(result['reached'],result)
                self.assertEqual(result['blocking'],[],result)
                self.assertIsNotNone(result['handoff_after_m'])


def report():
    path=legacy_core.plan_entry_path(PLAN_START);scan=helpers.scan_at(STOP_POSE);rows=[]
    for steer in (.24,.28,.32):
        for dwell in (0.,.30,.45,.60):
            actual=steer*(1.-math.exp(-dwell/.12))
            samples=core.constant_steer_horizon(STOP_POSE,steer,6.,distance=.65,
                speed=.9,initial_steer=actual)
            rows.append(dict(steer=steer,presteer_seconds=dwell,initial_response=actual,
                raw_hit=core.scan_hits_body(scan,STOP_POSE,samples,margin=.08),
                padded_map_clear=all(core.body_clear(q,margin=.08) for q in samples),
                max_padded_y_m=maximum_padded_y(samples)))
    weak_gain_cases=[]
    for gain in (4.,4.4,5.):
        samples=core.constant_steer_horizon(STOP_POSE,.32,gain,distance=.65,initial_steer=.32)
        weak_gain_cases.append(dict(nominal_gain=gain,raw_hit=core.scan_hits_body(scan,STOP_POSE,samples),
            max_padded_y_m=maximum_padded_y(samples)))
    return dict(recorded=SOURCE_EVIDENCE,plan_start=PLAN_START,stop_pose=STOP_POSE,
        legacy_nominal_gain=6.,legacy_gain_factors=(.8,1.,1.2),
        reconstruction='Nominal cones and handbook boards; actual scans/cone track centres unavailable in CSV.',
        scope='Legacy gain6 geometry comparison, not the new default gain5. Perfect current scan/pose; no real-world margin proof.',
        fixed_steer_cases=rows,weak_gain_cases=weak_gain_cases,
        integrated_cases=[dict(gain_factor=f,result=recovery_geometry_case(f)) for f in (.8,1.,1.2)])


if __name__=='__main__':
    import sys
    if '--report' in sys.argv:
        p=PACKAGE.parent/'stopped_curve_recovery_report.json'
        p.write_text(json.dumps(report(),ensure_ascii=False,indent=2),encoding='utf-8');print(p)
    else:unittest.main(verbosity=2)
