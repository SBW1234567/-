"""Final-straight regressions using measured handoffs and source-time odometry.

The independent plant is deliberately simple: physical speed is supplied in
m/s, steering input becomes curvature through a measured gain range, and a
120 ms first-order actuator lag is retained. It is an offline robustness
check, not a calibrated prediction of on-track performance.
"""
import copy
import json
import math
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers

cm, core, ros = helpers.cm, helpers.core, helpers.ros
HANDOFFS = (
    dict(log='race_control_20261001_215134.csv',
         pose=(5.3249313, 3.5256932, -.0914531), steering=.0292532, speed=.5563),
    dict(log='race_control_20261001_215403.csv',
         pose=(5.1347471, 3.5164243, -.0838896), steering=.0298751, speed=.4669),
)


class FinalStraightV3516Tests(unittest.TestCase):
    def setUp(self):
        self.now = 100.
        self.source_now = 1000.
        timer = patch.object(cm.time, 'monotonic', side_effect=lambda: self.now)
        timer.start()
        self.addCleanup(timer.stop)
        previous = ros.FakeNode.overrides
        self.addCleanup(setattr, ros.FakeNode, 'overrides', previous)
        ros.FakeNode.overrides = dict(curve_route=True, relative_route=True,
            exit_continuous=True, entry_v32_enabled=True, entry_v33_enabled=True,
            entry_v34_enabled=True, dry_run=True, bounded_heading_control=True,
            side_distance_guard_enabled=False, side_steering_guard_enabled=False)
        self.c = cm.RaceTaskController()
        self.addCleanup(self.c.close_curve_worker)
        self.c.get_clock = lambda: NS(now=lambda: NS(nanoseconds=round(self.source_now*1e9)))
        self.c.phase = self.c.ORBIT_CONE_2
        self.c.curve_follower = core.PathFollower(core.plan_entry_path((5.08, .86, .075)))
        self.c.front_clearance = self.c.boundary_front = 3.
        self.c.left_valid = self.c.right_valid = True
        self.c.left_distance = self.c.right_distance = .45
        self.c.left_proximity = self.c.right_proximity = .45
        self.c.center_error = 0.
        self.c.lidar_emergency = self.c.lidar_caution = False
        self.refresh_sensors()

    def refresh_sensors(self):
        c = self.c
        c.last_lidar_time = c.last_boundary_time = c.last_vision_time = self.now

    def advance(self, dt):
        self.now += dt
        self.source_now += dt
        self.refresh_sensors()

    def receive_laser_pose(self, pose, source=None):
        """Use the production base->laser transform, never write motion history."""
        ns = round((self.source_now if source is None else source)*1e9)
        x, y, yaw = pose
        msg = NS(header=NS(stamp=NS(sec=ns//1000000000, nanosec=ns%1000000000)),
            pose=NS(pose=NS(position=NS(x=x-.07*math.cos(yaw), y=y-.07*math.sin(yaw)),
                orientation=NS(x=0., y=0., z=math.sin(yaw/2), w=math.cos(yaw/2)))),
            twist=NS(twist=NS(linear=NS(x=0.), angular=NS(z=0.))))
        self.c.odom_callback(msg)

    def prepare_handoff(self, pose=None, odom_pose=None, steering=None):
        recorded = HANDOFFS[0]
        pose = recorded['pose'] if pose is None else pose
        odom_pose = pose if odom_pose is None else odom_pose
        c = self.c
        self.receive_laser_pose(odom_pose)
        c.curve_locator.pose = tuple(pose)
        c.curve_locator.time = self.now
        c.curve_locator.hits = 4
        c.curve_pose_odom = tuple(odom_pose)
        c.curve_pose_stamp = c.curve_pose_odom_stamp = round(self.source_now*1e9)
        c.curve_pose_odom_alignment = 'SCAN_ALIGNED'
        c.last_lane_angular = recorded['steering'] if steering is None else steering
        c.last_lane_command_time = self.now-.05
        c.set_phase(c.SEEK_LIGHT)
        return c

    def test_recorded_handoffs_keep_the_small_left_correction(self):
        for row in HANDOFFS:
            with self.subTest(log=row['log']):
                c = self.c
                c.phase = c.ORBIT_CONE_2
                self.advance(.1)
                self.prepare_handoff(row['pose'], steering=row['steering'])
                command = c.lane_command()
                self.assertGreater(command.linear.x, 0.)
                self.assertGreater(command.angular.z, 0.)
                self.assertLessEqual(abs(command.angular.z), .08)
                self.assertLessEqual(abs(command.angular.z-row['steering']), .18*.05+1e-9)

    def test_forty_five_centimetre_left_wall_cannot_force_a_right_turn(self):
        c = self.prepare_handoff()
        c.left_distance = .45
        c.right_distance = .62
        c.center_error = -.085
        c.left_proximity = .33
        with patch.object(c, 'boundary_escape_state', side_effect=AssertionError('legacy escape used')), \
             patch.object(c, 'wall_direction_guard', side_effect=AssertionError('legacy side rule used')):
            command = c.lane_command()
        self.assertGreater(command.linear.x, 0.)
        self.assertGreater(command.angular.z, 0.)

    def test_ninety_centimetre_front_returns_straight_without_old_turn_vote(self):
        c = self.prepare_handoff((5.3, 3.55, 0.), steering=0.)
        c.front_clearance = c.boundary_front = .90
        c.preferred_side = -1
        command = c.lane_command()
        self.assertGreater(command.linear.x, 0.)
        self.assertAlmostEqual(command.angular.z, 0.)

    def test_real_front_standoff_stops_without_steering_toward_a_side(self):
        c = self.prepare_handoff()
        c.front_clearance = .64
        command = c.lane_command()
        self.assertEqual(command.linear.x, 0.)
        self.assertEqual(command.angular.z, 0.)

    def test_fresh_pose_continues_after_global_fit_expires(self):
        c = self.prepare_handoff()
        reference = copy.deepcopy(c.final_straight_reference)
        c.curve_locator.time = 1.
        c.curve_locator.pose = (3., .45, math.pi)
        c.curve_pose_odom = (-3., -2., -1.)
        c.lane_raw_time = 1.
        c.lane_band_upper = None
        c.lane_direction_hits = 0
        self.advance(.1)
        self.receive_laser_pose(HANDOFFS[0]['pose'])
        with patch.object(c, 'curve_pose_estimate', side_effect=AssertionError('old global TTL used')):
            command = c.lane_command()
        self.assertGreater(command.linear.x, 0.)
        self.assertGreater(command.angular.z, 0.)
        self.assertEqual(c.final_straight_reference, reference)

    def test_red_wait_keeps_the_same_lane_reference_on_restart(self):
        c = self.prepare_handoff()
        reference = copy.deepcopy(c.final_straight_reference)
        c.set_phase(c.RED_WAIT)
        c.publish_stop()
        c.curve_locator.pose = (4., 1., 1.4)
        c.curve_pose_odom = (11., 8., -1.)
        self.advance(.1)
        self.receive_laser_pose(HANDOFFS[0]['pose'])
        c.set_phase(c.FINISH_APPROACH)
        command = c.lane_command()
        self.assertEqual(c.final_straight_reference, reference)
        self.assertGreater(command.linear.x, 0.)
        self.assertGreater(command.angular.z, 0.)
        self.assertLessEqual(command.angular.z, .18*.1+1e-9)

    def test_no_aligned_odom_anchor_does_not_fall_back_to_legacy_lane(self):
        c = self.c
        c.curve_locator.pose = HANDOFFS[0]['pose']
        c.curve_locator.time = self.now
        c.curve_locator.hits = 4
        c.curve_pose_odom = None
        c.set_phase(c.SEEK_LIGHT)
        with patch.object(c, 'boundary_escape_state', side_effect=AssertionError('legacy fallback used')):
            command = c.lane_command()
        self.assertEqual(command.linear.x, 0.)

    def test_source_age_over_limit_stops_even_with_fresh_receipt(self):
        c = self.prepare_handoff()
        self.advance(1.2)
        self.receive_laser_pose(HANDOFFS[0]['pose'], source=1000.1)
        self.assertEqual(c.last_odom_time, self.now)
        self.assertEqual(c.lane_command().linear.x, 0.)

    def test_final_straight_does_not_reuse_the_long_curve_prediction_budget(self):
        c = self.prepare_handoff()
        self.advance(.6)
        self.receive_laser_pose(HANDOFFS[0]['pose'], source=1000.05)
        self.assertIsNotNone(c.curve_motion_at(round(self.source_now*1e9), self.now)[0])
        self.assertEqual(c.lane_command().linear.x, 0.)

    def test_nonfinite_terminal_anchor_stops_instead_of_creating_a_lane(self):
        c = self.c
        self.receive_laser_pose(HANDOFFS[0]['pose'])
        c.curve_locator.pose = (5.3, float('nan'), -.08)
        c.curve_locator.time = self.now
        c.curve_locator.hits = 4
        c.curve_pose_odom = HANDOFFS[0]['pose']
        c.set_phase(c.SEEK_LIGHT)
        self.assertIsNone(c.final_straight_reference)
        self.assertEqual(c.lane_command().linear.x, 0.)

    def test_future_source_stamp_cannot_authorize_motion(self):
        c = self.prepare_handoff()
        self.receive_laser_pose(HANDOFFS[0]['pose'], source=1000.1)
        self.assertEqual(c.lane_command().linear.x, 0.)

    def test_ros_clock_jump_cannot_authorize_motion(self):
        c = self.prepare_handoff()
        self.source_now += .3
        self.assertEqual(c.lane_command().linear.x, 0.)

    def test_source_prediction_uses_motion_instead_of_stale_received_pose(self):
        c = self.prepare_handoff((5.3, 3.55, .04), steering=0.)
        self.advance(.1)
        self.receive_laser_pose((5.35, 3.55, -.04))
        self.advance(.1)
        # Source yaw velocity is -0.8 rad/s, so present heading is about -0.12.
        # A reused historical heading would ask for a much smaller correction.
        command = c.lane_command()
        self.assertGreater(command.linear.x, 0.)
        self.assertGreater(command.angular.z, .02)

    def test_rotated_and_translated_odom_frame_preserves_correction(self):
        c = self.prepare_handoff((5.3, 3.50, -.08),
                                 odom_pose=(12., -7., math.pi/2-.08), steering=0.)
        command = c.lane_command()
        self.assertGreater(command.linear.x, 0.)
        self.assertGreater(command.angular.z, 0.)
        reference = c.final_straight_reference
        # Check geometrically by moving along the intended line in the ODOM
        # frame: east in track coordinates is north in this rotated frame.
        self.advance(.1)
        self.receive_laser_pose((11.95, -6.95, math.pi/2))
        c.last_lane_angular = 0.
        command = c.lane_command()
        self.assertAlmostEqual(command.angular.z, 0., places=7)
        self.assertEqual(c.final_straight_reference, reference)

    def test_mirrored_heading_and_lateral_error_reverse_the_correction(self):
        c = self.prepare_handoff((5.3, 3.63, .08), steering=0.)
        command = c.lane_command()
        self.assertLess(command.angular.z, 0.)
        self.assertGreater(command.linear.x, 0.)

    def test_speed_uses_existing_drive_command_limit(self):
        c = self.prepare_handoff()
        c.normal_speed = .31
        c.lane_straight_drive = .35
        self.assertAlmostEqual(c.lane_command().linear.x, .31)
        c.normal_speed = .35
        c.lane_straight_drive = .30
        self.assertAlmostEqual(c.lane_command().linear.x, .30)

    def test_paired_parallel_walls_provide_only_small_centre_refinement(self):
        c = self.prepare_handoff((5.3, 3.55, 0.), steering=0.)
        c.exit_spatial = [0.]*21
        c.exit_spatial[15:17] = [.55, .35]
        c.exit_current_wall = (0., 0., True, True)
        command = c.lane_command()
        self.assertGreater(command.angular.z, 0.)
        self.assertLess(command.angular.z, .01)

    def test_corner_walls_cannot_rotate_the_frozen_lane_direction(self):
        c = self.prepare_handoff((5.3, 3.55, 0.), steering=0.)
        reference = c.final_straight_reference
        c.exit_spatial = [0.]*21
        c.exit_spatial[15:17] = [.55, .35]
        c.exit_current_wall = (math.radians(18.), math.radians(18.), True, True)
        command = c.lane_command()
        self.assertEqual(command.angular.z, 0.)
        self.assertEqual(c.final_straight_reference, reference)

    def test_stale_paired_walls_cannot_refine_the_lane(self):
        c = self.prepare_handoff((5.3, 3.55, 0.), steering=0.)
        c.exit_spatial = [0.]*21
        c.exit_spatial[15:17] = [.55, .35]
        c.exit_current_wall = (0., 0., True, True)
        c.last_boundary_time = self.now-.30
        self.assertEqual(c.lane_command().angular.z, 0.)

    def test_unmodified_noncurve_route_keeps_legacy_dispatch(self):
        c = self.prepare_handoff()
        c.curve_route = False
        with patch.object(c, 'final_straight_command', side_effect=AssertionError('new mode escaped curve route')):
            c.lane_command()

    def one_control_tick(self):
        """Exercise production publishing priority without worker side effects."""
        c = self.c
        noops = ('entry_v34_poll_lane', 'curve_poll_registration', 'curve_poll_entry_plan',
                 'curve_update_scan_wait', 'curve_update_pose_wait', 'entry_prepare_update',
                 'update_phase')
        guards = ('relative_stop_reason', 'layout_stop_reason', 'departure_stop_reason')
        patches = [patch.object(c, name, return_value=None) for name in noops]
        patches += [patch.object(c, name, return_value='') for name in guards]
        for item in patches:
            item.start()
        try:
            c.last_route_status_time = self.now
            c.control_loop()
        finally:
            for item in reversed(patches):
                item.stop()
        return c.cmd_pub.messages[-1]

    def test_global_lidar_emergency_has_priority_over_final_straight(self):
        c = self.prepare_handoff()
        c.lidar_emergency = True
        with patch.object(c, 'lane_command', side_effect=AssertionError('lane called during emergency')):
            command = self.one_control_tick()
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))

    def test_red_wait_has_priority_over_final_straight(self):
        c = self.prepare_handoff()
        c.set_phase(c.RED_WAIT)
        with patch.object(c, 'lane_command', side_effect=AssertionError('lane called during red wait')):
            command = self.one_control_tick()
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))

    def test_missing_sensor_data_still_blocks_final_straight(self):
        c = self.prepare_handoff()
        c.last_lidar_time = self.now-2.
        with patch.object(c, 'lane_command', side_effect=AssertionError('lane called without lidar')):
            command = self.one_control_tick()
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))

    def read_final_diagnostic(self):
        """The diagnostic must not evaluate inactive entrance geometry."""
        c = self.c
        with patch.object(c, 'entry_gate_snapshot', side_effect=AssertionError('inactive entry gate used')), \
             patch.object(c, 'curve_pose_estimate', side_effect=AssertionError('expired curve pose used')):
            c.publish_entry_status(self.now)
        report = json.loads(c.entry_status_pub.messages[-1].data)
        self.assertEqual(report['status_scope'], 'FINAL_STRAIGHT')
        self.assertEqual(report['phase'], c.phase)
        self.assertEqual(report['monotonic_time'], self.now)
        self.assertNotIn('gates', report)
        return report['final_straight']

    def test_final_diagnostic_uses_current_source_age_without_entry_gates(self):
        c = self.prepare_handoff()
        c.lane_command()
        self.advance(.12)
        self.receive_laser_pose(HANDOFFS[0]['pose'], source=self.source_now-.10)
        status = self.read_final_diagnostic()
        self.assertAlmostEqual(status['odom_source_age_s'], .10)
        self.assertAlmostEqual(status['odom_receipt_age_s'], 0.)
        self.assertTrue(status['active'])
        self.assertGreater(status['issued_drive'], 0.)

    def test_red_wait_diagnostic_keeps_reference_and_reports_live_aging(self):
        c = self.prepare_handoff()
        c.lane_command()
        reference = c.final_straight_reference
        c.set_phase(c.RED_WAIT)
        c.publish_stop()
        self.advance(2.)
        status = self.read_final_diagnostic()
        self.assertEqual(status['reference'], list(reference))
        self.assertFalse(status['active'])
        self.assertAlmostEqual(status['odom_source_age_s'], 2.)
        self.assertAlmostEqual(status['odom_receipt_age_s'], 2.)
        self.assertEqual(status['state'], 'RED_WAIT')
        self.assertEqual((status['issued_drive'], status['issued_steering']), (0., 0.))

    def test_global_publish_stop_clears_previous_driving_diagnostic(self):
        c = self.prepare_handoff()
        c.lane_command()
        c.publish_stop()
        status = self.read_final_diagnostic()
        self.assertEqual(status['state'], 'CONTROL_STOP')
        self.assertEqual((status['issued_drive'], status['issued_steering']), (0., 0.))
        self.assertEqual((c.cmd_pub.messages[-1].linear.x, c.cmd_pub.messages[-1].angular.z), (0., 0.))

    def test_short_finish_travel_front_standoff_does_not_claim_finished(self):
        c = self.prepare_handoff()
        c.travel_distance = 10.
        c.set_phase(c.FINISH_APPROACH)
        c.travel_distance += .4
        c.front_clearance = .6
        command = c.lane_command()
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))
        status = self.read_final_diagnostic()
        self.assertEqual(status['state'], 'PARK_WAIT_REAL_MOTION')
        c.update_phase(self.now)
        self.assertEqual(c.phase, c.FINISH_APPROACH)
        self.assertEqual(len(c.finished_pub.messages), 0)

    def test_finish_travel_and_front_alone_cannot_claim_verified_parking(self):
        c = self.prepare_handoff()
        c.travel_distance = 10.
        c.set_phase(c.FINISH_APPROACH)
        c.travel_distance += c.finish_min_travel
        c.front_clearance = .6
        c.update_phase(self.now)
        self.assertEqual(c.phase, c.FINISH_APPROACH)
        self.assertFalse(c.finished_pub.messages)
        command = self.one_control_tick()
        self.assertEqual((command.linear.x, command.angular.z), (0., 0.))

    def test_independent_lagged_rollout_stays_in_corridor_for_both_recorded_handoffs(self):
        c = self.c
        all_cases = []
        for recorded in HANDOFFS:
            for mirror in (1., -1.):
                for speed in (recorded['speed'], .45, .75, 1.0):
                    for gain in (3.1, 4.4, 5.7):
                        with self.subTest(log=recorded['log'], mirror=mirror, speed=speed, gain=gain):
                            pose = [recorded['pose'][0],
                                    3.55+mirror*(recorded['pose'][1]-3.55),
                                    mirror*recorded['pose'][2]]
                            self.advance(.1)
                            c.phase = c.ORBIT_CONE_2
                            c.last_motion_stamp = None
                            c.last_odom_xy = c.last_yaw = None
                            c.curve_motion_samples.clear()
                            c.curve_motion_status = {}
                            c.final_straight_reference = None
                            self.prepare_handoff(tuple(pose), steering=mirror*recorded['steering'])
                            initial_x = pose[0]
                            response = c.last_lane_angular
                            minimum_clearance = 1.
                            peak_heading = 0.
                            max_input = 0.
                            dt = .05
                            # Independent integrator, no controller bridge or
                            # production command_horizon is used as the oracle.
                            with patch.object(c, 'curve_motion_at', side_effect=lambda *a: (
                                    tuple(pose), {'policy': 'SOURCE_MEASURED', 'odom_source_age_s': 0.})):
                                while pose[0]-initial_x < 2.0:
                                    command = c.final_straight_command(self.now)
                                    self.assertGreater(command.linear.x, 0.)
                                    request = command.angular.z
                                    self.assertLessEqual(abs(request), .08+1e-12)
                                    response = request+(response-request)*math.exp(-dt/.12)
                                    yaw_rate = speed*gain*response
                                    mid_yaw = pose[2]+.5*dt*yaw_rate
                                    pose[0] += speed*math.cos(mid_yaw)*dt
                                    pose[1] += speed*math.sin(mid_yaw)*dt
                                    pose[2] += yaw_rate*dt
                                    peak_heading = max(peak_heading, abs(pose[2]))
                                    max_input = max(max_input, abs(request))
                                    for longitudinal in (-.185, .20):
                                        for lateral in (-.15, .15):
                                            corner_y = pose[1]+longitudinal*math.sin(pose[2])+lateral*math.cos(pose[2])
                                            minimum_clearance = min(minimum_clearance, corner_y-3.1, 4.-corner_y)
                                    self.advance(dt)
                                    c.last_odom_time = self.now
                            self.assertGreater(minimum_clearance, .12)
                            self.assertLess(abs(pose[2]), math.radians(3.))
                            self.assertLess(abs(pose[1]-3.55), .08)
                            all_cases.append(dict(log=recorded['log'], mirror=mirror, speed=speed,
                                curvature_gain_per_m=gain, minimum_body_clearance_m=minimum_clearance,
                                final_lateral_m=pose[1]-3.55, final_yaw_rad=pose[2],
                                peak_heading_rad=peak_heading, maximum_steering=max_input))
        self.assertEqual(len(all_cases), 48)
        self.rollout_cases = all_cases


if __name__ == '__main__':
    unittest.main(verbosity=2)
