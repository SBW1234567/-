"""Current behavior plus inherited straight, crosswalk and collision checks."""
import unittest
import test_continuous
import test_straight
import test_sweep_gaps
import test_scan_seam
import test_uneven_wall
import test_registration_recovery
import test_entry_tolerant_control
import test_entry_plan_relaxed
import test_registration_relaxed
import test_curve_relaxed
import test_relaxed_handoff
import test_curve_response
import test_curve_prediction
import test_curve_control_response
import test_sweep_performance
import test_planning_recovery_v35_13
import test_collision_diagnostics_v35_13
import test_stopped_curve_recovery_v35_13
import test_controller_recovery_v35_13
import test_command_horizon_geometry_v35_13
import test_recorded_gain_v35_13

import test_body_guard_v35_14
import test_localization_v35_14
import test_upper_exit_v35_14
import test_motion_continuity_v35_14
import test_posix_packaging_v35_14
import test_real_shutdown_v35_14

import test_final_straight_v35_16
import test_crosswalk_timing_v35_15
import test_rollout_performance_v35_15
import test_rf2o_install_v35_15
import test_install_lock_v35_15

import test_recovery_cadence_v35_18
import test_crosswalk_vision_v35_18
import test_package_v35_23
import test_first_cone_dwell_v35_22
import test_finish_parking_v35_22
import test_finish_history_v35_23
import test_finish_parking_v35_23
import test_finish_dynamics_v35_23
import test_second_recovery_v35_21
import test_registration_latency_v35_21
import test_traffic_control_v35_20
import test_traffic_vision_v35_20
import test_second_cone_v35_19
import test_crosswalk_start_zone_v35_19
import test_approach_speed_v35_18

suite=unittest.TestSuite()
for module in (test_continuous,test_scan_seam,test_uneven_wall,test_registration_recovery,
    test_entry_tolerant_control,test_entry_plan_relaxed,test_registration_relaxed,
    test_curve_relaxed,test_relaxed_handoff,test_curve_response,
    test_curve_prediction,test_curve_control_response,test_sweep_performance,
    test_planning_recovery_v35_13,test_collision_diagnostics_v35_13,
    test_stopped_curve_recovery_v35_13,test_controller_recovery_v35_13,
    test_command_horizon_geometry_v35_13,test_recorded_gain_v35_13):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(test_sweep_gaps.SweepGapTests))
for test in unittest.defaultTestLoader.loadTestsFromTestCase(test_straight.StraightTests):
    if test._testMethodName not in ('test_task_and_collision_methods_unchanged',
                                    'test_geometry_only_approved_functions_changed'):
        suite.addTest(test)
for module in (test_body_guard_v35_14,test_localization_v35_14,test_upper_exit_v35_14,test_motion_continuity_v35_14,test_posix_packaging_v35_14,test_real_shutdown_v35_14):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
for module in (test_crosswalk_timing_v35_15,test_rollout_performance_v35_15,test_rf2o_install_v35_15,test_install_lock_v35_15):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_final_straight_v35_16))
for module in (test_recovery_cadence_v35_18, test_crosswalk_vision_v35_18, test_package_v35_23, test_approach_speed_v35_18, test_second_cone_v35_19, test_crosswalk_start_zone_v35_19, test_traffic_control_v35_20, test_traffic_vision_v35_20):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
for module in (test_second_recovery_v35_21, test_registration_latency_v35_21):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
for module in (test_first_cone_dwell_v35_22, test_finish_parking_v35_23, test_finish_dynamics_v35_23):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(test_finish_history_v35_23.compatibility_and_historical_suite())
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
