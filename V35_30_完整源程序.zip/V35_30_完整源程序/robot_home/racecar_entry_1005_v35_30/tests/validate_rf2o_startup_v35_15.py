#!/usr/bin/env python3
"""Launch the real RF2O executable in an isolated domain, without any sensors."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--executable', type=Path, required=True)
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
binary = args.executable.resolve()
env = dict(os.environ, ROS_DOMAIN_ID='217', ROS_LOCALHOST_ONLY='1')
command = [str(binary), '--ros-args', '-r', '__node:=codex_rf2o_startup_validation',
           '-p', 'laser_scan_topic:=/codex_validation/no_scan',
           '-p', 'odom_topic:=/codex_validation/odom', '-p', 'publish_tf:=false']
report = dict(passed=False, executable=str(binary), command=command,
              ros_domain_id=217, driver_started=False, sensors_started=False)
with tempfile.TemporaryFile(mode='w+b') as log:
    child = None
    try:
        if not binary.is_file() or not os.access(binary, os.X_OK):
            raise RuntimeError('RF2O executable missing or not executable')
        report['sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
        ldd = subprocess.run(['ldd', str(binary)], env=env, capture_output=True, text=True, timeout=10)
        report['ldd'] = ldd.stdout + ldd.stderr
        if ldd.returncode or 'not found' in report['ldd']:
            raise RuntimeError('RF2O shared libraries unavailable')
        child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True)
        started = time.monotonic()
        while time.monotonic()-started < 3.0 and child.poll() is None:
            time.sleep(.05)
        report['alive_after_observation'] = child.poll() is None
        if not report['alive_after_observation']:
            raise RuntimeError('RF2O exited during startup')
        child.send_signal(signal.SIGINT)
        report['exit_code'] = child.wait(timeout=8)
        if report['exit_code'] != 0:
            raise RuntimeError('RF2O did not shut down cleanly')
        log.seek(0)
        output = log.read().decode('utf-8', errors='replace')
        if 'V26_TF_READY' not in output or 'Waiting for laser_scans' not in output:
            raise RuntimeError('RF2O did not reach its scan-wait main loop')
        report['passed'] = True
    except Exception as exc:
        report['error'] = type(exc).__name__ + ': ' + str(exc)
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        log.seek(0)
        report['output'] = log.read().decode('utf-8', errors='replace')
args.report.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: report.get(key) for key in ('passed', 'sha256', 'exit_code', 'error')}))
raise SystemExit(0 if report['passed'] else 1)
