"""Historical-scan SE(2) bridge. No current-time prediction budget is widened."""
import ast
from collections import deque
import math
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as fixtures
cm,core=fixtures.cm,fixtures.core


class MotionContinuityV3526Tests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.ros=1000.65
        p=patch.object(cm.time,'monotonic',side_effect=lambda:self.now);p.start();self.addCleanup(p.stop)
        self.c=cm.RaceTaskController.__new__(cm.RaceTaskController)
        c=self.c;c.last_odom_time=100.;c.curve_odom_max_age=.80;c.curve_prediction_max_time=.95
        c.curve_motion_clock_sample=None;c.curve_pause_active=False;c.curve_prediction_pause=None
        c.curve_prediction_max_distance=.80;c.curve_prediction_max_turn=1.80
        c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=round(self.ros*1e9)))
        c.curve_control_prediction_enabled=True;c.curve_follower=object()
        c.curve_locator=NS(pose=(0.,0.,0.),time=100.,hits=3);c.curve_pose_odom=(0.,0.,0.)
        c.curve_pose_ttl=10.;c.curve_prediction_distance=8.;c.curve_prediction_yaw=6.
        c.rel_data={};c.lidar_emergency=False;c.curve_sweep_unknown_since=None;c.curve_sweep_diagnostics={}
        c.curve_body_stop_reason=lambda now:''
        self.history()

    def history(self, times=(0.,.3,.6), velocity=(.4,0.,.6)):
        c=self.c
        poses=[c.curve_integrate_motion((0.,0.,0.),velocity,t) for t in times]
        c.curve_motion_samples=deque((round((1000.+t)*1e9),*pose) for t,pose in zip(times,poses))
        c.curve_odom_samples=deque((1000.+t,*pose) for t,pose in zip(times,poses))
        c.curve_motion_velocity=velocity
        c.curve_motion_status=dict(velocity_policy='SOURCE_SE2')
        c.curve_scan_stamp=round(1000.4e9)
        return poses

    def bridge(self,t=.4,**kwargs):
        return self.c.curve_motion_at(round((1000.+t)*1e9),self.now,allow_scan_bridge=True,**kwargs)

    def scan(self,point=None):
        angle=-math.pi if point is None else math.atan2(point[1],point[0])
        scan=NS(ranges=[8.]*360,angle_min=angle,angle_max=angle+359*math.pi/180,
                angle_increment=math.pi/180,range_min=.05,range_max=10.)
        if point is not None:scan.ranges[0]=math.hypot(*point)
        self.c.curve_scan=scan;self.c.curve_scan_time=self.now
        return scan

    def test_old_gap_still_rejects_without_scan_opt_in(self):
        pose,detail=self.c.curve_motion_at(round(1000.4e9),self.now)
        self.assertIsNone(pose);self.assertEqual(detail['policy'],'SOURCE_INTERPOLATION_GAP')

    def test_real_pair_and_neighbor_restore_arc_without_changing_history(self):
        old=list(self.c.curve_motion_samples);pose,d=self.bridge()
        expected=self.c.curve_integrate_motion((0.,0.,0.),(.4,0.,.6),.4)
        for a,b in zip(pose,expected):self.assertAlmostEqual(a,b,12)
        self.assertEqual(d['policy'],'SOURCE_BRIDGED_BOUNDED')
        self.assertAlmostEqual(d['bridge_span_s'],.3)
        self.assertEqual(len(d['bridge_neighbors']),1)
        self.assertEqual(list(self.c.curve_motion_samples),old)
        self.assertGreater(d['bridge_position_error_m'],0.)
        self.assertGreater(d['bridge_yaw_error_rad'],0.)

    def test_total_pair_span_045_allowed_but_0451_rejected(self):
        for span,accepted in [(.45,True),(.451,False)]:
            self.history((0.,.3,.3+span),(.4,0.,.3));self.ros=1000.+.3+span+.05
            pose,d=self.bridge(.5)
            self.assertEqual(pose is not None,accepted)
            if not accepted:self.assertEqual(d['bridge_reason'],'PAIR_SPAN')

    def test_recorded_gap_scales_with_010_source_age_clear_short_scan_sweeps(self):
        # Interval scales observed in the run; constant-motion poses and raw
        # scans are synthetic, not a claimed complete sensor-message replay.
        for span in [.396,.307]:
            with self.subTest(span=span):
                self.history((0.,.3,.3+span),(.2,0.,.2));self.ros=1000.+.3+span+.10
                pose,d=self.bridge()
                self.assertIsNotNone(pose);self.assertAlmostEqual(d['odom_source_age_s'],.10,8)
                self.assertAlmostEqual(d['bridge_span_s'],span,8)
                scan=self.scan();h=pose[2]
                samples=[pose,(pose[0]+.15*math.cos(h),pose[1]+.15*math.sin(h),h)]
                ok,reason=self.c.curve_check_sweep(scan,pose,samples,self.now)
                self.assertTrue(ok);self.assertEqual(reason,'CLEAR_RAW')
                self.assertGreater(self.c.curve_sweep_diagnostics['bridge_extra_margin_m'],0.)
                self.assertLess(self.c.curve_sweep_diagnostics['bridge_extra_margin_m'],.06)

    def test_isolated_pair_cannot_claim_smooth_interpolation(self):
        self.history((.3,.6));pose,d=self.bridge()
        self.assertIsNone(pose);self.assertEqual(d['bridge_reason'],'NO_NEIGHBOR')

    def test_pair_translation_turn_speed_and_yaw_rate_bounds(self):
        cases=[((0.,.4,.8),(.8,0.,0.),.5), # .32m interval
               ((0.,.4,.8),(0.,0.,1.6),.5), # .64rad interval
               ((0.,.3,.6),(.91,0.,0.),.4),
               ((0.,.3,.6),(0.,0.,1.81),.4)]
        for times,v,t in cases:
            with self.subTest(v=v):
                self.history(times,v);self.ros=1000.+times[-1]+.05
                pose,d=self.bridge(t);self.assertIsNone(pose);self.assertEqual(d['bridge_reason'],'PAIR_MOTION')

    def test_neighbor_speed_and_yaw_disagreement_reject(self):
        for previous in [(.75,0.,.6),(.4,0.,-.1)]:
            self.history();a=list(self.c.curve_motion_samples)
            prev=self.c.curve_integrate_motion(tuple(a[1][1:]),previous,-.3)
            a[0]=(a[0][0],*prev);self.c.curve_motion_samples=deque(a)
            pose,d=self.bridge();self.assertIsNone(pose);self.assertEqual(d['bridge_reason'],'NEIGHBOR_DISAGREEMENT')

    def test_bad_adjacent_history_cannot_be_ignored(self):
        self.history((-.4,.3,.6));pose,d=self.bridge()
        self.assertIsNone(pose);self.assertEqual(d['bridge_reason'],'NEIGHBOR_MOTION')

    def test_receipt_source_and_clock_checks_still_apply(self):
        self.c.last_odom_time=99.;pose,d=self.bridge();self.assertIsNone(pose)
        self.assertEqual(d['policy'],'ODOM_RECEIPT_STALE')
        self.c.last_odom_time=100.;self.ros=1001.6;pose,d=self.bridge()
        self.assertIsNone(pose);self.assertEqual(d['bridge_reason'],'SOURCE_AGE')
        self.ros=1000.65;self.c.curve_motion_clock_sample=(100.,round(1000.3e9))
        pose,d=self.bridge();self.assertIsNone(pose);self.assertEqual(d['policy'],'SOURCE_CLOCK_CHANGED')

    def test_no_future_extrapolation_or_source_velocity_bypass(self):
        self.ros=1001.56
        pose,d=self.bridge(1.56);self.assertIsNone(pose);self.assertEqual(d['policy'],'SOURCE_PREDICTION_LIMIT')
        self.ros=1000.65;self.c.curve_motion_status['velocity_policy']='SOURCE_VELOCITY_REJECTED'
        pose,d=self.bridge();self.assertIsNone(pose);self.assertEqual(d['policy'],'SOURCE_VELOCITY_REJECTED')

    def test_margin_catches_raw_point_outside_original_padding(self):
        self.history(velocity=(0.,0.,0.));scan=self.scan((.5,.245));samples=[(0.,0.,0.),(.5,0.,0.)]
        self.assertFalse(core.scan_hits_body(scan,(0.,0.,0.),samples))
        ok,reason=self.c.curve_check_sweep(scan,(0.,0.,0.),samples,self.now)
        self.assertFalse(ok);self.assertEqual(reason,'SWEPT_OBSTACLE')
        d=self.c.curve_sweep_diagnostics
        self.assertGreater(d['bridge_extra_margin_m'],.015)
        self.assertLessEqual(d['bridge_extra_margin_m'],.06)
        self.assertAlmostEqual(d['margin_m'],.08+d['bridge_extra_margin_m'])

    def test_uncertainty_uses_full_lever_arm_and_refuses_excess(self):
        self.history(velocity=(0.,0.,0.));scan=self.scan()
        with patch.object(cm,'scan_hits_body',return_value=False) as hit:
            ok,reason=self.c.curve_check_sweep(scan,(0.,0.,0.),[(0.,0.,0.),(3.,0.,0.)],self.now)
        self.assertFalse(ok);self.assertEqual(reason,'SCAN_ODOM_ALIGNMENT');hit.assert_not_called()
        d=self.c.curve_sweep_diagnostics
        self.assertGreater(d['bridge_lever_arm_m'],3.)
        self.assertGreater(d['bridge_extra_margin_m'],.06)

    def test_clear_scan_accepts_with_extra_margin_then_does_not_cache_it(self):
        self.history(velocity=(0.,0.,0.));scan=self.scan();samples=[(0.,0.,0.),(.5,0.,0.)]
        ok,reason=self.c.curve_check_sweep(scan,(0.,0.,0.),samples,self.now)
        self.assertTrue(ok);self.assertEqual(reason,'CLEAR_RAW')
        self.assertGreater(self.c.curve_sweep_diagnostics['bridge_extra_margin_m'],0.)
        self.c.curve_scan_stamp=round(1000.6e9)
        ok,reason=self.c.curve_check_sweep(scan,(0.,0.,0.),samples,self.now)
        self.assertTrue(ok);self.assertEqual(self.c.curve_motion_status['scan_bridge'],{})
        self.assertNotIn('bridge_extra_margin_m',self.c.curve_sweep_diagnostics)

    def test_unknown_scan_keeps_inflated_fallback_checks(self):
        self.history(velocity=(0.,0.,0.));scan=self.scan();scan.ranges=[math.inf]*360
        self.c.curve_sweep_unknown_stamp=0;self.c.curve_sweep_clear_hits=0
        self.c.travel_distance=0.;self.c.last_yaw=0.
        with patch.object(cm,'scan_observes_body',return_value=(False,'SCAN_GEOMETRY')) as observe:
            ok,reason=self.c.curve_check_sweep(scan,(0.,0.,0.),[(0.,0.,0.),(.5,0.,0.)],self.now)
        self.assertFalse(ok);self.assertGreater(observe.call_args.kwargs['margin'],.08)

    def test_short_interpolation_and_prediction_match_fixed_v25(self):
        baseline=Path(__file__).parent/'baselines/controller_before_v35_26.py'
        tree=ast.parse(baseline.read_text(encoding='utf-8'))
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
        fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='curve_motion_at')
        ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(baseline),'exec'),cm.__dict__,ns)
        self.history((.3,.4,.5),(.4,0.,.6))
        for t in [.35,.4,.48,.6,.9,1.5]:
            expected,detail=ns['curve_motion_at'](self.c,round((1000.+t)*1e9),self.now)
            actual,current=self.c.curve_motion_at(round((1000.+t)*1e9),self.now,allow_scan_bridge=True)
            self.assertEqual(actual,expected);self.assertEqual(current,detail)


if __name__=='__main__':unittest.main()
