from collections import deque
"""Synthetic geometry and controller tests. No onboard scan replay claimed."""
import copy
import json
import math
import types
import unittest
from concurrent.futures import Future
from unittest.mock import patch
import numpy as np
import test_straight as t
import test_entry_quick as q

g=t.core


def scan(n=720, distance=2., angle_min=0.):
    return types.SimpleNamespace(ranges=[distance]*n,angle_min=angle_min,
        angle_increment=2*math.pi/n,range_min=.05,range_max=12.,
        header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=100,nanosec=0)))


PATH=[(float(x),0.,0.) for x in np.arange(0.,.651,.05)]


class SweepGapTests(unittest.TestCase):
    def check(self,s,path=PATH,allow=True):
        detail={}
        result=g.scan_observes_body(s,(0.,0.,0.),path,
                                   allow_small_gaps=allow,diagnostics=detail)
        self.assertEqual(detail['result'],result[1])
        json.dumps(detail,allow_nan=False)
        return result,detail

    def test_clear_scan_preserves_original_result(self):
        self.assertEqual(self.check(scan())[0],(True,'CLEAR'))

    def test_single_infinite_ray_supported(self):
        s=scan();s.ranges[0]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(True,'CLEAR_GAP_TOLERATED'))
        self.assertEqual(d['inferred_rays'],1)
        self.assertGreaterEqual(d['checked_rays'],20)

    def test_single_nan_ray_supported(self):
        s=scan();s.ranges[0]=math.nan
        self.assertTrue(self.check(s)[0][0])

    def test_two_adjacent_rays_supported(self):
        s=scan();s.ranges[0]=s.ranges[1]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(True,'CLEAR_GAP_TOLERATED'))
        self.assertEqual(d['inferred_rays'],2)

    def test_strict_default_still_rejects_single_missing_ray(self):
        s=scan();s.ranges[0]=math.inf
        self.assertEqual(g.scan_observes_body(s,(0.,0.,0.),PATH),(False,'SWEPT_UNKNOWN'))

    def test_one_degree_scan_single_ray_supported(self):
        s=scan(n=360);s.ranges[0]=math.inf
        self.assertEqual(self.check(s)[0],(True,'CLEAR_GAP_TOLERATED'))

    def test_three_adjacent_rays_rejected(self):
        s=scan();s.ranges[0:3]=[math.inf]*3
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'GAP_TOO_WIDE')

    def test_scan_blind_sector_rejected(self):
        s=scan();s.ranges[:100]=[math.inf]*100
        self.assertEqual(self.check(s)[0],(False,'SWEPT_UNKNOWN'))

    def test_all_missing_scan_rejected(self):
        for value in (math.inf,math.nan):
            s=scan();s.ranges=[value]*720
            self.assertEqual(self.check(s)[0],(False,'SWEPT_UNKNOWN'))

    def test_near_self_and_finite_out_of_range_not_filled(self):
        for value in (0.,.1,.29,-math.inf,13.):
            with self.subTest(value=value):
                s=scan();s.ranges[0]=value
                result,d=self.check(s)
                self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
                self.assertEqual(d['unknown_reason'],'INVALID_RANGE')

    def test_boundary_depth_discontinuity_rejected(self):
        s=scan();s.ranges[0]=math.inf;s.ranges[1]=s.ranges[2]=3.
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'DEPTH_EDGE')

    def test_support_needs_two_real_rays_each_side(self):
        s=scan();s.ranges[0]=s.ranges[2]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'NO_SUPPORT')

    def test_coarse_angular_gap_rejected(self):
        s=scan(n=180);s.ranges[0]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'GAP_ANGLE')

    def test_far_support_gap_rejected(self):
        s=scan(n=360,distance=5.);s.ranges[0]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'SUPPORT_TOO_FAR')

    def test_gap_width_at_future_body_rejected(self):
        s=scan(distance=4.);s.ranges[0]=math.inf
        result,d=self.check(s,[(3.,0.,0.)])
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'QUERY_GAP_WIDTH')

    def test_insufficient_inferred_clearance_rejected(self):
        s=scan(distance=.85);s.ranges[0]=math.inf
        result,d=self.check(s,[(.5,0.,0.)])
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'SUPPORT_CLEARANCE')

    def test_too_many_isolated_gaps_rejected(self):
        s=scan()
        for i in (0,10,20,710):s.ranges[i]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'GAP_COUNT_LIMIT')

    def test_sparse_query_fraction_limit_rejected(self):
        s=scan(n=360);s.ranges[0]=math.inf
        # Isolate a narrow footprint to exercise the global fraction limit.
        d={}
        result=g.scan_observes_body(s,(0.,0.,0.),[(.65,0.,0.)],margin=-.14,
                                   allow_small_gaps=True,diagnostics=d)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'GAP_FRACTION_LIMIT')

    def test_scan_edge_does_not_wrap_partial_scan(self):
        s=scan();s.ranges=s.ranges[:360];s.ranges[0]=math.inf
        result,d=self.check(s,[(.6,.2,0.)])
        self.assertFalse(result[0])
        self.assertEqual(result[1],'SWEPT_UNKNOWN')

    def test_full_circle_seam_support(self):
        s=scan();s.ranges[0]=s.ranges[-1]=math.inf
        self.assertEqual(self.check(s)[0],(True,'CLEAR_GAP_TOLERATED'))

    def test_nearly_full_scan_never_infers_across_unmeasured_seam(self):
        s=scan();s.ranges=s.ranges[:-2];s.ranges[0]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertEqual(d['unknown_reason'],'SCAN_EDGE')

    def test_negative_angle_min_supported(self):
        s=scan(angle_min=-math.pi);s.ranges[360]=math.inf
        self.assertEqual(self.check(s)[0],(True,'CLEAR_GAP_TOLERATED'))

    def test_observed_obstacle_still_rejected_despite_gap(self):
        s=scan();s.ranges[0]=math.inf;s.ranges[10]=.5
        self.assertEqual(self.check(s)[0],(False,'SWEPT_OBSTACLE'))

    def test_occluding_return_still_rejected(self):
        s=scan();s.ranges[0]=.4
        self.assertEqual(self.check(s,[(1.,0.,0.)])[0],(False,'SWEPT_OCCLUDED'))

    def test_raw_scan_never_mutated(self):
        s=scan();s.ranges[0]=math.inf;before=copy.deepcopy(s)
        self.check(s)
        self.assertEqual(s.ranges,before.ranges)
        self.assertEqual(s.header.stamp,before.header.stamp)

    def test_diagnostics_not_reused_as_observations(self):
        s=scan();s.ranges[0]=math.inf;d={}
        self.assertTrue(g.scan_observes_body(s,(0.,0.,0.),PATH,allow_small_gaps=True,diagnostics=d)[0])
        s.ranges=[math.inf]*720
        self.assertFalse(g.scan_observes_body(s,(0.,0.,0.),PATH,allow_small_gaps=True,diagnostics=d)[0])
        self.assertEqual(d['inferred_rays'],0)

    def test_reject_invalid_scan_geometry(self):
        for inc in (0.,-.01,math.nan):
            s=scan();s.angle_increment=inc
            self.assertEqual(self.check(s)[0],(False,'SCAN_GEOMETRY'))

    def test_default_matches_previous_version_over_varied_scans(self):
        old=q.baseline();rng=np.random.default_rng(9354)
        for i in range(100):
            s=scan();s.ranges=rng.uniform(.3,6.,720).tolist()
            if i%3==0:s.ranges[int(rng.integers(720))]=math.inf
            path=[(float(rng.uniform(.1,1.)),float(rng.uniform(-.5,.5)),float(rng.uniform(-.4,.4)))]
            self.assertEqual(g.scan_observes_body(s,(0.,0.,0.),path),
                             old.scan_observes_body(s,(0.,0.,0.),path))

    def test_real_obstacle_rejections_never_relaxed_in_random_scenes(self):
        old=q.baseline();rng=np.random.default_rng(435)
        rejected=0
        for _ in range(150):
            s=scan();s.ranges[0]=math.inf
            for k in rng.integers(0,720,15):s.ranges[int(k)]=float(rng.uniform(.3,1.2))
            before=old.scan_observes_body(s,(0.,0.,0.),PATH)
            after=self.check(s)[0]
            if before[1] in ('SWEPT_OBSTACLE','SWEPT_OCCLUDED'):
                rejected+=1;self.assertFalse(after[0])
        self.assertGreater(rejected,10)


class SweepControllerTests(unittest.TestCase):
    def setUp(self):
        t.ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=t.controller.RaceTaskController();self.addCleanup(self.c.close_curve_worker)

    def test_curve_path_and_command_checks_both_enable_tolerance(self):
        c=self.c
        c.curve_follower=types.SimpleNamespace(time=0.,path=None,horizon=lambda:PATH,
            command=lambda *args:None,output=.02,curvature=0.,lateral=0.)
        c.curve_locator.pose=(0.,0.,0.);c.curve_locator.time=100.
        c.curve_pose_scan=scan();c.last_route_status_time=100.
        with patch.object(t.controller,'scan_observes_body',return_value=(True,'CLEAR')) as check, \
             patch.object(t.controller,'command_horizon',return_value=PATH):
            c.curve_command(100.)
        self.assertEqual(check.call_count,2)
        for call in check.call_args_list:
            self.assertTrue(call.kwargs['allow_small_gaps'])

    def test_straight_sweep_call_remains_strict(self):
        import ast
        tree=ast.parse((t.SCRIPTS/'race_task_controller.py').read_text(encoding='utf-8'))
        calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)
               and isinstance(n.func,ast.Name) and n.func.id=='scan_observes_body']
        self.assertEqual(len(calls),4)
        self.assertEqual(sum(any(k.arg=='allow_small_gaps' for k in n.keywords) for n in calls),3)

    def test_entry_unknown_remains_recoverable_with_diagnostics(self):
        c=self.c;c.phase=c.SEEK_CONE_1
        c.entry_v33_braked=c.entry_hold=True;c.last_odom_xy=(5.,.7);c.last_yaw=.1;c.last_odom_time=100.
        pose=(5.2,.79,0.)
        c.curve_locator.pose=pose;c.curve_pose_scan=scan();c.curve_pose_scan.ranges=[math.inf]*720
        c.entry_plan_anchor=dict(pose=pose,started=100.,checked=100.,odom=(5.,.7,.1),samples=deque([(99.5,5.,.7,.1),(99.8,5.,.7,.1),(100.,5.,.7,.1)]),stamp=100.)
        c.entry_plan_ready=(q.g.plan_entry_path(pose),pose,((6.,2.),(2.,2.)),100.,c.curve_generation)
        with patch.object(c,'odom_is_still',return_value=True), \
             patch.object(c,'entry_gate_snapshot',return_value={'POSE':True,'FIRST_CONE':True}), \
             patch.object(c.curve_tracks,'ready',return_value=True):
            c.curve_update(100.1)
        self.assertIsNone(c.curve_follower)
        self.assertEqual(c.entry_plan_reason,'ENTRY_SWEPT_UNKNOWN')
        self.assertFalse(c.route_fault)
        self.assertEqual(c.curve_sweep_diagnostics['unknown_reason'],'GAP_TOO_WIDE')

    def test_supported_gap_handoff_and_first_curve_command(self):
        c=self.c;c.phase=c.SEEK_CONE_1
        c.entry_v33_braked=c.entry_hold=True;c.last_odom_xy=(5.,.7);c.last_yaw=.1;c.last_odom_time=100.
        pose=(5.2,.79,0.)
        c.curve_locator.pose=pose;c.curve_locator.time=100.1;c.curve_locator.hits=2
        s=q.scan_at(pose);s.ranges[0]=math.inf;c.curve_pose_scan=s
        path=q.g.plan_entry_path(pose)
        f=g.PathFollower(path,enable_integral=True);f.locate(pose)
        self.assertEqual(q.baseline().scan_observes_body(s,pose,f.horizon()),(False,'SWEPT_UNKNOWN'))
        c.entry_plan_anchor=dict(pose=pose,started=100.,checked=100.,odom=(5.,.7,.1),samples=deque([(99.5,5.,.7,.1),(99.8,5.,.7,.1),(100.,5.,.7,.1)]),stamp=100.)
        c.entry_plan_ready=(path,pose,((6.,2.),(2.,2.)),100.,c.curve_generation)
        with patch.object(c,'odom_is_still',return_value=True), \
             patch.object(c,'entry_gate_snapshot',return_value={'POSE':True,'FIRST_CONE':True}), \
             patch.object(c.curve_tracks,'ready',return_value=True), \
             patch.object(t.controller.time,'monotonic',return_value=100.12):
            c.curve_update(100.11)
        self.assertEqual(c.phase,c.ENTER_OBSTACLES)
        self.assertEqual(c.curve_sweep,'CLEAR_GAP_TOLERATED')
        self.assertEqual(c.curve_sweep_diagnostics['scope'],'ENTRY')
        c.curve_locator.time=100.15;c.last_route_status_time=100.16
        cmd=c.curve_command(100.16)
        self.assertGreater(cmd.linear.x,0.)
        self.assertFalse(c.route_fault)
        self.assertEqual(c.curve_sweep,'CLEAR_GAP_TOLERATED')
        self.assertEqual(c.curve_sweep_diagnostics['scope'],'COMMAND')
        s.ranges[:80]=[math.inf]*80;c.curve_locator.time=100.2
        self.assertEqual(c.curve_command(100.21).linear.x,0.)
        self.assertEqual(c.route_fault,'CURVE_SWEPT_UNKNOWN')


if __name__=='__main__':unittest.main(verbosity=2)
