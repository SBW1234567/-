"""Reproduce the 14:39 run's interrupted stopped-steering recovery.

Source intervals, stop pose, cone centres and handoff pose are recorded. The
CSV has no raw scans: geometry tests explicitly use handbook-board ray casts,
and stationary odometry isolates the timing failure rather than simulating a
new successful physical run.
"""
from collections import deque
import importlib.util
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_controller_recovery_v35_13 as recovery_fixture

cm,core=helpers.cm,helpers.core
STOP_POSE=(6.942719621151721,2.233915944550186,1.9708727836443458)
HANDOFF_POSE=(5.523274810781539,.9799511982515257,.07685270873781917)
CONES=((6.239052076006404,1.8988350910906415),(1.9873489789190333,1.988026952193528))
RECORDED_STAMPS=(1790923254816620582,1790923255018309584,1790923255321054170)


class RecoveryCadenceTests(unittest.TestCase):
    source=recovery_fixture.ControllerRecoveryTests.source
    inputs=recovery_fixture.ControllerRecoveryTests.inputs

    @classmethod
    def setUpClass(cls):
        # Preserve the original blocked normal horizon when testing recovery
        # cadence. V26's earlier geometry clears this fixed pose instead.
        # Only PATH is fixed: every controller/stop/raw check below is current.
        file=Path(__file__).parent/'baselines/core_before_v35_26.py'
        spec=importlib.util.spec_from_file_location('cadence_fixed_v25_geometry',file)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module)
        cls.path=module.plan_entry_path(HANDOFF_POSE,cones=CONES)

    def setUp(self):
        recovery_fixture.ControllerRecoveryTests.setUp(self)
        c=self.c
        c.curve_curvature_gain=5.
        f=c.curve_follower=core.PathFollower(self.path)
        f.index=min(range(len(self.path.samples)),key=lambda j:core.dist(self.path.samples[j],STOP_POSE))
        f.progress=float(self.path.lengths[f.index])
        c.curve_locator.pose=STOP_POSE;c.curve_pose_odom=STOP_POSE
        c.curve_odom_samples.clear();c.curve_motion_samples.clear();c.last_motion_stamp=0.
        for t in (999.0,999.3,999.6,999.9):self.source(t,STOP_POSE)
        self.inputs(STOP_POSE)

    def tick(self,dt=.1,source=None):
        self.now+=dt;self.ros_time+=dt
        if source is not None:self.source(source,STOP_POSE)
        self.inputs(STOP_POSE)
        return self.c.curve_command(self.now)

    def presteer(self):
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        # V24 prefers the stronger clear arc; cadence must preserve whichever
        # checked steering was actually selected, not the old .24 preference.
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertTrue(self.c.curve_recovery_state['preposition_required'])
        return command

    def test_recorded_201ms_then_303ms_does_not_erase_a_real_stop(self):
        # At elapsed 73.083 the original .5s crop retained only TWO poses.
        shifted=[s-RECORDED_STAMPS[-1]+999800000000 for s in RECORDED_STAMPS]
        self.c.curve_motion_samples=deque(((s,*STOP_POSE) for s in shifted),maxlen=8)
        self.assertEqual(len([s for s in shifted if shifted[-1]-s<=500000000]),2)
        self.assertTrue(self.c.curve_recovery_stopped(self.now))

    def test_half_second_boundary_retains_three_real_measurements(self):
        self.assertTrue(self.c.curve_recovery_stopped(self.now))
        samples=list(self.c.curve_motion_samples)
        self.assertEqual(len([a for a in samples if samples[-1][0]-a[0]<=500000000]),2)

    def test_recorded_stop_geometry_still_requires_a_different_checked_arc(self):
        f=self.c.curve_follower;f.command(STOP_POSE,self.now,5.,.32)
        self.assertAlmostEqual(f.lateral,-.1644,delta=.01)
        self.assertAlmostEqual(f.heading,.4536,delta=.02)
        self.assertAlmostEqual(f.progress,2.738,delta=.02)
        scan=helpers.scan_at(STOP_POSE)
        normal=core.command_horizon(STOP_POSE,f,5.,distance=.935,speed=.9)
        self.assertTrue(core.scan_hits_body(scan,STOP_POSE,normal))
        arc=core.constant_steer_horizon(STOP_POSE,.24,5.,distance=.65,speed=.9,initial_steer=.24)
        self.assertFalse(core.scan_hits_body(scan,STOP_POSE,arc))

    def test_sparse_source_cadence_can_finish_presteer_and_fresh_checked_launch(self):
        self.presteer();started=self.c.curve_recovery_state['started']
        commands=[]
        for i in range(1,9):
            # This alternates .3/.4s real source updates, matching the log's
            # cadence; fresh receipt alone never manufactures extra samples.
            source={3:1000.2,7:1000.6}.get(i)
            command=self.tick(.1,source)
            commands.append(command)
            if command.linear.x>0:break
            self.assertIsNotNone(self.c.curve_recovery_state)
            self.assertEqual(self.c.curve_recovery_state['started'],started)
        self.assertGreater(commands[-1].linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertGreaterEqual(self.c.curve_recovery_status['elapsed_s'],.60)
        self.assertLessEqual(self.c.curve_recovery_status['elapsed_s'],.81)

    def test_brief_scan_alignment_wait_keeps_zero_drive_and_original_dwell(self):
        self.presteer();state=self.c.curve_recovery_state
        started,checked=state['started'],state['checked_at']
        self.now+=.2;self.ros_time+=.2;self.source(1000.1,STOP_POSE);self.inputs(STOP_POSE)
        with patch.object(self.c,'curve_scan_pose',return_value=None):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,state['steer'])
        self.assertIs(self.c.curve_recovery_state,state)
        self.assertEqual(state['started'],started);self.assertEqual(state['checked_at'],checked)
        self.assertEqual(self.c.curve_recovery_status['state'],'PREPOSITION_WAIT_FRESH_SCAN')
        self.assertEqual(state['clear_hits'],0)

    def test_alignment_wait_cannot_refresh_itself_indefinitely(self):
        self.presteer();checked=self.c.curve_recovery_state['checked_at']
        steer=self.c.curve_recovery_state['steer']
        # V26 extends ONLY this zero-drive first-cone hold to a fixed 1.20s.
        # Fresh received samples cannot renew the original scan/proof time.
        for dt in (.20,.20,.20,.20,.20,.19,.02):
            self.now+=dt;self.ros_time+=dt
            self.source(self.ros_time-.1,STOP_POSE);self.inputs(STOP_POSE)
            with patch.object(self.c,'curve_scan_pose',return_value=None):
                command=self.c.curve_command(self.now)
            self.assertEqual(command.linear.x,0.)
            if self.now-checked<=1.20:
                self.assertAlmostEqual(command.angular.z,steer)
                self.assertEqual(self.c.curve_recovery_state['checked_at'],checked)
        self.assertEqual(command.angular.z,0.)
        self.assertIsNone(self.c.curve_recovery_state)

    def test_motion_long_source_gap_and_stale_receipt_still_reject_standstill(self):
        original=list(self.c.curve_motion_samples)
        for defect in ('translation','yaw','gap','receipt','source'):
            with self.subTest(defect=defect):
                c=self.c;c.curve_motion_samples=deque(original,maxlen=8)
                self.ros_time=1000.;c.last_odom_time=self.now
                if defect=='translation':
                    a=list(c.curve_motion_samples[-2]);a[1]+=.041;c.curve_motion_samples[-2]=tuple(a)
                elif defect=='yaw':
                    a=list(c.curve_motion_samples[-2]);a[3]+=.101;c.curve_motion_samples[-2]=tuple(a)
                elif defect=='gap':
                    c.curve_motion_samples=deque(((round(t*1e9),*STOP_POSE) for t in (998.9,999.2,999.9)),maxlen=8)
                elif defect=='receipt':c.last_odom_time=self.now-.36
                else:self.ros_time=1000.7
                self.assertFalse(c.curve_recovery_stopped(self.now))

    def test_pre_drive_measurements_cannot_confirm_standstill(self):
        self.c.curve_last_drive_time=self.now-.55
        self.assertFalse(self.c.curve_recovery_stopped(self.now))

    def test_data_hold_is_not_available_after_a_positive_drive(self):
        self.presteer()
        self.c.curve_last_drive_time=self.now+.01
        self.now+=.2;self.ros_time+=.2
        self.assertIsNone(self.c.curve_recovery_hold_command(self.now))

    def test_fault_emergency_movement_and_stale_source_do_not_hold_presteer(self):
        self.presteer();state=dict(self.c.curve_recovery_state)
        original=list(self.c.curve_motion_samples)
        for defect in ('fault','emergency','motion','receipt','source'):
            with self.subTest(defect=defect):
                c=self.c;c.curve_recovery_state=dict(state);c.route_fault='';c.lidar_emergency=False
                c.curve_body_guard_active=False;c.last_odom_time=self.now;self.ros_time=1000.
                c.curve_motion_samples=deque(original,maxlen=8)
                if defect=='fault':c.route_fault='TEST'
                elif defect=='emergency':c.lidar_emergency=True
                elif defect=='motion':
                    a=list(c.curve_motion_samples[-2]);a[2]+=.06;c.curve_motion_samples[-2]=tuple(a)
                # Only cached ZERO-drive holding now admits receipt <=.80s;
                # the genuine standstill test above still rejects .36s.
                elif defect=='receipt':c.last_odom_time=self.now-.81
                else:self.ros_time=1000.7
                self.assertIsNone(c.curve_recovery_hold_command(self.now))

    def test_an_actual_new_obstacle_still_blocks_a_settled_recovery(self):
        self.presteer()
        self.now+=.7;self.ros_time+=.7
        for source in (1000.2,1000.5):self.source(source,STOP_POSE)
        self.inputs(STOP_POSE)
        # Put a real return inside the chosen future arc. The timed presteer
        # alone cannot authorize motion against this new measurement.
        steer=self.c.curve_recovery_state['steer']
        arc=core.constant_steer_horizon(STOP_POSE,steer,5.,distance=.65,speed=.9,initial_steer=steer)
        x,y=core.local(arc[15],STOP_POSE)
        k=round((math.atan2(y,x)%(2*math.pi))/self.c.curve_scan.angle_increment)%len(self.c.curve_scan.ranges)
        self.c.curve_scan.ranges[k]=math.hypot(x,y)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertFalse(self.c.curve_recovery_status.get('arc_clear',False))

    def test_recorded_217ms_overrun_waits_then_uses_next_fresh_check(self):
        self.presteer();started=self.c.curve_recovery_state['started']
        self.now+=.7;self.ros_time+=.7
        for source in (1000.2,1000.5):self.source(source,STOP_POSE)
        self.inputs(STOP_POSE)
        original=self.c.curve_check_sweep
        def slow(*args):
            result=original(*args)
            self.now+=.10875;self.ros_time+=.10875
            return result
        with patch.object(self.c,'curve_check_sweep',side_effect=slow):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertGreater(self.c.curve_control_status['compute_ms'],200.)
        self.assertEqual(self.c.curve_recovery_state['started'],started)
        command=self.tick(.1,1000.9)
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])


if __name__=='__main__':unittest.main(verbosity=2)
