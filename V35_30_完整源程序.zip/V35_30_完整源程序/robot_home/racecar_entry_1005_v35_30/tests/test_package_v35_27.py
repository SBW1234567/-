"""V27 seven-file install/rollback checks using real payloads and temporary trees."""
import copy
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
import apply_patch as installer

class PackageV3527Tests(unittest.TestCase):
    def test_only_reviewed_runtime_functions_and_methods_change_against_v26(self):
        scope=json.loads((PACKAGE/'tests/v35_27_scope.json').read_text(encoding='utf-8'))
        self.assertTrue(scope['frozen'],'V27 runtime scope must be reviewed and frozen')
        for stem,filename in (('controller','race_task_controller.py'),('core','race_curve_core.py')):
            old=ast.parse((PACKAGE/'tests/baselines'/f'{stem}_before_v35_27.py').read_text(encoding='utf-8'))
            new=ast.parse((PACKAGE/'payload/src/racecar/scripts'/filename).read_text(encoding='utf-8').replace('OPTIONAL_MAP_ASSIST_1003_V35_27','FIRST_CONE_CONTINUITY_1002_V35_26'))
            def members(tree):
                functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
                methods={c.name+'.'+n.name:n for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef)}
                return functions,methods
            for kind,before,after in zip(('functions','methods'),members(old),members(new)):
                changed={n for n in before.keys() & after.keys() if ast.dump(before[n])!=ast.dump(after[n])}
                self.assertEqual(changed,set(scope[stem+'_changed_'+kind]),stem+' '+kind)
                self.assertEqual(after.keys()-before.keys(),set(scope[stem+'_new_'+kind]))
                self.assertEqual(before.keys()-after.keys(),set(scope[stem+'_removed_'+kind]))
            for tree in (old,new):
                tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef)]
                for c in tree.body:
                    if isinstance(c,ast.ClassDef):c.body=[n for n in c.body if not isinstance(n,ast.FunctionDef)]
            # New profile helpers may add imports/classes. Their residual module
            # AST is pinned separately after explicit review, never ignored.
            residual=ast.dump(new,include_attributes=False).encode('utf-8')
            self.assertEqual(hashlib.sha256(residual).hexdigest(),
                             scope[stem+'_module_ast_sha256'],stem+' imports/classes/constants changed outside frozen review')

    def test_v26_controller_baseline_and_rollback_remain_exact(self):
        expected='9ead8b82a31c216e253a4b65df12f119323200542b6de7117a279994f092ccaa'
        for relative in ('tests/baselines/controller_before_v35_27.py',
                         'rollback/src/racecar/scripts/race_task_controller.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_v26_core_baseline_and_rollback_remain_exact(self):
        expected='310e7f1901e736c788cc8b3936c211153df0b181adc09110d80c665d71e2665e'
        for relative in ('tests/baselines/core_before_v35_27.py',
                         'rollback/src/racecar/scripts/race_curve_core.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_original_v22_parking_test_source_is_preserved(self):
        old_tests=PACKAGE/'tests/test_finish_parking_v35_22.py'
        self.assertEqual(hashlib.sha256(old_tests.read_bytes()).hexdigest(),
                         '3e8575055c7fc69c74624bb9e8a7b9051127a3b757deb7932eeb018a57a48ab6')

    def test_first_cone_historical_comparison_keeps_exact_v21(self):
        path=PACKAGE/'tests/baselines/controller_before_v35_22.py'
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         'f3c8f5b1c2e1e666bac22452dfd7a9576805586a7c3b369ab4f31eda34197fbe')

    def test_vision_config_and_guard_retain_exact_v26(self):
        expected={
            'src/racecar/scripts/race_lidar_guard.py':'2651735dd452a24def8d00b3fbaf41c02df41b8df975852f745237b0395c2e4f',
            'src/racecar/scripts/ican_vision_node.py':'f06836a2f4fd71afbb921950fdb6dd90f822e844481dc1a2e9fb0f9456886e9a',
            'src/racecar/config/competition_params.yaml':'7adc3341f9a5adb57a9e1a58dc97d6dc28a1b725a3b0030c5105e4f74ea46852',
        }
        for relative,value in expected.items():
            for directory in ('payload','rollback'):
                with self.subTest(path=relative,directory=directory):
                    self.assertEqual(hashlib.sha256((PACKAGE/directory/relative).read_bytes()).hexdigest(),value)

    def test_historical_vision_calibration_keeps_original_v19_inputs(self):
        report=json.loads((PACKAGE/'CALIBRATION_V35_20.json').read_text(encoding='utf-8'))
        for filename,key in (('vision_before_v35_20.py','v19_source_sha256'),
                             ('competition_params_before_v35_20.yaml','v19_config_sha256')):
            self.assertEqual(hashlib.sha256((PACKAGE/'tests/baselines'/filename).read_bytes()).hexdigest(),report[key])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/scripts/ican_vision_node.py').read_bytes()).hexdigest(),report['v20_source_sha256'])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/config/competition_params.yaml').read_bytes()).hexdigest(),report['v20_config_sha256'])

    def test_runner_arguments_preserve_v26_except_explicit_slam_off(self):
        def function(path,name):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        current=function(PACKAGE/'launch_centered.py','make_command')
        lists=[n for n in ast.walk(current) if isinstance(n,ast.List)]
        additions=[n for sequence in lists for n in sequence.elts
                   if isinstance(n,ast.Constant) and n.value=='enable_slam:=false']
        self.assertEqual(len(additions),1)
        for sequence in lists:
            sequence.elts=[n for n in sequence.elts if n is not additions[0]]
        self.assertEqual(ast.dump(current),ast.dump(function(
            PACKAGE/'tests/baselines/launch_centered_before_v35_27.py','make_command')))
        runner=(PACKAGE/'run_v35_27.sh').read_text(encoding='utf-8')
        self.assertIn('RACE_DRY_RUN=${2:-true}',runner)
        self.assertIn('RACE_PREPARE_DRIVE=${3:-0.35}',runner)

    def test_install_and_rollback_snapshot_precedes_source_mutation(self):
        for filename,label,action in (
                ('install.sh','before-v35-27-install','--workspace "$RACE_WORKSPACE"\n'),
                ('rollback_v35_26.sh','before-v35-27-rollback-to-v35-26','--workspace "$RACE_WORKSPACE" --rollback')):
            shell=(PACKAGE/filename).read_text(encoding='utf-8')
            snapshot='python3 /home/bianbu/snapshot_vehicle_git.py --label '+label
            mutation='python3 "$PATCH_DIR/apply_patch.py" '+action
            with self.subTest(script=filename):
                self.assertIn('set -e\n',shell)
                self.assertIn('"$(readlink -f -- "$RACE_WORKSPACE")" != /home/bianbu/racecar',shell)
                self.assertLess(shell.index('--check'),shell.index(snapshot))
                self.assertLess(shell.index(snapshot),shell.index(mutation))

    def test_exact_seven_file_overlay_includes_both_launches_and_rollback(self):
        base,overlay,changes=installer.load_manifests()
        self.assertEqual(overlay['version'],'OPTIONAL_MAP_ASSIST_1003_V35_27')
        self.assertEqual(base['version'],overlay['base'])
        self.assertEqual(overlay['base'],'FIRST_CONE_CONTINUITY_1002_V35_26')
        self.assertEqual(len(changes),7)
        controller=(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py').read_text(encoding='utf-8')
        self.assertEqual(controller.count('OPTIONAL_MAP_ASSIST_1003_V35_27'),3)
        self.assertNotIn('FIRST_CONE_CONTINUITY_1002_V35_26',controller)
        baselines={item['path']:item for item in base['files']}
        for relative in ('src/racecar/scripts/ican_vision_node.py','src/racecar/config/competition_params.yaml',
                         'src/racecar/launch/race_competition.launch.py','src/racecar/launch/Run_explorer.launch.py'):
            self.assertIn(relative,changes)
            self.assertNotIn(relative,base['dependencies'])
            self.assertIsNotNone(changes[relative]['installed_path'])
            self.assertEqual(changes[relative]['installed_path'],baselines[relative]['installed_path'])

    def test_only_optional_slam_switch_changes_launches_and_defaults_stay_true(self):
        hashes={'Run_explorer.launch.py':'d10b4050b6c23a025077839cdb7eea05472f010e523671a2d4652532858ab43f',
                'race_competition.launch.py':'10af9e64911d05fb3633c289131f37b00896ceff9b9d90fe792a25267b3f4ecd'}
        for filename,expected in hashes.items():
            relative='src/racecar/launch/'+filename
            old=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual(hashlib.sha256(old).hexdigest(),expected)
            tree=ast.parse((PACKAGE/'payload'/relative).read_text(encoding='utf-8'))
            function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='generate_launch_description')
            actions=next(n for n in function.body if isinstance(n,ast.Return)).value.args[0].elts
            additions=[n for n in actions if isinstance(n,ast.Call)
                       and isinstance(n.func,ast.Name) and n.func.id=='DeclareLaunchArgument'
                       and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='enable_slam']
            self.assertEqual(len(additions),1)
            default=next(k.value for k in additions[0].keywords if k.arg=='default_value')
            self.assertEqual(ast.literal_eval(default),'true')
            actions.remove(additions[0])
            if filename=='Run_explorer.launch.py':
                assignments=[n for n in function.body if isinstance(n,ast.Assign)
                             and any(isinstance(t,ast.Name) and t.id=='enable_slam' for t in n.targets)]
                self.assertEqual(len(assignments),1)
                self.assertEqual(ast.dump(assignments[0].value),ast.dump(ast.parse("LaunchConfiguration('enable_slam')",mode='eval').body))
                function.body.remove(assignments[0])
                timers=[n for n in actions if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
                        and n.func.id=='TimerAction' and any(k.arg=='period' and ast.literal_eval(k.value)==2.0 for k in n.keywords)]
                self.assertEqual(len(timers),1)
                conditions=[k for k in timers[0].keywords if k.arg=='condition']
                self.assertEqual(len(conditions),1)
                self.assertEqual(ast.dump(conditions[0].value),ast.dump(ast.parse('IfCondition(enable_slam)',mode='eval').body))
                timers[0].keywords.remove(conditions[0])
            else:
                additions=[(n,i) for n in ast.walk(tree) if isinstance(n,ast.Dict)
                           for i,key in enumerate(n.keys) if isinstance(key,ast.Constant) and key.value=='enable_slam']
                self.assertEqual(len(additions),1)
                mapping,index=additions[0]
                self.assertEqual(ast.dump(mapping.values[index]),ast.dump(ast.parse("LaunchConfiguration('enable_slam')",mode='eval').body))
                mapping.keys.pop(index);mapping.values.pop(index)
            # The permitted switch is now removed; every original action,
            # parameter, topic, condition, RF2O setting and import must agree.
            self.assertEqual(ast.dump(tree),ast.dump(ast.parse(old)),filename)

    def fixture(self):
        base,overlay,changes=installer.load_manifests()
        base=copy.deepcopy(base)
        base['files']=[i for i in base['files'] if i['path'] in changes]
        cmake=b'project(racecar)\n'
        base['dependencies']={'src/racecar/CMakeLists.txt':hashlib.sha256(cmake).hexdigest()}
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name)/'racecar'
        for relative,data in [('src/racecar/CMakeLists.txt',cmake)]:
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for relative,item in changes.items():
            for name in (relative,item['installed_path']):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(PACKAGE/'rollback'/relative,target)
        loader=patch.object(installer,'load_manifests',return_value=(base,overlay,changes));loader.start();self.addCleanup(loader.stop)
        running=patch.object(installer,'active_race_processes',return_value=[]);running.start();self.addCleanup(running.stop)
        return root,changes

    def build_fixture(self,root,changes):
        for relative,item in changes.items():shutil.copyfile(root/relative,root/item['installed_path'])

    def test_all_seven_sources_and_installed_files_return_to_exact_v26(self):
        root,changes=self.fixture()
        installer.validate_tree(root,'original_v35',binaries=False)
        installer.copy_version(root,binaries=False)
        archives=list(root.parent.glob('racecar_before_entry_v35_27_*.tar.gz'))
        self.assertEqual(len(archives),1)
        with tarfile.open(archives[0]) as archive:
            self.assertEqual(set(archive.getnames()),set(changes))
            for relative in changes:
                self.assertEqual(archive.extractfile(relative).read(),(PACKAGE/'rollback'/relative).read_bytes())
        self.build_fixture(root,changes)
        installer.validate_tree(root,'v35',binaries=False)
        installer.copy_version(root,rollback=True,binaries=False)
        self.build_fixture(root,changes)
        installer.validate_tree(root,'original_v35',binaries=False)
        for relative,item in changes.items():
            expected=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual((root/relative).read_bytes(),expected)
            self.assertEqual((root/item['installed_path']).read_bytes(),expected)

    def test_unknown_installed_vision_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/changes['src/racecar/scripts/ican_vision_node.py']['installed_path']
        target.write_bytes(target.read_bytes()+b'\n# user edit\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
        self.assertEqual(list(root.parent.glob('racecar_before_*')),[])

    def test_unknown_yaml_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/'src/racecar/config/competition_params.yaml'
        target.write_bytes(target.read_bytes()+b'\n# user tuning\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

    def test_unknown_launch_source_or_install_is_rejected_before_any_write(self):
        root,changes=self.fixture()
        for relative in ('src/racecar/launch/Run_explorer.launch.py',
                         'src/racecar/launch/race_competition.launch.py'):
            for candidate in (relative,changes[relative]['installed_path']):
                with self.subTest(path=candidate):
                    target=root/candidate;original=target.read_bytes()
                    target.write_bytes(original+b'\n# unrecognized local edit\n')
                    before={r:(root/r).read_bytes() for r in changes}
                    with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
                        installer.copy_version(root,binaries=False)
                    self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
                    self.assertEqual(list(root.parent.glob('racecar_before_*')),[])
                    target.write_bytes(original)

    def test_active_car_is_not_modified(self):
        root,changes=self.fixture()
        before={r:(root/r).read_bytes() for r in changes}
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing race'):
                installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

if __name__=='__main__':unittest.main(verbosity=2)
