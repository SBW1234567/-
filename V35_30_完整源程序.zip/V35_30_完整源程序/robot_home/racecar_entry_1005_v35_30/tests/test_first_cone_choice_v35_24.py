"""First-cone strong-turn choice, with frozen-V23 counterfactuals.

Poses/cones are from the two actual V23 runs at 18:44 and 18:47. The exact
planner seed and raw scan were not logged: paths use the handoff observation;
scans independently raycast handbook walls/cones. The 3.05 m divider is an
explicit approximation to recorded obstacle hits (y=3.046..3.11), not a replay.
The simple physical plant checks geometrical reconnection, not motor dynamics.
"""
import ast
import copy
import math
from pathlib import Path
from types import MethodType
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_controller_recovery_v35_13 as fixture

cm,core=helpers.cm,helpers.core
START=(5.116100238911558,.8577469873121395,.0827633341223341)
CONES=((6.255646944484355,1.8973752623787639),(2.012965856140977,1.992860084615792))
EARLY=(7.078976892284957,1.9521394471066735,1.4020256442218708) # 42.030 s, before push
LATE=(6.97680166481864,2.2984077715514006,1.9236629786408928) # 60.029 s, before push
GOOD_START=(5.131206485460791,.8048386271332583,.12317388689406576)
GOOD_CONES=((6.254107967406535,1.8976104203826214),(2.010030271516804,1.988372342186228))
GOOD_POSES=((7.02826983080358,2.1023388236706295,1.7355065812070622),
            (6.958176512657641,2.239801097187665,1.9369113441433674),
            (6.708510919349001,2.5011158226131767,2.4167356858354427))
PATHS={}


class FirstConeChoiceV3524Tests(unittest.TestCase):
    source=fixture.ControllerRecoveryTests.source
    inputs=fixture.ControllerRecoveryTests.inputs

    def setUp(self):
        fixture.ControllerRecoveryTests.setUp(self)
        self.original_walls=tuple(core.WALLS)
        self.original_cones=tuple(core.CONES)
        self.configure()

    def configure(self,pose=EARLY,start=START,cones=CONES,board=3.05):
        walls=list(self.original_walls);walls[-1]=((4.8,board),(8.,board))
        core.WALLS=tuple(walls);core.CONES=cones
        self.addCleanup(setattr,core,'WALLS',self.original_walls)
        self.addCleanup(setattr,core,'CONES',self.original_cones)
        key=(start,cones)
        if key not in PATHS:
            # Planning stays on the configured nominal map; the scanner's
            # independent divider may be 5 cm inward, as hardware can be.
            with patch.object(core,'WALLS',self.original_walls):
                PATHS[key]=core.plan_entry_path(start,cones=cones)
        self.pose=tuple(pose);self.cones=cones;c=self.c
        c.phase=c.ORBIT_CONE_1;c.curve_curvature_gain=5.;c.curve_cones=cones
        f=c.curve_follower=core.PathFollower(PATHS[key])
        f.index=min(range(len(f.path.samples)),key=lambda j:core.dist(f.path.samples[j],pose))
        f.progress=float(f.path.lengths[f.index])
        c.curve_locator.pose=tuple(pose);c.curve_locator.time=self.now;c.curve_pose_odom=tuple(pose)
        c.curve_odom_samples.clear();c.curve_motion_samples.clear()
        c.last_motion_stamp=0.;c.last_odom_xy=None;c.last_yaw=None
        c.curve_last_drive_time=self.now-2.;c.last_lane_angular=0.;c.curve_drive=0.
        c.curve_recovery_state=None;c.curve_pause_active=False;c.curve_control_status={};c.route_fault=''
        for dt in (-.9,-.6,-.3,-.1):self.source(self.ros_time+dt,pose)
        self.inputs(pose);c.curve_pose_estimate(self.now)
        return f

    def bind_v23(self):
        path=Path(__file__).resolve().parent/'baselines/controller_before_v35_24.py'
        cls=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.ClassDef))
        node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='curve_obstacle_recovery')
        namespace=dict(cm.__dict__)
        exec(compile(ast.Module(body=[copy.deepcopy(node)],type_ignores=[]),str(path),'exec'),namespace)
        self.c.curve_obstacle_recovery=MethodType(namespace[node.name],self.c)

    def tick(self,pose,dt=.1):
        self.now+=dt;self.ros_time+=dt
        self.source(self.ros_time,pose);self.inputs(pose)
        c=self.c;c.curve_locator.pose=tuple(pose);c.curve_locator.time=self.now;c.curve_pose_odom=tuple(pose)
        return c.curve_command(self.now)

    def rollout(self,gain=5.,steps=140):
        pose=self.pose;servo=0.;trace=[];f=self.c.curve_follower
        for step in range(steps):
            command=self.tick(pose);target=command.angular.z
            mean=target+(servo-target)*.12/.1*(-math.expm1(-.1/.12))
            servo=target+(servo-target)*math.exp(-.1/.12)
            speed=.5 if command.linear.x>0. else 0.
            pose=self.c.curve_integrate_motion(pose,(speed,0.,speed*gain*mean),.1)
            self.assertTrue(core.body_clear(pose,cones=self.cones,margin=.02),(step,pose))
            self.assertFalse(self.c.route_fault)
            self.assertLessEqual(abs(target),.32)
            trace.append(dict(step=step,pose=pose,drive=command.linear.x,steer=target,
                recovery=self.c.curve_recovery_status.get('state')))
            if f.progress>=f.path.gates[1]-.05:return True,trace
        return False,trace

    def test_before_push_pose_prepositions_stronger_raw_clear_arc_at_zero_drive(self):
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)
        detail=self.c.curve_recovery_status
        self.assertTrue(detail['first_scope']);self.assertFalse(detail['second_scope'])
        self.assertTrue(detail['standstill']['valid'])
        self.assertEqual(detail['candidates'][0],dict(steer=.32,reason='CLEAR_RAW'))
        self.assertEqual(detail['state'],'STOPPED_STEERING_PREPOSITION')

    def test_frozen_v23_weak_choice_traps_at_same_early_pose_and_inward_divider(self):
        self.bind_v23();reached,trace=self.rollout()
        self.assertFalse(reached)
        self.assertAlmostEqual(trace[0]['steer'],.24)
        self.assertEqual(trace[-1]['drive'],0.)
        self.assertEqual(trace[-1]['recovery'],'NO_CLEAR_ARC')

    def test_strong_choice_reconnects_before_divider_at_nominal_and_high_gain(self):
        for gain in (5.,6.):
            with self.subTest(gain=gain):
                self.configure();reached,trace=self.rollout(gain)
                self.assertTrue(reached,trace[-1])
                self.assertLess(len(trace),60)
                self.assertEqual(trace[-1]['recovery'],'NORMAL_PATH_CLEAR')

    def test_first_successful_run_poses_remain_recoverable(self):
        for pose in GOOD_POSES:
            with self.subTest(pose=pose):
                self.configure(pose,GOOD_START,GOOD_CONES,board=3.1)
                reached,trace=self.rollout()
                self.assertTrue(reached,trace[-1])

    def test_already_late_real_pose_is_not_forced_into_measured_divider(self):
        self.configure(LATE)
        for _ in range(10):
            command=self.tick(LATE)
            self.assertEqual(command.linear.x,0.)
        self.assertEqual(self.c.curve_recovery_status['state'],'NO_CLEAR_ARC')
        self.assertEqual([d['steer'] for d in self.c.curve_recovery_status['candidates']],[.32,.28,.24])
        self.assertTrue(all(d['reason']=='SWEPT_OBSTACLE' for d in self.c.curve_recovery_status['candidates']))

    def test_low_physical_turn_gain_cannot_be_assumed_rescued(self):
        # A stronger preference cannot exceed hardware lock or eliminate a
        # genuine no-forward-space configuration. Preserve that limitation.
        reached,trace=self.rollout(4.)
        self.assertFalse(reached)
        self.assertEqual(trace[-1]['drive'],0.)

    def test_preposition_still_requires_six_tenths_and_fresh_scan(self):
        command=self.c.curve_command(self.now);started=self.c.curve_recovery_state['started']
        self.assertEqual(command.linear.x,0.)
        for _ in range(5):
            command=self.tick(EARLY)
            self.assertEqual(command.linear.x,0.)
        self.now+=.11;self.ros_time+=.11;self.source(self.ros_time,EARLY)
        self.c.curve_scan_time=self.now-.36
        command=self.c.curve_command(self.now)
        self.assertGreater(self.now-started,.6)
        self.assertEqual(command.linear.x,0.)
        for _ in range(10):
            command=self.tick(EARLY)
            if command.linear.x>0.:break
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])

    def test_no_extra_scan_work_for_first_clear_strong_candidate(self):
        original=self.c.curve_check_sweep;calls=[]
        def record(*args):calls.append(args[2]);return original(*args)
        with patch.object(self.c,'curve_check_sweep',side_effect=record):
            self.c.curve_command(self.now)
        # Normal feedback, settled candidate selection, actual-servo check.
        # No additional scan pass or longer rollout was added by V24.
        self.assertEqual(len(calls),3)
        self.assertEqual([len(s) for s in calls],[115,79,79])


if __name__=='__main__':unittest.main(verbosity=2)
