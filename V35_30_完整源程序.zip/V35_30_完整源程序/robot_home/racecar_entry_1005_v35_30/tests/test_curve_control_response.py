"""Controller timing, issued steering continuity, and actual obstacle checks."""
import math
import unittest
from unittest.mock import patch
import numpy as np
import test_continuous as helpers

cm, core, ros = helpers.cm, helpers.core, helpers.ros


class CurveControlResponseTests(unittest.TestCase):
    def setUp(self):
        self.clock = patch.object(cm.time, 'monotonic', return_value=100.).start()
        self.addCleanup(patch.stopall)
        ros.FakeNode.overrides = dict(curve_route=True, relative_route=True,
            exit_continuous=True, entry_v32_enabled=True, entry_v33_enabled=True,
            entry_v34_enabled=True, dry_run=True)
        self.c = cm.RaceTaskController()
        self.addCleanup(self.c.close_curve_worker)
        c = self.c
        c.phase = c.ENTER_OBSTACLES
        path = core.plan_entry_path((5.08, .864, .075))
        c.curve_follower = core.PathFollower(path, enable_integral=True)
        f = c.curve_follower
        index = int(np.searchsorted(path.lengths, 2.0))
        f.index = index; f.progress = float(path.lengths[index])
        self.pose = tuple(path.samples[index, :3])
        f.time = 99.8; f.output = .16
        c.last_lane_angular = .16; c.curve_last_drive_time = 99.8
        c.curve_scan = helpers.scan_at(self.pose)
        c.curve_scan_time = c.last_lidar_time = c.last_odom_time = 100.
        c.curve_scan_stamp = int(100e9)
        c.rel_data = dict(body_clear=True); c.rel_time = 100.
        # These tests isolate command completion timing. Source-clock and
        # scan/control frame prediction are exercised in test_curve_prediction.
        patch.object(c, 'curve_pose_estimate', return_value=self.pose).start()
        patch.object(c, 'curve_scan_pose', return_value=self.pose).start()

    def test_short_pause_has_zero_drive_and_preserves_issued_steering(self):
        cmd = self.c.curve_pause_command(100.)
        self.assertEqual(cmd.linear.x, 0.)
        self.assertAlmostEqual(cmd.angular.z, .16)
        self.assertAlmostEqual(self.c.curve_follower.output, .16)
        self.assertTrue(self.c.curve_pause_active)

    def test_steering_sign_is_applied_once_during_pause(self):
        self.c.steering_sign = -1.
        self.assertEqual(self.c.curve_pause_command(100.).angular.z, -.16)
        self.assertEqual(self.c.curve_pause_command(100.05).angular.z, -.16)
        self.assertEqual(self.c.last_lane_angular, .16)

    def test_long_pause_centres_and_cannot_extend_itself(self):
        self.c.curve_pause_command(100.)
        cmd = self.c.curve_pause_command(100.151)
        self.assertEqual(cmd.angular.z, 0.)
        self.assertEqual(self.c.curve_follower.output, 0.)

    def test_collision_emergency_and_fault_never_hold_steering(self):
        self.c.curve_static_body_guard_enabled=True
        for condition in ('sweep', 'body', 'emergency', 'fault'):
            with self.subTest(condition=condition):
                c=self.c;c.last_lane_angular=.16;c.curve_sweep='CLEAR_RAW'
                c.rel_data['body_clear']=True;c.lidar_emergency=False;c.route_fault=''
                if condition=='sweep':c.curve_sweep='SWEPT_OBSTACLE'
                elif condition=='body':c.rel_data['body_clear']=False
                elif condition=='emergency':c.lidar_emergency=True
                else:c.route_fault='TEST_FAULT'
                self.assertEqual(c.curve_pause_command(100.).angular.z, 0.)

    def test_default_static_body_diagnostic_preserves_short_pause_and_clear_control(self):
        c=self.c
        self.assertFalse(c.curve_static_body_guard_enabled)
        c.rel_data['body_clear']=False
        self.assertEqual(c.curve_stop_reason(100.),'')
        command=c.curve_pause_command(100.)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.16)
        ok,reason=c.curve_check_sweep(c.curve_scan,self.pose,[self.pose],100.)
        self.assertTrue(ok,reason)
        # Completion timing is the focus of this fixture; true raw obstacle
        # rejection is separately exercised below without this isolated gate.
        with patch.object(c,'curve_check_sweep',return_value=(True,'CLEAR_RAW')):
            command=c.curve_command(100.)
        self.assertGreater(command.linear.x,0.,c.curve_reason)

    def test_hard_stop_resets_even_after_soft_pause(self):
        self.c.curve_pause_command(100.)
        self.c.publish_stop()
        self.assertEqual(self.c.cmd_pub.messages[-1].angular.z, 0.)
        self.assertEqual(self.c.curve_follower.output, 0.)

    def test_resume_does_not_restart_at_00375(self):
        c=self.c;c.curve_pause_command(100.)
        self.clock.return_value=100.05
        with patch.object(c,'curve_check_sweep',return_value=(True,'CLEAR_RAW')):
            cmd=c.curve_command(100.05)
        self.assertGreater(cmd.linear.x,0.,c.curve_reason)
        self.assertGreater(cmd.angular.z,.16)
        self.assertLessEqual(abs(cmd.angular.z),c.curve_max_steer)

    def test_scan_expiring_during_compute_cannot_authorize_drive(self):
        c=self.c;c.curve_scan_time=99.8
        def slow(*args):
            self.clock.return_value=100.18
            return True,'CLEAR_RAW'
        with patch.object(c,'curve_check_sweep',side_effect=slow):
            cmd=c.curve_command(100.)
        self.assertEqual(cmd.linear.x,0.)
        self.assertIn('CURVE_RAW_SCAN_STALE',c.curve_reason)
        self.assertAlmostEqual(c.curve_control_status['compute_ms'],180.)

    def test_overrun_without_expired_scan_cannot_authorize_drive(self):
        c=self.c
        def slow(*args):
            self.clock.return_value=100.21
            return True,'CLEAR_RAW'
        with patch.object(c,'curve_check_sweep',side_effect=slow):
            cmd=c.curve_command(100.)
        self.assertEqual(cmd.linear.x,0.)
        self.assertIn('CURVE_CONTROL_OVERRUN',c.curve_reason)

    def test_current_command_start_replaces_old_timer_timestamp(self):
        self.clock.return_value=100.15
        with patch.object(self.c,'curve_check_sweep',return_value=(True,'CLEAR_RAW')):
            cmd=self.c.curve_command(99.8)
        self.assertGreater(cmd.linear.x,0.)
        self.assertEqual(self.c.curve_control_status['started'],100.15)

    def test_healthy_raw_check_skips_redundant_polar_grid(self):
        with patch.object(cm,'scan_observes_body',side_effect=AssertionError('redundant grid')):
            ok,reason=self.c.curve_check_sweep(self.c.curve_scan,self.pose,[self.pose],100.)
        self.assertTrue(ok,reason)
        self.assertEqual(reason,'CLEAR_RAW')

    def test_fast_path_still_rejects_real_return_in_future_body(self):
        c=self.c;pose=(5.,1.,0.);scan=helpers.scan_at(pose)
        scan.ranges[0]=.45;c.curve_scan=scan
        with patch.object(c,'curve_scan_pose',return_value=pose):
            ok,reason=c.curve_check_sweep(scan,pose,[pose,(5.4,1.,0.)],100.)
        self.assertFalse(ok)
        self.assertEqual(reason,'SWEPT_OBSTACLE')

    def test_fast_path_cannot_accept_invalid_metadata_or_all_missing(self):
        c=self.c
        for defect in ('increment','missing'):
            with self.subTest(defect=defect):
                scan=helpers.scan_at(self.pose);c.curve_scan=scan
                if defect=='increment':scan.angle_increment=0.
                else:scan.ranges=[math.inf]*720
                self.assertFalse(c.curve_check_sweep(scan,self.pose,[self.pose],100.)[0])


if __name__=='__main__':unittest.main(verbosity=2)
