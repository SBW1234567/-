"""Entry handoff and moving control with delayed observations, real ray casts."""
import math
import unittest
from collections import deque
from unittest.mock import patch
import test_continuous as helpers

cm,core,ros=helpers.cm,helpers.core,helpers.ros


class RelaxedHandoffTests(unittest.TestCase):
    def setUp(self):
        self.clock=patch.object(cm.time,'monotonic',return_value=100.)
        self.clock.start();self.addCleanup(self.clock.stop)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        # Handoff fixtures have synthetic source history and no ROS clock.
        self.c.curve_control_prediction_enabled=False
        c=self.c;c.phase=c.SEEK_CONE_1
        c.entry_v33_braked=c.entry_hold=c.entry_v34_turn_stop=True
        c.entry_v33_brake_since=90.
        self.start=(5.384,.843,.1395)
        c.curve_locator.pose=self.start;c.curve_locator.time=96.;c.curve_locator.hits=2
        c.curve_pose_odom=(0.,0.,0.);c.curve_pose_stamp=int(996e9)
        c.curve_pose_scan=helpers.scan_at(self.start)
        c.last_odom_xy=(.087,0.);c.last_yaw=.09
        c.last_odom_time=c.last_lidar_time=100.
        c.curve_odom_samples=deque([(1000.,.087,0.,.09)])
        c.odom_still_samples=deque([(99.5,.08,0.,.08),(100.,.087,0.,.09)])
        self.pose=c.curve_pose_estimate(100.)
        c.curve_scan=helpers.scan_at(self.pose);c.curve_scan_time=100.
        c.curve_scan_stamp=int(1000e9)
        c.rel_data=None;c.crosswalk_clear_count=0
        c.curve_cones=core.CONES

    def ready_path(self):
        c=self.c;path=core.plan_entry_path(self.start)
        c.entry_plan_anchor=dict(pose=self.start,started=91.,checked=100.,
            odom=(0.,0.,0.),samples=deque(c.odom_still_samples),stamp=1000.)
        c.entry_plan_ready=(path,self.start,core.CONES,91.,c.curve_generation)
        return path

    def test_ready_path_hands_off_after_nine_seconds_and_five_degree_drift(self):
        self.ready_path();c=self.c
        self.assertTrue(all(c.entry_gate_snapshot(100.).values()))
        c.curve_update(100.)
        self.assertEqual(c.phase,c.ENTER_OBSTACLES,c.curve_reason)
        self.assertIsNotNone(c.curve_follower)
        self.assertFalse(c.entry_hold)
        self.assertEqual(c.route_fault,'')
        command=c.curve_command(100.1)
        self.assertGreater(command.linear.x,0.,c.curve_reason)

    def test_fresh_actual_obstacle_blocks_handoff_without_discarding_path(self):
        self.ready_path();c=self.c
        scan=c.curve_scan
        index=round((0.-scan.angle_min)/scan.angle_increment)%len(scan.ranges)
        scan.ranges[index]=.45
        c.curve_update(100.)
        self.assertEqual(c.phase,c.SEEK_CONE_1)
        self.assertIsNone(c.curve_follower)
        self.assertIsNotNone(c.entry_plan_ready)
        self.assertEqual(c.curve_sweep,'SWEPT_OBSTACLE')
        self.assertEqual(c.route_fault,'')

    def test_old_derived_features_do_not_stop_live_raw_scan_and_odom(self):
        c=self.c;c.curve_follower=object();c.phase=c.ENTER_OBSTACLES
        c.curve_static_body_guard_enabled=True
        c.rel_data=dict(body_clear=False);c.rel_time=95.
        self.assertEqual(c.curve_stop_reason(100.),'')
        c.rel_time=100.
        self.assertEqual(c.curve_stop_reason(100.),'REL_BODY_OBSTRUCTION')

    def test_default_static_body_diagnostic_does_not_block_fresh_pose_and_raw_scan(self):
        c=self.c;c.curve_follower=object();c.phase=c.ENTER_OBSTACLES
        self.assertFalse(c.curve_static_body_guard_enabled)
        c.rel_data=dict(body_clear=False);c.rel_time=100.
        self.assertEqual(c.curve_stop_reason(100.),'')
        ok,reason=c.curve_check_sweep(c.curve_scan,self.pose,[self.pose],100.)
        self.assertTrue(ok,reason)
        self.assertEqual(c.route_fault,'')

    def test_pose_bridge_covers_full_turn_without_refreshing_wall_time(self):
        c=self.c;c.curve_odom_samples[-1]=(1000.,1.2,0.,math.pi/2)
        self.assertIsNotNone(c.curve_pose_estimate(100.))
        self.assertEqual(c.curve_locator.time,96.)
        c.last_odom_time=99.
        self.assertIsNone(c.curve_pose_estimate(100.))

    def test_healthy_scan_gaps_do_not_accumulate_a_motion_stop_budget(self):
        c=self.c
        for now,travel,yaw in ((100.,0.,0.),(101.,1.,.7),(105.,4.,2.0)):
            c.curve_scan_time=c.last_lidar_time=now;c.travel_distance=travel;c.last_yaw=yaw
            with patch.object(cm,'scan_observes_body',return_value=(False,'SWEPT_UNKNOWN')):
                ok,reason=c.curve_check_sweep(c.curve_scan,self.pose,[self.pose],now)
            self.assertTrue(ok,reason)
        c.curve_scan.ranges=[math.inf]*720
        with patch.object(cm,'scan_observes_body',return_value=(False,'SWEPT_UNKNOWN')):
            self.assertFalse(c.curve_check_sweep(c.curve_scan,self.pose,[self.pose],105.)[0])

    def test_scan_returns_are_transformed_from_acquisition_pose(self):
        c=self.c
        c.curve_odom_samples=deque([(1000.,0.,0.,0.),(1000.2,.2,0.,0.)])
        current=(5.584,.843,.1395)
        expected=core.bridge_pose(current,(.2,0.,0.),(0.,0.,0.))
        with patch.object(cm,'scan_hits_body',return_value=False) as hits, \
             patch.object(cm,'scan_observes_body',return_value=(True,'CLEAR')):
            c.curve_check_sweep(c.curve_scan,current,[current],100.)
        self.assertEqual(hits.call_args.args[1],expected)

    def test_old_unanchored_pose_before_braking_only_seeds_new_fits(self):
        c=self.c;c.curve_pose_odom=None;c.curve_locator.time=95.
        c.entry_v33_brake_since=96.
        with patch.object(c,'entry_is_stopped',return_value=True):
            self.assertIsNone(c.curve_pose_estimate(100.))
        self.assertEqual(c.curve_locator.time,95.)

    def test_old_entry_brake_evidence_cannot_authorize_unanchored_orbit_pose(self):
        c=self.c;c.curve_pose_odom=None;c.curve_locator.time=99.5
        c.phase=c.ORBIT_CONE_1;c.entry_hold=False;c.curve_follower=object()
        with patch.object(c,'entry_is_stopped',return_value=True):
            self.assertIsNone(c.curve_pose_estimate(100.))

    def test_local_wall_straight_branch_also_checks_actual_raw_obstacles(self):
        c=self.c;c.entry_hold=c.entry_v34_turn_stop=False
        c.curve_scan.ranges[0]=.45
        command=ros.Twist();command.linear.x=.35
        with patch.object(c,'centre_heading_command',return_value=command):
            issued=c.curve_straight_command(100.)
        self.assertEqual(issued.linear.x,0.)
        self.assertEqual(c.curve_sweep,'SWEPT_OBSTACLE')
        self.assertEqual(c.route_fault,'')

    def test_local_wall_straight_branch_keeps_calibrated_drive_when_clear(self):
        c=self.c;c.entry_hold=c.entry_v34_turn_stop=False
        command=ros.Twist();command.linear.x=.35
        with patch.object(c,'centre_heading_command',return_value=command):
            issued=c.curve_straight_command(100.)
        self.assertEqual(issued.linear.x,.35)


if __name__=='__main__':unittest.main(verbosity=2)
