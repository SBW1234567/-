"""Unpaired wall-fit handoff and slow-callback clock regressions.

Run with --candidate before integration; default imports the package's actual
controller. RF2O samples retain original source stamps through real callbacks.
"""
from concurrent.futures import Future
import importlib.util
import math
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import unittest
from unittest.mock import Mock,patch
import test_continuous as fixtures

cm,core,ros=fixtures.cm,fixtures.core,fixtures.ros
if '--candidate' in sys.argv:
    sys.argv.remove('--candidate')
    path=Path(__file__).resolve().parents[2]/'localization_work/race_task_controller.py'
    spec=importlib.util.spec_from_file_location('localization_v35_14_candidate',path)
    cm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=cm;spec.loader.exec_module(cm)


class LocalizationPairingTests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.ros_ns=round(1000.e9)
        patch.object(cm.time,'monotonic',side_effect=lambda:self.now).start()
        self.addCleanup(patch.stopall)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        c=self.c;c.phase=c.ENTER_OBSTACLES;c.curve_follower=object()
        c.curve_control_prediction_enabled=True
        c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=self.ros_ns))
        self.source(999.4,(.07,0.,0.));self.source(999.5,(.07,0.,0.))
        c.curve_locator.pose=(6.1362454,.9228870,.3930347)
        c.curve_locator.time=99.4;c.curve_locator.hits=5;c.curve_locator.reason='TRACKING'
        c.curve_pose_odom=(.07,0.,0.);c.curve_pose_stamp=round(999.4e9)
        c.curve_pose_odom_stamp=c.curve_pose_stamp;c.curve_pose_odom_alignment='SCAN_ALIGNED'
        c.curve_last_drive_time=99.85
        self.old_locator=c.curve_locator;self.old_anchor=c.curve_pose_odom

    def source(self,t,laser_pose=(.07,0.,0.)):
        ns=round(t*1e9);x,y,h=laser_pose
        msg=NS(header=NS(stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)),
            pose=NS(pose=NS(position=NS(x=x-.07*math.cos(h),y=y-.07*math.sin(h)),
                orientation=NS(x=0.,y=0.,z=math.sin(h/2),w=math.cos(h/2)))),
            twist=NS(twist=NS(linear=NS(x=0.),angular=NS(z=0.))))
        self.c.odom_callback(msg)

    def advance(self,dt):
        self.now+=dt;self.ros_ns+=round(dt*1e9)

    def completed_fit(self,stamp=999.9,received=99.95,accepted=True):
        locator=core.WallLocalizer(True)
        locator.pose=(6.1719530,.9401194,.4207858)
        locator.time=received;locator.hits=6;locator.reason='TRACKING'
        scan=fixtures.scan_at(locator.pose)
        future=Future();future.set_result((locator,accepted,.085))
        self.c.curve_job=(future,scan,received,round(stamp*1e9),self.c.curve_generation)
        return locator,scan

    def assert_old_anchor_intact(self):
        c=self.c
        self.assertIs(c.curve_locator,self.old_locator)
        self.assertEqual(c.curve_pose_odom,self.old_anchor)
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')
        self.assertEqual(c.curve_locator.time,99.4)

    def test_logged_unpaired_fit_keeps_previous_valid_moving_reference(self):
        self.completed_fit();self.c.curve_poll_registration(self.now)
        self.assert_old_anchor_intact()
        self.assertIsNotNone(self.c.curve_pose_estimate(self.now))
        self.assertIsNotNone(self.c.curve_pending_fit)
        self.assertEqual(self.c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')

    def test_late_same_scan_source_atomically_adopts_without_refreshing_time(self):
        locator,scan=self.completed_fit();c=self.c;c.curve_poll_registration(self.now)
        self.advance(.10);self.source(999.85);self.source(999.90)
        c.curve_poll_registration(self.now)
        self.assertIs(c.curve_locator,locator);self.assertIs(c.curve_pose_scan,scan)
        self.assertEqual(c.curve_pose_stamp,round(999.9e9))
        self.assertEqual(c.curve_pose_odom_stamp,round(999.9e9))
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')
        self.assertEqual(c.curve_locator.time,99.95)
        self.assertIsNone(c.curve_pending_fit)
        self.assertIsNotNone(c.curve_pose_estimate(self.now))

    def test_waiting_fit_does_not_chase_newer_unpaired_scans(self):
        self.completed_fit();c=self.c;c.curve_poll_registration(self.now)
        candidate=c.curve_pending_fit;executor=Mock()
        with patch.object(c,'curve_executor',executor):
            c.curve_submit_registration(fixtures.scan_at(self.old_locator.pose),self.now,round(1000.e9))
        executor.submit.assert_not_called()
        self.assertIs(c.curve_pending_fit,candidate)
        self.assertEqual(c.curve_registration_pending[2],round(1000.e9))

    def test_expired_pending_result_is_discarded_and_never_renews_old_pose(self):
        self.completed_fit();c=self.c;c.curve_poll_registration(self.now)
        self.advance(1.30);self.source(999.9)
        c.curve_poll_registration(self.now)
        self.assert_old_anchor_intact();self.assertIsNone(c.curve_pending_fit)
        self.assertEqual(c.curve_registration_status,'RESULT_TOO_OLD')

    def test_phase_generation_change_or_reset_discards_pending_fit(self):
        self.completed_fit();c=self.c;c.curve_poll_registration(self.now)
        c.curve_generation+=1;c.curve_poll_registration(self.now)
        self.assertIsNone(c.curve_pending_fit);self.assert_old_anchor_intact()
        self.completed_fit();c.curve_poll_registration(self.now)
        self.assertIsNotNone(c.curve_pending_fit)
        c.curve_reset_entry_pose();self.assertIsNone(c.curve_pending_fit)

    def test_rejected_fit_never_changes_valid_reference(self):
        self.completed_fit(accepted=False);self.c.curve_poll_registration(self.now)
        self.assert_old_anchor_intact()

    def test_captured_same_scan_pair_survives_worker_history_rollover(self):
        locator,_=self.completed_fit();c=self.c
        c.curve_job_odom=(round(999.9e9),c.curve_generation,(.17,.02,.03))
        c.curve_odom_samples.clear();c.curve_poll_registration(self.now)
        self.assertIs(c.curve_locator,locator)
        self.assertEqual(c.curve_pose_odom,(.17,.02,.03))
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')

    def stopped_sources(self):
        c=self.c;c.curve_last_drive_time=98.5
        c.curve_odom_samples.clear();c.curve_motion_samples.clear();c.last_motion_stamp=0
        for t in (999.3,999.4,999.5,999.6,999.7):self.source(t)

    def test_stationary_source_window_can_pair_a_post_stop_scan_with_real_stamp(self):
        self.stopped_sources();locator,_=self.completed_fit();c=self.c
        self.assertIsNone(c.curve_odom_at(round(999.9e9)))
        c.curve_poll_registration(self.now)
        self.assertIs(c.curve_locator,locator)
        self.assertEqual(c.curve_pose_odom_alignment,'STOPPED_ODOM_ANCHOR')
        self.assertEqual(c.curve_pose_odom_stamp,round(999.7e9))
        self.assertEqual(c.curve_pose_stamp,round(999.9e9))
        self.assertEqual(c.curve_locator.time,99.95)

    def test_pre_stop_measurements_cannot_pair_a_fresh_scan(self):
        self.stopped_sources();c=self.c;c.curve_last_drive_time=99.5
        self.completed_fit();c.curve_poll_registration(self.now)
        self.assert_old_anchor_intact();self.assertIsNotNone(c.curve_pending_fit)

    def test_scan_taken_before_stop_cannot_use_later_stationary_source_window(self):
        self.stopped_sources()
        self.assertIsNone(self.c.curve_registration_stopped_anchor(round(999.2e9),99.2,self.now))
        self.completed_fit(stamp=999.2,received=99.2)
        self.c.curve_poll_registration(self.now)
        self.assert_old_anchor_intact();self.assertIsNone(getattr(self.c,'curve_pending_fit',None))

    def test_current_clocks_remain_consistent_after_160ms_callback_computation(self):
        c=self.c;self.advance(.16)
        result,detail=c.curve_motion_at(round(999.9e9),100.)
        self.assertIsNotNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTED')
        self.assertAlmostEqual(detail['clock_error_s'],0.,places=7)
        self.assertAlmostEqual(detail['odom_source_age_s'],.66,places=7)

    def test_actual_ros_clock_jump_is_still_rejected(self):
        self.advance(.16);self.ros_ns+=round(.30e9)
        result,detail=self.c.curve_motion_at(round(999.9e9),100.)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'SOURCE_CLOCK_CHANGED')
        self.assertAlmostEqual(detail['clock_error_s'],.30,places=7)

    def test_old_callback_now_cannot_refresh_an_expired_odom_receipt(self):
        c=self.c
        self.now=99.30;self.ros_ns=round(999.30e9)
        c.curve_motion_samples.clear();c.curve_odom_samples.clear();c.last_motion_stamp=0
        self.source(999.0);self.source(999.1)
        self.advance(.86)
        # Callback start sees a .70s receipt age, but a 160ms calculation
        # makes the actual receipt .86s old. Source target remains the scan.
        result,detail=c.curve_motion_at(round(999.2e9),100.)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'ODOM_RECEIPT_STALE')
        self.assertAlmostEqual(self.now-c.last_odom_time,.86,places=7)
        self.assertEqual(detail['target_source_stamp'],round(999.2e9))

    def test_pause_elapsed_starts_when_current_clocks_are_read_after_computation(self):
        c=self.c;c.curve_motion_samples.clear();c.curve_odom_samples.clear();c.last_motion_stamp=0
        self.source(999.9);self.source(1000.)
        self.advance(.16);c.curve_pause_active=True
        result,detail=c.curve_motion_at(self.ros_ns,100.)
        self.assertIsNotNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTED')
        self.assertAlmostEqual(c.curve_prediction_pause[0],100.16,places=7)
        self.assertEqual(c.curve_prediction_pause[1],round(1000.16e9))
        self.advance(.50)
        result,detail=c.curve_motion_at(self.ros_ns,self.now)
        self.assertIsNotNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTED')
        self.advance(.11)
        result,detail=c.curve_motion_at(self.ros_ns,self.now)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'PRE_STOP_SOURCE_EXPIRED')

    def test_old_source_is_not_made_fresh_by_current_clock_pair(self):
        self.advance(.51)
        result,detail=self.c.curve_motion_at(self.ros_ns,100.)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(detail['odom_source_age_s'],1.01,places=7)

    def source_pair(self,speed=0.,yaw_rate=0.):
        """Fresh receipts of genuinely delayed original-source poses."""
        c=self.c;c.curve_motion_samples.clear();c.curve_odom_samples.clear()
        c.last_motion_stamp=0
        self.source(999.4,(.07-.1*speed,0.,-.1*yaw_rate))
        self.source(999.5,(.07,0.,0.))

    def test_default_850ms_straight_prediction_uses_real_source_velocity(self):
        self.source_pair(speed=.6);self.advance(.35)
        result,detail=self.c.curve_motion_at(self.ros_ns,self.now)
        self.assertEqual(self.c.curve_prediction_max_time,.95)
        self.assertIsNotNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTED')
        self.assertAlmostEqual(detail['prediction_dt_s'],.85,places=7)
        self.assertAlmostEqual(detail['prediction_distance_m'],.51,places=7)
        self.assertAlmostEqual(result[0],.58,places=7)

    def test_960ms_source_is_outside_the_default_window(self):
        self.source_pair(speed=.3);self.advance(.46)
        result,detail=self.c.curve_motion_at(self.ros_ns,self.now)
        self.assertIsNone(result)
        self.assertEqual(detail['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(detail['prediction_dt_s'],.96,places=7)

    def test_850ms_prediction_still_rejects_over_80cm_distance(self):
        self.source_pair(speed=1.);self.advance(.35)
        result,detail=self.c.curve_motion_at(self.ros_ns,self.now)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(detail['prediction_dt_s'],.85,places=7)
        self.assertAlmostEqual(detail['prediction_distance_m'],.85,places=7)

    def test_850ms_prediction_still_rejects_over_18rad_turn(self):
        self.source_pair(yaw_rate=2.5);self.advance(.35)
        result,detail=self.c.curve_motion_at(self.ros_ns,self.now)
        self.assertIsNone(result);self.assertEqual(detail['policy'],'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(detail['prediction_dt_s'],.85,places=7)
        self.assertAlmostEqual(detail['prediction_yaw_rad'],2.125,places=7)

    def test_slow_callback_can_still_check_its_real_fresh_raw_scan(self):
        c=self.c;pose=c.curve_locator.pose;scan=fixtures.scan_at(pose)
        ns=round(999.9e9);scan.header.stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)
        c.curve_scan=scan;c.curve_scan_stamp=ns;c.curve_scan_time=c.rel_time=self.now
        c.rel_data=dict(body_clear=True)
        self.advance(.16)
        clear,why=c.curve_check_sweep(scan,pose,[pose],100.)
        self.assertTrue(clear,why);self.assertEqual(why,'CLEAR_RAW')
        self.assertEqual(c.curve_motion_status['scan_pose_policy'],'SOURCE_PREDICTED')


if __name__=='__main__':unittest.main(verbosity=2)
