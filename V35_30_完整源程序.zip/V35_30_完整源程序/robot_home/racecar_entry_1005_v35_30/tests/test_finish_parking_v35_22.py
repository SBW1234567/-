"""Endpoint identity, physical standstill, delayed coasting and pulse bounds.

Scans raycast independent handbook walls. Rollouts are pressure tests, not a
calibrated motor model; the two logged post-neutral advances bound the cases.
"""
import math
import unittest
from types import SimpleNamespace as NS
from unittest.mock import patch

import test_continuous as helpers
import test_final_straight_v35_16 as straight

cm,core=helpers.cm,helpers.core


class FinishParkingV3522Tests(unittest.TestCase):
    setUp=straight.FinalStraightV3516Tests.setUp
    refresh_sensors=straight.FinalStraightV3516Tests.refresh_sensors
    advance=straight.FinalStraightV3516Tests.advance
    receive_laser_pose=straight.FinalStraightV3516Tests.receive_laser_pose

    def prepare(self, x=7., yaw=0., speed=0., delay=0.):
        c=self.c;self.pose=(x,3.55,yaw)
        c.curve_motion_samples.clear();c.curve_odom_samples.clear()
        c.curve_motion_velocity=None;c.curve_motion_status={}
        c.last_motion_stamp=0.;c.last_odom_xy=c.last_yaw=None;c.route_fault=''
        c.phase=c.SEEK_LIGHT
        c.final_straight_reference=(5.45,3.55,0.)
        c.final_straight_status=dict(track_reference=(5.45,3.55,0.))
        for dt in (-.2,-.1,0.):
            self.receive_laser_pose((x+speed*(dt-delay),3.55,yaw),source=self.source_now+dt-delay)
        c.set_phase(c.FINISH_APPROACH)
        self.scan()
        return c

    def scan(self, walls=None):
        c=self.c
        with patch.object(core,'WALLS',core.WALLS if walls is None else walls):
            scan=helpers.scan_at(self.pose)
        stamp=round(self.source_now*1e9)
        scan.header.stamp=NS(sec=stamp//1000000000,nanosec=stamp%1000000000)
        c.curve_scan_callback(scan)
        c.front_clearance=c.boundary_front=min(3.,min(r for i,r in enumerate(scan.ranges)
            if abs(cm.normalize_angle(scan.angle_min+i*scan.angle_increment))<=math.radians(25)))
        self.refresh_sensors()

    def tick(self, dt=.1, pose=None, delay=0., source=True, scan=True, walls=None):
        self.advance(dt)
        if pose is not None:self.pose=pose
        if source:self.receive_laser_pose(self.pose,source=self.source_now-delay)
        if scan:self.scan(walls)
        command=self.c.lane_command()
        return self.c.finish_parking_bound_command(command,self.now)

    def stopped_ticks(self, count=10, **kwargs):
        commands=[]
        for _ in range(count):commands.append(self.tick(**kwargs))
        return commands

    def test_true_board_requires_multiple_distinct_scan_sources(self):
        c=self.prepare(7.5)
        for _ in range(8):c.lane_command()
        self.assertFalse(c.finish_parking_status.get('valid'))
        self.assertEqual(c.finish_parking_status.get('board_hits'),1)
        self.stopped_ticks(3)
        self.assertTrue(c.finish_parking_status['valid'])

    def test_real_static_car_inside_box_finishes_only_after_standstill(self):
        c=self.prepare(7.52)
        self.stopped_ticks(4)
        c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)
        self.stopped_ticks(5)
        self.assertEqual(c.finish_parking_status['state'],'PARK_VERIFIED')
        c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISHED)
        self.assertTrue(c.finished_pub.messages[-1].data)

    def test_green_near_finish_does_not_need_another_metre(self):
        c=self.prepare(7.52);c.travel_distance=10.;c.finish_start_distance=10.
        self.stopped_ticks(9);c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISHED)

    def test_logged_early_close_object_is_not_an_endpoint(self):
        c=self.prepare(5.863)
        c.front_clearance=c.boundary_front=.627
        command=c.lane_command()
        self.assertEqual(command.linear.x,0.)
        c.travel_distance+=2.;c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)
        self.assertFalse(c.finish_parking_status['complete'])

    def test_broad_temporary_board_at_wrong_map_position_cannot_finish(self):
        c=self.prepare(6.3)
        fake=list(core.WALLS)+[((6.9,3.1),(6.9,4.))]
        self.stopped_ticks(12,walls=fake)
        self.assertEqual(c.finish_parking_status['reason'],'ENDPOINT_MAP_MISMATCH')
        self.assertEqual(c.finish_parking_status['issued_drive'],0.)
        c.update_phase(self.now);self.assertEqual(c.phase,c.FINISH_APPROACH)

    def test_narrow_object_cannot_supply_broad_wall_confirmation(self):
        c=self.prepare(7.52)
        walls=[((8.,3.43),(8.,3.67))]
        self.stopped_ticks(10,walls=walls)
        self.assertFalse(c.finish_parking_status['valid'])
        self.assertFalse(c.finish_parking_status['complete'])

    def test_source_and_receipt_ages_both_required(self):
        c=self.prepare(7.52)
        self.stopped_ticks(9)
        self.advance(.35);self.refresh_sensors();self.scan()
        self.assertEqual(c.lane_command().linear.x,0.)
        self.assertFalse(c.finish_parking_verified(self.now))

    def test_repeated_old_source_does_not_prove_standstill(self):
        c=self.prepare(7.52)
        self.stopped_ticks(12,source=False)
        self.assertFalse(c.finish_parking_status['complete'])
        self.assertFalse(c.finish_parking_settled(self.now))

    def test_stale_raw_scan_cannot_authorize_pulse_or_finished(self):
        c=self.prepare(7.52)
        self.stopped_ticks(12,scan=False)
        self.assertEqual(c.lane_command().linear.x,0.)
        self.assertFalse(c.finish_parking_verified(self.now))

    def test_new_range_jump_invalidates_previously_verified_completion(self):
        c=self.prepare(7.52)
        self.stopped_ticks(9);self.assertTrue(c.finish_parking_status['complete'])
        self.advance(.1);self.receive_laser_pose(self.pose)
        fake=list(core.WALLS)+[((7.82,3.1),(7.82,4.))]
        self.scan(fake);c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)

    def test_small_new_board_jump_must_pass_stable_window_again(self):
        c=self.prepare(7.52);self.stopped_ticks(9)
        self.assertTrue(c.finish_parking_status['complete'])
        self.advance(.1);self.receive_laser_pose(self.pose)
        fake=list(core.WALLS)+[((7.95,3.1),(7.95,4.))]
        self.scan(fake);c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)

    def test_active_pulse_and_moving_arrival_cannot_claim_finished(self):
        c=self.prepare(7.)
        while c.finish_parking['pulse_deadline'] is None:self.tick()
        # A moved-in/pushed pose never overrides the active pulse/settling gate.
        c.finish_parking_status.update(complete=True,updated=self.now)
        self.assertFalse(c.finish_parking_verified(self.now))
        self.tick(pose=(7.05,3.55,0.))
        self.assertFalse(c.finish_parking_status['complete'])

    def test_new_near_obstacle_blocks_even_when_end_board_is_identified(self):
        c=self.prepare(7.52);self.stopped_ticks(9)
        c.front_clearance=.31
        self.assertEqual(c.lane_command().linear.x,0.)
        self.assertFalse(c.finish_parking_status['complete'])
        self.assertEqual(c.finish_parking_status['state'],'PARK_FRONT_OBSTRUCTION')

    def test_body_window_and_wall_relative_heading(self):
        for x,yaw in ((7.72,0.),(7.40,0.),(7.52,math.radians(15))):
            with self.subTest(x=x,yaw=yaw):
                c=self.prepare(x,yaw);self.stopped_ticks(9)
                self.assertFalse(c.finish_parking_status['complete'])

    def test_body_inside_with_margins_finishes_without_extra_fixed_band(self):
        for distance in (.34,.56):
            with self.subTest(distance=distance):
                c=self.prepare(8.-distance)
                commands=self.stopped_ticks(9)
                self.assertTrue(all(cmd.linear.x==0. for cmd in commands))
                self.assertTrue(c.finish_parking_status['complete'])
                c.update_phase(self.now)
                self.assertEqual(c.phase,c.FINISHED)

    def test_board_tilt_changes_body_normal_not_frozen_lane_heading(self):
        c=self.prepare(7.52,math.radians(6))
        # End board normal is -6deg, body +6deg: 12deg disagreement, not6.
        tangent=math.tan(math.radians(6))
        walls=[w for w in core.WALLS if w!=((8.,0.),(8.,4.))]
        walls=[((8.+tangent*(3.1-3.55),3.1),(8.+tangent*(4.-3.55),4.))]
        self.stopped_ticks(9,walls=walls)
        self.assertAlmostEqual(abs(c.finish_parking_status['body_board_angle_rad']),math.radians(12),delta=.015)
        self.assertFalse(c.finish_parking_status['complete'])

    def test_first_pulse_is_low_and_deadline_is_rechecked_at_publication(self):
        c=self.prepare(7.)
        commands=self.stopped_ticks(8)
        positive=[x for x in commands if x.linear.x>0]
        self.assertTrue(positive)
        self.assertAlmostEqual(positive[0].linear.x,.28)
        deadline=c.finish_parking['pulse_deadline']
        if deadline is None:
            while c.finish_parking['pulse_deadline'] is None:self.tick()
            deadline=c.finish_parking['pulse_deadline']
        command=cm.Twist();command.linear.x=.28
        self.assertEqual(c.finish_parking_bound_command(command,deadline+.001).linear.x,0.)
        self.assertIsNone(c.finish_parking['pulse_deadline'])

    def test_delayed_publication_drops_the_positive_pulse(self):
        c=self.prepare(7.)
        while c.finish_parking['pulse_deadline'] is None:self.tick()
        command=cm.Twist();command.linear.x=.28
        previous_deadline=c.finish_parking['pulse_deadline']
        # Event-loop/publication delay; this cannot retract already-sent PWM,
        # but it must not issue a new positive value after the host deadline.
        self.advance(.20)
        self.assertGreater(self.now,previous_deadline)
        self.assertEqual(c.finish_parking_bound_command(command,self.now).linear.x,0.)
        self.assertFalse(c.finish_parking_verified(self.now))

    def test_no_second_pulse_until_new_source_standstill_after_neutral(self):
        c=self.prepare(7.)
        while c.finish_parking['pulse_deadline'] is None:self.tick()
        self.tick(.2)
        neutral=c.finish_parking['neutral_source']
        for _ in range(4):
            self.assertEqual(self.tick().linear.x,0.)
            self.assertEqual(c.finish_parking['neutral_source'],neutral)

    def test_ineffective_pulses_escalate_pwm_but_never_duration(self):
        c=self.prepare(7.);levels=[]
        previous=False
        for _ in range(42):
            command=self.tick();positive=command.linear.x>0
            if positive and not previous:levels.append(command.linear.x)
            previous=positive
        self.assertEqual(levels[:3],[.28,.30,.35])
        self.assertTrue(all(v<=.35 for v in levels))
        self.assertLessEqual(c.finish_parking['pulse_duration'],.15)

    def test_high_speed_entry_brakes_outside_box_and_point_four_runon_stays_out(self):
        for speed in (.85,1.03):
            with self.subTest(speed=speed):
                c=self.prepare(6.2,speed=speed,delay=.15)
                self.assertEqual(c.lane_command().linear.x,0.)
                for i in range(1,9):
                    # Independent stipulated coast .40m; cannot finish/pulse while moving.
                    position=6.2+.4*(1.-(1.-i/8.)**2)
                    self.assertEqual(self.tick(pose=(position,3.55,0.)).linear.x,0.)
                    self.assertFalse(c.finish_parking_status['complete'])
                self.assertGreater(8.-position,.80)

    def test_independent_delayed_motor_plant_parks_without_hitting_end_board(self):
        # Deliberately severe neutral response: tau=.39 yields .402m coast
        # at1.03m/s. PWM deadband and acceleration differ from the controller;
        # no controller distance/velocity is substituted for physical truth.
        self.rollout_results=[]
        for initial_speed in (.85,1.03):
            with self.subTest(initial_speed=initial_speed):
                c=self.prepare(6.2,speed=initial_speed,delay=.15)
                x=6.2;v=initial_speed;drive=0.;dt=.05;start=self.source_now
                samples=[(start+t,6.2+initial_speed*t) for t in (-.2,-.15,-.1,-.05,0.)]
                peak_x=x;pulses=0;last_positive=False
                for step in range(6000):
                    if drive>=.32:v+=(1.05-v)*(1.-math.exp(-dt/.18))
                    else:v*=math.exp(-dt/.39)
                    x+=v*dt;peak_x=max(peak_x,x)
                    self.advance(dt);samples.append((self.source_now,x))
                    old=next(p for p in reversed(samples) if p[0]<=self.source_now-.15+1e-8)
                    self.pose=(x,3.55,0.);self.receive_laser_pose((old[1],3.55,0.),source=old[0]);self.scan()
                    command=c.lane_command();command=c.finish_parking_bound_command(command,self.now)
                    drive=command.linear.x
                    if drive>0 and not last_positive:pulses+=1
                    last_positive=drive>0
                    c.update_phase(self.now)
                    if c.phase==c.FINISHED:break
                    self.assertLess(x+.20,8.,str((step,x,v,drive,c.finish_parking_status)))
                self.assertEqual(c.phase,c.FINISHED,(x,v,c.finish_parking_status))
                self.assertLessEqual(8.-x,.80-.185-.04+.01)
                self.assertGreaterEqual(8.-x,.20+.10-.01)
                self.assertLess(v,.05)
                self.rollout_results.append(dict(initial_speed=initial_speed,elapsed_s=self.source_now-start,
                    distance_m=8.-x,pulses=pulses,physical_peak_x=peak_x))

    def test_stationary_high_rate_source_history_can_cover_settle_window(self):
        c=self.prepare(7.52)
        self.stopped_ticks(22,dt=.05)
        self.assertTrue(c.finish_parking_status['complete'])

    def test_maximum_travel_is_a_fault_stop_not_false_success(self):
        c=self.prepare(7.);c.travel_distance=c.finish_start_distance+c.finish_max_travel
        c.update_phase(self.now)
        self.assertEqual(c.phase,c.ROUTE_FAULT)
        self.assertFalse(c.finished_pub.messages)

    def test_legacy_noncurve_finish_criterion_is_preserved(self):
        c=self.prepare(7.);c.curve_route=False;c.travel_distance+=c.finish_min_travel
        c.front_clearance=c.boundary_front=.6;c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISHED)


if __name__=='__main__':unittest.main()
