"""V25 local clockwise second-cone geometry and original-map certificates.

Recorded handoff observations approximate the unlogged planner seeds. Tests
compare actual planner selections against an immutable V24 implementation;
they do not claim to reconstruct the unrecorded laser scans or motor response.

V26 intentionally repairs the first-cone fallback. The V24 second-cone
counterfactual remains, while immutable V25 verifies every downstream sample.
"""
import importlib.util
import math
from pathlib import Path
import sys
import threading
import unittest
from unittest.mock import patch

import numpy as np
import test_continuous as helpers

core=helpers.core
BASE=Path(__file__).resolve().parent/'baselines/core_before_v35_25.py'
spec=importlib.util.spec_from_file_location('profile_baseline_v24',BASE)
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
spec25=importlib.util.spec_from_file_location('profile_baseline_v25',
    Path(__file__).resolve().parent/'baselines/core_before_v35_26.py')
v25=importlib.util.module_from_spec(spec25);sys.modules[spec25.name]=v25;spec25.loader.exec_module(v25)

CASES=(
 ('205457',(5.456715610182328,.9032474659520782,.20121850114427756),
  ((6.238521030908153,1.8877494035506248),(2.,2.))),
 ('205815',(4.33969794867755,.8053021858485518,.002057967945593768),
  ((6.259963477760678,1.8891729628084646),(1.9987357898010463,1.9957559444004978))),
 ('V23_success',(5.131206485460791,.8048386271332583,.12317388689406576),
  ((6.254107967406535,1.8976104203826214),(2.010030271516804,1.988372342186228))),
 ('V23_stall',(5.116100238911558,.8577469873121395,.0827633341223341),
  ((6.255646944484355,1.8973752623787639),(2.012965856140977,1.992860084615792))),
 ('V21_exit',(6.008109777254023,.7149543267907735,.027931131615782086),
  ((6.249381290595993,1.8911962175000991),(2.0033001900880767,1.9914508675155305))),
 ('V22_first_dwell',(5.565858938178845,.8601056696563996,.11761866582210344),
  ((6.239025302501285,1.8905091068437998),(1.9999683361858744,1.982182670712573))),
 ('nominal_wide',(4.523,.78,.025),((6.,2.),(2.,2.))),
)


class SecondProfileV3525Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.paths={name:(old.plan_entry_path(start,cones),core.plan_entry_path(start,cones))
                   for name,start,cones in CASES}

    def assert_certificate(self,path,cones):
        self.assertLessEqual(path.max_curvature,1/.55)
        self.assertLessEqual(float(np.max(np.diff(path.lengths))),.055)
        self.assertTrue(core.path_body_clear(path.samples,cones,margin=.10))
        turn=path.samples[480:801]
        self.assertLessEqual(float(np.max(turn[:,3])),.003)
        self.assertLessEqual(float(np.max(abs(turn[:,3]))),1/.55)
        self.assertEqual(path.upper_exit_start,path.gates[3])
        self.assertEqual(path.upper_straight_start,path.gates[4])
        self.assertTrue(path.upper_exit_family)

    def test_first_contract_preserves_successful_wide_and_second_profile_bit_for_bit(self):
        for name,start,cones in CASES:
            with self.subTest(name=name):
                before=v25.plan_entry_path(start,cones);after=self.paths[name][1]
                np.testing.assert_array_equal(before.samples[480:],after.samples[480:])
                if getattr(after,'entry_family',None) in ('EARLY_FIRST_CONE','CLEARANCE_RAMP_FIRST_CONE'):
                    self.assertIsNone(getattr(before,'entry_family',None))
                    self.assertLessEqual(after.first_half_max_curvature,1.35)
                    self.assertGreaterEqual(after.first_half_min_curvature,-.02)
                    self.assert_certificate(after,cones)
                else:
                    self.assertEqual(getattr(before,'entry_family',None),getattr(after,'entry_family',None))
                    np.testing.assert_array_equal(before.samples[:321],after.samples[:321])
                    np.testing.assert_array_equal(before.lengths[:321],after.lengths[:321])

    def test_every_recorded_and_nominal_plan_keeps_original_certificates(self):
        for name,_,cones in CASES:
            with self.subTest(name=name):self.assert_certificate(self.paths[name][1],cones)

    def test_real_fallback_flat_reverse_patch_exists_only_in_baseline(self):
        for name in ('205457','205815'):
            with self.subTest(name=name):
                before,after=self.paths[name]
                self.assertIsNone(getattr(before,'entry_family',None))
                old_turn=before.samples[480:801]
                self.assertGreater(float(np.max(old_turn[:,3])),.04)
                new_turn=after.samples[480:801]
                self.assertLessEqual(float(np.max(new_turn[:,3])),0.)
                # Remain clockwise while still facing the upper board. The
                # only gentle straightening is close to the eastward tangent.
                facing=new_turn[new_turn[:,2]>.25]
                self.assertLess(float(np.max(facing[:,3])),-.10)

    def test_five_cm_west_contraction_is_local_not_global_radius_scaling(self):
        for name,_,cones in CASES[:2]:
            with self.subTest(name=name):
                before,after=self.paths[name]
                self.assertAlmostEqual(after.samples[640,0]-before.samples[640,0],.05)
                self.assertAlmostEqual(after.samples[640,0],cones[1][0]-.97)
                self.assertAlmostEqual(after.samples[640,1],cones[1][1]+.60)
                np.testing.assert_allclose(after.samples[800,:3],(2.4,3.55,0.),atol=1e-12)
                np.testing.assert_array_equal(before.samples[480,:3],after.samples[480,:3])

    def test_second_knots_and_final_line_have_continuous_heading_and_curvature(self):
        for name,_,_ in CASES:
            with self.subTest(name=name):
                path=self.paths[name][1]
                np.testing.assert_allclose(path.samples[[480,640,800,960],3],(-.8,-1.2,0.,0.),atol=1e-12)
                np.testing.assert_allclose(path.samples[[480,640,800,960],2],
                                           (math.pi,math.pi/2,0.,0.),atol=1e-12)
                np.testing.assert_allclose(path.samples[800:,1],3.55,atol=1e-12)
                np.testing.assert_allclose(path.samples[800:,2:],0.,atol=1e-12)
                # No positional/heading jump at the sampling boundary.
                for knot in (480,640,800):
                    self.assertLess(abs(core.wrap(path.samples[knot,2]-path.samples[knot-1,2])),.04)
                # Check G2 continuity from the actual requested Hermite end
                # derivatives. Unequal parameter speeds are permitted; a
                # finite sample's curvature difference is not a G2 test.
                pieces=[];original=core.quintic
                def record(*args,**kwargs):
                    pieces.append(args);return original(*args,**kwargs)
                case=next(x for x in CASES if x[0]==name)
                with patch.object(core,'quintic',side_effect=record):
                    core.plan_entry_path(case[1],case[2])
                def curvature(v,a):return (v[0]*a[1]-v[1]*a[0])/math.hypot(*v)**3
                for left,right in zip(pieces[-6:-1],pieces[-5:]):
                    np.testing.assert_array_equal(left[1],right[0])
                    self.assertAlmostEqual(core.wrap(math.atan2(left[3][1],left[3][0])-
                                                     math.atan2(right[2][1],right[2][0])),0.,places=12)
                    self.assertAlmostEqual(curvature(left[3],left[5]),
                                           curvature(right[2],right[4]),places=12)

    def test_fallback_metadata_activates_existing_upper_exit_feedback(self):
        # V28's current selection may use its new first-cone bank; both it
        # and the still-reachable original fallback must carry exit metadata.
        with patch.object(core,'first_cone_clearance_paths',return_value=[]):
            fallback=core.plan_entry_path(*CASES[0][1:])
        self.assertIsNone(getattr(fallback,'entry_family',None))
        current=self.paths['205457'][1]
        np.testing.assert_array_equal(current.samples[480:],fallback.samples[480:])
        for path in (current,fallback):
            self.assert_certificate(path,CASES[0][2])
            follower=core.PathFollower(path)
            follower.index=640;follower.progress=float(path.lengths[640])
            follower.command(tuple(path.samples[641,:3]),1.,5.)
            self.assertTrue(follower.upper_exit_active)

    def test_direct_legacy_builder_stays_exact_when_profile_not_requested(self):
        start=CASES[0][1];cones=CASES[0][2]
        before=old.make_path(start,cones);after=core.make_path(start,cones)
        np.testing.assert_array_equal(before.samples,after.samples)
        np.testing.assert_array_equal(before.lengths,after.lengths)
        self.assertFalse(hasattr(after,'upper_exit_start'))

    def test_explicit_profiles_are_built_once_each_not_rewritten_after_validation(self):
        calls=[];built=[];original=core.make_path
        def observe(*args,**kwargs):
            calls.append(kwargs.get('second_exit_profile'))
            path=original(*args,**kwargs)
            built.append((path,path.samples.copy(),path.lengths.copy()))
            return path
        with patch.object(core,'make_path',side_effect=observe):
            path=core.plan_entry_path(*CASES[0][1:])
        self.assertTrue(calls);self.assertTrue(all(calls))
        # V28 builds a bounded three-candidate bank. Each returned candidate
        # passed make_path's full checks, and selection changes no geometry.
        self.assertEqual(len(calls),3)
        self.assertEqual(sum(candidate is path for candidate,_,_ in built),1)
        for candidate,samples,lengths in built:
            self.assert_certificate(candidate,CASES[0][2])
            np.testing.assert_array_equal(candidate.samples,samples)
            np.testing.assert_array_equal(candidate.lengths,lengths)
        self.assert_certificate(path,CASES[0][2])
        calls.clear();built.clear()
        with patch.object(core,'first_cone_clearance_paths',return_value=[]),patch.object(core,'make_path',side_effect=observe):
            fallback=core.plan_entry_path(*CASES[0][1:])
        self.assertEqual(calls,[True])
        self.assertIs(fallback,built[0][0])
        np.testing.assert_array_equal(fallback.samples,built[0][1])
        self.assert_certificate(fallback,CASES[0][2])

    def test_optimizer_fallback_also_propagates_profile_without_reconstruction(self):
        original=core.make_path;seen=[]
        def record(*args,**kwargs):
            seen.append(kwargs.get('second_exit_profile'))
            return original(*args,**kwargs)
        with patch.object(core,'make_path',side_effect=record):
            path=core.plan_path(CASES[0][1],CASES[0][2],second_exit_profile=True)
        self.assertTrue(all(seen));self.assert_certificate(path,CASES[0][2])

    def test_stop_request_is_checked_inside_candidate_construction(self):
        cancel=threading.Event();original=core.make_path;calls=[]
        def interrupt(*args,**kwargs):
            calls.append(1);cancel.set();return original(*args,**kwargs)
        with patch.object(core,'make_path',side_effect=interrupt):
            with self.assertRaises(core.PlanningInterrupted):
                core.plan_entry_path(CASES[0][1],CASES[0][2],cancel=cancel)
        self.assertEqual(len(calls),1)

    def test_deadline_cannot_return_a_plan_after_expiry(self):
        now=[100.]
        def clock():now[0]+=.001;return now[0]
        with patch.object(core.time,'monotonic',side_effect=clock):
            with self.assertRaises(core.PlanningInterrupted):
                core.plan_entry_path(CASES[0][1],CASES[0][2],deadline=100.007)
        self.assertLess(now[0],100.02)

    def test_reverse_curvature_is_rejected_even_without_body_check(self):
        with self.assertRaisesRegex(ValueError,'PATH_SECOND_REVERSE_CURVATURE'):
            core.make_path((5.,.75,0.),((6.,2.),(2.,3.2)),min_radius=.01,
                           check_body=False,second_exit_profile=True)

    def test_cone_offsets_keep_full_vehicle_and_curvature_certificate(self):
        start=CASES[0][1]
        for x in (1.90,2.0,2.10):
            for y in (1.90,2.,2.10):
                with self.subTest(x=x,y=y):
                    cones=(CASES[0][2][0],(x,y))
                    path=core.plan_entry_path(start,cones)
                    self.assert_certificate(path,cones)


if __name__=='__main__':unittest.main(verbosity=2)
