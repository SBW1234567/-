"""Earlier first-cone bank: actual seed bounds and unchanged second cone.

CSV records observations/command poses, not the worker's exact planning seed.
All three plausible seeds per run are tested; none is claimed as an exact
reconstruction of physical motion. Closed-loop tests live in first_loop.
"""
import math
import threading
import unittest
from unittest.mock import patch

import numpy as np
from test_second_profile_v35_25 import CASES, core, v25


RUNS=(
    ('222526',((6.240534537119169,1.8903501317074034),(2.,2.)),(
        (5.627845261655012,.8728320382266391,.18719406196258556),
        (5.71896016038828,.8966230391551078,.19563429866659293),
        (5.708055149358013,.9013844427284673,.21208608884753494))),
    ('222840',((6.253442312222965,1.900147422574186),(2.,2.)),(
        (5.202258422282525,.8009815607747888,.1621353835097364),
        (5.243480970441124,.8086774458189075,.16609993710015722),
        (5.234970812450709,.8055255055314384,.16518892744672414))),
)


class FirstProfileV3526Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records=[(run,cones,start,v25.plan_entry_path(start,cones),
                      core.plan_entry_path(start,cones))
                     for run,cones,seeds in RUNS for start in seeds]

    def test_actual_cones_make_old_wide_endpoint_limit_impossible(self):
        for _,cones,_,old,_ in self.records:
            radius=min(2.70,cones[0][1]+.70)-max(1.90,cones[0][1]-.15)
            self.assertGreater(1/radius,1.35)
            self.assertIsNone(getattr(old,'entry_family',None))
            self.assertGreater(float(np.max(abs(old.samples[:321,3]))),1.70)

    def test_all_latest_seed_bounds_select_earlier_certified_family(self):
        for run,_,start,_,path in self.records:
            with self.subTest(run=run,start=start):
                self.assertIn(path.entry_family,('EARLY_FIRST_CONE','CLEARANCE_RAMP_FIRST_CONE'))
                self.assertLessEqual(path.first_half_max_curvature,1.35)
                self.assertGreaterEqual(path.first_half_min_curvature,-.02)
                self.assertLessEqual(path.max_curvature,1/.55)

    def test_complete_vehicle_clearance_and_sample_spacing_are_unchanged(self):
        for run,cones,start,_,path in self.records:
            with self.subTest(run=run,start=start):
                self.assertTrue(core.path_body_clear(path.samples,cones,margin=.10))
                self.assertTrue(all(core.body_clear(tuple(p[:3]),cones,margin=.10)
                                    for p in path.samples))
                self.assertLessEqual(float(np.max(np.diff(path.lengths))),.055)
                self.assertTrue(np.isfinite(path.samples).all())

    def test_second_cone_all_samples_and_finish_line_remain_exact_v25(self):
        for run,_,start,old,path in self.records:
            with self.subTest(run=run,start=start):
                np.testing.assert_array_equal(old.samples[480:],path.samples[480:])
                self.assertEqual(path.upper_exit_start,path.gates[3])
                self.assertEqual(path.upper_straight_start,path.gates[4])
                np.testing.assert_allclose(path.samples[800,:3],(2.4,3.55,0.),atol=1e-12)

    def test_latest_turn_moves_inward_before_divider_without_global_scaling(self):
        for _,cones,_,old,path in self.records:
            self.assertLess(path.samples[160,0],old.samples[160,0])
            self.assertLess(path.samples[160,1],old.samples[160,1]+.005)
            # V28 may choose its certified lower north-side ramp bank. Keep
            # the original height as a ceiling, not an exact old coordinate.
            self.assertLessEqual(path.samples[320,1],min(2.70,cones[0][1]+.70)+1e-12)
            self.assertGreaterEqual(path.samples[160,0]-cones[0][0],.68-1e-12)
            self.assertLessEqual(path.samples[160,0]-cones[0][0],.90+1e-12)
            np.testing.assert_array_equal(path.samples[480:],old.samples[480:])

    def test_successful_old_wide_family_is_preserved_exactly(self):
        _,start,cones=CASES[-1]
        old=v25.plan_entry_path(start,cones);path=core.plan_entry_path(start,cones)
        self.assertEqual(old.entry_family,'WIDE_FIRST_CONE')
        self.assertEqual(path.entry_family,old.entry_family)
        np.testing.assert_array_equal(path.samples,old.samples)
        np.testing.assert_array_equal(path.lengths,old.lengths)

    def test_unavailable_early_bank_retains_certified_old_fallback(self):
        _,start,cones=CASES[0]
        old=v25.plan_entry_path(start,cones)
        # Exercise the unchanged old fallback when the new bank is absent.
        with patch.object(core,'first_cone_clearance_paths',return_value=[]):
            path=core.plan_entry_path(start,cones)
        self.assertIsNone(getattr(path,'entry_family',None))
        np.testing.assert_array_equal(path.samples,old.samples)
        self.assertTrue(core.path_body_clear(path.samples,cones,margin=.10))

    def test_small_measured_cone_offsets_retain_body_and_second_profile(self):
        for _,cones,seeds in RUNS:
            for dx,dy in ((-.03,0.),(.03,0.),(0.,-.03),(0.,.03)):
                shifted=((cones[0][0]+dx,cones[0][1]+dy),cones[1])
                with self.subTest(cones=shifted):
                    path=core.plan_entry_path(seeds[0],shifted)
                    old=v25.plan_entry_path(seeds[0],shifted)
                    self.assertTrue(core.path_body_clear(path.samples,shifted,margin=.10))
                    self.assertLessEqual(path.max_curvature,1/.55)
                    np.testing.assert_array_equal(path.samples[480:],old.samples[480:])

    def test_original_quintic_fallback_joins_have_exact_g2_end_derivatives(self):
        pieces=[];original=core.quintic
        def observe(*args,**kwargs):
            pieces.append(args);return original(*args,**kwargs)
        _,cones,seeds=RUNS[0]
        with patch.object(core,'quintic',side_effect=observe),patch.object(core,'first_cone_clearance_paths',return_value=[]):
            path=core.plan_entry_path(seeds[0],cones)
        pieces=pieces[-6:]
        def curvature(v,a):return (v[0]*a[1]-v[1]*a[0])/math.hypot(*v)**3
        for left,right in zip(pieces,pieces[1:]):
            np.testing.assert_array_equal(left[1],right[0])
            self.assertAlmostEqual(core.wrap(math.atan2(left[3][1],left[3][0])-
                math.atan2(right[2][1],right[2][0])),0.,places=12)
            self.assertAlmostEqual(curvature(left[3],left[5]),curvature(right[2],right[4]),places=12)
        for knot in (160,320,480):
            self.assertLess(abs(core.wrap(path.samples[knot,2]-path.samples[knot-1,2])),.04)

    def test_candidate_banks_keep_latest_search_to_at_most_three_complete_constructions(self):
        for _,cones,seeds in RUNS:
            for start in seeds:
                calls=[];original=core.make_path
                def observe(*args,**kwargs):
                    calls.append(kwargs);return original(*args,**kwargs)
                with patch.object(core,'make_path',side_effect=observe):
                    path=core.plan_entry_path(start,cones)
                self.assertLessEqual(len(calls),3)
                self.assertTrue(all(call['second_exit_profile'] for call in calls))
                self.assertIn(path.entry_family,('EARLY_FIRST_CONE','CLEARANCE_RAMP_FIRST_CONE'))

    def test_cancellation_interrupts_cheap_prefilter_before_full_build(self):
        event=threading.Event();original=core.quintic;calls=[]
        def interrupt(*args,**kwargs):
            event.set();return original(*args,**kwargs)
        _,cones,seeds=RUNS[0]
        with patch.object(core,'quintic',side_effect=interrupt),patch.object(core,'make_path') as build,patch.object(core,'first_cone_clearance_paths',return_value=[]):
            with self.assertRaises(core.PlanningInterrupted):
                core.plan_entry_path(seeds[0],cones,cancel=event)
            build.assert_not_called()

    def test_deadline_interrupts_prefilter_without_finishing_expired_path(self):
        now=[100.]
        def clock():now[0]+=.001;return now[0]
        _,cones,seeds=RUNS[0]
        with patch.object(core.time,'monotonic',side_effect=clock):
            with self.assertRaisesRegex(core.PlanningInterrupted,'PLAN_DEADLINE'):
                core.plan_entry_path(seeds[0],cones,deadline=100.007)
        self.assertLess(now[0],100.02)

    def test_collision_rejection_cannot_be_bypassed_by_early_bank(self):
        _,cones,seeds=RUNS[1]
        with patch.object(core,'path_body_clear',return_value=False):
            with self.assertRaisesRegex(ValueError,'ENTRY_NO_FEASIBLE_CURVE'):
                core.plan_entry_path(seeds[0],cones)


if __name__=='__main__':unittest.main(verbosity=2)
