"""Second-cone correction/recovery with explicit reconstruction limits.

The 15:09 CSV records the stopped pose, cones and tracking errors, but neither
the complete laser scan nor exact planner seed. Scans below independently ray
cast handbook boards and 12 cm cone circles. The path seeded at the recorded
handoff observation is a plausible fixture, NOT the unrecorded actual path.
Recorded feedback terms are tested separately from this geometry fixture.
"""
import math
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_controller_recovery_v35_13 as recovery_fixture

cm,core=helpers.cm,helpers.core
STOP=(2.475,1.478,2.905)
HANDOFF=(4.660378844610954,.6520576922655463,.007656657089257513)
CONES=((6.248668274553537,1.9139754014936834),(1.9868200290538467,1.9748094836429546))
PATH=None


def fixture_path():
    global PATH
    if PATH is None:PATH=core.plan_entry_path(HANDOFF,cones=CONES)
    return PATH


def follower_at(pose=STOP):
    path=fixture_path();f=core.PathFollower(path)
    f.index=min(range(len(path.samples)),key=lambda j:core.dist(path.samples[j],pose))
    f.progress=float(path.lengths[f.index]);f.command(pose,100.,5.,.32)
    return f


class SecondConeFollowerTests(unittest.TestCase):
    def test_recorded_opposing_preview_no_longer_overrules_large_heading_error(self):
        f=follower_at();f.heading=.53;f.lateral=.133
        error=f.heading+math.atan2(1.3*f.lateral,.65)
        recorded_ff=-.1559;feedback=.16*error
        self.assertLess(recorded_ff+feedback,0.)
        corrected=f.approach_feedforward(recorded_ff,error)
        self.assertAlmostEqual(corrected,.2*recorded_ff)
        self.assertGreater(corrected+feedback,.09)

    def test_first_cone_upper_exit_aligned_and_agreeing_steering_unchanged(self):
        f=follower_at();g=f.path.gates
        for progress,heading,lateral,ff,error in (
                (g[0],.53,.133,-.1559,.79),
                (g[3]+.1,.53,.133,-.1559,.79),
                (g[2]-.5,.10,.04,-.1559,.18),
                (g[2]-.5,.53,.133,.1559,.79)):
            with self.subTest(progress=progress,heading=heading,ff=ff):
                f.progress=progress;f.heading=heading;f.lateral=lateral
                self.assertEqual(f.approach_feedforward(ff,error),ff)

    def test_command_and_horizon_use_same_correction(self):
        f=follower_at();calls=[];original=core.PathFollower.approach_feedforward
        def capture(instance,ff,error):
            value=original(instance,ff,error)
            calls.append((instance.progress,value/ff if ff else 1.,value))
            return value
        with patch.object(core.PathFollower,'approach_feedforward',capture):
            f.command(STOP,100.1,5.)
            samples=core.command_horizon(STOP,f,5.,distance=.65,speed=.9)
        self.assertGreater(len(samples),20)
        self.assertGreater(len(calls),10)
        self.assertLess(calls[0][1],1.)
        self.assertTrue(any(scale<1. for _,scale,_ in calls[1:]))


class SecondConeRecoveryTests(unittest.TestCase):
    source=recovery_fixture.ControllerRecoveryTests.source
    inputs=recovery_fixture.ControllerRecoveryTests.inputs

    def setUp(self):
        recovery_fixture.ControllerRecoveryTests.setUp(self)
        patch.object(core,'CONES',CONES).start()
        c=self.c;c.phase=c.SEEK_CONE_2;c.curve_curvature_gain=5.;c.curve_cones=CONES
        c.curve_follower=follower_at();c.curve_follower.time=None
        c.curve_follower.output=c.curve_follower.response_output=0.
        c.curve_locator.pose=STOP;c.curve_pose_odom=STOP
        c.curve_odom_samples.clear();c.curve_motion_samples.clear();c.last_motion_stamp=0.
        c.last_odom_xy=None;c.last_yaw=None
        for t in (999.,999.3,999.6,999.9):self.source(t,STOP)
        self.inputs(STOP)
        c.curve_pose_estimate(self.now)
        c.curve_follower.command(STOP,self.now,5.)
        c.curve_control_status={}

    def recovery(self):
        return self.c.curve_obstacle_recovery(STOP,self.c.curve_follower,self.now)

    def advance(self,dt=.1):
        self.now+=dt;self.ros_time+=dt
        self.source(self.ros_time-.1,STOP);self.inputs(STOP)
        self.c.curve_pose_estimate(self.now)

    def test_synthetic_recorded_stop_rejects_toward_cone_and_lower_divider(self):
        f=self.c.curve_follower;scan=self.c.curve_scan
        for steer in (-.24,-.28,-.32,.32):
            with self.subTest(steer=steer):
                arc=core.constant_steer_horizon(STOP,steer,5.,distance=.65,initial_steer=steer)
                self.assertTrue(core.scan_hits_body(scan,STOP,arc))
                self.assertFalse(self.c.curve_second_recovery_geometry(STOP,f,arc)[0])
        arc=core.constant_steer_horizon(STOP,.16,5.,distance=.65,initial_steer=.16)
        self.assertFalse(core.scan_hits_body(scan,STOP,arc))
        self.assertTrue(self.c.curve_second_recovery_geometry(STOP,f,arc)[0])

    def test_opposite_arc_keeps_original_dwell_when_requested_sign_changes(self):
        f=self.c.curve_follower;f.ff=-.1559;f.p=.125;f.i=f.d=0.
        command=self.recovery();self.assertIsNotNone(command)
        self.assertEqual(command.linear.x,0.);self.assertAlmostEqual(command.angular.z,.16)
        state=self.c.curve_recovery_state;started=state['started']
        for sign in (1.,-1.,1.,-1.,1.,-1.,1.):
            self.advance();f.ff=sign*.03;f.p=f.i=f.d=0.
            command=self.recovery();self.assertIsNotNone(command)
            self.assertIs(self.c.curve_recovery_state,state)
            self.assertEqual(state['started'],started)
            self.assertAlmostEqual(command.angular.z,.16)
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])

    def test_selected_alternative_cannot_continue_beyond_one_metre(self):
        self.recovery();state=self.c.curve_recovery_state
        state['origin_progress']=self.c.curve_follower.progress-1.01
        self.assertIsNone(self.recovery())
        self.assertEqual(self.c.curve_recovery_status['state'],'SECOND_RECOVERY_DISTANCE_BOUND')

    def test_stale_source_cannot_launch_alternative(self):
        self.recovery();self.advance(.7)
        self.c.last_odom_time=self.now-.8
        self.assertIsNone(self.recovery())

    def test_moving_alternative_uses_actual_servo_response(self):
        c=self.c;f=c.curve_follower
        c.curve_last_drive_time=self.now-.05;c.curve_motion_status['speed_mps']=.5
        f.response_output=-.32
        # V21's additional +.28 candidate is clear even with the real
        # initially opposite servo. The weaker arcs remain obstructed.
        command=self.recovery()
        self.assertIsNotNone(command);self.assertGreater(command.linear.x,0.)
        candidates=c.curve_recovery_status['candidates']
        self.assertEqual([x['reason'] for x in candidates[:2]],
                         ['SECOND_RECOVERY_MAP','SECOND_RECOVERY_MAP'])
        self.assertEqual(candidates[-1]['steer'],.28)
        self.assertEqual(candidates[-1]['reason'],'CLEAR_RAW')
        self.assertTrue(candidates[-1]['geometry']['map_clear'])
        self.assertTrue(c.curve_recovery_status['actual_response_geometry']['map_clear'])
        self.assertEqual(c.curve_recovery_status['response_at_check'],-.32)
        self.assertEqual(c.curve_recovery_status['final_check_reason'],'')
        c.curve_recovery_state=None
        f.response_output=.16
        command=self.recovery()
        self.assertIsNotNone(command);self.assertGreater(command.linear.x,0.)
        self.assertFalse(c.curve_recovery_status['preposition_required'])
        self.assertAlmostEqual(c.curve_recovery_status['response_at_check'],.16)

    def test_two_distinct_clear_normal_scans_release_alternative(self):
        self.recovery();self.assertIsNotNone(self.c.curve_recovery_state)
        self.advance()
        self.c.curve_command(self.now)
        self.assertIsNotNone(self.c.curve_recovery_state)
        self.assertEqual(self.c.curve_recovery_state['clear_hits'],1)
        self.advance()
        command=self.c.curve_command(self.now)
        self.assertIsNone(self.c.curve_recovery_state)
        self.assertEqual(self.c.curve_recovery_status['state'],'NORMAL_PATH_CLEAR')
        self.assertGreater(command.linear.x,0.)

    def test_clear_raw_arc_cannot_override_map_or_progress_bounds(self):
        f=self.c.curve_follower
        arc=core.constant_steer_horizon(STOP,.16,5.,distance=.65,initial_steer=.16)
        # Geometry sees the extra cone even if a sensor scan misses it.
        self.c.curve_cones=(CONES[0],arc[15][:2])
        self.assertFalse(self.c.curve_second_recovery_geometry(STOP,f,arc)[0])
        self.c.curve_cones=CONES
        self.assertEqual(self.c.curve_second_recovery_geometry(STOP,f,[STOP]*len(arc)),
                         (False,'SECOND_RECOVERY_PROGRESS'))

    def test_new_raw_obstacle_blocks_settled_alternative(self):
        self.recovery()
        for _ in range(7):self.advance()
        f=self.c.curve_follower;f.response_output=.16
        arc=core.constant_steer_horizon(STOP,.16,5.,distance=.65,initial_steer=.16)
        x,y=core.local(arc[15],STOP)
        scan=self.c.curve_scan
        k=round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment)%len(scan.ranges)
        scan.ranges[k]=math.hypot(x,y)
        command=self.recovery()
        self.assertIsNotNone(command);self.assertEqual(command.linear.x,0.)
        self.assertFalse(self.c.curve_recovery_status['arc_clear'])

    def test_closed_loop_clears_second_turn_without_push_for_gain_range(self):
        # Independent body motion and scan rendering at each real simulated
        # pose. Ideal fresh localization isolates controller/geometry: this
        # does not claim to reproduce RF2O noise or the absent recorded scan.
        for physical_gain in (4.,5.,6.):
            with self.subTest(physical_gain=physical_gain):
                c=self.c;c.curve_follower=follower_at();f=c.curve_follower
                c.curve_recovery_state=None;c.curve_pause_active=False
                c.curve_last_drive_time=self.now-2.
                c.last_lane_angular=0.;c.curve_drive=0.
                c.curve_odom_samples.clear();c.curve_motion_samples.clear()
                c.last_motion_stamp=0.;c.last_odom_xy=None;c.last_yaw=None
                pose=STOP;servo=0.;dt=.1
                for t in (self.ros_time-.9,self.ros_time-.6,self.ros_time-.3):self.source(t,pose)
                for step in range(160):
                    self.now+=dt;self.ros_time+=dt
                    self.source(self.ros_time,pose);self.inputs(pose)
                    c.curve_locator.pose=pose;c.curve_locator.time=self.now;c.curve_pose_odom=pose
                    command=c.curve_command(self.now)
                    target=command.angular.z
                    mean=target+(servo-target)*.12/dt*(-math.expm1(-dt/.12))
                    servo=target+(servo-target)*math.exp(-dt/.12)
                    speed=.5 if command.linear.x>0. else 0.
                    pose=c.curve_integrate_motion(pose,(speed,0.,speed*physical_gain*mean),dt)
                    self.assertTrue(core.body_clear(pose,cones=CONES,margin=.02),(step,pose))
                    self.assertFalse(c.route_fault)
                    if f.progress>f.path.gates[3]+.30:break
                self.assertGreater(f.progress,f.path.gates[3]+.30)
                self.assertLess(step,70)


if __name__=='__main__':unittest.main(verbosity=2)
