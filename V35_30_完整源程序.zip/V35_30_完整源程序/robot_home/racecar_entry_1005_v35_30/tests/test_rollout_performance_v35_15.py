"""V35.15 exact rollout equivalence and reproducible, non-driving benchmark.

The frozen V35.14 module is the oracle. Performance numbers are reported rather
than asserted in tests because scheduling and hardware change wall-clock time.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import platform
import statistics
import sys
import time
import types
import unittest

import numpy as np

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / 'payload/src/racecar/scripts'))
import race_curve_core as core

BASELINE = Path(__file__).parent / 'baselines/race_curve_core_v35_14.py'
BASELINE_SHA256 = '541b56324259a65dbcb65a963c0afafca250db03f9fbb3520dabc3d790aba830'
spec = importlib.util.spec_from_file_location('rollout_oracle_v35_14', BASELINE)
old = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = old
spec.loader.exec_module(old)


def recorded_paths():
    fixtures = json.loads((PACKAGE / 'tests/fixtures/recorded_v35_13_five_inputs.json')
                          .read_text(encoding='utf-8'))['fixtures']
    return [core.plan_entry_path(f['start'], f['cones']) for f in fixtures]


def located_follower(module, path, index):
    follower = module.PathFollower(path, enable_integral=True)
    follower.index = index
    follower.progress = float(path.lengths[index])
    follower.command(tuple(path.samples[index, :3]), 10., 5.)
    return follower


class RolloutPerformanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.paths = recorded_paths()

    def test_frozen_oracle_is_exact_installed_v35_14_core(self):
        self.assertEqual(hashlib.sha256(BASELINE.read_bytes()).hexdigest(), BASELINE_SHA256)

    def test_nearest_search_matches_oracle_for_all_segments_and_bad_poses(self):
        rng = np.random.default_rng(3515)
        for case in range(1200):
            path = self.paths[case % len(self.paths)]
            index = int(rng.integers(0, len(path.samples)))
            pose = path.samples[index, :3].copy()
            pose[:2] += rng.uniform(-.7, .7, 2)
            pose[2] += rng.uniform(-4 * math.pi, 4 * math.pi)
            followers = [located_follower(m, path, index) for m in (old, core)]
            outcomes = []
            for follower in followers:
                try:
                    outcomes.append(('OK', follower.locate(pose), follower.progress))
                except ValueError as exc:
                    outcomes.append(('ERROR', str(exc)))
            self.assertEqual(outcomes[0], outcomes[1], msg=f'case {case}')
        for pose in ((math.nan, 0., 0.), (0., math.inf, 0.), (0., 0., math.nan)):
            for module in (old, core):
                with self.assertRaisesRegex(ValueError, 'CURVE_TRACK_ERROR'):
                    module.PathFollower(self.paths[0]).locate(pose)

    def test_heading_boundaries_ties_and_empty_path_keep_same_result(self):
        for heading in (-math.pi/2-2e-12, -math.pi/2, math.pi/2,
                        math.pi/2+2e-12, math.pi, 3*math.pi/2, 4*math.pi):
            samples = np.array([[0., 0., heading, 0.], [0., 0., heading, 0.]])
            path = core.Path(samples, np.array([0., .1]), (), 0.)
            outcomes = []
            for module in (old, core):
                try:
                    outcomes.append(module.PathFollower(path).locate((0., 0., 0.)))
                except ValueError as exc:
                    outcomes.append(str(exc))
            self.assertEqual(outcomes[0], outcomes[1])
        path = core.Path(np.empty((0, 4)), np.empty(0), (), 0.)
        for module in (old, core):
            with self.assertRaisesRegex(ValueError, 'CURVE_TRACK_ERROR'):
                module.PathFollower(path).locate((0., 0., 0.))

    def test_feedback_sequence_keeps_all_public_state_bit_equal(self):
        for path in self.paths:
            expected = old.PathFollower(path, enable_integral=True)
            actual = core.PathFollower(path, enable_integral=True)
            now = 20.
            for j, index in enumerate(range(0, len(path.samples), 3)):
                pose = path.samples[index, :3].copy()
                pose[0] += .03 * math.sin(j*.13)
                pose[1] += .04 * math.cos(j*.11)
                pose[2] += .05 * math.sin(j*.17)
                now += (.05, .10, .16, .40)[j % 4]
                if j % 31 == 0:
                    expected.reset_feedback(preserve_output=True)
                    actual.reset_feedback(preserve_output=True)
                for follower in (expected, actual):
                    follower.command(pose, now, 5., .32, preview_distance=(.0, .2, .43)[j % 3])
                self.assertEqual({k: v for k, v in vars(actual).items() if k != 'path'},
                                 {k: v for k, v in vars(expected).items() if k != 'path'})

    def test_every_rollout_sample_matches_at_segment_boundaries_and_exit(self):
        checked = 0
        for path in self.paths:
            indices = [0, 20, 100, 150, 159, 160, 161, 310, 319, 320,
                       470, 479, 480, 630, 639, 640, 790, 799, 800, 950, 960]
            for j, index in enumerate(indices):
                for offset in (-.025, 0., .025):
                    pose = path.samples[index, :3].copy()
                    pose[0] += offset
                    pose[1] -= offset
                    pose[2] += offset
                    followers = [located_follower(m, path, index) for m in (old, core)]
                    before = [copy.copy(vars(f)) for f in followers]
                    kwargs = dict(distance=(.65, .935, 1.1)[j % 3],
                                  speed=(.2, .9, 1.5)[j % 3], steer_tau=(.08, .12, .2)[j % 3])
                    values = [m.command_horizon(pose, f, (4., 5., 6.)[j % 3], .32, **kwargs)
                              for m, f in zip((old, core), followers)]
                    # V26's private rollout prefix changes summation order by
                    # floating-point roundoff (observed ~1e-15), not the model.
                    # Keep every sample, zero relative tolerance, and the
                    # separate complete raw-return verdict regression below.
                    np.testing.assert_allclose(values[0], values[1], atol=1e-12, rtol=0.)
                    distance = min(kwargs['distance'], max(.05, path.lengths[-1]-followers[0].progress))
                    self.assertEqual(len(values[1]), 1+3*2*math.ceil(distance/.05))
                    self.assertEqual(before, [vars(f) for f in followers])
                    checked += 1
        self.assertEqual(checked, 252)

    def test_full_return_collision_decisions_unchanged_for_both_rollouts(self):
        rng = np.random.default_rng(351501)
        hits = clears = 0
        for case in range(72):
            path = self.paths[case % len(self.paths)]
            index = (20, 160, 320, 480, 640, 800)[case % 6]
            pose = tuple(path.samples[index, :3])
            followers = [located_follower(m, path, index) for m in (old, core)]
            samples = [m.command_horizon(pose, f, 5., distance=.935, speed=.9)
                       for m, f in zip((old, core), followers)]
            ranges = rng.uniform(.3, 1.8, 450) if case % 2 else np.full(450, 8.)
            ranges[rng.random(450) < .15] = math.inf
            scan = types.SimpleNamespace(ranges=ranges, angle_min=-math.pi,
                angle_increment=2*math.pi/450, range_min=.05, range_max=12.)
            verdicts = [core.scan_hits_body(scan, pose, s) for s in samples]
            self.assertEqual(verdicts[0], verdicts[1])
            hits += verdicts[1]
            clears += not verdicts[1]
        self.assertGreater(hits, 20)
        self.assertGreater(clears, 20)

    def test_no_stale_cache_after_path_array_change_or_replacement(self):
        path = copy.deepcopy(self.paths[0])
        followers = [located_follower(m, path, 0) for m in (old, core)]
        path.samples[:, 3] *= .7
        path.samples[:, 0] += .02
        for follower in followers:
            follower.command(tuple(path.samples[2, :3]), 10.1, 5.)
        self.assertEqual(followers[0].output, followers[1].output)
        replacement = self.paths[1]
        for follower in followers:
            follower.path = replacement
            follower.index = 0
            follower.progress = 0.
            follower.command(tuple(replacement.samples[0, :3]), 10.2, 5.)
        self.assertEqual(followers[0].output, followers[1].output)


def benchmark(repeats=8, iterations=30):
    path = recorded_paths()[0]
    cases = [(tuple(path.samples[i, :3]), i) for i in (20, 160, 480, 800)]
    measured = {label: [] for label in ('v35_14', 'v35_15')}
    for repeat in range(repeats):
        versions = [('v35_14', old), ('v35_15', core)]
        if repeat % 2:
            versions.reverse()
        for label, module in versions:
            prepared = [(pose, located_follower(module, path, index)) for pose, index in cases]
            started = time.perf_counter()
            for _ in range(iterations):
                for pose, follower in prepared:
                    module.command_horizon(pose, follower, 5., distance=.935, speed=.9)
            measured[label].append((time.perf_counter()-started)*1000/(iterations*len(prepared)))
    medians = {label: statistics.median(values) for label, values in measured.items()}
    return dict(platform=platform.platform(), python=sys.version, iterations_per_batch=iterations*len(cases),
        batches=repeats, raw_ms_per_rollout=measured, median_ms_per_rollout=medians,
        speedup=medians['v35_14']/medians['v35_15'],
        reduction_fraction=1.-medians['v35_15']/medians['v35_14'],
        comparison='Identical three gain branches and 0.025 m body samples; no ROS or actuator access.')


if __name__ == '__main__':
    if '--benchmark' in sys.argv:
        parser = argparse.ArgumentParser()
        parser.add_argument('--benchmark', action='store_true')
        parser.add_argument('--output', type=Path)
        parser.add_argument('--iterations', type=int, default=30)
        args = parser.parse_args()
        result = json.dumps(benchmark(iterations=args.iterations), indent=2)+'\n'
        if args.output:
            args.output.write_text(result, encoding='utf-8', newline='\n')
        print(result)
    else:
        unittest.main()
