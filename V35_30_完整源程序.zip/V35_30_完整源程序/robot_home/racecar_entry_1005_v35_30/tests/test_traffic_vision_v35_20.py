"""Actual labeled camera regression plus synthetic light/negative cases.

No camera, ROS graph or vehicle driver is opened. Synthetic scale/position cases
exercise the algorithm; they do not establish accuracy at unmeasured distances.
"""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import unittest

import cv2
import numpy as np
import ros_stubs

PACKAGE = Path(__file__).resolve().parents[1]
VISION_PATH = PACKAGE / 'payload/src/racecar/scripts/ican_vision_node.py'
BASELINE_PATH = PACKAGE / 'tests/baselines/vision_before_v35_20.py'
FIXTURES = PACKAGE / 'tests/fixtures/traffic_lights'
CONFIG_PATH = PACKAGE / 'payload/src/racecar/config/competition_params.yaml'
spec = importlib.util.spec_from_file_location('traffic_camera_v35_20', VISION_PATH)
vision = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vision)

LIGHT_PARAMS = ('min_light_area', 'max_light_area', 'min_light_circularity',
                'light_roi_x_min', 'light_roi_x_max', 'red_ratio_threshold',
                'green_ratio_threshold', 'light_red_min_s', 'light_min_bright_v',
                'light_min_bright_fraction', 'light_min_hull_occupancy')


def detector():
    """Use the delivered YAML, without calling the camera-opening constructor."""
    # This fixture YAML section only uses scalar numeric light parameters.
    # Parse those explicitly so offline tests need no additional YAML package.
    section = CONFIG_PATH.read_text(encoding='utf-8').split('ican_vision_node:', 1)[1]
    section = re.split(r'\n[^\s#]', section, maxsplit=1)[0]
    params = {key: ast.literal_eval(re.search(
        r'^\s+' + re.escape(key) + r':\s*([^#\n]+)', section, re.M).group(1).strip())
        for key in LIGHT_PARAMS}
    node = vision.IcanVisionNode.__new__(vision.IcanVisionNode)
    for key in LIGHT_PARAMS:
        setattr(node, key, params[key])
    node.light_diagnostics = {}
    node.light_last_detection = None
    return node


def read_frame(path):
    frame = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError('Could not read fixture: ' + str(path))
    return cv2.resize(frame, (320, 240), interpolation=cv2.INTER_AREA)


def canvas():
    return np.zeros((240, 320, 3), dtype=np.uint8)


def lens(color='red', radius=12, center=(150, 60), value=255, white_core=False):
    hsv = np.zeros((240, 320, 3), dtype=np.uint8)
    cv2.circle(hsv, center, radius, (0 if color == 'red' else 60, 255, value), -1)
    frame = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    if white_core:
        cv2.circle(frame, center, max(1, radius - 3), (255, 255, 255), -1)
    return frame


def write_calibration_report():
    """Re-run both delivered versions on immutable labeled source images."""
    baseline_spec = importlib.util.spec_from_file_location('traffic_camera_v35_19', BASELINE_PATH)
    baseline = importlib.util.module_from_spec(baseline_spec)
    baseline_spec.loader.exec_module(baseline)
    old = baseline.IcanVisionNode.__new__(baseline.IcanVisionNode)
    old_config = PACKAGE / 'tests/baselines/competition_params_before_v35_20.yaml'
    section = old_config.read_text(encoding='utf-8').split('ican_vision_node:', 1)[1]
    section = re.split(r'\n[^\s#]', section, maxsplit=1)[0]
    old_keys = LIGHT_PARAMS[:7]
    for key in old_keys:
        setattr(old, key, ast.literal_eval(re.search(
            r'^\s+' + re.escape(key) + r':\s*([^#\n]+)', section, re.M).group(1).strip()))
    current = detector()
    manifest = json.loads((FIXTURES / 'manifest.json').read_text(encoding='utf-8'))
    groups, records = {}, []
    for record in manifest['files']:
        frame = read_frame(FIXTURES / record['path'])
        old_out = old.detect_traffic_light(frame)
        new_out = current.detect_traffic_light(frame)
        group = Path(record['path']).parts[0]
        summary = groups.setdefault(group, {'total': 0, 'v19_correct': 0, 'v20_correct': 0,
                                            'v20_red_areas': [], 'v20_green_areas': []})
        summary['total'] += 1
        summary['v19_correct'] += list(old_out[:2]) == record['expected']
        summary['v20_correct'] += list(new_out[:2]) == record['expected']
        summary['v20_red_areas'].append(new_out[3])
        summary['v20_green_areas'].append(new_out[4])
        records.append(dict(record, v19={'detected': old_out[:2], 'areas': old_out[3:]},
                            v20={'detected': new_out[:2], 'areas': new_out[3:],
                                 'diagnostics': current.light_diagnostics}))
    for group in groups.values():
        for color in ('red', 'green'):
            values = group.pop('v20_' + color + '_areas')
            group['v20_' + color + '_area_range'] = [min(values), max(values)]
    report = {
        'version': 'V35.20', 'sample_date': '2026-10-02',
        'scope': '20 stationary actual red/green images at two placements (far approximately 1 m), plus one actual starting-area negative. Repeated adjacent samples, not independent accuracy estimates. Synthetic scale/position tests do not prove other distances, exposure or moving-camera performance.',
        'input_size': [640, 480], 'processing_size': [320, 240],
        'camera_controls': {'auto_exposure': 1, 'exposure_time_absolute': 313,
                            'white_balance_automatic': 0, 'white_balance_temperature': 4000},
        'v19_source_sha256': hashlib.sha256(BASELINE_PATH.read_bytes()).hexdigest(),
        'v20_source_sha256': hashlib.sha256(VISION_PATH.read_bytes()).hexdigest(),
        'v19_config_sha256': hashlib.sha256(old_config.read_bytes()).hexdigest(),
        'v20_config_sha256': hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest(),
        'v19_parameters': {key: getattr(old, key) for key in old_keys},
        'v20_parameters': {key: getattr(current, key) for key in LIGHT_PARAMS},
        'groups': groups, 'records': records,
    }
    target = PACKAGE / 'CALIBRATION_V35_20.json'
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return report


class TrafficVisionTests(unittest.TestCase):
    def setUp(self):
        self.node = detector()

    def detect(self, frame):
        return self.node.detect_traffic_light(frame)[:2]

    def test_all_actual_labeled_camera_frames_and_hashes(self):
        manifest = json.loads((FIXTURES / 'manifest.json').read_text(encoding='utf-8'))
        counts = {}
        for record in manifest['files']:
            path = FIXTURES / record['path']
            group = Path(record['path']).parts[0]
            counts[group] = counts.get(group, 0) + 1
            with self.subTest(frame=record['path']):
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), record['sha256'])
                self.assertEqual(self.detect(read_frame(path)), tuple(record['expected']),
                                 self.node.light_diagnostics)
        self.assertEqual(counts, {'red_near': 5, 'green_near': 5, 'red_far': 5,
                                  'green_far': 5, 'start_negative': 1})

    def test_real_red_candidate_recovers_overexposed_core(self):
        self.assertEqual(self.detect(read_frame(FIXTURES / 'red_near/frame_060.png')), (1, 0))
        accepted = self.node.light_diagnostics['red']['candidates'][0]
        self.assertGreater(accepted['core_fraction'], .5)
        self.assertGreater(accepted['area'], 800)
        green = self.node.light_diagnostics['green']['candidates'][0]
        self.assertEqual(green['reason'], 'UNLIT_COLOR')
        self.assertLess(green['bright_fraction'], .12)

    def test_far_real_green_below_old_area_threshold_is_detected(self):
        self.assertEqual(self.detect(read_frame(FIXTURES / 'green_far/frame_060.png')), (0, 1))
        self.assertLess(self.node.light_diagnostics['green']['accepted_area'], 500)

    def test_actual_lens_scaled_and_repositioned_inside_roi(self):
        for color, region in [('red', (50, 0, 105, 43)), ('green', (172, 0, 245, 52))]:
            original = read_frame(FIXTURES / (color + '_near') / 'frame_060.png')
            x0, y0, x1, y1 = region
            crop = original[y0:y1, x0:x1]
            for scale in (.4, .6, 1.):
                patch = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
                for x, y in ((55, 20), (150, 80)):
                    frame = canvas()
                    frame[y:y + patch.shape[0], x:x + patch.shape[1]] = patch
                    with self.subTest(color=color, scale=scale, xy=(x, y)):
                        self.assertEqual(self.detect(frame), (1, 0) if color == 'red' else (0, 1),
                                         self.node.light_diagnostics)

    def test_small_lit_lenses_survive_without_five_pixel_opening(self):
        for color in ('red', 'green'):
            for radius in (4, 6, 12, 20):
                with self.subTest(color=color, radius=radius):
                    self.assertEqual(self.detect(lens(color, radius)),
                                     (1, 0) if color == 'red' else (0, 1))

    def test_overexposed_core_requires_colored_rim(self):
        for color in ('red', 'green'):
            with self.subTest(color=color):
                self.assertEqual(self.detect(lens(color, white_core=True)),
                                 (1, 0) if color == 'red' else (0, 1))
        frame = canvas()
        cv2.circle(frame, (150, 60), 20, (255, 255, 255), -1)
        self.assertEqual(self.detect(frame), (0, 0))

    def test_dark_red_and_green_lenses_remain_unlit(self):
        for color in ('red', 'green'):
            for value in (100, 140, 180):
                for core in (False, True):
                    with self.subTest(color=color, value=value, white_reflection=core):
                        self.assertEqual(self.detect(lens(color, value=value, white_core=core)), (0, 0))

    def test_single_bright_reflection_does_not_light_dark_lens(self):
        frame = lens('green', value=120)
        frame[60, 150] = (0, 255, 0)
        self.assertEqual(self.detect(frame), (0, 0))

    def test_white_core_with_isolated_colored_noise_is_not_a_lamp(self):
        frame = canvas()
        cv2.circle(frame, (150, 60), 18, (255, 255, 255), -1)
        for x, y in ((135, 60), (150, 45), (165, 60), (150, 75)):
            frame[y, x] = (0, 0, 255)
        self.assertEqual(self.detect(frame), (0, 0))

    def test_blank_blue_wall_and_red_banner_are_rejected(self):
        self.assertEqual(self.detect(canvas()), (0, 0))
        self.assertEqual(self.detect(np.full((240, 320, 3), (255, 40, 0), np.uint8)), (0, 0))
        for width, height in ((180, 18), (30, 30), (9, 9)):
            frame = canvas()
            frame[40:40 + height, 70:70 + width] = (0, 0, 255)
            with self.subTest(shape=(width, height)):
                self.assertEqual(self.detect(frame), (0, 0), self.node.light_diagnostics)

    def test_fragmented_led_noise_is_rejected(self):
        frame = canvas()
        for y in range(10, 140, 9):
            for x in range(45, 275, 9):
                cv2.circle(frame, (x, y), 1, (0, 0, 255) if x % 2 else (0, 255, 0), -1)
        self.assertEqual(self.detect(frame), (0, 0))

    def test_hollow_nonluminous_ring_rejected_by_hull_occupancy(self):
        frame = canvas()
        cv2.circle(frame, (150, 60), 20, (0, 0, 255), 1)
        self.assertEqual(self.detect(frame), (0, 0))
        self.assertIn('EMPTY_HULL', self.node.light_diagnostics['red']['rejected'])

    def test_both_lit_red_priority_preserves_both_candidate_evidence(self):
        frame = cv2.bitwise_or(lens('red', radius=7, center=(90, 60)),
                               lens('green', radius=20, center=(200, 60)))
        self.assertEqual(self.detect(frame), (1, 0))
        diag = self.node.light_diagnostics
        self.assertEqual(diag['decision'], 'AMBIGUOUS_RED_PRIORITY')
        self.assertGreater(diag['green']['accepted_area'], diag['red']['accepted_area'])
        self.assertGreater(diag['red']['accepted_area'], 0)

    def test_area_and_ratio_both_remain_enforced(self):
        frame = lens(radius=8)
        self.node.red_ratio_threshold = .1
        self.assertEqual(self.detect(frame), (0, 0))
        self.node.red_ratio_threshold = .0005
        self.node.min_light_area = 500
        self.assertEqual(self.detect(frame), (0, 0))

    def test_roi_unchanged_and_position_not_fixed(self):
        for point in ((10, 60), (305, 60), (160, 210)):
            self.assertEqual(self.detect(lens(center=point)), (0, 0))
        for point in ((70, 50), (250, 90), (160, 120)):
            self.assertEqual(self.detect(lens(center=point)), (1, 0))

    def test_diagnostics_are_bounded_and_changes_are_not_throttled(self):
        calls = []
        class Logger:
            def info(self, message, **kwargs):
                calls.append((message, kwargs))
        self.node.get_logger = lambda: Logger()
        for frame in (canvas(), canvas(), lens(), lens(), lens('green'), canvas()):
            state = self.detect(frame)
            self.node.log_light_diagnostics(*state)
            for color in ('red', 'green'):
                self.assertLessEqual(len(self.node.light_diagnostics[color]['candidates']), 3)
        events = [entry for entry in calls if entry[0].startswith('LIGHT_EVENT ')]
        details = [entry for entry in calls if entry[0].startswith('LIGHT_DIAG ')]
        self.assertEqual(len(events), 4)
        self.assertTrue(all(kwargs == {} for _, kwargs in events))
        self.assertTrue(all(kwargs == {'throttle_duration_sec': 1.0} for _, kwargs in details))

    def test_crosswalk_camera_controls_and_publishing_are_unchanged(self):
        def methods(path):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            cls = next(n for n in tree.body if isinstance(n, ast.ClassDef))
            return {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
        before, after = methods(BASELINE_PATH), methods(VISION_PATH)
        for name in ('open_camera', 'detect_crosswalk', 'confirm_position',
                     '_largest_valid_blob_area', 'destroy_node'):
            with self.subTest(method=name):
                self.assertEqual(ast.dump(before[name]), ast.dump(after[name]))
        process = after['process_frame']
        process.body = [n for n in process.body if not (
            isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
            and isinstance(n.value.func, ast.Attribute)
            and n.value.func.attr == 'log_light_diagnostics')]
        self.assertEqual(ast.dump(before['process_frame']), ast.dump(process))


if __name__ == '__main__':
    if sys.argv[1:] == ['--calibration-report']:
        print(json.dumps(write_calibration_report()['groups'], indent=2))
    else:
        unittest.main()
