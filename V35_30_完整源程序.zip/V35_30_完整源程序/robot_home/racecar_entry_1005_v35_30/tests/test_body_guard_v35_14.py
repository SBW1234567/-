"""Curve self returns stay diagnostic; real emergency pauses are recoverable."""
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

import numpy as np
import ros_stubs as ros

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import race_lidar_guard as guard

# Defaults to the delivered controller. During isolated development only,
# BODY_GUARD_CONTROLLER_PATH can select the parent-owned merge input.
source=Path(os.environ.get('BODY_GUARD_CONTROLLER_PATH',str(SCRIPTS/'race_task_controller.py')))
spec=importlib.util.spec_from_file_location('body_guard_controller_v35_14',source)
cm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=cm;spec.loader.exec_module(cm)


def scan_with(points=(),side_wall=None,front=None,stamp=100):
    n=720;angles=np.arange(n)*2*math.pi/n;ranges=np.full(n,math.inf)
    if side_wall is not None:
        ranges=np.divide(side_wall,np.abs(np.sin(angles)),out=np.full(n,math.inf),where=np.abs(np.sin(angles))>1e-9)
    for x,y in points:
        i=int(round((math.atan2(y,x)%(2*math.pi))*n/(2*math.pi)))%n
        ranges[i]=min(ranges[i],math.hypot(x,y))
    if front is not None:
        for i in (0,1,n-1):ranges[i]=front
    ranges=np.where(ranges<=8.,ranges,math.inf)
    return types.SimpleNamespace(ranges=ranges.tolist(),intensities=[],angle_min=0.,angle_increment=2*math.pi/n,
        angle_max=2*math.pi-2*math.pi/n,range_min=.05,range_max=12.,
        header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=stamp,nanosec=0)))


class BodyGuardTests(unittest.TestCase):
    def setUp(self):
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,entry_v32_enabled=True,
            entry_v33_enabled=True,entry_v34_enabled=True,exit_continuous=True,dry_run=True,
            curve_static_body_guard_enabled=False,
            self_filter_radius=.30,entry_body_rear=.185,entry_body_front=.20,entry_body_width=.30,
            publish_filtered_scan=False)
        self.g=guard.RaceLidarGuard()
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.curve_control_prediction_enabled=False
        self.c.phase=self.c.SEEK_CONE_1
        self.c.update_phase=lambda now:None
        self.c.relative_command=lambda now:self.drive()
        self.c.layout_stop_reason=lambda now:''
        self.c.departure_stop_reason=lambda now:''

    @staticmethod
    def drive():
        cmd=ros.Twist();cmd.linear.x=.35;return cmd

    def data(self,clear=True,stamp=1):
        return dict(schema=3,valid=True,stamp_ns=stamp,body_clear=clear,front=2.,front_coverage=1.,
            exit_path_front=3.,exit_path_coverage=1.,entry_side_clear=True,entry_side_nearest=.4,
            entry_side_coverage=1.,entry_side_geometry=[.185,.2,.15,.1,.5],
            exit_path_half_width=.25,exit_path_body_front=.2,entry_end_wall=None,cones=[])

    def tick(self,now,clear=True,stamp=1,emergency=False):
        c=self.c;c.rel_data=self.data(clear,stamp);c.rel_stamp=stamp
        c.rel_time=c.last_lidar_time=c.last_odom_time=c.curve_scan_time=now
        c.curve_scan=scan_with(side_wall=.4,stamp=int(now));c.curve_scan_stamp=stamp
        c.lidar_emergency=emergency
        with patch.object(cm.time,'monotonic',return_value=now):c.control_loop()
        return c.cmd_pub.messages[-1]

    def test_side_wall_returns_outside_the_real_body_do_not_stop(self):
        d=self.g.relative_features(scan_with(side_wall=.24))
        self.assertTrue(d['body_clear'])
        self.assertEqual(d['body_guard']['margin'],.03)
        self.assertEqual(d['body_guard']['hits'],0)
        np.testing.assert_allclose(d['body_guard']['bounds'],[-.215,.23,.18])
        self.assertGreater(self.tick(100.,clear=d['body_clear']).linear.x,0.)

    def test_self_body_return_is_diagnostic_and_does_not_stop_curve(self):
        d=self.g.relative_features(scan_with(points=((.19,.14),)))
        self.assertFalse(d['body_clear'])
        self.assertGreater(d['body_guard']['physical_hits'],0)
        self.assertAlmostEqual(d['body_guard']['minimum_valid_range'],.20)
        self.assertLess(d['body_guard']['nearest_dxy'][0],self.g.self_filter_radius)
        self.assertFalse(d['body_guard']['enabled'])
        self.assertFalse(d['body_guard']['static_enforced'])
        cmd=self.tick(100.,clear=d['body_clear'])
        self.assertGreater(cmd.linear.x,0.)
        self.assertEqual(self.c.entry_recovery_reason,'')
        self.assertFalse(self.c.curve_body_guard_status['static_enforced'])
        self.assertEqual(self.c.route_fault,'')
        self.assertFalse(self.c.entry_hold)
        self.assertFalse(self.c.entry_v33_braked)

    def test_debug_parameter_explicitly_enables_static_pause(self):
        self.g.curve_static_body_guard_enabled=self.c.curve_static_body_guard_enabled=True
        d=self.g.relative_features(scan_with(points=((.19,.14),)))
        self.assertTrue(d['body_guard']['static_enforced'])
        self.assertEqual(self.tick(100.,clear=d['body_clear']).linear.x,0.)
        self.assertEqual(self.c.entry_recovery_reason,'REL_BODY_OBSTRUCTION')
        self.assertTrue(self.c.curve_body_guard_status['static_enforced'])
        self.assertEqual(self.c.route_fault,'')

    def test_noncurve_profile_retains_original_self_filter_and_margin(self):
        self.g.curve_route=False
        self.assertTrue(self.g.relative_features(scan_with(points=((.19,.14),)))['body_clear'])
        d=self.g.relative_features(scan_with(points=((.28,.15),)))
        self.assertFalse(d['body_clear'])
        self.assertAlmostEqual(d['body_guard']['minimum_valid_range'],.30)
        self.assertAlmostEqual(d['body_guard']['margin'],.10)
        self.assertTrue(d['body_guard']['static_enforced'])
        c=self.c;c.curve_route=False;c.rel_data=d
        c.rel_time=c.last_lidar_time=100.;c.lidar_emergency=False
        self.assertEqual(c.curve_body_stop_reason(100.),'REL_BODY_OBSTRUCTION')

    def test_three_centimetre_candidate_margin_is_still_reported(self):
        self.assertFalse(self.g.relative_features(scan_with(points=((.22,0.),)))['body_clear'])
        self.assertTrue(self.g.relative_features(scan_with(points=((.24,0.),)))['body_clear'])

    def test_debug_body_pause_releases_within_half_a_second(self):
        self.c.curve_static_body_guard_enabled=True
        self.assertEqual(self.tick(100.,False,1).linear.x,0.)
        self.assertEqual(self.tick(100.4,True,2).linear.x,0.)
        self.assertGreater(self.tick(100.5,True,3).linear.x,0.)
        self.assertEqual(self.c.route_fault,'')

    def test_fourth_recorded_transient_near_return_does_not_latch_route_fault(self):
        # V35.13 fourth-run feature records: 395 ms near-return interval,
        # first clear at +507 ms, next clear at +598 ms.
        samples=((21.837,True),(21.941,False),(22.036,False),(22.137,False),
                 (22.243,False),(22.336,False),(22.448,True),(22.539,True))
        commands=[self.tick(100.+t,clear,i+1).linear.x for i,(t,clear) in enumerate(samples)]
        self.assertGreater(commands[0],0.)
        self.assertTrue(all(v>0. for v in commands[1:-1]))
        self.assertGreater(commands[-1],0.)
        self.assertEqual(self.c.route_fault,'')
        self.assertFalse(self.c.entry_v33_braked)

    def test_same_clear_scan_cannot_manufacture_two_confirmations(self):
        self.c.curve_static_body_guard_enabled=True
        self.tick(100.,False,1)
        self.tick(100.1,True,2)
        self.assertEqual(self.c.curve_body_guard_clear_hits,1)
        self.assertEqual(self.tick(100.15,True,2).linear.x,0.)
        self.assertEqual(self.c.curve_body_guard_clear_hits,1)
        self.assertGreater(self.tick(100.2,True,3).linear.x,0.)

    def test_stale_gap_cannot_accumulate_clear_confirmation(self):
        self.c.curve_static_body_guard_enabled=True
        self.tick(100.,False,1)
        self.tick(100.1,True,2)
        self.assertEqual(self.c.curve_body_guard_clear_hits,1)
        self.assertEqual(self.c.curve_body_stop_reason(100.5),'REL_BODY_CLEARING')
        self.assertEqual(self.c.curve_body_guard_clear_hits,0)
        self.assertIsNone(self.c.curve_body_guard_clear_stamp)
        self.assertEqual(self.tick(100.6,True,3).linear.x,0.)
        self.assertEqual(self.c.curve_body_guard_clear_hits,1)
        self.assertGreater(self.tick(100.7,True,4).linear.x,0.)

    def test_real_lidar_emergency_stops_and_then_releases(self):
        # Persistent self-body candidates must not prevent emergency release
        # when the static curve check is disabled.
        self.assertEqual(self.tick(100.,False,1,True).linear.x,0.)
        self.assertEqual(self.c.entry_recovery_reason,'REL_LIDAR_EMERGENCY')
        self.assertEqual(self.tick(100.4,False,2,False).linear.x,0.)
        self.assertGreater(self.tick(100.5,False,3,False).linear.x,0.)
        self.assertEqual(self.c.route_fault,'')

    def test_node_emergency_latch_releases_at_35cm_after_hold(self):
        with patch.object(guard.time,'monotonic',return_value=100.):self.g.scan_callback(scan_with(front=.25,stamp=100))
        self.assertTrue(self.g.emergency_latched)
        with patch.object(guard.time,'monotonic',return_value=100.2):self.g.scan_callback(scan_with(front=.40,stamp=101))
        self.assertTrue(self.g.emergency_latched)
        with patch.object(guard.time,'monotonic',return_value=100.4):self.g.scan_callback(scan_with(front=.40,stamp=102))
        self.assertFalse(self.g.emergency_latched)
        d=json.loads(self.g.entry_body_pub.messages[-1].data)
        self.assertAlmostEqual(d['emergency_guard']['clear_distance'],.35)

    def test_unknown_route_fault_is_never_unlocked(self):
        self.c.route_fault='ORBIT_1_WRONG_TURN_DIRECTION';self.c.phase=self.c.ROUTE_FAULT
        self.assertFalse(self.c.entry_recoverable_stop('REL_BODY_OBSTRUCTION',100.))
        self.assertEqual(self.tick(100.,True,1).linear.x,0.)
        self.assertEqual(self.tick(100.5,True,2).linear.x,0.)
        self.assertEqual(self.c.route_fault,'ORBIT_1_WRONG_TURN_DIRECTION')


if __name__=='__main__':unittest.main(verbosity=2)
