"""Distance approach regression and independent weak-start motor comparison.

The slow plant brackets the observed184736 small displacement per short input;
it is not an identified ESC model. The original fast/coasting plants also run.
"""
import ast
from contextlib import ExitStack,contextmanager
import math
from pathlib import Path
import unittest
from unittest.mock import patch

import test_finish_dynamics_v35_23 as dynamics
import test_finish_parking_v35_22 as fixture

cm=fixture.cm


class SluggishStartPlant(dynamics.MotorPlant):
    def running_speed(self,pwm):
        points=((.24,0.),(.28,.01),(.30,.035),(.32,.10),(.34,.32),(.35,.60))
        if pwm<=points[0][0]:return 0.
        for a,b in zip(points,points[1:]):
            if pwm<=b[0]:return a[1]+(b[1]-a[1])*(pwm-a[0])/(b[0]-a[0])
        return .60


@contextmanager
def old_parking():
    source=Path(__file__).parent/'baselines/controller_before_v35_24.py'
    tree=ast.parse(source.read_text(encoding='utf-8'))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
    names=('finish_parking_reset','finish_parking_observation',
           'finish_parking_command','finish_parking_verified')
    nodes=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in names]
    ns=dict(cm.__dict__)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),ns)
    with ExitStack() as stack:
        for name in names:stack.enter_context(patch.object(cm.RaceTaskController,name,ns[name]))
        yield


class FinishDistanceV3524Tests(unittest.TestCase):
    setUp=fixture.FinishParkingV3522Tests.setUp
    refresh_sensors=fixture.FinishParkingV3522Tests.refresh_sensors
    advance=fixture.FinishParkingV3522Tests.advance
    receive_laser_pose=fixture.FinishParkingV3522Tests.receive_laser_pose
    prepare=fixture.FinishParkingV3522Tests.prepare
    scan=fixture.FinishParkingV3522Tests.scan
    tick=fixture.FinishParkingV3522Tests.tick
    stopped_ticks=fixture.FinishParkingV3522Tests.stopped_ticks

    def test_moderate_speed_reduces_input_without_forcing_another_stop(self):
        c=self.prepare(6.5,speed=.30)
        commands=[]
        for _ in range(4):commands.append(self.tick(pose=(self.pose[0]+.03,3.55,0.)))
        self.assertEqual(c.finish_parking_status['state'],'PARK_DISTANCE_ROLLING')
        self.assertGreater(commands[-1].linear.x,0.)
        self.assertLess(commands[-1].linear.x,.35)

    def test_known_rolling_car_does_not_enter_trim_at_old_point_eight_five_gate(self):
        c=self.prepare(7.22,speed=.07)
        c.finish_parking['rolling_evidence']=True
        commands=[self.tick(pose=(self.pose[0]+.007,3.55,0.)) for _ in range(4)]
        self.assertFalse(c.finish_parking['trim_active'])
        self.assertTrue(all(cmd.linear.x>0 for cmd in commands[2:]))
        self.assertEqual(c.finish_parking_status['state'],'PARK_DISTANCE_ROLLING')

    def test_distance_lowers_target_while_preserving_positive_motion(self):
        targets=[]
        for distance in (1.6,1.2,.9,.7):
            c=self.prepare(8.-distance,speed=.10)
            c.finish_parking['rolling_evidence']=True
            for _ in range(4):cmd=self.tick(pose=(self.pose[0]+.01,3.55,0.))
            targets.append(c.finish_parking_status['target_speed_mps'])
            self.assertGreater(cmd.linear.x,0.)
        self.assertEqual(targets,sorted(targets,reverse=True))

    def test_final_range_coast_latches_until_real_standstill(self):
        c=self.prepare(7.1,speed=.5);c.finish_parking['rolling_evidence']=True
        for _ in range(4):self.tick(pose=(self.pose[0]+.05,3.55,0.))
        self.assertTrue(c.finish_parking['final_coast'])
        for _ in range(3):
            cmd=self.tick(pose=(self.pose[0]+.005,3.55,0.))
            self.assertEqual(cmd.linear.x,0.)
            self.assertFalse(c.finish_parking_status['complete'])

    def test_far_stopped_after_conservative_coast_can_restart_continuous_approach(self):
        c=self.prepare(6.8)
        c.finish_parking.update(final_coast=True,rolling_evidence=True)
        commands=self.stopped_ticks(10)
        self.assertFalse(c.finish_parking['final_coast'])
        self.assertFalse(c.finish_parking['trim_active'])
        self.assertGreater(commands[-1].linear.x,0.)

    def test_stale_source_stops_continuous_command_and_cannot_complete(self):
        c=self.prepare(6.4)
        self.stopped_ticks(4)
        self.assertGreater(c.finish_parking_status['issued_drive'],0.)
        self.advance(.30);self.scan()
        self.assertEqual(c.lane_command().linear.x,0.)
        self.assertFalse(c.finish_parking_verified(self.now))

    def test_data_wait_clears_startup_deadline_before_a_later_trim(self):
        c=self.prepare(6.4);self.stopped_ticks(4)
        old=c.finish_parking['startup_deadline']
        self.assertIsNotNone(old)
        self.advance(.30);self.scan()
        self.assertEqual(c.lane_command().linear.x,0.)
        self.assertIsNone(c.finish_parking['startup_deadline'])
        c.finish_parking.update(trim_active=True,rolling_evidence=True)
        for _ in range(25):
            cmd=self.tick()
            if cmd.linear.x>0 and self.now>old:break
        self.assertGreater(self.now,old)
        self.assertGreater(cmd.linear.x,0.)
        self.assertIsNone(c.finish_parking['startup_deadline'])

    def test_entering_body_window_cannot_restart_after_small_board_range_shift(self):
        c=self.prepare(7.415);c.finish_parking['rolling_evidence']=True
        self.stopped_ticks(4)
        self.assertTrue(c.finish_parking['final_coast'])
        walls=[w for w in fixture.core.WALLS if w!=((8.,0.),(8.,4.))]
        walls.append(((8.025,0.),(8.025,4.)))
        cmd=self.tick(walls=walls)
        self.assertTrue(c.finish_parking_status['valid'])
        self.assertFalse(c.finish_parking_status['body_inside'])
        self.assertEqual(cmd.linear.x,0.)
        self.assertFalse(c.finish_parking_status['complete'])

    def test_raw_wall_approach_rejects_v23_false_finished_when_odom_misses_motion(self):
        def scenario():
            self.advance(.1)
            c=self.prepare(7.52);self.stopped_ticks(4);rows=[]
            for i in range(1,5):
                self.advance(.1);self.pose=(7.52+i*.007,3.55,0.)
                self.receive_laser_pose((7.52,3.55,0.));self.scan();c.lane_command()
                rows.append((c.finish_parking_status['complete'],
                    c.finish_parking_verified(self.now),c.finish_parking_status['board_closing_mps']))
            return rows
        with old_parking():old=scenario()
        self.assertTrue(old[-2][0]);self.assertTrue(old[-2][1])
        self.assertGreater(old[-2][2],.06)
        new=scenario()
        self.assertTrue(all(not complete and not verified for complete,verified,_ in new))
        self.assertGreater(new[-1][2],.06)
        # When the independent wall really stops, fresh samples can prove it.
        for _ in range(10):
            self.advance(.1);self.receive_laser_pose((7.52,3.55,0.));self.scan();self.c.lane_command()
        self.assertTrue(self.c.finish_parking_status['complete'])
        self.assertTrue(self.c.finish_parking_verified(self.now))

    def test_missing_or_invalid_raw_wall_speed_cannot_confirm_standstill(self):
        c=self.prepare(7.52);self.stopped_ticks(10)
        self.assertTrue(c.finish_parking_status['complete'])
        previous=dict(c.finish_parking_status);observe=c.finish_parking_observation
        for closing in (None,float('nan'),.06):
            with self.subTest(closing=closing):
                def unavailable(*args):
                    result=observe(*args);result['board_closing_mps']=closing;return result
                with patch.object(c,'finish_parking_observation',side_effect=unavailable):
                    c.finish_parking_status=dict(previous)
                    self.assertFalse(c.finish_parking_verified(self.now))
                    self.assertEqual(c.lane_command().linear.x,0.)
                    self.assertFalse(c.finish_parking_status['complete'])

    def test_stipulated_runon_keeps_low_input_and_never_claims_finished(self):
        # This is a command-policy check on the old prescribed trajectory,
        # not a physical coast proof. Actual input-driven coast/collision is
        # separately exercised by the exponential/nonlinear motor plants.
        for speed in (.85,1.03):
            with self.subTest(speed=speed):
                self.advance(.1)
                c=self.prepare(6.2,speed=speed,delay=.15)
                self.assertEqual(c.lane_command().linear.x,0.)
                floor_checks=overspeed_checks=0
                for i in range(1,9):
                    position=6.2+.4*(1.-(1.-i/8.)**2)
                    cmd=self.tick(pose=(position,3.55,0.))
                    self.assertGreaterEqual(cmd.linear.x,0.)
                    self.assertLessEqual(cmd.linear.x,.35)
                    status=c.finish_parking_status
                    anticipated=status['anticipated_speed_mps']
                    target=status.get('target_speed_mps')
                    # Keep the same eight stipulated poses. V29 permits a
                    # higher far target; reduce input while actually above it,
                    # rather than freezing the historical first-six-tick floor.
                    if target is not None and anticipated>=target:
                        self.assertLessEqual(cmd.linear.x,.30)
                        overspeed_checks+=1
                    if anticipated>=.80:
                        self.assertLessEqual(cmd.linear.x,.24)
                        floor_checks+=1
                    self.assertFalse(c.finish_parking['trim_active'])
                    self.assertFalse(c.finish_parking_status['complete'])
                    self.assertFalse(c.finish_parking_verified(self.now))
                self.assertGreaterEqual(floor_checks,2)
                self.assertGreaterEqual(overspeed_checks,6)
                # At the last original pose the measured speed is below the
                # current target, still 1.4m from the wall: bounded recovery is
                # expected. Actual input-driven coast is covered separately.
                self.assertLess(anticipated,target)
                self.assertGreater(cmd.linear.x,0.)
                self.assertGreater(8.-position,.80)


class LoggedStartDynamicsV3524Tests(dynamics.FinishDynamicsV3523Tests):
    # Do not inherit and silently rerun historical tests: only these comparison
    # cases are loaded by load_tests below. Normal fast plants remain separate.
    comparisons=[]

    def test_short_logged_style_inputs_remain_weak_in_independent_plant(self):
        for duration in (.12,.20):
            p=SluggishStartPlant(start_delay=.30,micro_speed=.04,nonlinear_coast=True)
            for _ in range(round(duration/.005)):p.step(.35)
            for _ in range(200):p.step(0.)
            self.assertLess(p.x-6.4,.008)
        p=SluggishStartPlant(start_delay=.30,micro_speed=.04,nonlinear_coast=True)
        for _ in range(160):p.step(.35)
        self.assertGreater(p.x-6.4,.16)

    def test_weak_start_full_route_is_faster_with_fewer_stops_than_v23(self):
        for lag in (.25,.35):
            with self.subTest(lag=lag),patch.object(dynamics,'MotorPlant',SluggishStartPlant):
                config=dict(x=5.6,start_delay=lag,accel_tau=.25,micro_speed=.04,
                    nonlinear_coast=True,odom_delay=.15,scan_delay=.06)
                with old_parking():old=self.rollout('V23_weak_'+str(lag),**config)
                new=self.rollout('V24_weak_'+str(lag),**config)
                self.assertLess(new['elapsed_s'],old['elapsed_s']*.80)
                self.assertLess(new['positive_bursts'],old['positive_bursts'])
                self.comparisons.append(dict(lag=lag,before=old,after=new))

    def test_millimetre_source_noise_preserves_continuous_approach(self):
        receive=dynamics.FinishDynamicsV3523Tests.receive_laser_pose
        def noisy(case,pose,source=None):
            stamp=case.source_now if source is None else source
            delta=.001*math.sin(stamp*2*math.pi/.20)
            return receive(case,(pose[0]+delta,pose[1],pose[2]),source=source)
        with patch.object(dynamics,'MotorPlant',SluggishStartPlant), \
             patch.object(dynamics.FinishDynamicsV3523Tests,'receive_laser_pose',noisy):
            config=dict(x=5.6,start_delay=.30,accel_tau=.25,micro_speed=.04,
                nonlinear_coast=True,odom_delay=.15,scan_delay=.06)
            with old_parking():old=self.rollout('V23_weak_1mm_noise',**config)
            new=self.rollout('V24_weak_1mm_noise',**config)
            self.assertLess(new['elapsed_s'],old['elapsed_s']*.80)
            self.assertLess(new['positive_bursts'],old['positive_bursts'])
            self.comparisons.append(dict(odom_noise_amplitude_m=.001,before=old,after=new))


def load_tests(loader,tests,pattern):
    suite=loader.loadTestsFromTestCase(FinishDistanceV3524Tests)
    suite.addTest(LoggedStartDynamicsV3524Tests('test_short_logged_style_inputs_remain_weak_in_independent_plant'))
    suite.addTest(LoggedStartDynamicsV3524Tests('test_weak_start_full_route_is_faster_with_fewer_stops_than_v23'))
    suite.addTest(LoggedStartDynamicsV3524Tests('test_millimetre_source_noise_preserves_continuous_approach'))
    return suite


if __name__=='__main__':unittest.main()
