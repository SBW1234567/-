"""Vectorized finite-return sweep equivalence and boundary regressions."""
import math
from pathlib import Path
import sys
import types
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'))
import race_curve_core as core


def scan(ranges,angle_min=-math.pi,increment=None):
    return types.SimpleNamespace(ranges=ranges,angle_min=angle_min,
        angle_increment=2*math.pi/len(ranges) if increment is None else increment,
        range_min=.05,range_max=12.)


def scalar_hits(scan,pose,samples,margin=.08):
    """The V35.11 implementation, retained only as an independent oracle."""
    if scan is None:return True
    ranges=np.asarray(scan.ranges,dtype=float)
    valid=np.isfinite(ranges)&(ranges>=max(scan.range_min,.30))&(ranges<=scan.range_max)
    angles=scan.angle_min+np.flatnonzero(valid)*scan.angle_increment
    points=np.column_stack((ranges[valid]*np.cos(angles),ranges[valid]*np.sin(angles)))
    for q in samples:
        x,y=core.local(q,pose);h=core.wrap(q[2]-pose[2]);c,s=math.cos(h),math.sin(h)
        d=points-np.array([x,y]);bx=c*d[:,0]+s*d[:,1];by=-s*d[:,0]+c*d[:,1]
        if np.any((bx>=-.185-margin)&(bx<=.20+margin)&(abs(by)<=.15+margin)):
            return True
    return False


class SweepPerformanceTests(unittest.TestCase):
    def test_seeded_equivalence_for_full_partial_and_duplicated_scans(self):
        rng=np.random.default_rng(3512)
        hits=clears=0
        for case in range(240):
            n=(60,180,448,449,450,451,720)[case%7]
            r=rng.uniform(.05,13.,n)
            r[rng.random(n)<.18]=math.inf
            r[rng.random(n)<.04]=math.nan
            r[rng.random(n)<.01]=-math.inf
            inc=(math.pi/(n-1),2*math.pi/(n-1),2*math.pi/(n-2))[case%3]
            s=scan(r,math.radians(-3.)+rng.uniform(-.2,.2),inc)
            pose=tuple(rng.uniform((-8.,-4.,-math.pi),(8.,4.,math.pi)))
            # Alternate clear, far rectangles and poses traversing nearby rays.
            xy=rng.uniform((15.,15.),(18.,18.),(40,2)) if case%2 else rng.uniform((-.4,-.4),(1.,.4),(40,2))
            samples=[(*core.world(p,pose),pose[2]+rng.uniform(-1.5,1.5)) for p in xy]
            margin=(0.,.08,.12)[case%3]
            expected=scalar_hits(s,pose,samples,margin)
            actual=core.scan_hits_body(s,pose,samples,margin)
            self.assertEqual(actual,expected,msg=f'case {case}, n={n}')
            hits+=expected;clears+=not expected
        self.assertGreater(hits,60)
        self.assertGreater(clears,60)

    def test_each_exact_rectangle_boundary_is_conservatively_closed(self):
        pose=(5.2,1.1,.17)
        q=(*core.world((.9,.1),pose),pose[2]+.7)
        for point in ((-.265,0.),(.28,0.),(0.,-.23),(0.,.23),(-.265,.23),(.28,-.23)):
            with self.subTest(point=point):
                p=core.local(core.world(point,q),pose)
                s=scan([math.hypot(*p)]+[math.inf]*449,math.atan2(p[1],p[0]))
                self.assertTrue(core.scan_hits_body(s,pose,[q]))

    def test_tolerance_does_not_hide_a_real_boundary_exit(self):
        pose=(0.,0.,0.);q=(.6,0.,.7)
        for point in ((-.265-1e-9,0.),(.28+1e-9,0.),(0.,-.23-1e-9),(0.,.23+1e-9)):
            with self.subTest(point=point):
                p=core.world(point,q)
                s=scan([math.hypot(*p)]+[math.inf]*449,math.atan2(p[1],p[0]))
                self.assertFalse(core.scan_hits_body(s,pose,[q]))

    def test_raw_extra_endpoint_is_never_dropped(self):
        for n in (449,451):
            for endpoint in (0,n-2,n-1):
                with self.subTest(n=n,endpoint=endpoint):
                    r=[math.inf]*n;r[endpoint]=.5
                    s=scan(r,math.radians(-3.),2*math.pi/(n-2))
                    self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),[(.4,-.04,0.)]))

    def test_collision_in_final_block_and_empty_inputs(self):
        r=[12.]*720;r[0]=.5;s=scan(r,0.)
        samples=[(2.+i*.001,0.,0.) for i in range(240)]+[(.4,0.,0.)]
        self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),samples))
        self.assertFalse(core.scan_hits_body(s,(0.,0.,0.),samples[:-1]))
        self.assertFalse(core.scan_hits_body(s,(0.,0.,0.),[]))
        self.assertFalse(core.scan_hits_body(scan([math.inf]*450),(0.,0.,0.),samples))
        self.assertTrue(core.scan_hits_body(None,(0.,0.,0.),samples))

    def test_numpy_and_generator_samples_keep_equivalent_results(self):
        s=scan([2.]*450);pose=(0.,0.,0.)
        samples=[(i*.02,.05,0.) for i in range(40)]
        expected=scalar_hits(s,pose,samples)
        self.assertEqual(core.scan_hits_body(s,pose,np.asarray(samples)),expected)
        self.assertEqual(core.scan_hits_body(s,pose,(q for q in samples)),expected)

    def test_geometry_validator_matches_strict_metadata_gate(self):
        valid=scan([2.]*450)
        self.assertTrue(core.scan_geometry_valid(valid))
        for field,value in (('ranges',[2.]*59),('angle_increment',0.),
                ('angle_increment',math.nan),('angle_min',math.inf),
                ('range_min',math.nan),('range_max',.29),('range_max',math.inf)):
            with self.subTest(field=field,value=value):
                s=types.SimpleNamespace(**vars(valid));setattr(s,field,value)
                self.assertFalse(core.scan_geometry_valid(s))
                self.assertEqual(core.scan_observes_body(s,(0.,0.,0.),[]),(False,'SCAN_GEOMETRY'))
        self.assertFalse(core.scan_geometry_valid(None))
        self.assertFalse(core.scan_geometry_valid(types.SimpleNamespace()))


if __name__=='__main__':
    unittest.main()
