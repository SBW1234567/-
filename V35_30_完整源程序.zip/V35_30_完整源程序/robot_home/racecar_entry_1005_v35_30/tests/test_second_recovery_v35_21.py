"""Second-cone geometry and future/current tracking-error regressions.

Recorded poses/cones come from the two V20 runs at 16:27 and 16:29. Their
exact planning seeds and raw scans were not logged. Paths below are explicitly
reconstructed from handoff observations; scans independently raycast handbook
boards and 12 cm cones. Early-exit lag cases are synthetic pressure scenarios.
"""
import math
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_controller_recovery_v35_13 as fixture

cm,core=helpers.cm,helpers.core
LOWER_STOP=(2.4842551559683352,1.2399209054042282,-2.7382507427283818)
LOWER_START=(5.1293008302638805,.8212433462819252,.1727972201336536)
LOWER_CONES=((6.238751897452905,1.884480059866977),(1.9979217955929873,1.9826733170319568))
UPPER_STOP=(.9603919518376396,3.168409872992642,2.0114527375499014)
UPPER_EARLY=(1.1005878423728284,2.9343719904494616,1.766631088963687) # 65.104 s
UPPER_PREBRAKE=(1.2197834903478353,2.5667488545372255,1.2230180118870793) # 64.803 s
UPPER_START=(6.008109777254023,.7149543267907735,.027931131615782086)
UPPER_CONES=((6.249381290595993,1.8911962175000991),(2.0033001900880767,1.9914508675155305))
PATHS={}


class SecondRecoveryV3521Tests(unittest.TestCase):
    source=fixture.ControllerRecoveryTests.source
    inputs=fixture.ControllerRecoveryTests.inputs

    def setUp(self):
        fixture.ControllerRecoveryTests.setUp(self)
        self.configure(LOWER_STOP,LOWER_START,LOWER_CONES)

    def configure(self,pose,start,cones):
        key=(start,cones)
        if key not in PATHS:PATHS[key]=core.plan_entry_path(start,cones=cones)
        self.pose=pose;self.cones=cones;c=self.c
        c.phase=c.SEEK_CONE_2;c.curve_curvature_gain=5.;c.curve_cones=cones
        f=c.curve_follower=core.PathFollower(PATHS[key])
        f.index=min(range(len(f.path.samples)),key=lambda i:core.dist(f.path.samples[i],pose))
        f.progress=float(f.path.lengths[f.index])
        c.curve_locator.pose=pose;c.curve_locator.time=self.now;c.curve_pose_odom=pose
        c.curve_odom_samples.clear();c.curve_motion_samples.clear()
        c.last_motion_stamp=0.;c.last_odom_xy=None;c.last_yaw=None
        c.curve_last_drive_time=self.now-2.;c.last_lane_angular=0.;c.curve_drive=0.
        c.curve_recovery_state=None;c.curve_pause_active=False;c.curve_control_status={}
        c.route_fault=''
        for dt in (-.9,-.6,-.3,-.1):self.source(self.ros_time+dt,pose)
        self.fresh_scan(pose);c.curve_pose_estimate(self.now)
        return f

    def fresh_scan(self,pose):
        with patch.object(core,'CONES',self.cones):self.inputs(pose)

    def tick(self,dt=.1,pose=None):
        self.now+=dt;self.ros_time+=dt
        if pose is not None:self.pose=pose
        self.source(self.ros_time,self.pose);self.fresh_scan(self.pose)
        c=self.c;c.curve_locator.pose=self.pose;c.curve_locator.time=self.now;c.curve_pose_odom=self.pose
        return c.curve_command(self.now)

    def prepare_feedback(self):
        f=self.c.curve_follower;f.command(self.pose,self.now,5.)
        return f

    def test_lower_stop_37deg_veto_removed_but_forward_offset_bounds_retained(self):
        f=self.prepare_feedback()
        arc=core.constant_steer_horizon(self.pose,-.32,5.,distance=.65,initial_steer=-.32)
        self.assertTrue(self.c.curve_second_recovery_geometry(self.pose,f,arc)[0])
        endpoints=self.c.curve_recovery_geometry_status['endpoints']
        self.assertTrue(all(.10<=e['advance_m']<=1.15 and e['offset_m']<.30 for e in endpoints))
        self.assertFalse(core.scan_hits_body(self.c.curve_scan,self.pose,arc))
        self.assertEqual(self.c.curve_second_recovery_geometry(self.pose,f,[self.pose]*len(arc)),
                         (False,'SECOND_RECOVERY_PROGRESS'))
        # V25 keeps this recorded pose recoverable but its clockwise profile
        # changes the endpoint tangent: max error is now .595, below the old
        # .65 veto. Preserve a separate explicit witness for that removed veto
        # with only a synthetic -.10 rad heading perturbation; retain all map,
        # forward-progress, offset and raw-obstacle checks.
        x,y,yaw=LOWER_STOP
        f=self.configure((x,y,yaw-.10),LOWER_START,LOWER_CONES)
        self.prepare_feedback()
        arc=core.constant_steer_horizon(self.pose,-.32,5.,distance=.65,initial_steer=-.32)
        self.assertTrue(self.c.curve_second_recovery_geometry(self.pose,f,arc)[0])
        endpoints=self.c.curve_recovery_geometry_status['endpoints']
        self.assertGreater(max(e['heading_error_rad'] for e in endpoints),.65)
        self.assertTrue(all(.10<=e['advance_m']<=1.15 and e['offset_m']<.30 for e in endpoints))
        self.assertFalse(core.scan_hits_body(self.c.curve_scan,self.pose,arc))

    def test_lower_stop_missing_028_candidate_reaches_raw_check_and_presteers(self):
        f=self.prepare_feedback();original=self.c.curve_check_sweep;checks=[]
        def checked(*args):checks.append(args[2]);return original(*args)
        with patch.object(self.c,'curve_check_sweep',side_effect=checked):
            command=self.c.curve_obstacle_recovery(self.pose,f,self.now)
        self.assertIsNotNone(command)
        self.assertEqual(command.linear.x,0.);self.assertAlmostEqual(command.angular.z,-.28)
        candidates=self.c.curve_recovery_status['candidates']
        self.assertEqual(candidates[-1]['steer'],-.28)
        self.assertEqual(candidates[-1]['reason'],'CLEAR_RAW')
        self.assertTrue(candidates[-1]['geometry']['map_clear'])
        self.assertGreaterEqual(len(checks),2) # settled selection plus actual response

    def test_lower_stop_settles_then_uses_fresh_response_checked_drive(self):
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        for _ in range(9):
            command=self.tick()
            if command.linear.x>0.:break
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status.get('arc_clear',False)
                        or self.c.curve_recovery_status['state']=='NORMAL_PATH_CLEAR')

    def test_removed_heading_veto_does_not_bypass_a_real_raw_obstacle(self):
        f=self.prepare_feedback();self.assertTrue(self.c.curve_second_recovery_scope(f))
        # Add one measured obstacle in each map-clear strong candidate's path.
        scan=self.c.curve_scan
        for steer in (-.28,-.32):
            arc=core.constant_steer_horizon(self.pose,steer,5.,distance=.65,initial_steer=steer)
            x,y=core.local(arc[16],self.pose)
            k=round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment)%len(scan.ranges)
            scan.ranges[k]=math.hypot(x,y)
        self.assertIsNone(self.c.curve_obstacle_recovery(self.pose,f,self.now))
        reasons={x['steer']:x['reason'] for x in self.c.curve_recovery_status['candidates']}
        self.assertEqual(reasons[-.28],'SWEPT_OBSTACLE')
        self.assertEqual(reasons[-.32],'SWEPT_OBSTACLE')

    def test_current_tracking_failure_cannot_use_local_recovery(self):
        with patch.object(self.c.curve_follower,'command',side_effect=ValueError('CURVE_TRACK_ERROR')), \
             patch.object(self.c,'curve_obstacle_recovery',side_effect=AssertionError('current pose invalid')):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(self.c.curve_control_status['tracking_error_scope'],'CURRENT')
        self.assertEqual(self.c.curve_control_status['command_pose'],self.pose)
        self.assertEqual(self.c.curve_sweep_diagnostics['result'],'CURRENT_TRACK_ERROR')
        self.assertEqual(self.c.curve_sweep_diagnostics['scope'],'CURRENT')
        self.assertEqual(self.c.curve_sweep_diagnostics['finished_at'],self.now)

    def early_exit_lag(self):
        # A valid earlier exit pose, with wheels still physically left while
        # feedback now wants right. The future PID rollout loses the path;
        # a stopped, pre-positioned clockwise arc can reconnect safely.
        f=self.configure((1.,2.65,2.),UPPER_START,UPPER_CONES)
        self.c.phase=self.c.ORBIT_CONE_2
        f.output=f.response_output=.32;f.time=self.now
        self.c.last_lane_angular=.32
        return f

    def test_early_exit_future_error_enters_checked_recovery(self):
        f=self.early_exit_lag()
        self.assertFalse(f.second_cone_approach())
        self.assertTrue(self.c.curve_second_recovery_scope(f))
        command=self.c.curve_command(self.now)
        self.assertEqual(self.c.curve_control_status.get('tracking_error_scope'),'FUTURE')
        self.assertEqual(self.c.curve_control_status['tracking_error'],'CURVE_TRACK_ERROR')
        self.assertIsNotNone(self.c.curve_recovery_state)
        self.assertEqual(command.linear.x,0.)
        self.assertLess(command.angular.z,0.)
        self.assertEqual(self.c.curve_recovery_status['normal_sweep']['result'],'FUTURE_TRACK_ERROR')
        for _ in range(9):
            command=self.tick()
            if command.linear.x>0.:break
        self.assertGreater(command.linear.x,0.)

    def test_recorded_early_exit_blocked_sweep_can_preposition_and_recover(self):
        self.configure(UPPER_EARLY,UPPER_START,UPPER_CONES)
        self.c.phase=self.c.ORBIT_CONE_2
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertLess(command.angular.z,0.)
        self.assertEqual(self.c.curve_recovery_status['normal_sweep']['result'],'SWEPT_OBSTACLE')
        self.assertTrue(self.c.curve_recovery_status['candidates'][-1]['geometry']['map_clear'])
        self.assertEqual(self.c.curve_recovery_status['candidates'][-1]['reason'],'CLEAR_RAW')
        for _ in range(9):
            command=self.tick()
            if command.linear.x>0.:break
        self.assertGreater(command.linear.x,0.)

    def run_closed_loop(self,physical_gain,initial_servo=0.,first_command=None):
        # Independent physical body integration and fresh rendered scans.
        # The actual RF2O delays/noise and unrecorded scan are not reproduced.
        f=self.c.curve_follower;pose=self.pose;servo=initial_servo;dt=.1
        target_progress=f.path.gates[4]-.05
        for step in range(120):
            command=first_command if step==0 and first_command is not None else self.tick(dt,pose)
            target=command.angular.z
            mean=target+(servo-target)*.12/dt*(-math.expm1(-dt/.12))
            servo=target+(servo-target)*math.exp(-dt/.12)
            speed=.5 if command.linear.x>0. else 0.
            pose=self.c.curve_integrate_motion(pose,(speed,0.,speed*physical_gain*mean),dt)
            self.assertTrue(core.body_clear(pose,cones=self.cones,margin=.02),(step,pose))
            self.assertFalse(self.c.route_fault)
            if f.progress>=target_progress:break
        return f.progress>=target_progress,command

    def test_closed_loop_lower_stop_and_earlier_exit_for_all_gains(self):
        for start,seed,cones in ((LOWER_STOP,LOWER_START,LOWER_CONES),
                                  (UPPER_PREBRAKE,UPPER_START,UPPER_CONES)):
            for physical_gain in (4.,5.,6.):
                with self.subTest(start=start,physical_gain=physical_gain):
                    self.configure(start,seed,cones)
                    self.c.phase=self.c.ORBIT_CONE_2
                    reached,_=self.run_closed_loop(physical_gain)
                    self.assertTrue(reached,self.c.curve_recovery_status)

    def test_early_future_failure_closed_loop_reconnects_at_nominal_and_high_gain(self):
        for physical_gain in (5.,6.):
            with self.subTest(physical_gain=physical_gain):
                self.early_exit_lag()
                first=self.c.curve_command(self.now)
                self.assertEqual(self.c.curve_control_status['tracking_error_scope'],'FUTURE')
                reached,_=self.run_closed_loop(physical_gain,.32,first)
                self.assertTrue(reached,self.c.curve_recovery_status)

    def test_later_recorded_exit_recovery_has_real_space_limit(self):
        # The later 65.104 pose is recoverable at high curvature, but at lower
        # curvature all-gain clearance runs out after ~15 cm. Do not claim it
        # guarantees an autonomous exit or erase its genuine remaining stop.
        for physical_gain in (4.,5.,6.):
            with self.subTest(physical_gain=physical_gain):
                self.configure(UPPER_EARLY,UPPER_START,UPPER_CONES)
                self.c.phase=self.c.ORBIT_CONE_2
                reached,command=self.run_closed_loop(physical_gain)
                self.assertEqual(reached,physical_gain==6.)
                if not reached:
                    self.assertEqual(command.linear.x,0.)
                    self.assertEqual(self.c.curve_recovery_status['state'],'NO_CLEAR_ARC')

    def test_moving_early_exit_uses_actual_servo_not_settled_full_lock(self):
        for response in (0.,.32):
            with self.subTest(response=response):
                f=self.configure(UPPER_EARLY,UPPER_START,UPPER_CONES)
                c=self.c;c.phase=c.ORBIT_CONE_2
                c.curve_odom_samples.clear();c.curve_motion_samples.clear()
                c.last_motion_stamp=0.;c.last_odom_xy=None;c.last_yaw=None
                x,y,yaw=UPPER_EARLY
                for dt in (-.3,-.2,-.1,0.):
                    self.source(self.ros_time+dt,(x+.5*dt*math.cos(yaw),y+.5*dt*math.sin(yaw),yaw))
                c.curve_last_drive_time=self.now-.05
                f.output=f.response_output=response;f.time=self.now;c.last_lane_angular=response
                command=c.curve_command(self.now)
                if response==0.:
                    self.assertGreater(command.linear.x,0.)
                    self.assertFalse(c.curve_recovery_status['preposition_required'])
                    self.assertEqual(c.curve_recovery_status['response_at_check'],0.)
                    self.assertTrue(c.curve_recovery_status['actual_response_geometry']['map_clear'])
                else:
                    self.assertEqual(command.linear.x,0.)
                    self.assertEqual(c.curve_recovery_status['state'],'NO_CLEAR_ARC')

    def test_final_recorded_exit_trap_stays_stopped_when_all_forward_arcs_fail(self):
        self.configure(UPPER_STOP,UPPER_START,UPPER_CONES)
        self.c.phase=self.c.ORBIT_CONE_2
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(self.c.curve_control_status.get('tracking_error_scope'),'FUTURE')
        self.assertEqual(self.c.curve_recovery_status['state'],'NO_CLEAR_ARC')
        self.assertIsNone(self.c.curve_recovery_state)
        self.assertTrue(self.c.curve_recovery_status['candidates'])

    def test_first_cone_future_error_does_not_gain_second_cone_recovery(self):
        path=self.c.curve_follower.path
        pose=tuple(path.samples[180,:3]);f=self.configure(pose,LOWER_START,LOWER_CONES)
        self.assertFalse(self.c.curve_second_recovery_scope(f))
        with patch.object(cm,'command_horizon',side_effect=ValueError('CURVE_TRACK_ERROR')), \
             patch.object(self.c,'curve_obstacle_recovery',side_effect=AssertionError('first cone altered')):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertFalse(self.c.curve_recovery_status['local_recovery_allowed'])

    def test_stale_scan_during_future_error_never_authorizes_drive(self):
        self.early_exit_lag();self.c.curve_scan_time=self.now-.36
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertIsNone(self.c.curve_recovery_state)

    def test_source_expiring_after_clear_candidate_cannot_drive(self):
        f=self.prepare_feedback();original=self.c.curve_check_sweep
        def expire_source(*args):
            result=original(*args)
            if result[0]:self.c.last_odom_time=self.now-1.01
            return result
        with patch.object(self.c,'curve_check_sweep',side_effect=expire_source):
            command=self.c.curve_obstacle_recovery(self.pose,f,self.now)
        self.assertTrue(command is None or command.linear.x==0.)
        self.assertEqual(self.c.curve_recovery_status['state'],'RECOVERY_FINAL_CHECK_WAIT')
        self.assertTrue(self.c.curve_recovery_status['final_check_reason'])
        self.assertIsNone(self.c.curve_recovery_state)


if __name__=='__main__':unittest.main(verbosity=2)
