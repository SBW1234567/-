"""Current behavior plus inherited straight, crosswalk and collision checks."""
import unittest
import test_continuous
import test_straight
import test_sweep_gaps
import test_scan_seam
import test_uneven_wall
import test_registration_recovery
import test_entry_tolerant_control
import test_entry_plan_relaxed
import test_registration_relaxed
import test_curve_relaxed
import test_relaxed_handoff
import test_curve_response
import test_curve_prediction
import test_curve_control_response
import test_sweep_performance

suite=unittest.TestSuite()
for module in (test_continuous,test_scan_seam,test_uneven_wall,test_registration_recovery,
    test_entry_tolerant_control,test_entry_plan_relaxed,test_registration_relaxed,
    test_curve_relaxed,test_relaxed_handoff,test_curve_response,
    test_curve_prediction,test_curve_control_response,test_sweep_performance):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(test_sweep_gaps.SweepGapTests))
for test in unittest.defaultTestLoader.loadTestsFromTestCase(test_straight.StraightTests):
    if test._testMethodName not in ('test_task_and_collision_methods_unchanged',
                                    'test_geometry_only_approved_functions_changed'):
        suite.addTest(test)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
