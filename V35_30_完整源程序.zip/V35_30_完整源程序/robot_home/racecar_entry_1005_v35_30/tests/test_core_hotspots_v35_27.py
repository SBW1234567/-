"""Exact decisions and diagnostics versus frozen V26, including adversarial edges."""
import copy
import hashlib
import importlib.util
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
import warnings

import numpy as np

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE/'payload/src/racecar/scripts'))
import race_curve_core as current
BASE=PACKAGE/'tests/baselines/core_before_v35_27.py'
if hashlib.sha256(BASE.read_bytes()).hexdigest()!='310e7f1901e736c788cc8b3936c211153df0b181adc09110d80c665d71e2665e':
    raise AssertionError('Frozen V26 reference changed')
spec=importlib.util.spec_from_file_location('hotspots_frozen_v26',BASE)
before=importlib.util.module_from_spec(spec);sys.modules[spec.name]=before;spec.loader.exec_module(before)

def scan(n=451):
    return SimpleNamespace(ranges=np.full(n,math.inf),angle_min=-.0523598775598,
        angle_increment=2*math.pi/(n-1),range_min=.20,range_max=12.)

class ScanBroadPhaseTests(unittest.TestCase):
    def compare(self,s,pose,samples,margin=.08):
        d0={'obsolete':True};d1={'obsolete':True}
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            a=before.scan_hits_body(s,pose,samples,margin=margin,diagnostics=d0)
            b=current.scan_hits_body(s,pose,samples,margin=margin,diagnostics=d1)
        self.assertEqual(a,b);self.assertEqual(d0,d1)
        self.assertEqual(current.scan_hits_body(s,pose,samples,margin=margin),a)
        return b,d1

    def test_seeded_finite_scans_all_pose_blocks_and_margins(self):
        rng=np.random.default_rng(352701)
        for i in range(160):
            s=scan(int(rng.integers(60,801)));s.angle_min=float(rng.uniform(-math.pi,math.pi))
            s.ranges=rng.uniform(.05,15.,len(s.ranges));s.ranges[rng.random(len(s.ranges))<.1]=math.inf
            pose=tuple(rng.uniform((-2.,-2.,-math.pi),(8.,4.,math.pi)))
            samples=np.column_stack((rng.uniform(pose[0]-1,pose[0]+1,37),
              rng.uniform(pose[1]-1,pose[1]+1,37),rng.uniform(-4.,4.,37)))
            with self.subTest(case=i):self.compare(s,pose,samples,float(rng.choice([0.,.08,.11,.14,.25,.3,-.1])))

    def test_rotated_contact_and_picometre_thresholds(self):
        s=scan();s.ranges[37]=1.25
        a=s.angle_min+37*s.angle_increment
        for margin in (0.,.08,.14,.25,.251):
            for yaw in (0.,.73,math.pi/2,-2.8):
                for edge in ((.20+margin,0.),(-.185-margin,0.),(0.,.15+margin),(0.,-.15-margin),(.20+margin,.15+margin)):
                    for delta in (-2e-12,-.5e-12,0.,.5e-12,2e-12):
                        bx,by=edge;bx+=delta;by+=delta
                        pose=(2.,1.,.31);px,py=before.world((1.25*math.cos(a),1.25*math.sin(a)),pose)
                        q=(px-math.cos(yaw)*bx+math.sin(yaw)*by,py-math.sin(yaw)*bx-math.cos(yaw)*by,yaw)
                        with self.subTest(margin=margin,yaw=yaw,edge=edge,delta=delta):self.compare(s,pose,[q],margin)

    def test_culling_preserves_total_valid_count_and_first_ray_order(self):
        s=scan();s.angle_min=0.;s.ranges[:]=8.;s.ranges[5]=.7;s.ranges[7]=.7
        q=(.65,.05,0.)
        hit,d=self.compare(s,(0.,0.,0.),[(3.,3.,0.)]*25+[q])
        self.assertTrue(hit);self.assertEqual(d['sample_index'],25)
        self.assertEqual(d['ray_index'],5);self.assertEqual(d['valid_returns'],451)

    def test_duplicate_endpoint_and_earlier_sample_win(self):
        s=scan(452);s.angle_increment=2*math.pi/450;s.angle_min=0.
        s.ranges[0]=.50;s.ranges[451]=.90
        hit,d=self.compare(s,(0.,0.,0.),[(.85,0.,0.),(.4,0.,0.)])
        self.assertTrue(hit);self.assertEqual(d['sample_index'],0);self.assertEqual(d['ray_index'],451)

    def test_dense_scan_respects_original_diagnostics_across_block_sizes(self):
        s=scan(70000);s.ranges[:]=10.;s.ranges[-2]=.75
        hit,d=self.compare(s,(0.,0.,0.),[(5.,5.,0.)]*12+[(.7,0.,0.)])
        self.assertTrue(hit);self.assertEqual(d['sample_index'],12);self.assertEqual(d['valid_returns'],70000)

    def test_missing_empty_invalid_and_unbounded_inputs_keep_legacy_results(self):
        self.compare(None,(0.,0.,0.),[(0.,0.,0.)]);self.compare(scan(),(0.,0.,0.),[])
        s=scan();s.ranges[:]=np.nan;self.compare(s,(0.,0.,0.),[(0.,0.,0.)])
        s.ranges[0]=.6
        for pose,samples,margin in [((0.,0.,0.),[(math.nan,0.,0.)],.08),
          ((10000.,10000.,0.),[(10000.6,10000.,0.)],.08),
          ((0.,0.,0.),[(.5,0.,0.)],math.inf),((0.,0.,0.),[(.5,0.,0.)],math.nan),
          ((0.,0.,0.),[(.5,0.,0.)],-.3)]:self.compare(s,pose,samples,margin)
        for field in ('angle_min','angle_increment','range_max'):
            q=copy.deepcopy(s);setattr(q,field,math.nan)
            self.compare(q,(0.,0.,0.),[(.5,0.,0.)])

    def test_no_cross_scan_cache_or_input_mutation(self):
        s=scan();samples=np.asarray([(.5,0.,0.)]);original=samples.copy()
        self.assertFalse(self.compare(s,(0.,0.,0.),samples)[0])
        s.ranges[0]=.6;copy_ranges=s.ranges.copy()
        self.assertTrue(self.compare(s,(0.,0.,0.),samples)[0])
        np.testing.assert_array_equal(s.ranges,copy_ranges);np.testing.assert_array_equal(samples,original)
        s.ranges[0]=math.inf;self.assertFalse(self.compare(s,(0.,0.,0.),samples)[0])

    def test_generator_samples_match_original_once_consumed_sequence(self):
        s=scan();s.ranges[0]=.6;samples=[(2.,2.,0.),(.5,0.,0.)]
        d0={};d1={}
        a=before.scan_hits_body(s,(0.,0.,0.),(p for p in samples),diagnostics=d0)
        b=current.scan_hits_body(s,(0.,0.,0.),(p for p in samples),diagnostics=d1)
        self.assertEqual((a,d0),(b,d1))

class LocateNearestFirstTests(unittest.TestCase):
    def compare(self,samples,pose,index=0,progress=None):
        p=SimpleNamespace(samples=samples,lengths=np.arange(len(samples))*.025)
        a=before.PathFollower(p);b=current.PathFollower(p)
        for f in (a,b):f.index=index;f.progress=p.lengths[index] if progress is None and len(samples) else (progress or 0.)
        outcomes=[]
        for f in (a,b):
            try:outcomes.append(('return',f.locate(pose)))
            except (ValueError,IndexError,TypeError) as exc:outcomes.append((type(exc).__name__,str(exc)))
        self.assertEqual(outcomes[0],outcomes[1]);self.assertEqual((a.index,a.progress),(b.index,b.progress))
        return outcomes[1]

    def test_seeded_paths_ties_opposite_segments_and_monotonic_index(self):
        rng=np.random.default_rng(352702)
        for i in range(1000):
            a=rng.uniform((-1.,-1.,-math.pi,-1.),(1.,1.,math.pi,1.),(65,4))
            if i%3==0:a[2,:2]=a[1,:2]
            with self.subTest(case=i):self.compare(a,tuple(rng.uniform((-.2,-.2,-math.pi),(.2,.2,math.pi))),int(rng.integers(0,40)))

    def test_nearest_opposite_heading_is_not_selected(self):
        a=np.array([[0.,0.,math.pi,0.],[.01,0.,0.,0.],[.02,0.,0.,0.]])
        self.assertEqual(self.compare(a,(0.,0.,0.)),('return',1))

    def test_equal_distance_earliest_compatible_tie(self):
        a=np.array([[.1,0.,math.pi,0.],[-.1,0.,0.,0.],[.1,0.,0.,0.]])
        self.assertEqual(self.compare(a,(0.,0.,0.)),('return',1))

    def test_perpendicular_tolerance_nan_infinity_and_empty(self):
        for h in [math.pi/2+d for d in (-2e-10,-1e-12,0.,.5e-12,2e-12,2e-10)]+[1001.,1e100,1e300,math.nan,math.inf,-math.inf]:
            a=np.array([[.1,0.,h,0.],[.2,0.,0.,0.]])
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',RuntimeWarning);self.compare(a,(0.,0.,0.))
        for a,p in [(np.empty((0,4)),(0.,0.,0.)),(np.array([[0.,0.,0.,0.]]),(math.nan,0.,0.)),
            (np.array([[math.nan,0.,0.,0.],[.2,0.,0.,0.]]),(0.,0.,0.)),
            (np.array([[2.,0.,0.,0.]]),(0.,0.,0.))]:
            with warnings.catch_warnings():warnings.simplefilter('ignore',RuntimeWarning);self.compare(a,p)

    def test_custom_array_float32_and_more_dimensions_take_equivalent_path(self):
        class CustomArray(np.ndarray):pass
        data=np.array([[.1,0.,0.,0.,9.],[.2,0.,math.pi,0.,8.]])
        for a in (data.astype(np.float32),data.view(CustomArray),data):self.compare(a,(0.,0.,0.))

    def test_complete_rollout_samples_remain_exact_with_feedback(self):
        path=before.plan_entry_path((5.50,.87,.16),cones=((6.026371747668275,1.9875903017781726),(2.,2.)))
        for index in np.linspace(5,len(path.samples)-8,24,dtype=int):
            q=path.samples[index];pose=(float(q[0]+.015),float(q[1]-.012),float(q[2]+.02))
            a=before.PathFollower(path,enable_integral=True);b=current.PathFollower(path,enable_integral=True)
            for f in (a,b):
                f.index=int(index);f.progress=float(path.lengths[index]);f.command(pose,10.,5.,.32);f.response_output=f.output*.7
            for distance in (.65,.935,1.10):
                expected=before.command_horizon(pose,a,5.,.32,distance=distance,speed=.9)
                actual=current.command_horizon(pose,b,5.,.32,distance=distance,speed=.9)
                self.assertEqual(expected,actual)

if __name__=='__main__':unittest.main()
