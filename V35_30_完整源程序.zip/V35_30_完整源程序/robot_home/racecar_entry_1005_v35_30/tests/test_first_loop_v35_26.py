"""First-cone physical loops with production paths and fixed V25 comparison.

The plant is shared with the independently integrated V25 second-cone tests;
only the phase, first-cone endpoint and source cadence are adapted below.
It consumes actual controller commands and stamped delayed observations.
Motor/servo dynamics, exact periodic wall anchors and synthetic raycasts are
explicit assumptions. Recorded predicted poses are physical-start hypotheses,
not reconstructed ground truth; neither original full scan nor servo was logged.
"""
import importlib.util
import inspect
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import test_second_loop_v35_25 as plant

core=plant.core
PACKAGE=Path(__file__).resolve().parents[1]
RUNS={
 '222526':dict(seed=(5.71896016038828,.8966230391551078,.19563429866659293),
    cones=((6.240534537119169,1.8903501317074034),(2.,2.)),
    pose=(5.71896016038828,.8966230391551078,.19563429866659293),speed=.35,steer=0.),
 '222840':dict(seed=(5.243480970441124,.8086774458189075,.16609993710015722),
    cones=((6.253442312222965,1.900147422574186),(2.,2.)),
    pose=(5.243480970441124,.8086774458189075,.16609993710015722),speed=.35,steer=0.),
 '222526_early':dict(seed=(5.7559706355451,.8728320382266391,.18719406196258556),
    cones=((6.240534537119169,1.8903501317074034),(2.,2.)),
    pose=(6.821670016276642,1.448194755954019,.8689408315804237),
    speed=.18981644622037308,steer=.21798574393292947),
}
# The early seed is an arc-length-calibrated hypothesis matching the logged
# first gate, not a recorded exact planner start. Other seeds are handoff poses.
PATHS={};BASELINE_PATHS={}


def _adapt_plant():
    source=inspect.getsource(plant.simulate_second)
    replacements={
      'def simulate_second(':'def _simulate_first(',
      'scan_blackout_after=None):':'scan_blackout_after=None,source_period=.10):',
      'c.phase=c.ORBIT_CONE_2;':'c.phase=c.ENTER_OBSTACLES;',
      'next_source=now+.10':'next_source=now+source_period',
      'if f.progress>=path.gates[4]+.60 and state[0]>=2.9 and abs(state[1]-3.55)<.30 and abs(core.wrap(state[2]))<.30:':
      "if f.progress>=path.gates[1]+.25 and state[0]<item['cones'][0][0]+.10 and abs(core.wrap(state[2]-math.pi))<.50:",
    }
    for before,after in replacements.items():
        if source.count(before)!=1:raise RuntimeError('Shared plant interface changed: '+before)
        source=source.replace(before,after)
    namespace=dict(plant.__dict__)
    exec(compile(source,str(Path(__file__))+'::shared_plant','exec'),namespace)
    return namespace['_simulate_first']


_simulate_first=_adapt_plant()


def baseline_path(run):
    if run not in BASELINE_PATHS:
        spec=importlib.util.spec_from_file_location('first_loop_fixed_v25',
            PACKAGE/'tests/baselines/core_before_v35_26.py')
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module);item=RUNS[run]
        BASELINE_PATHS[run]=module.plan_entry_path(item['seed'],item['cones'])
    return BASELINE_PATHS[run]


def simulate_first(run,*,baseline=False,**kwargs):
    item=RUNS[run]
    if run not in PATHS:PATHS[run]=core.plan_entry_path(item['seed'],item['cones'])
    path=baseline_path(run) if baseline else PATHS[run]
    with patch.dict(plant.RUNS,{run:item}),patch.dict(plant.PATHS,{run:path}):
        result=_simulate_first(run,max_time=25.,**kwargs)
    on=[p['drive']>0 for p in result['trace']]
    result.update(baseline=baseline,path_family=getattr(path,'entry_family','LEGACY_FALLBACK'),
        positive_runs=sum(v and (i==0 or not on[i-1]) for i,v in enumerate(on)))
    return result


def concise(result):return {k:v for k,v in result.items() if k!='trace'}


class FirstLoopV3526Tests(unittest.TestCase):
    def test_recorded_handoffs_complete_with_gain_delay_and_servo_variation(self):
        for run in ('222526','222840'):
            for gain in (4.,5.,6.):
                with self.subTest(run=run,gain=gain):
                    result=simulate_first(run,gain=gain,delay=.34,tau=.25,initial_speed=.70)
                    self.assertTrue(result['reached'],concise(result))
                    self.assertFalse(result['collision'],concise(result))
                    self.assertGreater(result['minimum_clearance_m'],.10,concise(result))
                    self.assertEqual(result['positive_runs'],1,concise(result))

    def test_point65_delay_and_point30_source_cadence_complete(self):
        for run in ('222526','222840'):
            with self.subTest(run=run):
                result=simulate_first(run,delay=.65,tau=.25,source_period=.30)
                self.assertTrue(result['reached'],concise(result))
                self.assertFalse(result['collision'],concise(result))
                self.assertEqual(result['positive_runs'],1,concise(result))

    def test_earlier_recorded_pose_avoids_fixed_v25_later_obstacle_deadlock(self):
        kwargs=dict(delay=.65,tau=.25,source_period=.30)
        before=simulate_first('222526_early',baseline=True,**kwargs)
        after=simulate_first('222526_early',**kwargs)
        self.assertFalse(before['reached'],concise(before))
        self.assertFalse(before['collision'],concise(before))
        self.assertTrue(before['stop_reasons'].get('RECOVERING_SWEPT_OBSTACLE'))
        self.assertTrue(after['reached'],concise(after))
        self.assertFalse(after['collision'],concise(after))
        self.assertEqual(after['positive_runs'],1,concise(after))
        self.assertLess(after['time_s'],before['time_s'])

    def test_point90_source_age_remains_zero_drive_after_compute(self):
        for run in ('222526','222840'):
            with self.subTest(run=run):
                result=simulate_first(run,delay=.90,tau=.25,source_period=.30)
                self.assertFalse(result['reached'],concise(result))
                self.assertFalse(result['collision'],concise(result))
                self.assertTrue(all(p['drive']==0. for p in result['trace']))
                self.assertIn('RECOVERING_CURVE_POSE_UNCONFIRMED',result['stop_reasons'])


if __name__=='__main__':unittest.main(verbosity=2)
