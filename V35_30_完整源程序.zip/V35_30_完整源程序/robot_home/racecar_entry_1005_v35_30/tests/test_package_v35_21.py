"""V21 six-file install/rollback checks using real payloads and temporary trees."""
import copy
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
import apply_patch as installer

class PackageV3521Tests(unittest.TestCase):
    def test_controller_changes_are_limited_to_second_recovery_and_registration(self):
        def tree(path):
            text=path.read_text(encoding='utf-8').replace(
                'SECOND_CONE_1002_V35_21','TRAFFIC_LIGHT_1002_V35_20')
            return ast.parse(text)
        old=tree(PACKAGE/'tests/baselines/controller_before_v35_21.py')
        new=tree(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py')
        def controller_methods(module):
            cls=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
            return {n.name:ast.dump(n) for n in cls.body if isinstance(n,ast.FunctionDef)}
        before,after=controller_methods(old),controller_methods(new)
        allowed_changed={
            '__init__','odom_callback','curve_scan_callback',
            'curve_pair_registration','curve_poll_registration',
            'curve_submit_registration','curve_reset_entry_pose','publish_entry_status',
            'curve_command','curve_obstacle_recovery','curve_second_recovery_geometry',
        }
        allowed_added={
            'curve_remember_registration_scan','curve_select_registration_scan',
            'curve_second_recovery_scope',
        }
        self.assertFalse(before.keys()-after.keys(),'Existing controller methods were removed')
        self.assertLessEqual(after.keys()-before.keys(),allowed_added)
        changed={name for name in before.keys()&after.keys() if before[name]!=after[name]}
        self.assertLessEqual(changed,allowed_changed,'Unexpected controller behavior changed')
        # This compares the ENTIRE traffic callback, phase state machine, final
        # straight control and crosswalk helpers, not just parameter defaults.
        for name in before.keys()-allowed_changed:
            with self.subTest(method=name):self.assertEqual(before[name],after[name])
        def top_functions(module):
            return {n.name:ast.dump(n) for n in module.body if isinstance(n,ast.FunctionDef)}
        self.assertEqual(top_functions(old),top_functions(new))

    def test_init_and_odom_callback_only_add_registration_cache_lifecycle(self):
        def methods(path):
            module=ast.parse(path.read_text(encoding='utf-8'))
            cls=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
            return {n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)}
        before=methods(PACKAGE/'tests/baselines/controller_before_v35_21.py')
        after=methods(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py')
        expected_init=copy.deepcopy(before['__init__'])
        marker=ast.dump(ast.parse('self.curve_registration_pending=None').body[0])
        positions=[i for i,n in enumerate(expected_init.body) if ast.dump(n)==marker]
        self.assertEqual(len(positions),1)
        additions=ast.parse("self.curve_registration_scans=deque(maxlen=16)\n"
                            "self.curve_registration_pair_status={'state':'INACTIVE'}\n"
                            "self.curve_job_strict_pair=None\n").body
        position=positions[0]+1
        expected_init.body[position:position]=additions
        self.assertEqual(ast.dump(expected_init),ast.dump(after['__init__']))
        expected_odom=copy.deepcopy(before['odom_callback'])
        old_condition=ast.parse("self.curve_observation_active() and getattr(self,'curve_registration_pending',None) is not None",mode='eval').body
        new_condition=ast.parse("self.curve_observation_active() and (getattr(self,'curve_registration_pending',None) is not None or self.curve_registration_scans)",mode='eval').body
        branches=[n for n in expected_odom.body if isinstance(n,ast.If) and ast.dump(n.test)==ast.dump(old_condition)]
        self.assertEqual(len(branches),1)
        branches[0].test=new_condition
        self.assertEqual(ast.dump(expected_odom),ast.dump(after['odom_callback']))

    def test_vision_config_core_guard_and_launch_retain_exact_v20(self):
        expected={
            'src/racecar/scripts/race_curve_core.py':'3e1bac23f0c587b800b6e9365a9e438c1d1d2c0faf92bcdc4834b3528d37ce2d',
            'src/racecar/scripts/race_lidar_guard.py':'2651735dd452a24def8d00b3fbaf41c02df41b8df975852f745237b0395c2e4f',
            'src/racecar/launch/race_competition.launch.py':'10af9e64911d05fb3633c289131f37b00896ceff9b9d90fe792a25267b3f4ecd',
            'src/racecar/scripts/ican_vision_node.py':'f06836a2f4fd71afbb921950fdb6dd90f822e844481dc1a2e9fb0f9456886e9a',
            'src/racecar/config/competition_params.yaml':'7adc3341f9a5adb57a9e1a58dc97d6dc28a1b725a3b0030c5105e4f74ea46852',
        }
        for relative,value in expected.items():
            for directory in ('payload','rollback'):
                with self.subTest(path=relative,directory=directory):
                    self.assertEqual(hashlib.sha256((PACKAGE/directory/relative).read_bytes()).hexdigest(),value)

    def test_historical_vision_calibration_keeps_original_v19_inputs(self):
        report=json.loads((PACKAGE/'CALIBRATION_V35_20.json').read_text(encoding='utf-8'))
        for filename,key in (('vision_before_v35_20.py','v19_source_sha256'),
                             ('competition_params_before_v35_20.yaml','v19_config_sha256')):
            self.assertEqual(hashlib.sha256((PACKAGE/'tests/baselines'/filename).read_bytes()).hexdigest(),report[key])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/scripts/ican_vision_node.py').read_bytes()).hexdigest(),report['v20_source_sha256'])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/config/competition_params.yaml').read_bytes()).hexdigest(),report['v20_config_sha256'])

    def test_runner_arguments_preserve_v20(self):
        def function(path,name):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name))
        self.assertEqual(function(PACKAGE/'launch_centered.py','make_command'),
                         function(PACKAGE/'tests/baselines/launch_centered_before_v35_21.py','make_command'))
        runner=(PACKAGE/'run_v35_21.sh').read_text(encoding='utf-8')
        self.assertIn('RACE_DRY_RUN=${2:-true}',runner)
        self.assertIn('RACE_PREPARE_DRIVE=${3:-0.35}',runner)

    def test_install_and_rollback_snapshot_precedes_source_mutation(self):
        for filename,label,action in (
                ('install.sh','before-v35-21-install','--workspace "$RACE_WORKSPACE"\n'),
                ('rollback_v35_20.sh','before-v35-21-rollback-to-v35-20','--workspace "$RACE_WORKSPACE" --rollback')):
            shell=(PACKAGE/filename).read_text(encoding='utf-8')
            snapshot='python3 /home/bianbu/snapshot_vehicle_git.py --label '+label
            mutation='python3 "$PATCH_DIR/apply_patch.py" '+action
            with self.subTest(script=filename):
                self.assertIn('set -e\n',shell)
                self.assertIn('"$(readlink -f -- "$RACE_WORKSPACE")" != /home/bianbu/racecar',shell)
                self.assertLess(shell.index('--check'),shell.index(snapshot))
                self.assertLess(shell.index(snapshot),shell.index(mutation))

    def test_exact_six_file_overlay_includes_vision_and_yaml_rollback(self):
        base,overlay,changes=installer.load_manifests()
        self.assertEqual(overlay['version'],'SECOND_CONE_1002_V35_21')
        self.assertEqual(base['version'],overlay['base'])
        self.assertEqual(overlay['base'],'TRAFFIC_LIGHT_1002_V35_20')
        self.assertEqual(len(changes),6)
        controller=(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py').read_text(encoding='utf-8')
        self.assertEqual(controller.count('SECOND_CONE_1002_V35_21'),3)
        self.assertNotIn('TRAFFIC_LIGHT_1002_V35_20',controller)
        for relative in ('src/racecar/scripts/ican_vision_node.py','src/racecar/config/competition_params.yaml'):
            self.assertIn(relative,changes)
            self.assertNotIn(relative,base['dependencies'])
            self.assertIsNotNone(changes[relative]['installed_path'])

    def fixture(self):
        base,overlay,changes=installer.load_manifests()
        base=copy.deepcopy(base)
        base['files']=[i for i in base['files'] if i['path'] in changes]
        cmake=b'project(racecar)\n'
        base['dependencies']={'src/racecar/CMakeLists.txt':hashlib.sha256(cmake).hexdigest()}
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name)/'racecar'
        for relative,data in [('src/racecar/CMakeLists.txt',cmake)]:
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for relative,item in changes.items():
            for name in (relative,item['installed_path']):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(PACKAGE/'rollback'/relative,target)
        loader=patch.object(installer,'load_manifests',return_value=(base,overlay,changes));loader.start();self.addCleanup(loader.stop)
        running=patch.object(installer,'active_race_processes',return_value=[]);running.start();self.addCleanup(running.stop)
        return root,changes

    def build_fixture(self,root,changes):
        for relative,item in changes.items():shutil.copyfile(root/relative,root/item['installed_path'])

    def test_all_six_sources_and_installed_files_return_to_exact_v20(self):
        root,changes=self.fixture()
        installer.validate_tree(root,'original_v35',binaries=False)
        installer.copy_version(root,binaries=False)
        archives=list(root.parent.glob('racecar_before_entry_v35_21_*.tar.gz'))
        self.assertEqual(len(archives),1)
        with tarfile.open(archives[0]) as archive:
            self.assertEqual(set(archive.getnames()),set(changes))
            for relative in changes:
                self.assertEqual(archive.extractfile(relative).read(),(PACKAGE/'rollback'/relative).read_bytes())
        self.build_fixture(root,changes)
        installer.validate_tree(root,'v35',binaries=False)
        installer.copy_version(root,rollback=True,binaries=False)
        self.build_fixture(root,changes)
        installer.validate_tree(root,'original_v35',binaries=False)
        for relative,item in changes.items():
            expected=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual((root/relative).read_bytes(),expected)
            self.assertEqual((root/item['installed_path']).read_bytes(),expected)

    def test_unknown_installed_vision_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/changes['src/racecar/scripts/ican_vision_node.py']['installed_path']
        target.write_bytes(target.read_bytes()+b'\n# user edit\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
        self.assertEqual(list(root.parent.glob('racecar_before_*')),[])

    def test_unknown_yaml_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/'src/racecar/config/competition_params.yaml'
        target.write_bytes(target.read_bytes()+b'\n# user tuning\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

    def test_active_car_is_not_modified(self):
        root,changes=self.fixture()
        before={r:(root/r).read_bytes() for r in changes}
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing race'):
                installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

if __name__=='__main__':unittest.main(verbosity=2)
