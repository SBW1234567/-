"""Fixed-V25 math comparison on the same path, independent of plan geometry."""
import copy
import importlib.util
import math
from pathlib import Path
import random
import sys
from types import SimpleNamespace as NS
import unittest
import numpy as np
import test_continuous as fixtures

core=fixtures.core
spec=importlib.util.spec_from_file_location('rollout_fixed_v25',Path(__file__).parent/'baselines/core_before_v35_26.py')
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)


def follower(module,path,index,pose,values):
    f=module.PathFollower(path,enable_integral=True);f.index=index;f.progress=float(path.lengths[index])
    f.time=f.response_time=100.;f.output=values[0];f.response_output=values[1]
    f.error=values[2];f.integral=.002;f.derivative=.03;f.speed=.65;f.last_pose=tuple(pose)
    f.command(pose,100.12,5.,.32)
    return f


class RolloutEquivalenceV3526Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.path=core.plan_entry_path((5.25,.85,.08))

    def cases(self,n=80):
        rng=random.Random(3526)
        for _ in range(n):
            i=rng.randrange(12,len(self.path.samples)-180)
            x,y,h=self.path.samples[i,:3];lat=rng.uniform(-.12,.12)
            pose=(x-math.sin(h)*lat,y+math.cos(h)*lat,h+rng.uniform(-.12,.12))
            yield i,pose,(rng.uniform(-.32,.32),rng.uniform(-.32,.32),rng.uniform(-.12,.12)),rng.uniform(.65,1.05),rng.uniform(.5,1.1)

    def compare(self,path,i,pose,values,distance=.935,speed=.9):
        outputs=[];errors=[]
        for module in (old,core):
            try:
                f=follower(module,path,i,pose,values)
                before=dict(f.__dict__)
                out=module.command_horizon(pose,f,5.,.32,distance=distance,speed=speed)
                self.assertEqual(set(f.__dict__),set(before))
                for key in ('index','progress','output','time','response_output','preview_curvature'):
                    self.assertEqual(f.__dict__[key],before[key])
                outputs.append(np.asarray(out));errors.append(None)
            except ValueError as exc:outputs.append(None);errors.append((type(exc),str(exc)))
        self.assertEqual(errors[0],errors[1])
        if outputs[0] is not None:
            self.assertEqual(outputs[0].shape,outputs[1].shape)
            np.testing.assert_allclose(outputs[0],outputs[1],atol=5e-11,rtol=0.)
        return outputs

    def test_random_complete_rollouts_and_finite_raw_decisions_match_v25(self):
        for i,pose,values,distance,speed in self.cases():
            a,b=self.compare(self.path,i,pose,values,distance,speed)
            if a is None:continue
            scan=fixtures.scan_at(pose)
            self.assertEqual(old.scan_hits_body(scan,pose,a),core.scan_hits_body(scan,pose,b))
            self.assertEqual(len(a),1+3*2*math.ceil(min(distance,max(.05,self.path.lengths[-1]-follower(old,self.path,i,pose,values).progress))/.05))

    def test_perpendicular_heading_boundary_and_distance_ties_keep_old_indices(self):
        for centre in (-math.pi/2,math.pi/2,3*math.pi/2):
            for delta in (-2e-10,-2e-12,-1e-12,0.,1e-12,2e-12,2e-10):
                heading=centre+delta
                samples=np.array([[.10,.10,heading,0.],[.10,-.10,heading,0.],[.15,0.,0.,0.]])
                path=NS(samples=samples,lengths=np.array([0.,.1,.2]),gates=[0.,1.,2.,3.])
                got=[]
                for module in (old,core):
                    f=module.PathFollower(path)
                    try:got.append(f.locate((0.,0.,0.)))
                    except ValueError as e:got.append(str(e))
                self.assertEqual(got[0],got[1],(centre,delta))

    def test_raw_rectangles_near_boundary_keep_collision_decision(self):
        i=220;pose=tuple(self.path.samples[i,:3]);a,b=self.compare(self.path,i,pose,(.18,.15,.03))
        self.assertIsNotNone(a)
        for j in (12,25,40,70,100):
            q=a[j]
            for offset in (-1e-9,-2e-12,0.,2e-12,1e-9):
                point=(q[0]+(.28+offset)*math.cos(q[2]),q[1]+(.28+offset)*math.sin(q[2]))
                local=core.local(point,pose);angle=math.atan2(local[1],local[0])
                scan=NS(ranges=[8.]*360,angle_min=angle,angle_increment=math.pi/180,range_min=.05,range_max=9.)
                scan.ranges[0]=math.hypot(*local)
                self.assertEqual(old.scan_hits_body(scan,pose,[a[j]]),core.scan_hits_body(scan,pose,[b[j]]),(j,offset))

    def test_bad_earlier_curvature_does_not_poison_clean_future_slices(self):
        for bad in (math.nan,math.inf,1e30):
            path=copy.copy(self.path);path.samples=self.path.samples.copy();path.samples[0,3]=bad
            pose=tuple(path.samples[200,:3])
            a,b=self.compare(path,200,pose,(.1,.1,0.))
            self.assertIsNotNone(a)

    def test_path_mutation_between_calls_has_no_persistent_prefix_cache(self):
        path=copy.copy(self.path);path.samples=self.path.samples.copy();pose=tuple(path.samples[200,:3])
        a,b=self.compare(path,200,pose,(.1,.1,0.))
        path.samples[200:240,3]*=.85
        changed,new=self.compare(path,200,pose,(.1,.1,0.))
        self.assertNotEqual(float(np.max(np.abs(a-changed))),0.)
        self.assertFalse(any('prefix' in k for k in path.__dict__))

    def test_nonfinite_current_pose_keeps_track_error(self):
        for bad in (math.nan,math.inf,-math.inf):
            self.compare(self.path,200,(bad,1.,0.),(.1,.1,0.))

    def test_constant_duck_follower_with_no_sample_or_dict_contract_is_preserved(self):
        class MinimalPath:
            lengths=np.array([10.])
            @property
            def samples(self):raise AssertionError('custom follower does not use samples')
        class Constant:
            def __init__(self):
                self.path=MinimalPath();self.progress=0.;self.output=.12
                self.response_output=.08;self.speed=.7;self.time=100.
            def command(self,*args):return self.output
        class SlottedConstant:
            __slots__=('path','progress','output','response_output','speed','time')
            __init__=Constant.__init__
            command=Constant.command
        for cls in (Constant,SlottedConstant):
            f=cls()
            before=(f.path,f.progress,f.output,f.response_output,f.speed,f.time)
            a=old.command_horizon((0.,0.,.1),f,5.,distance=.935,speed=.9)
            b=core.command_horizon((0.,0.,.1),f,5.,distance=.935,speed=.9)
            np.testing.assert_array_equal(a,b)
            self.assertEqual(before,(f.path,f.progress,f.output,f.response_output,f.speed,f.time))

    def test_non_float64_sample_dtype_retains_original_mean_precision(self):
        path=copy.copy(self.path);path.samples=self.path.samples.astype(np.float32)
        pose=tuple(path.samples[200,:3]);values=(.1,.1,0.)
        a=old.command_horizon(pose,follower(old,path,200,pose,values),5.,distance=.935,speed=.9)
        b=core.command_horizon(pose,follower(core,path,200,pose,values),5.,distance=.935,speed=.9)
        np.testing.assert_array_equal(a,b)


if __name__=='__main__':unittest.main()
