"""Exercise the delivered detector on candidate sequences and synthetic paper rows.

Synthetic images test retained geometric rejection, not real camera accuracy.
No camera is opened and the test ROS interfaces cannot drive hardware.
"""
from collections import deque
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import numpy as np
import ros_stubs  # Install offline interfaces before loading the camera module.

PACKAGE = Path(__file__).resolve().parents[1]
VISION_PATH = PACKAGE / 'payload/src/racecar/scripts/ican_vision_node.py'
spec = importlib.util.spec_from_file_location('crosswalk_camera_v35_18', VISION_PATH)
vision = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vision)


def detector():
    node = vision.IcanVisionNode.__new__(vision.IcanVisionNode)
    node.trigger_y = .60
    node.position_frames = 2
    node.position_max_gap = .25
    node.position_max_jump = .08
    node.position_history = deque(maxlen=2)
    node.position_last_time = None
    node.position_reason = 'WAIT_POSITION'
    node.crosswalk_roi_y_min = .30
    node.crosswalk_white_max_s = 180
    node.crosswalk_white_min_v = 130
    node.min_crosswalk_area = 900
    node.crosswalk_weak_area = 450
    node.crosswalk_ratio_threshold = .020
    node.crosswalk_weak_ratio = .008
    return node


def papers(bottom=.65, count=3, width=30, height=20, spacing=60):
    image = np.zeros((240, 320, 3), dtype=np.uint8)
    y1 = round(bottom * 240)
    for i in range(count):
        x0 = 60 + i * spacing
        image[y1-height:y1, x0:x0+width] = 255
    return image


class CrosswalkVisionTests(unittest.TestCase):
    def setUp(self):
        self.node = detector()

    def confirm(self, y, now, present=True, strong=False):
        return self.node.confirm_position(present, y, now, strong=strong)

    def test_forward_growth_does_not_erase_two_valid_observations(self):
        self.assertFalse(self.confirm(.53, 10.))
        self.assertTrue(self.confirm(.74, 10.12))
        self.assertEqual(self.node.position_reason, 'POSITION_CONFIRMED')

    def test_far_geometry_alone_cannot_stop(self):
        self.assertFalse(self.confirm(.40, 10., strong=True))
        self.assertFalse(self.confirm(.45, 10.1, strong=True))

    def test_current_position_and_median_must_both_reach_gate(self):
        self.assertFalse(self.confirm(.40, 10.))
        self.assertFalse(self.confirm(.65, 10.1))
        self.assertTrue(self.confirm(.70, 10.2))

    def test_one_frame_dropout_retains_evidence_but_never_triggers(self):
        self.assertFalse(self.confirm(.64, 10.))
        self.assertFalse(self.confirm(-1., 10.1, present=False, strong=True))
        self.assertEqual(list(self.node.position_history), [.64])
        self.assertTrue(self.confirm(.72, 10.2))

    def test_repeated_misses_cannot_refresh_old_evidence(self):
        self.confirm(.65, 10.)
        for now in (10.1, 10.2, 10.3):
            self.assertFalse(self.confirm(-1., now, present=False))
        self.assertFalse(self.confirm(.72, 10.31))
        self.assertEqual(len(self.node.position_history), 1)

    def test_stale_second_frame_restarts_confirmation(self):
        self.assertFalse(self.confirm(.65, 10.))
        self.assertFalse(self.confirm(.72, 10.26))
        self.assertTrue(self.confirm(.74, 10.35))

    def test_exact_gap_limit_keeps_evidence(self):
        self.assertFalse(self.confirm(.65, 10.))
        self.assertTrue(self.confirm(.72, 10.25))

    def test_backwards_jump_restarts_even_a_strong_close_observation(self):
        self.assertTrue(self.confirm(.99, 10., strong=True))
        self.assertFalse(self.confirm(.85, 10.1, strong=True))
        self.assertEqual(self.node.position_reason, 'BACKWARD_POSITION_RESET')
        self.assertTrue(self.confirm(.87, 10.2, strong=True))

    def test_small_position_jitter_keeps_valid_confirmation(self):
        self.assertFalse(self.confirm(.70, 10.))
        self.assertTrue(self.confirm(.66, 10.1))

    def test_close_strong_frames_recorded_on_missed_runs_stop_immediately(self):
        for near_y in (.829, .917, .946):
            with self.subTest(near_y=near_y):
                node = detector()
                self.assertTrue(node.confirm_position(True, near_y, 10., strong=True))
                self.assertEqual(node.position_reason, 'STRONG_NEAR_IMMEDIATE')

    def test_close_weak_geometry_still_requires_two_frames(self):
        self.assertFalse(self.confirm(.92, 10., strong=False))
        self.assertTrue(self.confirm(.94, 10.1, strong=False))

    def test_strong_immediate_path_does_not_lower_configured_higher_gate(self):
        self.node.trigger_y = .90
        self.assertFalse(self.confirm(.85, 10., strong=True))
        self.assertTrue(self.confirm(.93, 10.1, strong=True))

    def test_invalid_positions_never_trigger_even_if_marked_strong(self):
        for y in (-1., float('nan'), float('inf'), 1.01):
            with self.subTest(y=y):
                node = detector()
                self.assertFalse(node.confirm_position(True, y, 10., strong=True))
                self.assertEqual(len(node.position_history), 0)

    def test_nonfinite_time_discards_evidence(self):
        self.confirm(.65, 10.)
        self.assertFalse(self.confirm(.90, float('nan'), strong=True))
        self.assertEqual(len(self.node.position_history), 0)
        self.assertFalse(self.confirm(.70, 10.1))

    def test_duplicate_or_backwards_timestamp_cannot_complete_confirmation(self):
        for second in (9.9, 10.):
            with self.subTest(second=second):
                node = detector()
                self.assertFalse(node.confirm_position(True, .65, 10.))
                self.assertFalse(node.confirm_position(True, .90, second, strong=True))
                self.assertEqual(node.position_reason, 'NONADVANCING_CLOCK')

    def detect(self, frame, now):
        with patch.object(vision.time, 'monotonic', return_value=now):
            return self.node.detect_crosswalk(frame)

    def test_three_aligned_papers_use_earlier_gate_after_two_frames(self):
        first = self.detect(papers(.64), 10.)
        second = self.detect(papers(.66), 10.1)
        self.assertEqual(first[0], 0)
        self.assertEqual(second[0], 1)
        self.assertEqual(second[2], 3)
        self.assertLess(self.node.crosswalk_near_y, .733)

    def test_close_strong_three_paper_image_triggers_on_first_frame(self):
        result = self.detect(papers(.92), 10.)
        self.assertEqual(result[0], 1)
        self.assertEqual(result[6], 1)
        self.assertEqual(result[7], 1)

    def test_close_two_paper_image_does_not_trigger(self):
        for now in (10., 10.1):
            result = self.detect(papers(.92, count=2), now)
            self.assertEqual(result[0], 0)
            self.assertFalse(self.node.crosswalk_present)

    def test_blank_or_large_white_panel_cannot_trigger(self):
        blank = np.zeros((240, 320, 3), dtype=np.uint8)
        panel = blank.copy()
        panel[100:239, 40:280] = 255
        for image in (blank, panel):
            for now in (10., 10.1):
                node = detector()
                with patch.object(vision.time, 'monotonic', return_value=now):
                    result = node.detect_crosswalk(image)
                self.assertEqual(result[0], 0)
                self.assertFalse(node.crosswalk_present)

    def test_bad_paper_spacing_cannot_trigger(self):
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        for x in (10, 145, 280):
            frame[180:220, x:x+20] = 255
        result = self.detect(frame, 10.)
        self.assertEqual(result[0], 0)
        self.assertFalse(self.node.crosswalk_present)

    def test_delivered_configuration_restores_original_gate(self):
        text = (PACKAGE / 'payload/src/racecar/config/competition_params.yaml').read_text(encoding='utf-8')
        self.assertIn('crosswalk_trigger_y: 0.733', text)
        self.assertIn('crosswalk_stop_duration: 3.2', text)


if __name__ == '__main__':
    unittest.main()
