"""Real controller closed-loop entry with source delay and measured-gain range.

Gain 4.0--6.0 is tested independently of the controller's nominal gain 5.0.
The servo/motor model and exact periodic wall anchors remain assumptions.
"""
import json
import hashlib
from pathlib import Path
import sys
import unittest
import test_curve_response as response

PACKAGE=Path(__file__).resolve().parents[1]
STARTS=dict(first_run=(4.523,.78,.025),second_run=(5.505296,.920365,.13961))
SOURCE_HASHES={name:hashlib.sha256((PACKAGE/'payload/src/racecar/scripts'/name).read_bytes()).hexdigest()
    for name in ('race_curve_core.py','race_task_controller.py')}


def run_cases(extended=False):
    rows=[]
    settings=((.3,.08),(.3,.15),(.5,.08),(.5,.15)) if extended else ((.5,.08),)
    for name,start in STARTS.items():
        for actual_gain in (4.,4.4,5.,6.):
            for delay,compute in settings:
                case=dict(start_pose=start,actual_gain=actual_gain,delay=delay,compute=compute,tau=.15)
                result=response.simulate_controller_entry(**case,trace=True)
                rows.append(dict(start_name=name,case=case,result=result))
    return rows


class RecordedGainControllerTests(unittest.TestCase):
    def test_recorded_entry_starts_with_measured_gain_range(self):
        for row in run_cases():
            with self.subTest(start=row['start_name'],gain=row['case']['actual_gain']):
                result=row['result']
                evidence=dict(case=row['case'],reached=result['reached'],collision=result['collision'],
                    final_pose=result['final_pose'],minimum_clearance_m=result['minimum_clearance_m'],
                    stop_reasons=result['stop_reasons'],path_family=result['path_family'])
                self.assertFalse(result['collision'],evidence)
                self.assertTrue(result['reached'],evidence)
                self.assertGreaterEqual(result['minimum_clearance_m'],.08,evidence)


def report():
    rows=run_cases(extended=True)
    return dict(source_hashes=SOURCE_HASHES,assumptions=dict(controller_gain=5.,physical_gain_range=(4.,4.4,5.,6.),
        source_delay_seconds=(.3,.5),compute_seconds=(.08,.15),servo_tau_seconds=.15,
        nominal_speed_mps=.9,calibrated_motor_input=.35,steering_limit=.32,
        scan='50ms acquisition age; ray-cast handbook walls/nominal cones',
        localization='real RF2O callbacks and controller source prediction; exact periodic wall anchors',
        scope='entry and first-cone north passage, not full-course proof'),
        summary=dict(total=len(rows),reached=sum(x['result']['reached'] for x in rows),
            collisions=sum(x['result']['collision'] for x in rows),
            minimum_clearance_m=min(x['result']['minimum_clearance_m'] for x in rows)),
        cases=rows)


if __name__=='__main__':
    if '--report' in sys.argv:
        p=PACKAGE.parent/'recorded_gain_response_report.json'
        data=report();p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        print(str(p));print(json.dumps(data['summary']))
    else:unittest.main(verbosity=2)
