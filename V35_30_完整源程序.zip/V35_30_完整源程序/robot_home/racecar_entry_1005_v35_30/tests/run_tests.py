"""Run all inherited and final-straight regressions."""
import run_tests_v35_16
