"""V25 six-file install/rollback checks using real payloads and temporary trees."""
import copy
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
import apply_patch as installer

class PackageV3525Tests(unittest.TestCase):
    def test_controller_behavior_is_exact_v24(self):
        old=(PACKAGE/'tests/baselines/controller_before_v35_25.py').read_text(encoding='utf-8')
        current=(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py').read_text(encoding='utf-8')
        self.assertEqual(current.replace('SECOND_CONE_1002_V35_25','CONTINUITY_1002_V35_24'),old)

    def test_only_reviewed_core_functions_change_against_exact_v24(self):
        scope=json.loads((PACKAGE/'tests/v35_25_scope.json').read_text(encoding='utf-8'))
        self.assertTrue(scope['frozen'],'V25 geometry scope is not reviewed/frozen')
        old=ast.parse((PACKAGE/'tests/baselines/core_before_v35_25.py').read_text(encoding='utf-8'))
        new=ast.parse((PACKAGE/'payload/src/racecar/scripts/race_curve_core.py').read_text(encoding='utf-8'))
        before={n.name:n for n in old.body if isinstance(n,ast.FunctionDef)}
        after={n.name:n for n in new.body if isinstance(n,ast.FunctionDef)}
        changed={name for name in before.keys() & after.keys() if ast.dump(before[name])!=ast.dump(after[name])}
        self.assertEqual(changed,set(scope['core_changed_functions']))
        self.assertEqual(after.keys()-before.keys(),set(scope['core_new_functions']))
        self.assertEqual(before.keys()-after.keys(),set(scope['core_removed_functions']))
        for module in (old,new):module.body=[n for n in module.body if not isinstance(n,ast.FunctionDef)]
        self.assertEqual(ast.dump(old),ast.dump(new),'Other core classes/constants/imports changed')

    def test_v24_controller_baseline_and_rollback_remain_exact(self):
        expected='108734363473e69df4a58fdcc03f301bfafe58f09acf176a184e876e049fe11f'
        for relative in ('tests/baselines/controller_before_v35_25.py',
                         'rollback/src/racecar/scripts/race_task_controller.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_v24_core_baseline_and_rollback_remain_exact(self):
        expected='3e1bac23f0c587b800b6e9365a9e438c1d1d2c0faf92bcdc4834b3528d37ce2d'
        for relative in ('tests/baselines/core_before_v35_25.py',
                         'rollback/src/racecar/scripts/race_curve_core.py'):
            self.assertEqual(hashlib.sha256((PACKAGE/relative).read_bytes()).hexdigest(),expected)

    def test_original_v22_parking_test_source_is_preserved(self):
        old_tests=PACKAGE/'tests/test_finish_parking_v35_22.py'
        self.assertEqual(hashlib.sha256(old_tests.read_bytes()).hexdigest(),
                         '3e8575055c7fc69c74624bb9e8a7b9051127a3b757deb7932eeb018a57a48ab6')

    def test_first_cone_historical_comparison_keeps_exact_v21(self):
        path=PACKAGE/'tests/baselines/controller_before_v35_22.py'
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                         'f3c8f5b1c2e1e666bac22452dfd7a9576805586a7c3b369ab4f31eda34197fbe')

    def test_vision_config_guard_and_launch_retain_exact_v24(self):
        expected={
            'src/racecar/scripts/race_lidar_guard.py':'2651735dd452a24def8d00b3fbaf41c02df41b8df975852f745237b0395c2e4f',
            'src/racecar/launch/race_competition.launch.py':'10af9e64911d05fb3633c289131f37b00896ceff9b9d90fe792a25267b3f4ecd',
            'src/racecar/scripts/ican_vision_node.py':'f06836a2f4fd71afbb921950fdb6dd90f822e844481dc1a2e9fb0f9456886e9a',
            'src/racecar/config/competition_params.yaml':'7adc3341f9a5adb57a9e1a58dc97d6dc28a1b725a3b0030c5105e4f74ea46852',
        }
        for relative,value in expected.items():
            for directory in ('payload','rollback'):
                with self.subTest(path=relative,directory=directory):
                    self.assertEqual(hashlib.sha256((PACKAGE/directory/relative).read_bytes()).hexdigest(),value)

    def test_historical_vision_calibration_keeps_original_v19_inputs(self):
        report=json.loads((PACKAGE/'CALIBRATION_V35_20.json').read_text(encoding='utf-8'))
        for filename,key in (('vision_before_v35_20.py','v19_source_sha256'),
                             ('competition_params_before_v35_20.yaml','v19_config_sha256')):
            self.assertEqual(hashlib.sha256((PACKAGE/'tests/baselines'/filename).read_bytes()).hexdigest(),report[key])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/scripts/ican_vision_node.py').read_bytes()).hexdigest(),report['v20_source_sha256'])
        self.assertEqual(hashlib.sha256((PACKAGE/'payload/src/racecar/config/competition_params.yaml').read_bytes()).hexdigest(),report['v20_config_sha256'])

    def test_runner_arguments_preserve_v24(self):
        def function(path,name):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name))
        self.assertEqual(function(PACKAGE/'launch_centered.py','make_command'),
                         function(PACKAGE/'tests/baselines/launch_centered_before_v35_25.py','make_command'))
        runner=(PACKAGE/'run_v35_25.sh').read_text(encoding='utf-8')
        self.assertIn('RACE_DRY_RUN=${2:-true}',runner)
        self.assertIn('RACE_PREPARE_DRIVE=${3:-0.35}',runner)

    def test_install_and_rollback_snapshot_precedes_source_mutation(self):
        for filename,label,action in (
                ('install.sh','before-v35-25-install','--workspace "$RACE_WORKSPACE"\n'),
                ('rollback_v35_24.sh','before-v35-25-rollback-to-v35-24','--workspace "$RACE_WORKSPACE" --rollback')):
            shell=(PACKAGE/filename).read_text(encoding='utf-8')
            snapshot='python3 /home/bianbu/snapshot_vehicle_git.py --label '+label
            mutation='python3 "$PATCH_DIR/apply_patch.py" '+action
            with self.subTest(script=filename):
                self.assertIn('set -e\n',shell)
                self.assertIn('"$(readlink -f -- "$RACE_WORKSPACE")" != /home/bianbu/racecar',shell)
                self.assertLess(shell.index('--check'),shell.index(snapshot))
                self.assertLess(shell.index(snapshot),shell.index(mutation))

    def test_exact_six_file_overlay_includes_vision_and_yaml_rollback(self):
        base,overlay,changes=installer.load_manifests()
        self.assertEqual(overlay['version'],'SECOND_CONE_1002_V35_25')
        self.assertEqual(base['version'],overlay['base'])
        self.assertEqual(overlay['base'],'CONTINUITY_1002_V35_24')
        self.assertEqual(len(changes),6)
        controller=(PACKAGE/'payload/src/racecar/scripts/race_task_controller.py').read_text(encoding='utf-8')
        self.assertEqual(controller.count('SECOND_CONE_1002_V35_25'),3)
        self.assertNotIn('CONTINUITY_1002_V35_24',controller)
        for relative in ('src/racecar/scripts/ican_vision_node.py','src/racecar/config/competition_params.yaml'):
            self.assertIn(relative,changes)
            self.assertNotIn(relative,base['dependencies'])
            self.assertIsNotNone(changes[relative]['installed_path'])

    def fixture(self):
        base,overlay,changes=installer.load_manifests()
        base=copy.deepcopy(base)
        base['files']=[i for i in base['files'] if i['path'] in changes]
        cmake=b'project(racecar)\n'
        base['dependencies']={'src/racecar/CMakeLists.txt':hashlib.sha256(cmake).hexdigest()}
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name)/'racecar'
        for relative,data in [('src/racecar/CMakeLists.txt',cmake)]:
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for relative,item in changes.items():
            for name in (relative,item['installed_path']):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(PACKAGE/'rollback'/relative,target)
        loader=patch.object(installer,'load_manifests',return_value=(base,overlay,changes));loader.start();self.addCleanup(loader.stop)
        running=patch.object(installer,'active_race_processes',return_value=[]);running.start();self.addCleanup(running.stop)
        return root,changes

    def build_fixture(self,root,changes):
        for relative,item in changes.items():shutil.copyfile(root/relative,root/item['installed_path'])

    def test_all_six_sources_and_installed_files_return_to_exact_v24(self):
        root,changes=self.fixture()
        installer.validate_tree(root,'original_v35',binaries=False)
        installer.copy_version(root,binaries=False)
        archives=list(root.parent.glob('racecar_before_entry_v35_25_*.tar.gz'))
        self.assertEqual(len(archives),1)
        with tarfile.open(archives[0]) as archive:
            self.assertEqual(set(archive.getnames()),set(changes))
            for relative in changes:
                self.assertEqual(archive.extractfile(relative).read(),(PACKAGE/'rollback'/relative).read_bytes())
        self.build_fixture(root,changes)
        installer.validate_tree(root,'v35',binaries=False)
        installer.copy_version(root,rollback=True,binaries=False)
        self.build_fixture(root,changes)
        installer.validate_tree(root,'original_v35',binaries=False)
        for relative,item in changes.items():
            expected=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual((root/relative).read_bytes(),expected)
            self.assertEqual((root/item['installed_path']).read_bytes(),expected)

    def test_unknown_installed_vision_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/changes['src/racecar/scripts/ican_vision_node.py']['installed_path']
        target.write_bytes(target.read_bytes()+b'\n# user edit\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
        self.assertEqual(list(root.parent.glob('racecar_before_*')),[])

    def test_unknown_yaml_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/'src/racecar/config/competition_params.yaml'
        target.write_bytes(target.read_bytes()+b'\n# user tuning\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

    def test_active_car_is_not_modified(self):
        root,changes=self.fixture()
        before={r:(root/r).read_bytes() for r in changes}
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing race'):
                installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

if __name__=='__main__':unittest.main(verbosity=2)
