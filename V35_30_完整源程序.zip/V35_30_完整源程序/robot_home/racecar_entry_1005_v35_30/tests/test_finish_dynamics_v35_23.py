"""Independent motor/latency pressure tests for distance-led terminal parking.

These are deliberately stipulated plants, not a fit to the controller or a
claimed vehicle calibration. Physical truth integrates at 5ms. Odometry and
raw wall scans are delayed independently, and never use controller forecasts.
The static/dynamic friction separation exposes the V22 short-pulse failure.
"""
import bisect
from dataclasses import dataclass
import math
from types import SimpleNamespace as NS
import unittest

import test_finish_parking_v35_22 as fixture

cm, core, helpers = fixture.cm, fixture.core, fixture.helpers


@dataclass
class MotorPlant:
    x: float = 6.4
    v: float = 0.
    start_delay: float = .30
    dynamic_threshold: float = .22
    accel_tau: float = .18
    coast_tau: float = .40
    micro_speed: float = 0.
    nonlinear_coast: bool = False
    started: bool = False
    held: float = 0.
    quiet: float = 0.

    def running_speed(self, pwm):
        if self.dynamic_threshold < .30:
            points = ((.22,0.),(.24,.10),(.28,.35),(.30,.60),(.35,1.05))
        elif self.dynamic_threshold < .32:
            points = ((.31,0.),(.32,.12),(.33,.36),(.35,1.05))
        else:
            points = ((.33,0.),(.335,.10),(.34,.30),(.35,1.05))
        if pwm <= points[0][0]:return 0.
        for a,b in zip(points,points[1:]):
            if pwm <= b[0]:return a[1]+(b[1]-a[1])*(pwm-a[0])/(b[0]-a[0])
        return points[-1][1]

    def step(self, pwm, dt=.005):
        if not self.started:
            self.held = self.held+dt if pwm>=.32 else 0.
            if pwm>=.32 and self.held+1e-9>=self.start_delay:self.started=True
        target = self.running_speed(pwm) if self.started else (self.micro_speed if pwm>0 else 0.)
        old_v=self.v
        if target>self.v:
            self.v=target+(self.v-target)*math.exp(-dt/self.accel_tau)
        elif target>0:
            self.v=target+(self.v-target)*math.exp(-dt/self.coast_tau)
        elif self.nonlinear_coast:
            # Independent low-speed drag: integral coast at 1.03m/s is .408m.
            self.v=max(0.,(self.v+.4/1.5)*math.exp(-1.5*dt)-.4/1.5)
        else:
            self.v*=math.exp(-dt/self.coast_tau)
        self.x+=(old_v+self.v)*dt*.5
        if self.v<.006 and pwm<max(.32,self.dynamic_threshold):self.quiet+=dt
        else:self.quiet=0.
        if self.quiet>=.12:self.started=False;self.held=0.


class FinishDynamicsV3523Tests(unittest.TestCase):
    setUp=fixture.FinishParkingV3522Tests.setUp
    refresh_sensors=fixture.FinishParkingV3522Tests.refresh_sensors
    advance=fixture.FinishParkingV3522Tests.advance
    receive_laser_pose=fixture.FinishParkingV3522Tests.receive_laser_pose
    prepare=fixture.FinishParkingV3522Tests.prepare
    scan=fixture.FinishParkingV3522Tests.scan
    results=[]

    @staticmethod
    def sample(history, when):
        i=bisect.bisect_right(history,(when,float('inf')))-1
        if i<0:return history[0][1]
        if i==len(history)-1:return history[i][1]
        a,b=history[i],history[i+1]
        return a[1]+(b[1]-a[1])*(when-a[0])/(b[0]-a[0])

    def delayed_scan(self, position, stamp):
        scan=helpers.scan_at((position,3.55,0.))
        ns=round(stamp*1e9)
        scan.header.stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)
        self.c.curve_scan_callback(scan)
        self.c.front_clearance=self.c.boundary_front=min(3.,min(r for i,r in enumerate(scan.ranges)
            if abs(cm.normalize_angle(scan.angle_min+i*scan.angle_increment))<=math.radians(25)))

    def rollout(self, name, *, x=6.4, initial_speed=0., start_delay=.30,
                dynamic_threshold=.22, odom_delay=.15, scan_delay=.15,
                accel_tau=.18, micro_speed=0., nonlinear_coast=False,
                late_ticks=False, late_tick_phase=20, duration=60., must_finish=True):
        c=self.prepare(x,speed=initial_speed,delay=odom_delay)
        c.curve_scan_stamp=0
        plant=MotorPlant(x=x,v=initial_speed,start_delay=start_delay,
            dynamic_threshold=dynamic_threshold,accel_tau=accel_tau,
            micro_speed=micro_speed,nonlinear_coast=nonlinear_coast,
            started=initial_speed>.01)
        start=self.source_now
        history=[(start+i*.005,x+initial_speed*i*.005) for i in range(-120,1)]
        drive=0.;previous_positive=False;bursts=0;minimum=8.-x;peak_v=initial_speed
        next_scan=start;trace=[];completed=False
        for tick in range(int(duration/.05)):
            dt=.15 if late_ticks and tick%40==late_tick_phase else .05
            for _ in range(round(dt/.005)):
                plant.step(drive)
                self.advance(.005)
                history.append((self.source_now,plant.x))
                minimum=min(minimum,8.-plant.x);peak_v=max(peak_v,plant.v)
            odom_stamp=self.source_now-odom_delay
            self.receive_laser_pose((self.sample(history,odom_stamp),3.55,0.),source=odom_stamp)
            if self.source_now+1e-8>=next_scan:
                stamp=self.source_now-scan_delay
                self.delayed_scan(self.sample(history,stamp),stamp)
                next_scan=self.source_now+.10
            self.pose=(plant.x,3.55,0.)
            command=c.lane_command()
            drive=c.finish_parking_bound_command(command,self.now).linear.x
            self.assertTrue(math.isfinite(drive) and 0.<=drive<=.35,(name,drive))
            if drive>0 and not previous_positive:bursts+=1
            previous_positive=drive>0
            c.update_phase(self.now)
            status=c.finish_parking_status
            trace.append(dict(t=round(self.source_now-start,3),distance=8.-plant.x,
                v=plant.v,drive=drive,state=status.get('state'),
                measured_v=status.get('speed_mps'),measured_distance=status.get('distance_m')))
            if c.phase==c.FINISHED:completed=True;break
            if plant.x+.20>=8. or c.phase==c.ROUTE_FAULT:break
        # Completion must be physical too: a premature FINISHED cannot hide coast.
        if completed:
            for _ in range(400):plant.step(0.)
            minimum=min(minimum,8.-plant.x)
        result=dict(name=name,completed=completed,elapsed_s=self.source_now-start,
            true_distance_m=8.-plant.x,true_speed_mps=plant.v,minimum_distance_m=minimum,
            peak_speed_mps=peak_v,positive_bursts=bursts,last_status=dict(c.finish_parking_status),
            plant=dict(start_delay=start_delay,dynamic_threshold=dynamic_threshold,
                accel_tau=accel_tau,coast_tau=.40,odom_delay=odom_delay,scan_delay=scan_delay,
                initial_speed=initial_speed,late_ticks=late_ticks,late_tick_phase=late_tick_phase),trace=trace)
        self.results.append(result)
        diagnostic={k:v for k,v in result.items() if k!='trace'}
        self.assertGreater(minimum,.20,diagnostic)
        if must_finish:self.assertTrue(completed,diagnostic)
        if completed:
            # A stopped physical body is stricter than the rule's four wheels.
            # Driving clearance is a separate controller limit, not this final
            # geometric containment criterion (front .03 / rear .02 margins).
            self.assertGreaterEqual(8.-plant.x,.20+.03-.001,diagnostic)
            self.assertLessEqual(8.-plant.x,.80-.185-.02+.001,diagnostic)
            self.assertLess(plant.v,.05,diagnostic)
        return result

    def test_model_short_pulses_fail_static_friction_but_continuous_input_starts(self):
        # This independently reproduces the latest run's missing physical progress;
        # no controller internals select the physical motor response.
        for micro in (0.,.012):
            short=MotorPlant(micro_speed=micro)
            for _ in range(60):
                for _ in range(30):short.step(.35)  # 150ms includes timer quantization.
                for _ in range(130):short.step(0.)
            self.assertLess((short.x-6.4)/60.,.006)
            self.assertLess(short.x,6.65)
            continuous=MotorPlant(micro_speed=micro)
            for _ in range(120):continuous.step(.35)
            self.assertGreater(continuous.x-6.4,.14)
            self.assertGreater(continuous.v,.8)

    def test_normal_far_start_with_static_delay_and_delayed_sensors(self):
        for lag,delay in ((.30,.10),(.40,.20)):
            with self.subTest(start_delay=lag,sensor_delay=delay):
                self.rollout('static_'+str(lag),start_delay=lag,
                    odom_delay=delay,scan_delay=delay)

    def test_quick_response_with_two_hundred_ms_sensor_delay(self):
        self.rollout('quick',start_delay=0.,accel_tau=.12,odom_delay=.20,scan_delay=.20)

    def test_high_dynamic_friction_thresholds(self):
        for threshold in (.31,.33):
            with self.subTest(threshold=threshold):
                self.rollout('high_friction_'+str(threshold),dynamic_threshold=threshold,
                    start_delay=.30,odom_delay=.15,scan_delay=.15)

    def test_high_speed_entry_with_point_four_metre_coast(self):
        for nonlinear in (False,True):
            with self.subTest(nonlinear=nonlinear):
                self.rollout('fast_entry_'+str(nonlinear),x=6.2,initial_speed=1.03,
                    nonlinear_coast=nonlinear,odom_delay=.20,scan_delay=.10)

    def test_static_delay_with_late_control_ticks(self):
        self.rollout('late_ticks',start_delay=.30,odom_delay=.15,scan_delay=.15,late_ticks=True)

    def test_near_cold_start_cannot_assume_old_zero_speed_prevents_overshoot(self):
        for lag in (0.,.30):
            with self.subTest(lag=lag):
                self.rollout('near_cold_'+str(lag),x=7.39,start_delay=lag,
                    accel_tau=.12,odom_delay=.20,scan_delay=.20,duration=12.,must_finish=False)

    def test_near_cold_start_with_control_delay_across_first_neutral_deadline(self):
        # Tick phase is exogenous. The last positive command persists while the
        # controller is late; a publication-time check cannot retract that PWM.
        # Phase15 crosses even the new40ms first deadline; delays between the
        # former immediate/.30s cases prevent skipping breakaway discontinuity.
        for lag in (0.,.15,.20):
            with self.subTest(start_delay=lag):
                self.rollout('near_cold_late_'+str(lag),x=7.39,start_delay=lag,
                    accel_tau=.12,odom_delay=.20,scan_delay=.20,duration=12.,
                    late_ticks=True,late_tick_phase=15,must_finish=False)


if __name__=='__main__':unittest.main()
