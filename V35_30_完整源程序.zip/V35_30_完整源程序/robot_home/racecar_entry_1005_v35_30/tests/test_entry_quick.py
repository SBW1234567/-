"""Entrance regression tests; synthetic observations, no hardware access."""
import ast
from concurrent.futures import Future
import importlib.util
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import numpy as np
import test_straight as t
import race_lidar_guard as guard
import json

g=t.core
cmod=t.controller

def baseline():
    spec=importlib.util.spec_from_file_location('v351_core',t.PACKAGE/'rollback/src/racecar/scripts/race_curve_core.py')
    old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
    return old

def scan_at(pose,n=720,noise=.002):
    angles=np.arange(n)*2*math.pi/n+pose[2]
    dirs=np.column_stack((np.cos(angles),np.sin(angles)))
    origin=np.asarray(pose[:2]);ranges=np.full(n,math.inf)
    for a,b in g.WALLS:
        v=np.asarray(b)-a;w=np.asarray(a)-origin
        cross=dirs[:,0]*v[1]-dirs[:,1]*v[0]
        safe=np.where(abs(cross)>1e-10,cross,1e-10)
        distance=(w[0]*v[1]-w[1]*v[0])/safe
        u=(w[0]*dirs[:,1]-w[1]*dirs[:,0])/safe
        ranges=np.minimum(ranges,np.where((abs(cross)>1e-10)&(distance>0)&(u>=0)&(u<=1),distance,math.inf))
    for cone in g.CONES:
        delta=np.asarray(cone)-origin;proj=dirs@delta
        disc=proj**2-(delta@delta-.12**2)
        distance=proj-np.sqrt(np.maximum(disc,0))
        ranges=np.minimum(ranges,np.where((disc>=0)&(distance>0),distance,math.inf))
    ranges+=np.random.default_rng(40).normal(0,noise,n)
    return types.SimpleNamespace(ranges=ranges.tolist(),angle_min=0.,angle_increment=2*math.pi/n,
        range_min=.05,range_max=12.,header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=100,nanosec=0)))

class QuickTests(unittest.TestCase):
    def setUp(self):
        t.ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True,
            bounded_heading_control=True,lane_parallel_band_enabled=True,lane_band_min_distance=.35,
            lane_band_max_distance=.5,side_distance_guard_enabled=False,side_steering_guard_enabled=False)
        self.c=cmod.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.phase=self.c.SEEK_CONE_1

    def cache(self,now=100.,distance=.79):
        right=(distance,0.,8,.60,.005)
        obs=(None,None,{},20.,right)
        self.c.entry_v34_wall_cache.append((123,now,obs))
        self.c.curve_features.append((123,now,dict(entry_end_wall=(2.8,0.,1.,.01,30),cones=[])))

    def test_wide_wall_localizes_but_not_straight_control(self):
        scan=scan_at((5.1,.79,0.))
        self.assertIsNone(g.nearby_wall(scan,-1))
        self.assertAlmostEqual(g.nearby_wall(scan,-1,entry=True)[0],.79,places=2)
        observations=cmod.entry_wall_observation(scan)
        self.assertIsNone(observations[0]);self.assertIsNotNone(observations[4])

    def test_wall_beyond_wide_bound_rejected(self):
        self.assertIsNone(g.nearby_wall(scan_at((5.1,1.3,0.)),-1,entry=True))

    def test_entry_wall_cannot_authorize_driving_or_stale_handoff(self):
        self.cache();self.assertFalse(self.c.entry_wall_current(100.1))
        self.c.entry_v33_braked=True
        self.assertTrue(self.c.entry_wall_current(100.1))
        self.assertFalse(self.c.entry_wall_current(100.31))
        self.assertFalse(self.c.entry_v34_local_ready(100.1))

    def test_right_079_seed_accepted(self):
        self.cache()
        with patch.object(self.c,'entry_wall_ready',return_value=True):
            seed=self.c.entry_v33_seed(None,100.1,123)
        self.assertEqual(seed,(5.2,.79,-0.))

    def test_wrong_scan_cannot_seed(self):
        self.cache()
        self.assertIsNone(self.c.entry_v33_seed(None,100.1,124))

    def test_farther_cone_seed_two_distinct_scans(self):
        self.cache(distance=.79)
        for stamp,now in [(123,100.),(124,100.1)]:
            self.c.entry_v34_wall_cache.append((stamp,now,(None,None,{},20.,(.79,0.,8,.6,.005))))
            self.c.curve_features.append((stamp,now,dict(entry_end_wall=None,cones=[(4.8,1.8)])))
            seed=self.c.entry_v33_seed(None,now,stamp)
            if stamp==123:self.assertIsNone(seed)
        self.assertIsNotNone(seed);self.assertEqual(self.c.entry_v33_relative_hits,2)
        self.c.entry_v33_seed(None,100.1,124)
        self.assertEqual(self.c.entry_v33_relative_hits,2)

    def test_first_cone_wider_association_accepts_one_fresh_unique_frame(self):
        tracks=g.ConeTracks(entry_relaxed=True,entry_wide=True);pose=(4.8,.8,0.)
        cones=[g.local((6.8,2.),pose)]
        tracks.update(cones,pose,1,100.)
        self.assertTrue(tracks.ready(0,100.))
        tracks.update(cones,pose,1,100.1)
        self.assertTrue(tracks.ready(0,100.1))
        tracks.update(cones,pose,2,100.2)
        self.assertTrue(tracks.ready(0,100.2))
        self.assertTrue(tracks.ready(0,100.51))
        self.assertFalse(tracks.ready(0,100.66))

    def test_two_cones_in_same_identity_gate_rejected(self):
        tracks=g.ConeTracks(entry_relaxed=True,entry_wide=True);pose=(4.8,.8,0.)
        cones=[g.local((6.,2.),pose),g.local((6.3,2.1),pose)]
        for stamp in (1,2,3):tracks.update(cones,pose,stamp,100.+stamp*.1)
        self.assertFalse(tracks.ready(0,100.3))

    def test_second_cone_and_outside_first_gate_unchanged(self):
        tracks=g.ConeTracks(entry_relaxed=True,entry_wide=True);pose=(4.8,.8,0.)
        for stamp in (1,2):tracks.update([g.local((7.1,2.),pose),g.local((2.,2.),pose)],pose,stamp,100.+stamp*.1)
        self.assertFalse(tracks.ready(0,100.2));self.assertFalse(tracks.ready(1,100.2))

    def test_registration_numerically_matches_baseline(self):
        old=baseline()
        for n in (360,720,1440):
            for pose in ((4.6,.45,0.),(5.2,.79,.06),(5.5,1.0,-.08),(6.4,2.6,1.5)):
                scan=scan_at(pose,n=n);seed=(pose[0]+.03,pose[1]-.02,pose[2]+.01)
                a,ao,_=old.register_scan(old.WallLocalizer(True),scan,100.,pose[2],seed)
                b,bo,_=g.register_scan(g.WallLocalizer(True),scan,100.,pose[2],seed)
                self.assertEqual(ao,bo);self.assertTrue(bo,(pose,b.reason))
                np.testing.assert_allclose(a.pose,b.pose,atol=1e-9)

    def test_parallel_walls_alone_cannot_localize(self):
        points=[(float(x),y) for x in np.linspace(-.2,2.,60) for y in (-.45,.45)]
        self.assertFalse(g.WallLocalizer(True).update(points,100.,0.,(1.,.45,0.)))

    def test_pre_crosswalk_uses_same_scan_seed(self):
        self.c.phase=self.c.APPROACH_CROSSWALK;self.c.last_yaw=0.;self.cache()
        with patch.object(cmod.time,'monotonic',return_value=100.1), \
             patch.object(self.c,'entry_v33_seed',return_value=(3.,.45,0.)) as seed, \
             patch.object(self.c.curve_executor,'submit',return_value=Future()):
            self.c.curve_submit_registration(scan_at((3.,.45,0.)),100.,123)
        seed.assert_called_once();self.assertIsNotNone(self.c.curve_job)

    def test_late_registration_still_rejected(self):
        loc=g.WallLocalizer(True);loc.pose=(5.1,.79,0.);loc.time=100.;loc.hits=2
        f=Future();f.set_result((loc,True,.28))
        self.c.curve_job=(f,None,100.,123,self.c.curve_generation)
        self.c.curve_poll_registration(100.28)
        self.assertEqual(self.c.curve_registration_status,'RESULT_TOO_OLD')
        self.assertIsNone(self.c.curve_locator.pose)

    def test_two_fresh_pose_hits_release_stopped_recovery(self):
        c=self.c;self.cache();c.entry_v33_braked=c.entry_v34_turn_stop=c.curve_pose_wait=True
        c.curve_locator.pose=(5.2,.79,0.);c.curve_locator.time=100.;c.curve_locator.hits=2
        c.curve_scan=object();c.curve_scan_time=c.rel_time=100.;c.rel_data={}
        with patch.object(c,'sensors_ready',return_value=True), \
             patch.object(c.curve_tracks,'ready',return_value=True), \
             patch.object(c,'curve_wait_fault',return_value=''):
            c.curve_update_pose_wait(100.1)
        self.assertFalse(c.curve_pose_wait)

    def test_pose_079_gate_and_stopped_requirements(self):
        c=self.c;c.curve_locator.pose=(5.2,.95,0.);c.curve_locator.time=100.;c.curve_locator.hits=2
        c.curve_pose_scan=object();self.cache(distance=.95);c.entry_v33_braked=True
        gates=c.entry_gate_snapshot(100.1)
        self.assertTrue(gates['ENTRY_Y']);self.assertTrue(gates['LANE'])
        self.assertFalse(gates['STOPPED'])

    def test_safety_methods_and_curve_planning_unchanged(self):
        def nodes(path):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return {n.name:ast.dump(n) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        old=nodes(t.PACKAGE/'rollback/src/racecar/scripts/race_task_controller.py')
        new=nodes(t.SCRIPTS/'race_task_controller.py')
        for name in ('entry_v33_safety_reason','curve_stop_reason',
                     'odom_is_still','centre_heading_command','bounded_corridor_request'):
            self.assertEqual(old[name],new[name],name)
        old=nodes(t.PACKAGE/'rollback/src/racecar/scripts/race_curve_core.py');new=nodes(t.SCRIPTS/'race_curve_core.py')
        for name in ('body_clear','PathFollower'):
            self.assertEqual(old[name],new[name],name)

    def test_narrow_arc_candidate_survives_controller_schema(self):
        lidar=guard.RaceLidarGuard();scan=scan_at((5.2,.79,0.))
        data=lidar.relative_features(scan)
        data.update(schema=3,stamp_ns=123,valid=True)
        data['cones']=[[.8,1.2,math.hypot(.8,1.2),.07,4]]
        with patch.object(cmod.time,'monotonic',return_value=100.):
            self.c.relative_callback(t.ros.Message(json.dumps(data)))
        self.assertIsNotNone(self.c.rel_data)
        data['stamp_ns']=124;data['cones'][0][3]=.04
        with patch.object(cmod.time,'monotonic',return_value=100.1):
            self.c.relative_callback(t.ros.Message(json.dumps(data)))
        self.assertIsNone(self.c.rel_data)

    def test_linear_board_and_sparse_arc_not_cones(self):
        lidar=guard.RaceLidarGuard()
        line=[(1.,float(y),0.,0.) for y in np.linspace(.9,1.1,10)]
        self.assertEqual(lidar.curve_cone_centres([line]),[])
        arc=[(1.+.12*math.cos(a),1.+.12*math.sin(a),0.,0.) for a in np.linspace(0,1.,3)]
        self.assertEqual(lidar.curve_cone_centres([arc]),[])

    def test_synthetic_stopped_entry_reaches_planning_gates(self):
        c=self.c;lidar=guard.RaceLidarGuard();pose=(5.2,.79,0.)
        c.entry_v33_braked=c.entry_v34_turn_stop=True;c.entry_v33_brake_since=99.
        c.crosswalk_clear_count=20;c.entry_body_count=10;c.lidar_left_clearance=1.5
        c.last_yaw=0.;c.last_odom_xy=(0.,0.)
        for i in range(8):
            now=100.+i*.1;stamp=100000000000+i*100000000
            scan=scan_at(pose);data=lidar.relative_features(scan)
            data.update(schema=3,stamp_ns=stamp,valid=True)
            c.entry_v34_wall_cache.append((stamp,now,cmod.entry_wall_observation(scan)))
            c.curve_scan=scan;c.curve_scan_time=now
            with patch.object(cmod.time,'monotonic',return_value=now):
                c.relative_callback(t.ros.Message(json.dumps(data)))
                self.assertIsNotNone(c.rel_data)
                c.curve_submit_registration(scan,now,stamp)
                if c.curve_job is not None:
                    c.curve_job[0].result(timeout=3.)
                    c.curve_poll_registration(now+.02)
        c.last_odom_time=now
        for delta in (-.6,-.4,-.2,0.):c.record_still_sample(now+delta,now+delta,0.,0.,0.)
        with patch.object(c,'sensors_ready',return_value=True),patch.object(c,'odom_is_still',return_value=True):
            gates=c.entry_gate_snapshot(now+.03)
        self.assertTrue(all(gates.values()),gates)
        self.assertEqual(c.entry_pair_reason,'MATCHED_SAME_SCAN')
        with patch.object(c,'sensors_ready',return_value=True),patch.object(c,'odom_is_still',return_value=True), \
             patch.object(cmod.time,'monotonic',return_value=now+.04):
            c.curve_update(now+.03)
            self.assertIsNotNone(c.entry_plan_job)
            c.entry_plan_job[0].result(timeout=5.)
            c.curve_update(now+.04)
        self.assertEqual(c.phase,c.ENTER_OBSTACLES)
        self.assertEqual(c.entry_stage,'HANDOFF')
        self.assertEqual(c.curve_sweep,'CLEAR')

if __name__=='__main__':unittest.main(verbosity=2)
