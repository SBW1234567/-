"""Issued-command timing, transient scan pairing and running torque behavior."""
import math
import unittest
from unittest.mock import patch
import test_continuous as helpers

cm, core, ros = helpers.cm, helpers.core, helpers.ros


class MotionContinuityTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.
        patch.object(cm.time, 'monotonic', side_effect=lambda: self.now).start()
        self.addCleanup(patch.stopall)
        ros.FakeNode.overrides = dict(curve_route=True, relative_route=True,
            exit_continuous=True, entry_v32_enabled=True, entry_v33_enabled=True,
            entry_v34_enabled=True, dry_run=True)
        self.c = cm.RaceTaskController()
        self.addCleanup(self.c.close_curve_worker)
        c = self.c
        c.phase = c.ENTER_OBSTACLES
        c.curve_follower = core.PathFollower(core.plan_entry_path((5.08, .86, .075)))
        self.f = c.curve_follower
        c.last_lane_angular = .20
        c.last_lane_command_time = c.curve_last_drive_time = 99.9
        self.f.time = self.f.response_time = 99.9
        self.f.output = .20
        self.f.response_output = .10
        c.curve_scan_time = c.last_odom_time = c.last_lidar_time = c.rel_time = 100.
        c.rel_data = dict(body_clear=True)
        c.curve_scan = helpers.scan_at((5.08, .86, .075))
        c.curve_scan_stamp = int(100e9)

    def test_compute_time_uses_previous_issued_target(self):
        self.c.curve_issued_steering(-.20, 100.05)
        expected = .20 + (.10-.20)*math.exp(-.15/self.f.response_tau)
        self.assertAlmostEqual(self.f.response_output, expected)
        self.assertEqual(self.f.output, -.20)
        self.assertEqual(self.f.time, 99.9)  # feedback clock is independent
        self.c.curve_issued_steering(-.20, 100.10)
        expected = -.20 + (expected+.20)*math.exp(-.05/self.f.response_tau)
        self.assertAlmostEqual(self.f.response_output, expected)

    def test_neutral_command_does_not_instantly_centre_the_servo_model(self):
        self.c.publish_stop()
        self.assertEqual(self.c.cmd_pub.messages[-1].angular.z, 0.)
        self.assertEqual(self.c.cmd_pub.messages[-1].linear.x, 0.)
        at_stop = .20 + (.10-.20)*math.exp(-.10/self.f.response_tau)
        self.assertAlmostEqual(self.f.response_output, at_stop)
        self.now = 100.12
        self.c.publish_stop()
        self.assertAlmostEqual(self.f.response_output, at_stop*math.exp(-.12/self.f.response_tau))

    def test_repeated_short_pauses_do_not_double_integrate_response(self):
        self.c.curve_pause_command(100.)
        self.now = 100.05
        command = self.c.curve_pause_command(self.now)
        self.assertEqual(command.linear.x, 0.)
        self.assertAlmostEqual(command.angular.z, .20)
        expected = .20 + (.10-.20)*math.exp(-.15/self.f.response_tau)
        self.assertAlmostEqual(self.f.response_output, expected)

    def test_temporary_scan_odom_pair_gap_preserves_the_last_issued_turn(self):
        pose = (5.08, .86, .075)
        with patch.object(self.c, 'curve_pose_estimate', return_value=pose), \
             patch.object(self.c, 'curve_check_sweep', return_value=(False, 'SCAN_ODOM_ALIGNMENT')):
            command = self.c.curve_command(100.)
        self.assertEqual(command.linear.x, 0.)
        self.assertAlmostEqual(command.angular.z, .20)
        self.assertTrue(self.c.curve_control_status['held_steering'])

    def test_normal_rollout_covers_launch_speed_without_changing_measured_velocity(self):
        # A delayed stationary source sample does not describe a newly launched
        # car's present speed. This is a conservative sweep scenario, not a
        # conversion of the .35 motor input or a replacement pose velocity.
        pose=(5.08,.86,.075)
        for measured,expected in ((.04,.9),(1.2,1.2),(None,.9)):
            with self.subTest(measured_speed=measured):
                c=self.c;c.curve_motion_status=dict(speed_mps=measured,odom_source_age_s=.3)
                with patch.object(c,'curve_pose_estimate',return_value=pose), \
                     patch.object(c,'curve_check_sweep',return_value=(True,'CLEAR_RAW')), \
                     patch.object(cm,'command_horizon',wraps=core.command_horizon) as rollout:
                    command=c.curve_command(100.)
                self.assertGreater(command.linear.x,0.)
                self.assertAlmostEqual(rollout.call_args.kwargs['speed'],expected)
                self.assertAlmostEqual(rollout.call_args.kwargs['distance'],
                    max(.65,min(1.1,.35+.65*expected)))
                self.assertEqual(c.curve_motion_status['speed_mps'],measured)

    def test_running_trim_reduces_high_measured_speed_but_relaunches_if_stalled(self):
        self.c.curve_motion_status = dict(speed_mps=.95, odom_source_age_s=.3)
        self.f.curvature = 1.2
        trimmed = self.c.curve_running_drive(100., self.f)
        self.assertGreaterEqual(trimmed, .30)
        self.assertLess(trimmed, .35)
        self.c.curve_motion_status['speed_mps'] = .08
        self.assertEqual(self.c.curve_running_drive(100., self.f), .35)
        self.assertEqual(self.c.curve_speed_status['mode'], 'LAUNCH_OR_NO_SPEED_FEEDBACK')

    def test_running_trim_cannot_accumulate_on_repeated_source_samples(self):
        self.c.curve_motion_status = dict(speed_mps=.60, odom_source_age_s=.3)
        values = [self.c.curve_running_drive(100., self.f) for _ in range(10)]
        self.assertEqual(min(values), max(values))
        self.assertTrue(all(.30 <= value <= .35 for value in values))


if __name__ == '__main__':
    unittest.main(verbosity=2)
