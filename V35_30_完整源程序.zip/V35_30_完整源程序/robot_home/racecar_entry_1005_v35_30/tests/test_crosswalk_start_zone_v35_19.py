"""Real odometry callback and vision decisions for the 0.8 m starting zone.

No source time exists in the visual array. Tests therefore require a new
visual callback after arming, and never describe it as source-time verified.
"""
import ast
import math
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_crosswalk_vision_v35_18 as camera

cm, ros = helpers.cm, helpers.ros


class CrosswalkStartZoneTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.
        self.ros_time = 1000.
        clock = patch.object(cm.time, 'monotonic', side_effect=lambda: self.now)
        clock.start()
        self.addCleanup(clock.stop)
        old = ros.FakeNode.overrides
        self.addCleanup(setattr, ros.FakeNode, 'overrides', old)
        ros.FakeNode.overrides = dict(curve_route=True, relative_route=True,
            exit_continuous=True, entry_v32_enabled=True, entry_v33_enabled=True,
            entry_v34_enabled=True, dry_run=True)
        self.c = cm.RaceTaskController()
        self.addCleanup(self.c.close_curve_worker)
        self.c.get_clock = lambda: NS(now=lambda: NS(nanoseconds=round(self.ros_time*1e9)))
        self.pose = (0., 0., 0.)

    def feed(self, x=None, y=0., yaw=0., dt=.1, source=None):
        self.now += dt
        self.ros_time += dt
        if x is None:
            x, y, yaw = self.pose
        stamp = round((self.ros_time-.1 if source is None else source)*1e9)
        msg = NS(header=NS(stamp=NS(sec=stamp//1000000000, nanosec=stamp%1000000000)),
            pose=NS(pose=NS(position=NS(x=x, y=y), orientation=NS(
                x=0., y=0., z=math.sin(yaw/2), w=math.cos(yaw/2)))),
            twist=NS(twist=NS(linear=NS(x=0.), angular=NS(z=0.))))
        self.c.odom_callback(msg)
        self.pose = (x, y, yaw)
        return msg

    def start(self, pose=(0., 0., 0.)):
        self.feed(*pose)
        self.c.set_phase(self.c.APPROACH_CROSSWALK)
        self.assertIsNotNone(self.c.crosswalk_start_pose)

    def move(self, x, y=0., yaw=0., steps=10):
        initial = self.pose
        for i in range(1, steps+1):
            u = i/steps
            self.feed(*(a+u*(b-a) for a,b in zip(initial, (x,y,yaw))))
        self.assertNotEqual(self.c.phase, self.c.ROUTE_FAULT)

    def see(self, detected=True):
        self.c.vision_callback(NS(data=[0, 0, int(detected), int(detected), int(detected)]))

    def test_latest_point_four_four_trigger_is_ignored(self):
        self.start()
        self.move(.44)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 0)
        self.assertAlmostEqual(self.c.crosswalk_arm_status['progress_m'], .44)

    def test_current_trigger_after_eight_tenths_stops(self):
        self.start()
        self.move(.800001)
        self.see()
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertEqual(self.c.cmd_pub.messages[-1].linear.x, 0.)

    def test_trigger_at_point_seven_nine_nine_does_not_stop(self):
        self.start()
        self.move(.799)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)

    def test_old_start_zone_trigger_does_not_latch_for_later(self):
        self.start()
        self.move(.44)
        self.see()
        self.move(.9)
        self.c.update_phase(self.now)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.see(False)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.see(True)
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_normal_update_phase_cannot_bypass_distance_gate(self):
        self.start()
        self.move(.44)
        self.c.crosswalk_count = 1
        self.c.last_vision_time = self.now
        self.c.update_phase(self.now)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 0)

    def test_normal_update_phase_clears_stale_visual_count(self):
        self.start()
        self.move(.9)
        self.c.crosswalk_count = 1
        self.c.last_vision_time = self.now-2.
        self.c.update_phase(self.now)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 0)

    def test_backward_distance_does_not_arm(self):
        self.start()
        self.move(-1.)
        self.see()
        self.assertLess(self.c.crosswalk_arm_status['progress_m'], 0.)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)

    def test_sideways_distance_does_not_arm(self):
        self.start()
        self.move(0., 1.)
        self.see()
        self.assertAlmostEqual(self.c.crosswalk_arm_status['progress_m'], 0.)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)

    def test_circle_and_accumulated_jitter_do_not_arm(self):
        self.start()
        for i in range(1, 81):
            angle = 2*math.pi*i/40
            self.feed(.15*math.sin(angle), .15-.15*math.cos(angle))
        self.assertGreater(self.c.travel_distance, .8)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertAlmostEqual(self.c.crosswalk_arm_status['progress_m'], 0.)

    def test_forward_then_reverse_into_start_zone_disarms(self):
        self.start()
        self.move(.9)
        self.assertTrue(self.c.crosswalk_stop_armed(self.now))
        self.move(.3)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)

    def test_initial_heading_defines_forward_axis(self):
        self.start((1., 2., math.pi/2))
        self.move(1., 2.9, math.pi/2)
        self.see()
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)
        self.assertAlmostEqual(self.c.crosswalk_arm_status['progress_m'], .9)

    def test_rotation_without_translation_does_not_move_base_origin(self):
        self.start()
        self.move(0., 0., math.pi/2, steps=20)
        self.assertFalse(self.c.crosswalk_stop_armed(self.now))
        self.assertAlmostEqual(self.c.crosswalk_arm_status['progress_m'], 0., places=10)

    def test_stale_source_with_fresh_receipt_does_not_arm(self):
        self.start()
        self.move(.9)
        last = self.c.last_motion_stamp
        self.now += .7
        self.ros_time += .7
        self.feed(.92, source=last+.1)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 0)
        self.assertEqual(self.c.crosswalk_arm_status['reason'], 'STALE_SOURCE_ODOM')

    def test_replayed_source_invalidates_receipt_and_cannot_arm(self):
        self.start()
        self.move(.9)
        last = self.c.last_motion_stamp
        self.feed(.9, source=last)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 0)

    def test_future_source_does_not_arm(self):
        self.start()
        self.move(.9)
        self.feed(.92, source=self.ros_time+.2)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_arm_status['reason'], 'STALE_SOURCE_ODOM')

    def test_changed_source_clock_does_not_arm(self):
        self.start()
        self.move(.9)
        self.ros_time += .25
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_arm_status['reason'], 'SOURCE_CLOCK_CHANGED')

    def test_rejected_source_span_does_not_arm(self):
        self.start()
        self.move(.9)
        self.feed(.91, dt=.01)
        self.see()
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_arm_status['reason'], 'REJECTED_SOURCE_ODOM')

    def test_missing_origin_holds_only_until_actual_source_pose_available(self):
        self.c.set_phase(self.c.APPROACH_CROSSWALK)
        with patch.object(self.c, 'centre_heading_command') as heading:
            self.assertEqual(self.c.approach_crosswalk_command().linear.x, 0.)
            heading.assert_not_called()
        self.feed(.12)
        sentinel = cm.Twist()
        sentinel.linear.x = .35
        with patch.object(self.c, 'centre_heading_command', return_value=sentinel) as heading:
            self.assertIs(self.c.approach_crosswalk_command(), sentinel)
            heading.assert_called_once()
        origin = self.c.crosswalk_start_pose
        self.move(.40)
        self.c.crosswalk_stop_armed(self.now, initialize=True)
        self.assertEqual(self.c.crosswalk_start_pose, origin)

    def test_origin_is_not_reset_by_an_ordinary_same_phase_notification(self):
        self.start()
        original = self.c.crosswalk_start_pose
        self.move(.4)
        self.c.set_phase(self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_start_pose, original)

    def test_configured_curve_gate_cannot_disable_start_zone(self):
        for value, expected in ((0., .8), (.3, .8), (.8, .8), (1., 1.)):
            with self.subTest(value=value):
                ros.FakeNode.overrides['crosswalk_arm_travel'] = value
                c = cm.RaceTaskController()
                self.addCleanup(c.close_curve_worker)
                self.assertEqual(c.crosswalk_arm_travel, expected)

    def test_legacy_route_keeps_previous_visual_stop_behavior(self):
        self.c.curve_route = False
        self.c.set_phase(self.c.APPROACH_CROSSWALK)
        self.see()
        self.assertEqual(self.c.phase, self.c.CROSSWALK_STOP)

    def test_legacy_update_phase_does_not_apply_new_freshness_reset(self):
        self.c.curve_route = False
        self.c.set_phase(self.c.APPROACH_CROSSWALK)
        self.c.crosswalk_count = 1
        self.c.last_vision_time = self.now-2.
        self.c.update_phase(self.now)
        self.assertEqual(self.c.phase, self.c.APPROACH_CROSSWALK)
        self.assertEqual(self.c.crosswalk_count, 1)

    def test_delivered_visual_gate_rejects_the_early_point_six_to_point_seven_row(self):
        node = camera.detector()
        node.trigger_y = .733
        for now, near in ((10., .65), (10.1, .696), (10.2, .725)):
            with patch.object(camera.vision.time, 'monotonic', return_value=now):
                self.assertEqual(node.detect_crosswalk(camera.papers(near))[0], 0)
        for now, near in ((10.3, .75), (10.4, .77)):
            with patch.object(camera.vision.time, 'monotonic', return_value=now):
                result = node.detect_crosswalk(camera.papers(near))[0]
        self.assertEqual(result, 1)

    def test_startup_sensor_readiness_and_physical_hold_unchanged_from_exact_v18(self):
        def methods(path):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=='RaceTaskController')
            return {n.name:n for n in cls.body if isinstance(n, ast.FunctionDef)}
        old = methods(helpers.PACKAGE/'tests/baselines/controller_before_v35_19.py')
        new = methods(helpers.SCRIPTS/'race_task_controller.py')
        for name in ('sensors_ready', 'begin_crosswalk_stop', 'crosswalk_record_sample',
                     'crosswalk_reset_hold', 'crosswalk_hold_ready', 'record_still_sample',
                     'approach_crosswalk_drive'):
            self.assertEqual(ast.dump(old[name]), ast.dump(new[name]), name)
        # First branch of update_phase is the complete existing STARTUP flow.
        self.assertEqual(ast.dump(old['update_phase'].body[0]), ast.dump(new['update_phase'].body[0]))
        for name in ('startup_delay', 'sensor_timeout', 'crosswalk_stop_duration'):
            self.assertEqual(getattr(self.c, name), {'startup_delay':8., 'sensor_timeout':1.,
                'crosswalk_stop_duration':3.2}[name])


if __name__ == '__main__':
    unittest.main(verbosity=2)
