#!/usr/bin/env python3
"""Exercise installed ROS callbacks using synthetic poses and visual results.

Only a dry-run controller and synthetic publishers run: no driver, camera or
lidar process. Domain 223, localhost-only transport and remapped command topics
keep all proposed motion away from actuators. This verifies phase decisions,
not camera accuracy, stopping distance or actual track placement.
"""
import argparse
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=Path('/home/bianbu/racecar'))
    parser.add_argument('--report', type=Path, default=Path('/tmp/real_ros_start_zone_v35_23.json'))
    args = parser.parse_args()
    os.environ['ROS_DOMAIN_ID'] = '223'
    os.environ['ROS_LOCALHOST_ONLY'] = '1'
    workspace = args.workspace.resolve()
    executable = workspace/'install/racecar/lib/racecar/race_task_controller.py'
    params = workspace/'install/racecar/share/racecar/config/competition_params.yaml'
    topic = '/codex_validation/proposed_cmd_vel'
    command = [str(executable), '--ros-args', '--params-file', str(params)]
    for value in ('dry_run:=true', 'curve_route:=true', 'relative_route:=true',
                  'exit_continuous:=true', 'entry_v32_enabled:=true',
                  'entry_v33_enabled:=true', 'entry_v34_enabled:=true',
                  'vision_topic:=/codex_validation/vision',
                  'lidar_topic:=/codex_validation/lidar',
                  'boundary_topic:=/codex_validation/boundary',
                  'odom_topic:=/codex_validation/odom'):
        command.extend(('-p', value))
    command.extend(('-r', '/race/proposed_cmd_vel:='+topic,
                    '-r', '/car_cmd_vel:=/codex_validation/unused_cmd_vel',
                    '-r', '/scan:=/codex_validation/unused_scan'))
    report = dict(passed=False, workspace=str(workspace), command=command,
        ros_domain_id=223, localhost_only=True, driver_started=False,
        sensors_started=False, synthetic_sensor_messages=True,
        physical_command_topic_used=False, phases=[], gate_snapshots=[],
        twist_messages=0, early_true_vision_messages=0,
        beyond_gate_false_vision_messages=0, late_true_vision_messages=0,
        errors=[])
    child = listener = rclpy = None
    started = approach_started = stop_started = late_trigger_sent = None
    current_phase = None
    last_x = 0.
    with tempfile.TemporaryFile(mode='w+b') as logfile:
        try:
            if not executable.is_file() or not os.access(executable, os.X_OK):
                raise RuntimeError('Installed controller missing or not executable')
            raw = executable.read_bytes()
            if not raw.startswith(b'#!') or b'\r' in raw.partition(b'\n')[0]:
                raise RuntimeError('Invalid installed POSIX shebang')
            if not params.is_file():
                raise RuntimeError('Installed parameter YAML missing')
            import rclpy as real_rclpy
            from rclpy.node import Node
            from geometry_msgs.msg import Twist
            from nav_msgs.msg import Odometry
            from std_msgs.msg import String, Float32MultiArray, Int16MultiArray
            rclpy = real_rclpy
            rclpy.init(args=[])
            listener = Node('codex_v35_23_start_zone_observer')

            def elapsed():
                return time.monotonic()-started if started is not None else 0.

            def observe_phase(value):
                nonlocal approach_started, stop_started, current_phase
                current_phase = value
                if not report['phases'] or report['phases'][-1]['phase'] != value:
                    report['phases'].append(dict(t=elapsed(), phase=value, synthetic_x=last_x))
                if value == 'APPROACH_CROSSWALK' and approach_started is None:
                    approach_started = time.monotonic()
                if value == 'CROSSWALK_STOP' and stop_started is None:
                    stop_started = time.monotonic()
                    report['stop_observed_x'] = last_x
                    if late_trigger_sent is None or last_x < .8:
                        report['errors'].append('Crosswalk stop before a new visual trigger outside start zone')

            def twist(msg):
                report['twist_messages'] += 1
                if not all(math.isfinite(v) for v in (
                        msg.linear.x, msg.linear.y, msg.linear.z,
                        msg.angular.x, msg.angular.y, msg.angular.z)):
                    report['errors'].append('Nonfinite proposed command')

            def phase(msg):
                observe_phase(msg.data)

            def route(msg):
                match = re.search(r'(?:^|\s)phase=([^\s]+)', msg.data)
                if match:
                    observe_phase(match.group(1))

            def entry(msg):
                try:
                    arm = json.loads(msg.data).get('crosswalk', {}).get('arm')
                    if isinstance(arm, dict):
                        report['gate_snapshots'].append(dict(t=elapsed(), **arm))
                except (ValueError, TypeError):
                    pass

            subscriptions = [listener.create_subscription(Twist, topic, twist, 10),
                listener.create_subscription(String, '/race/task_phase', phase, 10),
                listener.create_subscription(String, '/race/route_status', route, 10),
                listener.create_subscription(String, '/race/entry_status', entry, 10)]
            publishers = dict(
                vision=listener.create_publisher(Int16MultiArray, '/codex_validation/vision', 10),
                lidar=listener.create_publisher(Float32MultiArray, '/codex_validation/lidar', 10),
                boundary=listener.create_publisher(Float32MultiArray, '/codex_validation/boundary', 10),
                odom=listener.create_publisher(Odometry, '/codex_validation/odom', 10))
            child = subprocess.Popen(command, env=dict(os.environ), cwd=str(workspace),
                stdout=logfile, stderr=subprocess.STDOUT, start_new_session=True)
            report['pid'] = child.pid
            started = time.monotonic()
            next_publish = started+.2
            while elapsed() < 30. and child.poll() is None:
                now = time.monotonic()
                if now >= next_publish:
                    next_publish = now+.10
                    since_approach = now-approach_started if approach_started is not None else 0.
                    detected = False
                    last_x = 0.
                    if approach_started is not None:
                        if since_approach < 2.2:
                            last_x = .2*since_approach
                        elif since_approach < 3.2:
                            last_x = .44
                            detected = True
                            report['early_true_vision_messages'] += 1
                        elif since_approach < 5.5:
                            last_x = min(.90, .44+.2*(since_approach-3.2))
                        elif since_approach < 6.2:
                            last_x = .90
                            report['beyond_gate_false_vision_messages'] += 1
                        else:
                            last_x = .90
                            detected = True
                            if late_trigger_sent is None:
                                late_trigger_sent = now
                            report['late_true_vision_messages'] += 1
                    lidar = Float32MultiArray()
                    lidar.data = [0., 0., 0., 0., 3., 0., 0., 0., .45, .45, 0., 1.]
                    boundary = Float32MultiArray()
                    boundary.data = [.45, .45, 3., 0., 0., 1., 1., .45, .45]
                    odom = Odometry()
                    odom.header.stamp = listener.get_clock().now().to_msg()
                    odom.header.frame_id = 'odom'
                    odom.child_frame_id = 'base_footprint'
                    odom.pose.pose.position.x = last_x
                    odom.pose.pose.orientation.w = 1.
                    vision = Int16MultiArray()
                    vision.data = [0, 0, int(detected), int(detected), int(detected)]
                    publishers['lidar'].publish(lidar)
                    publishers['boundary'].publish(boundary)
                    publishers['odom'].publish(odom)
                    publishers['vision'].publish(vision)
                rclpy.spin_once(listener, timeout_sec=.02)
                if stop_started is not None and time.monotonic()-stop_started > .5:
                    break
                if late_trigger_sent is not None and time.monotonic()-late_trigger_sent > 3.:
                    report['errors'].append('No crosswalk stop after new valid trigger at 0.90m')
                    break
            report['observed_seconds'] = elapsed()
            report['alive_after_observation'] = child.poll() is None
            report['first_approach_s'] = approach_started-started if approach_started else None
            report['first_stop_s'] = stop_started-started if stop_started else None
            report['late_trigger_to_stop_s'] = stop_started-late_trigger_sent if stop_started and late_trigger_sent else None
            report['published_topics'] = [name for name,_ in listener.get_topic_names_and_types()]
            if not report['alive_after_observation']:
                report['errors'].append('Controller exited prematurely')
            if approach_started is None:
                report['errors'].append('Normal STARTUP did not admit healthy synthetic sensors')
            if stop_started is None:
                report['errors'].append('Required crosswalk phase transition missing')
            if report['early_true_vision_messages'] < 5 or report['beyond_gate_false_vision_messages'] < 3:
                report['errors'].append('Insufficient inside-zone or beyond-zone negative test coverage')
            if report['twist_messages'] < 20:
                report['errors'].append('No sustained control loop observations')
            if not any(g.get('reason') == 'INSIDE_START_ZONE' and .40 < (g.get('progress_m') or 0.) < .50
                       for g in report['gate_snapshots']):
                report['errors'].append('No gate diagnostic confirmed the 0.44m negative case')
            if not any(g.get('armed') and (g.get('progress_m') or 0.) >= .8 for g in report['gate_snapshots']):
                report['errors'].append('No armed diagnostic beyond 0.8m')
            if any(row['phase'] not in ('STARTUP', 'APPROACH_CROSSWALK', 'CROSSWALK_STOP') for row in report['phases']):
                report['errors'].append('Unexpected task phase')
            if '/car_cmd_vel' in report['published_topics']:
                report['errors'].append('Physical command topic unexpectedly present')
        except Exception as exc:
            report['errors'].append(type(exc).__name__+': '+str(exc))
        finally:
            if child is not None:
                if child.poll() is None:
                    child.send_signal(signal.SIGINT)
                    try:
                        child.wait(timeout=3.)
                    except subprocess.TimeoutExpired:
                        report['errors'].append('Controller failed to stop within three seconds')
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=3.)
                report['returncode'] = child.returncode
                if child.returncode not in (0, 130):
                    report['errors'].append('Unexpected controller exit '+str(child.returncode))
            if listener is not None:
                listener.destroy_node()
            if rclpy is not None and rclpy.ok():
                rclpy.shutdown()
            logfile.seek(0)
            report['controller_output'] = logfile.read().decode('utf-8', errors='replace')
            if 'Traceback (most recent call last)' in report['controller_output']:
                report['errors'].append('Controller traceback')
            report['passed'] = not report['errors']
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({key:report.get(key) for key in ('passed', 'phases', 'stop_observed_x',
        'early_true_vision_messages', 'beyond_gate_false_vision_messages',
        'late_true_vision_messages', 'late_trigger_to_stop_s', 'returncode', 'errors')}, ensure_ascii=False), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
