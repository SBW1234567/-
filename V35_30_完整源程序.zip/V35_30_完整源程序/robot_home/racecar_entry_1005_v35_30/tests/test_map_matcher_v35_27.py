"""Optional map hints: geometry, fallback, masks, bounded work and bad inputs.

Before embedding, run with RACECAR_MAP_ASSIST_DRAFT=1. Production runs import
the packaged race_curve_core so the deployed implementation is exercised.
"""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import numpy as np


PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE.parent
SOURCE = (ROOT/'map_assist_impl.py' if os.environ.get('RACECAR_MAP_ASSIST_DRAFT') == '1'
          else PACKAGE/'payload/src/racecar/scripts/race_curve_core.py')
spec = importlib.util.spec_from_file_location('map_assist_current_v35_27', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
MapAssist = module.MapAssist


def scan_points(pose=(.30, .10, .03), n=144):
    """Ray/rectangle intersections, independent of matcher transform routines."""
    points = []
    x, y, yaw = pose
    for angle in np.linspace(-math.pi, math.pi, n, endpoint=False):
        vx, vy = math.cos(angle+yaw), math.sin(angle+yaw)
        distances = []
        if abs(vx) > 1e-10:
            distances.append(((2. if vx > 0 else -2.)-x)/vx)
        if abs(vy) > 1e-10:
            distances.append(((1.5 if vy > 0 else -1.5)-y)/vy)
        distance = min(v for v in distances if v > 0)
        points.append((distance*math.cos(angle), distance*math.sin(angle)))
    return np.asarray(points)


class MapMatcherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)

    def profile(self, *, transform=(0., 0., 0.), field=None, valid=None, **overrides):
        resolution = .025
        origin = np.array((-4., -4.))
        yy, xx = np.indices((320, 320))
        xx, yy = origin[0]+(xx+.5)*resolution, origin[1]+(yy+.5)*resolution
        tx, ty, yaw = transform
        x = math.cos(yaw)*(xx-tx)+math.sin(yaw)*(yy-ty)
        y = -math.sin(yaw)*(xx-tx)+math.cos(yaw)*(yy-ty)
        distances = np.minimum(abs(abs(x)-2.), abs(abs(y)-1.5)).astype(np.float32)
        if field is not None:
            distances = np.asarray(field(xx, yy), dtype=np.float32)
        if valid is None:
            valid = np.ones(distances.shape, dtype=np.uint8)
        field_path = self.directory/'distance_field.npz'
        np.savez(field_path, distances=distances, valid=valid, origin_xy=origin,
                 resolution=resolution)
        profile = dict(schema=1, profile_id='independent-rectangle',
                       distance_field=field_path.name,
                       distance_field_sha256=hashlib.sha256(field_path.read_bytes()).hexdigest(),
                       course_to_map=list(transform),
                       valid_course_polygon=[[-3., -3.], [3., -3.], [3., 3.], [-3., 3.]],
                       exclude_map_polygons=[])
        profile.update(overrides)
        path = self.directory/'profile.json'
        path.write_text(json.dumps(profile), encoding='utf-8')
        return path

    def load(self, path=None, **options):
        helper = MapAssist(path if path is not None else self.profile(**options))
        helper._loader.join(3.)
        self.assertFalse(helper._loader.is_alive())
        return helper

    def candidate(self, helper, points, seed):
        # Geometry tests freeze the clock. Separate tests assert actual deadline
        # semantics; this avoids turning a slow CI scheduler into a geometry fail.
        with patch.object(module._map_time, 'perf_counter', return_value=100.):
            return helper.candidate(points, seed, 100.02)

    def test_recovers_local_translation_and_yaw(self):
        helper = self.load()
        actual = (.30, .10, .03)
        result = self.candidate(helper, scan_points(actual), (.40, .05, .03+math.radians(2.)))
        self.assertIsNotNone(result, helper.status)
        self.assertLess(np.linalg.norm(np.array(result[:2])-actual[:2]), .035)
        self.assertLess(abs(result[2]-actual[2]), math.radians(1.1))
        self.assertEqual(helper.status['state'], 'CANDIDATE')
        self.assertLessEqual(helper.status['points'], 144)

    def test_nonzero_course_map_transform_and_grid_origin(self):
        helper = self.load(transform=(.7, -.3, .12))
        result = self.candidate(helper, scan_points(), (.40, .05, .03))
        self.assertIsNotNone(result, helper.status)
        self.assertLess(np.linalg.norm(np.array(result[:2])-(.3, .1)), .04)

    def test_already_good_seed_is_not_changed(self):
        helper = self.load()
        self.assertIsNone(self.candidate(helper, scan_points(), (.30, .10, .03)))
        self.assertEqual(helper.status['state'], 'NO_MEANINGFUL_IMPROVEMENT')

    def test_featureless_wrong_field_has_no_candidate(self):
        helper = self.load(field=lambda x, y: np.zeros_like(x))
        self.assertIsNone(self.candidate(helper, scan_points(), (.40, .05, .03)))
        self.assertEqual(helper.status['state'], 'NO_MEANINGFUL_IMPROVEMENT')

    def test_single_wall_ambiguous_translation_is_rejected(self):
        helper = self.load(field=lambda x, y: abs(x-1.8))
        points = np.column_stack((np.full(120, 1.8), np.linspace(-1., 1., 120)))
        self.assertIsNone(self.candidate(helper, points, (.1, 0., 0.)))
        self.assertEqual(helper.status['state'], 'AMBIGUOUS_MATCH')

    def test_unknown_and_outside_are_penalized_not_rewarded(self):
        valid = np.ones((320, 320), dtype=np.uint8)
        valid[160:180, 160:180] = 0
        helper = self.load(valid=valid, field=lambda x, y: np.zeros_like(x))
        values, known = helper._values(np.array([.1, 20., -1.]), np.array([.1, 20., -1.]))
        np.testing.assert_array_equal(known, [False, False, True])
        np.testing.assert_allclose(values, [.2, .2, 0.])

    def test_polygon_mask_is_frozen_at_original_seed(self):
        helper = self.load(exclude_map_polygons=[[[1.8, -3.], [3., -3.], [3., 3.], [1.8, 3.]]])
        captured = []
        original = helper._scores
        def scored(points, seed, offsets, deadline):
            captured.append(points.copy())
            return original(points, seed, offsets, deadline)
        with patch.object(helper, '_scores', side_effect=scored):
            self.candidate(helper, scan_points(), (.4, .05, .03))
        self.assertEqual(len(captured), 2)
        np.testing.assert_array_equal(captured[0], captured[1])
        seed = (.4, .05, .03)
        endpoint_x = seed[0]+math.cos(seed[2])*captured[0][:, 0]-math.sin(seed[2])*captured[0][:, 1]
        self.assertTrue(np.all(endpoint_x < 1.8))

    def test_small_course_region_causes_optional_ignore(self):
        helper = self.load(valid_course_polygon=[[-.1, -.1], [.1, -.1], [.1, .1], [-.1, .1]])
        self.assertIsNone(self.candidate(helper, scan_points(), (.3, .1, .03)))
        self.assertEqual(helper.status['state'], 'INSUFFICIENT_FIXED_SUPPORT')

    def test_closed_polygon_duplicate_vertex_does_not_admit_every_point(self):
        polygon = np.array([[0., 0.], [1., 0.], [1., 1.], [0., 1.], [0., 0.]])
        inside = MapAssist._inside(np.array([[.5, .5], [0., .5], [2., 2.]]), polygon)
        np.testing.assert_array_equal(inside, [True, True, False])

    def test_search_never_exceeds_configured_local_bounds(self):
        helper = self.load()
        seen = []
        original = helper._scores
        def scored(points, seed, offsets, deadline):
            seen.append(offsets.copy())
            return original(points, seed, offsets, deadline)
        with patch.object(helper, '_scores', side_effect=scored):
            self.candidate(helper, scan_points(), (.42, .10, .03))
        offsets = np.vstack(seen)
        self.assertTrue(np.all(np.linalg.norm(offsets[:, :2], axis=1) <= .15+1e-9))
        self.assertTrue(np.all(abs(offsets[:, 2]) <= math.radians(4.)+1e-9))

    def test_expired_deadline_does_no_search(self):
        helper = self.load()
        with patch.object(module._map_time, 'perf_counter', return_value=100.), patch.object(helper, '_scores') as work:
            self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), 99.))
        work.assert_not_called()
        self.assertEqual(helper.status['state'], 'BUDGET_EXPIRED')

    def test_thirty_ms_budget_overrides_long_caller_deadline(self):
        helper = self.load()
        with patch.object(module._map_time, 'perf_counter', side_effect=[100., 100.031, 100.032]):
            self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), 200.))
        self.assertEqual(helper.status['state'], 'BUDGET_EXPIRED')

    def test_shorter_caller_deadline_is_preserved(self):
        helper = self.load()
        with patch.object(module._map_time, 'perf_counter', side_effect=[100., 100.011, 100.012]):
            self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), 100.01))
        self.assertEqual(helper.status['state'], 'BUDGET_EXPIRED')

    def test_nonfinite_deadline_is_rejected_before_search(self):
        for deadline in (float('nan'), float('inf'), -float('inf')):
            helper = self.load()
            with patch.object(module._map_time, 'perf_counter', return_value=100.), patch.object(helper, '_scores') as work:
                self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), deadline))
            self.assertEqual(helper.status['state'], 'INVALID_DEADLINE')
            work.assert_not_called()

    def test_attempt_rate_is_at_most_four_hz(self):
        helper = self.load()
        self.candidate(helper, scan_points(), (.4, .05, .03))
        attempts = helper._attempts
        with patch.object(module._map_time, 'perf_counter', return_value=100.10), patch.object(helper, '_scores') as work:
            self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), 100.12))
        self.assertEqual(helper._attempts, attempts)
        self.assertEqual(helper.status['state'], 'RATE_LIMIT')
        self.assertEqual(helper.status['attempts'], attempts)
        self.assertEqual(helper.status['profile_id'], 'independent-rectangle')
        work.assert_not_called()
        with patch.object(module._map_time, 'perf_counter', return_value=100.26):
            helper.candidate(scan_points(), (.4, .05, .03), 100.28)
        self.assertEqual(helper._attempts, attempts+1)

    def test_missing_map_never_raises_or_becomes_ready(self):
        helper = self.load(self.directory/'absent.json')
        self.assertFalse(helper.ready)
        self.assertEqual(helper.status['state'], 'UNAVAILABLE')
        self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), float('inf')))

    def test_bad_hash_is_disabled(self):
        helper = self.load(distance_field_sha256='0'*64)
        self.assertFalse(helper.ready)
        self.assertIn('SHA256_MISMATCH', helper.status['reason'])

    def test_parent_path_is_disabled(self):
        helper = self.load(distance_field='../distance_field.npz')
        self.assertFalse(helper.ready)
        self.assertIn('OUTSIDE_PROFILE', helper.status['reason'])

    def test_bad_schema_is_disabled(self):
        helper = self.load(schema=2)
        self.assertFalse(helper.ready)
        self.assertIn('UNSUPPORTED_SCHEMA', helper.status['reason'])

    def test_loader_is_asynchronous_and_pending_hint_is_none(self):
        release = threading.Event()
        entered = threading.Event()
        def waiting(instance, path):
            entered.set()
            release.wait(3.)
        with patch.object(MapAssist, '_load', waiting):
            helper = MapAssist('unused')
            try:
                self.assertTrue(entered.wait(1.))
                self.assertFalse(helper.ready)
                self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), float('inf')))
            finally:
                release.set()
                helper._loader.join(3.)

    def test_cache_is_complete_and_immutable_before_ready(self):
        path = self.profile()
        release, entered = threading.Event(), threading.Event()
        original = MapAssist._prepare_cache
        def waiting(instance):
            entered.set()
            release.wait(3.)
            original(instance)
        with patch.object(MapAssist, '_prepare_cache', waiting):
            helper = MapAssist(path)
            try:
                self.assertTrue(entered.wait(1.))
                self.assertFalse(helper.ready)
                self.assertEqual(helper.status['state'], 'LOADING')
                self.assertIsNone(helper.candidate(scan_points(), (.4, .05, .03), float('inf')))
                self.assertEqual(helper.status['state'], 'LOADING')
            finally:
                release.set()
                helper._loader.join(3.)
        self.assertTrue(helper.ready)
        for name in ('_fa', '_fb', '_fc', '_fd', '_fq', '_offsets', '_refinement'):
            self.assertFalse(getattr(helper, name).flags.writeable, name)
        self.assertEqual(helper._offsets.shape, (145, 3))
        self.assertEqual(helper._refinement.shape, (27, 3))

    def test_cached_interpolation_preserves_known_mask_and_distance(self):
        valid = np.ones((320, 320), dtype=np.uint8)
        valid[30:90, 130:160] = 0
        helper = self.load(valid=valid)
        rng = np.random.default_rng(27)
        x = np.concatenate((rng.uniform(-5., 5., 4000), np.array([-4.1, -3.9875, 0., 3.9875, 4.1])))
        y = np.concatenate((rng.uniform(-5., 5., 4000), np.array([-4.1, -3.9875, 0., 3.9875, 4.1])))
        original, original_known = helper._values(x, y)
        cached, cached_known = helper._cached_values((x-helper._origin[0])/helper._resolution-.5,
                                                     (y-helper._origin[1])/helper._resolution-.5)
        np.testing.assert_array_equal(cached_known, original_known)
        self.assertLess(float(np.max(abs(cached-original))), 2e-7)

    def test_cached_layer_scores_match_original_bilinear_values(self):
        helper = self.load(transform=(.7, -.3, .12))
        points = scan_points()
        seed = np.array((.4, .05, .03))
        offsets = helper._offsets
        x, y = helper._map_points(points, seed[None, :]+offsets)
        original, _ = helper._values(x, y)
        expected = np.mean(original, axis=1)
        with patch.object(module._map_time, 'perf_counter', return_value=100.):
            actual = helper._scores(points, seed, offsets, 100.03)
        self.assertLess(float(np.max(abs(actual-expected))), 2e-7)

    def test_internal_exception_does_not_escape(self):
        helper = self.load()
        with patch.object(helper, '_scores', side_effect=RuntimeError('deliberate')):
            self.assertIsNone(self.candidate(helper, scan_points(), (.4, .05, .03)))
        self.assertEqual(helper.status['state'], 'IGNORED_ERROR')

    def test_bad_candidate_inputs_are_ignored(self):
        for seed in (None, (1., 2.), (float('nan'), 0., 0.)):
            helper = self.load()
            self.assertIsNone(self.candidate(helper, scan_points(), seed))
            self.assertEqual(helper.status['state'], 'INVALID_INPUT')

    def test_profile_replacement_is_not_hot_loaded(self):
        path = self.profile()
        helper = self.load(path)
        path.write_text('{}', encoding='utf-8')
        self.assertTrue(helper.ready)
        self.assertIsNotNone(self.candidate(helper, scan_points(), (.4, .05, .03)), helper.status)


if __name__ == '__main__':
    unittest.main()
