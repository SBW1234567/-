"""Current V35.9 behavior plus inherited straight and raw-sweep regressions."""
import unittest
import test_continuous
import test_straight
import test_sweep_gaps

suite=unittest.TestSuite()
suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(test_continuous))
for test in unittest.defaultTestLoader.loadTestsFromTestCase(test_straight.StraightTests):
    # These two freeze the V35.8 implementation; the new crosswalk/straight AST
    # check and V35.9 behavior tests replace them. Inherited behavior still runs.
    if test._testMethodName not in ('test_task_and_collision_methods_unchanged',
                                    'test_geometry_only_approved_functions_changed'):
        suite.addTest(test)
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(test_sweep_gaps.SweepGapTests))
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
