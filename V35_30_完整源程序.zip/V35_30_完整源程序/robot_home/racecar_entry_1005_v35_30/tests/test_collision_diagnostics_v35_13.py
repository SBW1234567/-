"""Raw finite collision diagnostics preserve the sweep's boolean decision."""
import json
import math
from pathlib import Path
import sys
import types
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'))
import race_curve_core as core


def scan(n=450):
    return types.SimpleNamespace(ranges=[math.inf]*n,angle_min=0.,
        angle_increment=2*math.pi/n,range_min=.05,range_max=12.)


class CollisionDiagnosticsTests(unittest.TestCase):
    def test_transformed_first_collision_reports_all_three_frames(self):
        s=scan();s.angle_min=.2;s.ranges[0]=.5
        pose=(5.,1.,.35);q=(*core.world((.45,.07),pose),pose[2]+.1)
        samples=[pose,q];detail={'obsolete':True}
        self.assertTrue(core.scan_hits_body(s,pose,samples,diagnostics=detail))
        self.assertEqual(detail['result'],'SWEPT_OBSTACLE')
        self.assertTrue(detail['hit']);self.assertNotIn('obsolete',detail)
        self.assertEqual(detail['sample_index'],1);self.assertEqual(detail['ray_index'],0)
        laser=(.5*math.cos(.2),.5*math.sin(.2));global_hit=core.world(laser,pose)
        np.testing.assert_allclose(detail['hit_xy_laser'],laser,atol=1e-12)
        np.testing.assert_allclose(detail['hit_xy_world'],global_hit,atol=1e-12)
        np.testing.assert_allclose(detail['hit_xy_body'],core.local(global_hit,q),atol=1e-12)
        self.assertEqual(detail['future_pose'],list(q))
        self.assertEqual(detail['scan_pose'],list(pose))
        self.assertAlmostEqual(detail['sample_displacement_m'],math.hypot(.45,.07))
        self.assertEqual(detail['valid_returns'],1);self.assertEqual(detail['samples'],2)
        json.dumps(detail,allow_nan=False)

    def test_earliest_sample_precedes_a_lower_ray_index_in_later_sample(self):
        s=scan();s.ranges[0]=.5;s.ranges[1]=.9
        poses=[(0.,0.,0.),(.8,0.,0.),(.4,0.,0.)];detail={}
        self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),poses,diagnostics=detail))
        self.assertEqual(detail['sample_index'],1);self.assertEqual(detail['ray_index'],1)

    def test_collision_after_multiple_blocks_uses_absolute_sample_index(self):
        s=scan();s.ranges[0]=.5
        poses=[(2.,0.,0.) for _ in range(25)]+[(.4,0.,0.)];detail={}
        self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),poses,diagnostics=detail))
        self.assertEqual(detail['sample_index'],25);self.assertEqual(detail['ray_index'],0)

    def test_overallocated_driver_ray_retains_original_raw_index(self):
        s=scan(451);s.angle_min=math.radians(-3.)
        s.angle_increment=2*math.pi/449;s.ranges[450]=.5;detail={}
        self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),[(.4,-.04,0.)],diagnostics=detail))
        self.assertEqual(detail['ray_index'],450)

    def test_clear_empty_and_missing_scan_do_not_claim_a_measured_hit(self):
        for s,poses,expected,result in ((scan(),[(0.,0.,0.)],False,'CLEAR'),
                (scan(),[],False,'CLEAR'),(None,[(0.,0.,0.)],True,'SCAN_MISSING')):
            with self.subTest(result=result):
                detail={'hit_xy_world':[999.,999.]}
                self.assertEqual(core.scan_hits_body(s,(0.,0.,0.),poses,diagnostics=detail),expected)
                self.assertEqual(detail['result'],result);self.assertFalse(detail['hit'])
                self.assertNotIn('hit_xy_world',detail)

    def test_optional_diagnostics_preserve_default_boolean_for_seeded_cases(self):
        rng=np.random.default_rng(3513)
        for case in range(80):
            s=scan();r=rng.uniform(.05,5.,450);r[rng.random(450)<.2]=math.inf;s.ranges=r
            pose=tuple(rng.uniform((-5.,-3.,-math.pi),(5.,3.,math.pi)))
            samples=[(*core.world(p,pose),pose[2]+rng.uniform(-.8,.8))
                     for p in rng.uniform((-.3,-.3),(1.,.3),(30,2))]
            default=core.scan_hits_body(s,pose,samples);detail={}
            self.assertIs(type(default),bool)
            self.assertEqual(core.scan_hits_body(s,pose,samples,diagnostics=detail),default)
            self.assertEqual(detail['hit'],default)
            if default:
                self.assertGreaterEqual(detail['sample_index'],0)
                self.assertLess(detail['sample_index'],len(samples))
                self.assertLessEqual(abs(detail['hit_xy_body'][1]),.23+1e-12)


if __name__=='__main__':unittest.main()
