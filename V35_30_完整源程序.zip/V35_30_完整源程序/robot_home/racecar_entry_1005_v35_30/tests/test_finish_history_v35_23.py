"""Keep V22 policy characterizations on the immutable V22 controller.

Five tests assert the replaced pulse protocol and one its old stopped margin.
V24 also replaces one prescribed-run-on test's unconditional zero-input policy
with a low-input assertion plus independent input-driven motor models. These
seven policy characterizations stay on V22; the other eighteen V22 parking
tests continue to run against the current production controller.
Current distance-control requirements live in test_finish_parking_v35_23,
test_finish_distance_v35_24 and the independent motor dynamics tests.
Historical passes are not current-version behavior evidence.
"""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

import test_finish_parking_v35_22 as legacy
import test_final_straight_v35_16 as straight

HISTORICAL_V22_POLICY_TESTS={
    'test_active_pulse_and_moving_arrival_cannot_claim_finished',
    'test_first_pulse_is_low_and_deadline_is_rechecked_at_publication',
    'test_delayed_publication_drops_the_positive_pulse',
    'test_no_second_pulse_until_new_source_standstill_after_neutral',
    'test_ineffective_pulses_escalate_pwm_but_never_duration',
    'test_body_window_and_wall_relative_heading',
    'test_high_speed_entry_brakes_outside_box_and_point_four_runon_stays_out',
}
BASELINE=Path(__file__).resolve().parent/'baselines/controller_before_v35_23.py'
spec=importlib.util.spec_from_file_location('historical_v22_parking_controller',BASELINE)
baseline_controller=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline_controller)


class HistoricalV22ParkingPolicyTests(legacy.FinishParkingV3522Tests):
    def setUp(self):
        # The existing fixture constructs its controller through this module
        # binding. Other helpers use the same unchanged ROS message classes.
        with patch.object(straight,'cm',baseline_controller):
            straight.FinalStraightV3516Tests.setUp(self)
        self.assertIs(type(self.c),baseline_controller.RaceTaskController)


def compatibility_and_historical_suite():
    suite=unittest.TestSuite()
    names=unittest.defaultTestLoader.getTestCaseNames(legacy.FinishParkingV3522Tests)
    missing=HISTORICAL_V22_POLICY_TESTS-set(names)
    if missing:raise AssertionError('Missing historical V22 policy tests: '+repr(missing))
    for name in names:
        cls=HistoricalV22ParkingPolicyTests if name in HISTORICAL_V22_POLICY_TESTS else legacy.FinishParkingV3522Tests
        suite.addTest(cls(name))
    return suite
