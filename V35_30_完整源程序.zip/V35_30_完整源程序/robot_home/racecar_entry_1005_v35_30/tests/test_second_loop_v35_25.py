"""Independent physical second-cone loops, not ideal path-point replay.

The two seeds/cones and starting control poses are recorded observations from
20:54/20:58 V24 runs. Exact plan seeds, actual servo angles and raw scans were
not logged. The plant reconstructs raycasts, uses exact periodic wall anchors,
and integrates its own body trajectory from issued commands. Gain, motor and
delay variations are explicit assumptions, not a fitted or measured car model.
"""
import ast
from bisect import bisect_right
from collections import Counter
import importlib.util
import hashlib
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import numpy as np
import test_continuous as helpers
from test_curve_response import integrate, obstacle_clearance

cm,core,ros=helpers.cm,helpers.core,helpers.ros
PACKAGE=Path(__file__).resolve().parents[1]
ROOT=PACKAGE.parents[1]
CORE_SHA256=hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest()
CONTROLLER_SHA256=hashlib.sha256(Path(cm.__file__).read_bytes()).hexdigest()
RUNS={
 '205457':dict(seed=(5.456715610182328,.9032474659520782,.20121850114427756),
   cones=((6.238521030908153,1.8877494035506248),(2.,2.)),
   pose=(2.7098860143617447,1.420605963433969,-3.079521256194413),
   speed=.45010595571782236,steer=.020477382752340276),
 '205815':dict(seed=(4.33969794867755,.8053021858485518,.002057967945593768),
   cones=((6.259963477760678,1.8891729628084646),(1.9987357898010463,1.9957559444004978)),
   pose=(2.3311221069955232,1.5065103000983722,3.097448464771422),
   speed=.5258375046968287,steer=.0581),
 '205457_early_exit':dict(seed=(5.456715610182328,.9032474659520782,.20121850114427756),
   cones=((6.238521030908153,1.8877494035506248),(2.,2.)),
   pose=(1.0400314454093602,2.1422928776939862,1.7094860608130154),
   speed=.40032502772381595,steer=-.0709),
}
PATHS={}


def path_for(run):
    item=RUNS[run]
    if run not in PATHS:PATHS[run]=core.plan_entry_path(item['seed'],item['cones'])
    return PATHS[run]


def baseline_path(run):
    spec=importlib.util.spec_from_file_location('second_loop_v24_baseline',
        PACKAGE/'tests/baselines/core_before_v35_25.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    item=RUNS[run]
    return module.plan_entry_path(item['seed'],item['cones'])


def simulate_second(run,*,gain=5.,delay=.20,compute=.08,tau=.15,
                    speed_at_035=.70,initial_servo=None,initial_speed=None,metadata=True,max_time=24.,
                    source_blackout_after=None,scan_blackout_after=None):
    """Real command controller, no forced centreline, teleport or manual input.

    PWM .35 reaches speed_at_035, lower input has a cubic speed response. Motor
    acceleration tau=.30 s and neutral coast tau=.40 s; servo tau is varied.
    Source callbacks have .10 s cadence; each 5 Hz control tick receives a scan
    acquired .05 s earlier. One compute delay is charged per sweep/recovery.
    Wall anchors are periodically exact at the associated delayed source pose;
    this isolates tracking/actuation from unmodelled wall-fit errors.
    """
    item=RUNS[run];path=path_for(run)
    if not metadata:
        import copy
        path=copy.copy(path)
        for field in ('upper_exit_start','upper_straight_start'):
            if hasattr(path,field):delattr(path,field)
    ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
       entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
    clock={'t':0.};state=tuple(item['pose']);speed=item['speed'] if initial_speed is None else initial_speed
    actual_u=item['steer'] if initial_servo is None else initial_servo
    target_u=actual_u;target_drive=.33;pending=[]
    # A physically consistent constant-motion prehistory gives real distinct
    # source timestamps; it does not manufacture stationary launch proof.
    times=[-.8+i*.01 for i in range(81)]
    history=[integrate(state,speed,0.,speed*gain*actual_u,t) for t in times]
    def observed(t):
        i=max(0,min(len(times)-1,bisect_right(times,t)-1))
        return history[i]
    minimum=math.inf;minwall=math.inf;mincone=math.inf;trace=[]
    reasons=Counter();zero=positive=0;reached=collision=False
    next_control=0.;next_source=.10;next_anchor=.50;compute_charged=False
    with patch.object(cm.time,'monotonic',side_effect=lambda:100.+clock['t']), \
         patch.object(core,'CONES',item['cones']):
        c=cm.RaceTaskController()
        try:
            c.phase=c.ORBIT_CONE_2;c.curve_cones=item['cones'];c.curve_curvature_gain=5.
            c.curve_control_prediction_enabled=True
            c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=round((1000.+clock['t'])*1e9)))
            f=c.curve_follower=core.PathFollower(path)
            f.index=int(np.argmin(np.linalg.norm(path.samples[:,:2]-np.asarray(state[:2]),axis=1)))
            f.progress=float(path.lengths[f.index]);f.output=f.response_output=actual_u
            f.time=f.response_time=100.;f.speed=speed
            c.last_lane_angular=actual_u;c.curve_last_drive_time=100.;c.curve_drive=target_drive
            c.curve_pose_odom_alignment='SCAN_ALIGNED'
            def source(t,received):
                clock['t']=received;pose=observed(t);ns=round((1000.+t)*1e9);x,y,h=pose
                c.odom_callback(NS(header=NS(stamp=NS(sec=ns//10**9,nanosec=ns%10**9)),
                  pose=NS(pose=NS(position=NS(x=x-.07*math.cos(h),y=y-.07*math.sin(h)),
                    orientation=NS(x=0.,y=0.,z=math.sin(h/2),w=math.cos(h/2)))),
                  twist=NS(twist=NS(linear=NS(x=0.),angular=NS(z=0.)))))
                return pose
            for t in (-.3,-.2,-.1,0.):source(t-delay,t)
            c.curve_locator.pose=observed(-delay);c.curve_locator.time=100.;c.curve_locator.hits=3
            c.curve_pose_odom=tuple(c.curve_odom_samples[-1][1:4])
            original=c.curve_check_sweep
            def timed_sweep(*args):
                nonlocal compute_charged
                result=original(*args)
                if not compute_charged:clock['t']+=compute;compute_charged=True
                return result
            c.curve_check_sweep=timed_sweep
            for tick in range(1,round(max_time/.01)+1):
                now=tick*.01;clock['t']=now
                if now+1e-9>=next_source and (source_blackout_after is None or now<=source_blackout_after):
                    pose=source(now-delay,now);next_source=now+.10
                    if now+1e-9>=next_anchor:
                        c.curve_locator.pose=pose;c.curve_locator.time=100.+now
                        c.curve_pose_odom=tuple(c.curve_odom_samples[-1][1:4])
                        next_anchor=now+.50
                if now+1e-9>=next_control:
                    compute_charged=False
                    if scan_blackout_after is None or now<=scan_blackout_after:
                        scan_t=now-.05;scan=helpers.scan_at(observed(scan_t))
                        ns=round((1000.+scan_t)*1e9)
                        scan.header.stamp=NS(sec=ns//10**9,nanosec=ns%10**9)
                        c.curve_scan=scan;c.curve_scan_stamp=ns
                        c.curve_scan_time=c.last_lidar_time=c.rel_time=100.+now
                    c.rel_data={'body_clear':core.body_clear(state,margin=0.)}
                    command=c.curve_command(100.+now)
                    assert math.isfinite(command.linear.x) and 0.<=command.linear.x<=.35
                    assert math.isfinite(command.angular.z) and abs(command.angular.z)<=.32+1e-9
                    if command.linear.x>0.:positive+=1
                    else:zero+=1;reasons[c.curve_reason]+=1
                    trace.append(dict(t=now,pose=state,speed=speed,servo=actual_u,
                      drive=command.linear.x,steer=command.angular.z,progress=f.progress,
                      lateral=f.lateral,heading=f.heading,ff=f.ff,upper_exit=getattr(f,'upper_exit_active',False),
                      reason=c.curve_reason,recovery=c.curve_recovery_status.get('state'),
                      pose_reason=c.curve_pose_estimate_reason,sweep=c.curve_sweep,
                      source_age=c.curve_motion_status.get('odom_source_age_s')))
                    pending.append((now+compute,command.angular.z,command.linear.x))
                    next_control=now+.20
                while pending and pending[0][0]<=now+1e-9:
                    _,target_u,target_drive=pending.pop(0)
                actual_u+=(1.-math.exp(-.01/tau))*(target_u-actual_u)
                wanted=speed_at_035*(target_drive/.35)**3 if target_drive>0. else 0.
                speed+=(1.-math.exp(-.01/(.30 if wanted>speed else .40)))*(wanted-speed)
                state=integrate(state,speed,0.,speed*gain*actual_u,.01)
                times.append(now);history.append(state)
                wall,cone,gap=obstacle_clearance(state)
                minimum=min(minimum,gap);minwall=min(minwall,wall);mincone=min(mincone,cone)
                collision=not core.body_clear(state,item['cones'],margin=0.)
                if collision:break
                if f.progress>=path.gates[4]+.60 and state[0]>=2.9 and abs(state[1]-3.55)<.30 and abs(core.wrap(state[2]))<.30:
                    reached=True;break
                if now>12. and speed<.005 and all(x['drive']==0. for x in trace[-30:]):break
            return dict(run=run,gain=gain,delay=delay,compute=compute,tau=tau,speed_at_035=speed_at_035,
              core_sha256=CORE_SHA256,controller_sha256=CONTROLLER_SHA256,
              path_module=type(path).__module__,
              initial_servo=initial_servo,initial_speed=initial_speed,metadata=metadata,reached=reached,collision=collision,
              source_blackout_after=source_blackout_after,scan_blackout_after=scan_blackout_after,
              time_s=now,final_pose=state,minimum_clearance_m=minimum,wall_clearance_m=minwall,
              cone_clearance_m=mincone,positive_commands=positive,zero_commands=zero,
              stop_reasons=dict(reasons),route_fault=c.route_fault,trace=trace)
        finally:c.close_curve_worker()


class SecondLoopV3525Tests(unittest.TestCase):
    def test_controller_methods_preserve_second_cone_and_other_parking_helpers(self):
        before=PACKAGE/'tests/baselines/controller_before_v35_30.py'
        after=PACKAGE/'payload/src/racecar/scripts/race_task_controller.py'
        def methods(path):
            tree=ast.parse(path.read_text(encoding='utf-8-sig'))
            for node in ast.walk(tree):
                if isinstance(node,ast.Constant) and isinstance(node.value,str):
                    for marker in ('PARKING_CONTINUITY_1005_V35_30','PARKING_APPROACH_1005_V35_29'):
                        node.value=node.value.replace(marker,'VERSION_MARKER_ONLY')
            cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
            return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}
        a,b=methods(before),methods(after)
        # V30 parking observation and continuity scope is explicitly reviewed.
        # All second-cone motion stays unchanged and is exercised below.
        scope=json.loads((PACKAGE/'tests/v35_30_scope.json').read_text(encoding='utf-8'))
        self.assertTrue(scope['frozen'])
        allowed={name.split('.',1)[1] for name in scope['controller_changed_methods']
                 if name.startswith('RaceTaskController.')}
        added={name.split('.',1)[1] for name in scope['controller_new_methods']
               if name.startswith('RaceTaskController.')}
        removed={name.split('.',1)[1] for name in scope['controller_removed_methods']
                 if name.startswith('RaceTaskController.')}
        self.assertEqual(b.keys()-a.keys(),added)
        self.assertEqual(a.keys()-b.keys(),removed)
        self.assertEqual({name for name in a.keys() & b.keys() if a[name]!=b[name]},allowed)
        protected={'curve_second_recovery_scope','curve_second_recovery_geometry',
                   'curve_command','curve_recovery_hold_command',
                   'curve_first_preposition_still',
                   'finish_parking_bound_command',
                   'finish_parking_settled','final_straight_command',
                   'vision_callback','crosswalk_hold_ready',
                   'crosswalk_stop_armed','control_loop'}
        self.assertTrue(protected.issubset(a.keys() & b.keys()))
        self.assertTrue(protected.isdisjoint(allowed | added | removed))
        self.assertEqual({name:a[name] for name in protected},
                         {name:b[name] for name in protected})

    def test_recorded_second_cone_entries_finish_with_nominal_independent_plant(self):
        for run in ('205457','205815'):
            with self.subTest(run=run):
                r=simulate_second(run)
                self.assertFalse(r['collision'],r)
                self.assertTrue(r['reached'],{k:v for k,v in r.items() if k!='trace'})

    def test_gain_source_delay_servo_and_point_seven_entry_speed_complete(self):
        for run in ('205457','205815'):
            for gain in (4.,5.,6.):
                with self.subTest(run=run,gain=gain):
                    r=simulate_second(run,gain=gain,delay=.34,tau=.25,
                        initial_speed=.70,speed_at_035=.90)
                    summary={k:v for k,v in r.items() if k!='trace'}
                    self.assertTrue(r['reached'],summary)
                    self.assertFalse(r['collision'],summary)
                    self.assertGreater(r['minimum_clearance_m'],.08,summary)

    def test_recorded_early_pose_escapes_where_fixed_v24_geometry_stops(self):
        run='205457_early_exit'
        for gain in (4.,5.):
            with self.subTest(gain=gain):
                with patch.dict(PATHS,{run:baseline_path(run)}):
                    before=simulate_second(run,gain=gain,delay=.30,tau=.25)
                after=simulate_second(run,gain=gain,delay=.30,tau=.25)
                self.assertFalse(before['collision'])
                self.assertFalse(before['reached'])
                self.assertIn('RECOVERING_SWEPT_OBSTACLE',before['stop_reasons'])
                self.assertTrue(after['reached'],{k:v for k,v in after.items() if k!='trace'})
                self.assertFalse(after['collision'])

    def test_delayed_source_or_scan_loss_still_stops_real_forward_input(self):
        for option in ('source_blackout_after','scan_blackout_after'):
            with self.subTest(option=option):
                r=simulate_second('205457',max_time=4.,**{option:.40})
                self.assertFalse(r['reached'])
                self.assertFalse(r['collision'])
                self.assertGreater(r['zero_commands'],0)
                self.assertTrue(all(t['drive']==0. for t in r['trace'][-5:]))
                self.assertLess(r['trace'][-1]['speed'],.02)

    def test_exit_metadata_is_active_only_from_its_new_gate(self):
        r=simulate_second('205457')
        gate=path_for('205457').gates[3]
        self.assertTrue(any(not x['upper_exit'] for x in r['trace']))
        self.assertTrue(any(x['upper_exit'] for x in r['trace']))
        for x in r['trace']:
            self.assertEqual(x['upper_exit'],x['progress']>=gate)


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='matrix':
        out=Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
        cases=[dict(run=run,gain=gain,delay=.20) for run in ('205457','205815') for gain in (4.,5.,6.)]
        cases += [dict(run=run,gain=gain,delay=.34,tau=.25,initial_speed=.7,speed_at_035=.9)
                  for run in ('205457','205815') for gain in (4.,5.,6.)]
        cases += [dict(run='205457_early_exit',gain=g,delay=.30,tau=.25) for g in (4.,5.,6.)]
        cases += [dict(run='205457_early_exit',gain=5.,delay=.30,tau=.25,metadata=False)]
        cases += [dict(run='205457_early_exit',gain=5.,delay=.30,tau=.25,initial_servo=u)
                  for u in (0.,.15,.32)]
        results=[]
        for case in cases:
            r=simulate_second(**case);results.append(r)
            out.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
            print(json.dumps({k:v for k,v in r.items() if k!='trace'}),flush=True)
    else:unittest.main()
