"""Bounded ZERO-drive presteer continuity across V25 recorded source delays.

Timing witnesses come from 22:25:26; the pose/raycast fixture is an existing
recorded first-cone stopped case, not a reconstruction of unlogged raw scans.
Old methods use the exact V25 baseline. No cached proof may enable propulsion.
"""
import ast
from collections import deque
import copy
import math
from pathlib import Path
from types import MethodType
import unittest
from unittest.mock import patch

import test_first_cone_dwell_v35_22 as fixture

cm,core=fixture.cm,fixture.core
STOP=fixture.STOP
PRODUCTION_PATH=None


class FirstContinuityV3526Tests(unittest.TestCase):
    source=fixture.FirstConeDwellV3522Tests.source
    inputs=fixture.FirstConeDwellV3522Tests.inputs
    presteer=fixture.FirstConeDwellV3522Tests.presteer
    tick=fixture.FirstConeDwellV3522Tests.tick

    def setUp(self):
        # New tests always exercise current production geometry. The separate
        # V22 timing tests deliberately hold their old blocked-path geometry.
        global PRODUCTION_PATH
        if PRODUCTION_PATH is None:
            PRODUCTION_PATH=core.plan_entry_path(fixture.HANDOFF,cones=fixture.CONES)
        with patch.object(fixture,'PATH',PRODUCTION_PATH):
            fixture.FirstConeDwellV3522Tests.setUp(self)
        self.assertIs(self.c.curve_follower.path,PRODUCTION_PATH)

    def delayed(self,age,dt):
        self.now+=dt;self.ros_time+=dt
        self.source(self.ros_time-age,STOP);self.inputs(STOP)

    def old_methods(self):
        path=Path(__file__).parent/'baselines/controller_before_v35_26.py'
        cls=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body
                 if isinstance(n,ast.ClassDef))
        namespace=dict(cm.__dict__)
        for node in cls.body:
            if isinstance(node,ast.FunctionDef) and node.name in {
                    'curve_first_preposition_still','curve_recovery_hold_command'}:
                exec(compile(ast.Module(body=[copy.deepcopy(node)],type_ignores=[]),str(path),'exec'),namespace)
                patch.object(self.c,node.name,MethodType(namespace[node.name],self.c)).start()

    def assert_zero_hold(self,state,proof,checked):
        state['clear_hits']=9
        command=self.c.curve_recovery_hold_command(self.now)
        self.assertIsNotNone(command)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,state['steer'])
        self.assertIs(self.c.curve_recovery_state,state)
        self.assertEqual(state['first_standstill_proof'],proof)
        self.assertEqual(state['checked_at'],checked)
        self.assertEqual(state['clear_hits'],0)
        self.assertFalse(self.c.curve_standstill_status['valid'])
        return command

    def test_recorded_receipt_point398_keeps_zero_steering_without_renewal(self):
        state=self.presteer();proof=copy.deepcopy(state['first_standstill_proof'])
        checked=state['checked_at'];self.now+=.23;self.ros_time+=.23
        self.c.last_odom_time=self.now-.398
        self.assert_zero_hold(state,proof,checked)
        self.assertEqual(self.c.curve_standstill_status['reason'],'STOP_INPUTS_OR_RECEIPT')

    def test_recorded_source_point759_after_point61_keeps_zero_only(self):
        state=self.presteer();proof=copy.deepcopy(state['first_standstill_proof'])
        checked=state['checked_at'];self.delayed(.759,.61)
        self.assert_zero_hold(state,proof,checked)
        self.assertEqual(self.c.curve_standstill_status['reason'],'STOP_SOURCE_AGE')
        self.assertGreater(self.now-state['started'],.60)

    def test_recorded_final_point973_waits_then_rechecks_before_drive(self):
        state=self.presteer();started=state['started'];proof=copy.deepcopy(state['first_standstill_proof'])
        self.delayed(.973,.602)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertIs(self.c.curve_recovery_state,state)
        self.assertEqual(state['first_standstill_proof'],proof)
        self.assertEqual(state['started'],started)
        self.delayed(.65,.10)
        command=self.c.curve_command(self.now)
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['standstill']['valid'])
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertEqual(self.c.curve_recovery_status['final_check_reason'],'')
        self.assertNotIn('first_standstill_proof',state)

    def test_fixed_v25_methods_reset_all_three_recorded_timing_witnesses(self):
        self.old_methods();state=self.presteer();saved=copy.deepcopy(state)
        samples=list(self.c.curve_motion_samples)
        for witness in ('receipt','source','final'):
            with self.subTest(witness=witness):
                self.now=100.;self.ros_time=1000.;self.c.last_odom_time=100.
                self.c.curve_motion_samples=deque(samples,maxlen=8)
                self.c.curve_recovery_state=copy.deepcopy(saved)
                if witness=='receipt':
                    self.now+=.23;self.ros_time+=.23;self.c.last_odom_time=self.now-.398
                elif witness=='source':self.delayed(.759,.61)
                else:self.delayed(.973,.602)
                self.assertIsNone(self.c.curve_recovery_hold_command(self.now))

    def test_point70_real_sample_gap_can_hold_but_cannot_prove_current_stop(self):
        state=self.presteer();proof=copy.deepcopy(state['first_standstill_proof'])
        checked=state['checked_at'];self.delayed(.65,.70)
        self.assert_zero_hold(state,proof,checked)
        self.assertEqual(self.c.curve_standstill_status['reason'],'STOP_SOURCE_GAP')

    def test_fixed_expiry_does_not_refresh_on_repeated_zero_ticks(self):
        state=self.presteer();proof=copy.deepcopy(state['first_standstill_proof']);checked=state['checked_at']
        self.delayed(.759,.61);self.assert_zero_hold(state,proof,checked)
        self.delayed(.759,.50);self.assert_zero_hold(state,proof,checked)
        self.delayed(.759,.091)
        self.assertIsNone(self.c.curve_recovery_hold_command(self.now))
        self.assertNotIn('first_standstill_proof',state)
        self.assertEqual(state['started'],100.)
        # Production pause path discards rejected old state. A subsequent
        # genuinely fresh standstill may start again, with a NEW dwell time.
        self.c.publish_stop();self.now+=.6;self.ros_time+=.6
        for dt in (-.5,-.3,-.1):self.source(self.ros_time+dt,STOP)
        self.inputs(STOP);command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertGreater(self.c.curve_recovery_state['started'],state['started'])

    def test_motion_clock_positive_drive_or_long_gap_invalidates_old_proof(self):
        state=self.presteer();saved=copy.deepcopy(state);samples=list(self.c.curve_motion_samples)
        for defect in ('push','rotate','gap','receipt','source_age','regress',
                       'clock_back','clock_jump','drive','emergency','fault'):
            with self.subTest(defect=defect):
                self.now=100.2;self.ros_time=1000.2;c=self.c
                c.curve_recovery_state=copy.deepcopy(saved);state=c.curve_recovery_state
                c.curve_motion_samples=deque(samples,maxlen=8);c.last_odom_time=self.now
                c.curve_last_drive_time=98.5;c.lidar_emergency=False;c.route_fault=''
                if defect in ('push','rotate'):
                    moved=(STOP[0]+.06,STOP[1],STOP[2]) if defect=='push' else (*STOP[:2],STOP[2]+.12)
                    c.curve_motion_samples.append((999500000000,*moved))
                elif defect=='gap':
                    self.now=100.9;self.ros_time=1000.9;c.last_odom_time=self.now
                    c.curve_motion_samples.append((1000160000000,*STOP))
                elif defect=='receipt':c.last_odom_time=self.now-.801
                elif defect=='source_age':self.now=100.451;self.ros_time=1000.451
                elif defect=='regress':c.curve_motion_samples=deque(samples[:-1],maxlen=8)
                elif defect=='clock_back':self.ros_time=999.99
                elif defect=='clock_jump':self.ros_time+=.11
                elif defect=='drive':c.curve_last_drive_time=100.1
                elif defect=='emergency':c.lidar_emergency=True
                else:c.route_fault='TEST'
                self.assertIsNone(c.curve_recovery_hold_command(self.now))
                self.assertNotIn('first_standstill_proof',state)

    def test_stale_scan_retains_only_zero_and_new_raw_obstacle_still_blocks(self):
        state=self.presteer();self.delayed(.759,.61)
        self.c.curve_scan_time=self.now-.36
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.);self.assertEqual(state['clear_hits'],0)
        self.assertAlmostEqual(command.angular.z,.32)
        self.delayed(.65,.1)
        arc=core.constant_steer_horizon(STOP,.32,5.,distance=.65,initial_steer=.32)
        x,y=core.local(arc[15],STOP);scan=self.c.curve_scan
        k=round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment)%len(scan.ranges)
        scan.ranges[k]=math.hypot(x,y)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)

    def test_new_still_window_after_push_cannot_reuse_old_dwell(self):
        state=self.presteer();self.now+=.9;self.ros_time+=.9
        moved=(STOP[0]+.06,STOP[1],STOP[2])
        # A fresh short stationary window at the PUSHED pose is sufficient
        # for a new stopped check, but cannot validate the older arc/dwell.
        self.c.curve_motion_samples.clear()
        for t in (1000.3,1000.5,1000.7):self.source(t,moved)
        self.assertTrue(self.c.curve_recovery_stopped(self.now))
        self.assertIsNone(self.c.curve_recovery_hold_command(self.now))
        self.assertNotIn('first_standstill_proof',state)

    def test_missing_proof_sliding_or_second_cone_cannot_use_extension(self):
        state=self.presteer();saved=copy.deepcopy(state)
        for defect in ('no_proof','sliding','second'):
            with self.subTest(defect=defect):
                self.now=100.61;self.ros_time=1000.61
                self.c.phase=self.c.ORBIT_CONE_1
                self.c.curve_recovery_state=copy.deepcopy(saved)
                state=self.c.curve_recovery_state
                if defect=='no_proof':state.pop('first_standstill_proof')
                elif defect=='sliding':self.c.curve_motion_samples.append((999800000000,STOP[0]+.06,*STOP[1:]))
                else:self.c.phase=self.c.ORBIT_CONE_2
                self.assertIsNone(self.c.curve_recovery_hold_command(self.now))


if __name__=='__main__':unittest.main(verbosity=2)
