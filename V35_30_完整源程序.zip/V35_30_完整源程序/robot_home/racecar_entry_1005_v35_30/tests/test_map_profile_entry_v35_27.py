"""Optional profile selection must not change ordinary launch parameters."""
import ast
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
from launch_centered import select_map_profile


class MapProfileEntryV3527Tests(unittest.TestCase):
    def test_default_uses_bundled_lab_profile(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            profile=root/'maps/lab_20261003/profile.json'
            profile.parent.mkdir(parents=True)
            profile.write_text('{}',encoding='utf-8')
            selected,note=select_map_profile(None,root)
            self.assertEqual(selected,str(profile.resolve()))
            self.assertIn('controller validates',note)

    def test_missing_default_disables_only_map_assist(self):
        with tempfile.TemporaryDirectory() as directory:
            selected,note=select_map_profile(None,Path(directory))
            self.assertEqual(selected,'off')
            self.assertIn('missing',note)

    def test_explicit_directory_and_file_select_same_profile(self):
        with tempfile.TemporaryDirectory(prefix='map profile ') as directory:
            root=Path(directory)
            profile=root/'profile.json'
            profile.write_text('{}',encoding='utf-8')
            from_directory=select_map_profile(str(root),PACKAGE)[0]
            from_file=select_map_profile(str(profile),PACKAGE)[0]
            self.assertEqual(from_directory,str(profile.resolve()))
            self.assertEqual(from_file,from_directory)

    def test_missing_explicit_profile_keeps_startup_available(self):
        with tempfile.TemporaryDirectory() as directory:
            selected,note=select_map_profile(str(Path(directory)/'missing.json'),PACKAGE)
            self.assertEqual(selected,'off')
            self.assertIn('missing',note)

    def test_explicit_off_never_resolves_or_loads_a_profile(self):
        with patch.object(Path,'resolve',side_effect=AssertionError('off must not access map')):
            for value in ('off','OFF',' off '):
                self.assertEqual(select_map_profile(value,PACKAGE)[0],'off')

    def test_empty_selection_disables_assist(self):
        self.assertEqual(select_map_profile('',PACKAGE)[0],'off')

    def test_profile_path_error_is_nonblocking(self):
        with patch.object(Path,'resolve',side_effect=OSError('unavailable mount')):
            selected,note=select_map_profile('unknown_profile.json',PACKAGE)
        self.assertEqual(selected,'off')
        self.assertIn('unavailable',note)

    def test_profile_content_validation_is_left_to_controller(self):
        with tempfile.TemporaryDirectory() as directory:
            profile=Path(directory)/'profile.json'
            profile.write_text('invalid content for controller validation',encoding='utf-8')
            selected,note=select_map_profile(str(profile),PACKAGE)
            self.assertEqual(selected,str(profile.resolve()))
            self.assertIn('controller validates',note)

    def test_fourth_argument_is_quoted_environment_only(self):
        runner=(PACKAGE/'run_v35_27.sh').read_text(encoding='utf-8')
        self.assertIn('RACE_MAP_PROFILE=${4:-$PATCH_DIR/maps/lab_20261003/profile.json}',runner)
        self.assertIn('export RACECAR_MAP_PROFILE="$RACE_MAP_PROFILE"',runner)
        self.assertIn('"$#" -gt 4',runner)
        self.assertNotIn('map_profile:=',runner)

    def test_install_hash_check_precedes_profile_and_launch(self):
        source=(PACKAGE/'launch_centered.py').read_text(encoding='utf-8')
        main=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        text=ast.get_source_segment(source,main)
        self.assertLess(text.index("'--verify-install'"),text.index('select_map_profile('))
        self.assertLess(text.index('select_map_profile('),text.index('os.execvp('))

    def test_old_production_entrypoints_are_not_in_v27_package(self):
        for name in ('run_v35_26.sh','verify_v35_26.sh','rollback_v35_25.sh'):
            self.assertFalse((PACKAGE/name).exists(),name)


if __name__ == '__main__':
    unittest.main(verbosity=2)
