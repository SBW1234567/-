"""Real process-name detection and Linux inherited/competing flock checks."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
from baseline_check import active_race_processes
from install_lock import workspace_lock


class ActiveRF2OTests(unittest.TestCase):
    def test_standalone_rf2o_node_is_detected_without_driver_or_launcher(self):
        with tempfile.TemporaryDirectory() as directory:
            proc = Path(directory)
            process = proc / '123'
            process.mkdir()
            (process / 'cmdline').write_bytes(
                b'/home/bianbu/racecar/install/rf2o_laser_odometry/lib/rf2o_laser_odometry/'
                b'rf2o_laser_odometry_node\0--ros-args\0-r\0__node:=race_rf2o_laser_odometry\0')
            self.assertEqual(active_race_processes(proc), ['123'])

    def test_hardware_free_benchmark_and_finished_process_do_not_block_install(self):
        with tempfile.TemporaryDirectory() as directory:
            proc = Path(directory)
            for name, command in [('123', b'\0'.join((b'/tmp/rf2o_benchmark_Release', b'--rays', b'720', b''))),
                                  ('456', b''), ('not_a_pid', b'rf2o_laser_odometry_node\0')]:
                process = proc / name
                process.mkdir()
                (process / 'cmdline').write_bytes(command)
            self.assertEqual(active_race_processes(proc), [])


CHILD_PROBE = """
import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, sys.argv[1])
from install_lock import workspace_lock
with patch.object(Path, 'home', return_value=Path(sys.argv[2])):
    try:
        with workspace_lock():
            print('acquired')
    except BlockingIOError:
        print('blocked')
        raise SystemExit(17)
    except (ValueError, OSError) as error:
        print(type(error).__name__ + ': ' + str(error))
        raise SystemExit(19)
"""


@unittest.skipUnless(os.name == 'posix', 'Linux flock/descriptor inheritance requires POSIX')
class InstallLockTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        home_patch = patch.object(Path, 'home', return_value=self.home)
        home_patch.start()
        self.addCleanup(home_patch.stop)
        env_patch = patch.dict(os.environ, {}, clear=False)
        env_patch.start()
        self.addCleanup(env_patch.stop)
        # Do not alter the actual HOME environment variable or real home files.
        os.environ.pop('RACECAR_INSTALL_LOCK_FD', None)
        self.path = self.home / '.config/racecar/steering_center.lock'
        self.path.parent.mkdir(parents=True)
        self.path.touch()

    def probe(self, descriptor=None):
        env = os.environ.copy()
        env.pop('RACECAR_INSTALL_LOCK_FD', None)
        inherited = ()
        if descriptor is not None:
            env['RACECAR_INSTALL_LOCK_FD'] = str(descriptor)
            inherited = (descriptor,)
        return subprocess.run([sys.executable, '-c', CHILD_PROBE, str(PACKAGE), str(self.home)],
                              env=env, pass_fds=inherited, capture_output=True,
                              text=True, timeout=5)

    def test_competing_process_is_rejected_and_lock_releases_after_context(self):
        with workspace_lock():
            competing = self.probe()
            self.assertEqual(competing.returncode, 17, competing.stderr + competing.stdout)
        later = self.probe()
        self.assertEqual(later.returncode, 0, later.stderr + later.stdout)
        self.assertIn('acquired', later.stdout)

    def test_child_reuses_inherited_lock_without_releasing_shell_ownership(self):
        import fcntl
        with self.path.open('a') as shell_lock:
            fcntl.flock(shell_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            child = self.probe(shell_lock.fileno())
            self.assertEqual(child.returncode, 0, child.stderr + child.stdout)
            competing = self.probe()
            self.assertEqual(competing.returncode, 17, competing.stderr + competing.stdout)
        self.assertEqual(self.probe().returncode, 0)

    def test_unrelated_inherited_descriptor_is_rejected(self):
        wrong = self.home / 'different.lock'
        with wrong.open('a') as descriptor:
            child = self.probe(descriptor.fileno())
        self.assertEqual(child.returncode, 19, child.stderr + child.stdout)
        self.assertIn('Inherited descriptor is not the workspace lock', child.stdout)

    def test_same_inode_separate_open_cannot_bypass_competing_lock(self):
        import fcntl
        with self.path.open('a') as owner, self.path.open('a') as pretender:
            fcntl.flock(owner.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            child = self.probe(pretender.fileno())
            self.assertEqual(child.returncode, 17, child.stderr + child.stdout)


if __name__ == '__main__':
    unittest.main(verbosity=2)
