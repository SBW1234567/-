"""Measured-cone geometry and late-exit feedback regressions for V35.14."""
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import numpy as np

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE/'tests'));sys.path.insert(0,str(PACKAGE/'payload/src/racecar/scripts'))
import race_curve_core as core
import validate_upper_exit_v35_14 as validation


class UpperExitV3514Tests(unittest.TestCase):
    def test_all_recorded_plans_keep_full_body_certificate_and_straight_join(self):
        fixtures,missing=validation.recorded_inputs()
        self.assertEqual(len(fixtures),4)
        self.assertEqual(missing,['race_control_20261001_195815.csv'])
        for fixture in fixtures:
            with self.subTest(log=fixture['name']):
                path=core.plan_entry_path(fixture['start'],fixture['cones'])
                self.assertEqual(path.upper_exit_family,'ZERO_CURVATURE_JOIN')
                self.assertTrue(core.path_body_clear(path.samples,fixture['cones'],margin=.10))
                self.assertLessEqual(path.max_curvature,1/.55)
                self.assertLessEqual(float(max(np.diff(path.lengths))),.055)
                self.assertLessEqual(float(max(abs(path.samples[480:801,3]))),1.35)
                self.assertLessEqual(float(max(path.samples[480:801,3])),.003)
                # V25's reviewed local profile joins the straight at x=2.4;
                # all original body/curvature/continuity checks remain below.
                np.testing.assert_allclose(path.samples[800,:3],(2.4,3.55,0.),atol=1e-12)
                np.testing.assert_allclose(path.samples[800:,1:4],
                    np.tile((3.55,0.,0.),(len(path.samples)-800,1)),atol=1e-12)

    def test_different_parameter_speeds_preserve_geometric_join_continuity(self):
        fixture=validation.recorded_inputs()[0][-1]
        with patch.object(core,'quintic',wraps=core.quintic) as segments:
            core.plan_entry_path(fixture['start'],fixture['cones'])
        # The accepted first candidate needs six pieces; compare their exact
        # endpoint position, unit tangent and curvature, not sample rounding.
        calls=segments.call_args_list[-6:]
        def curvature(v,a):return (v[0]*a[1]-v[1]*a[0])/math.hypot(*v)**3
        for left,right in zip(calls,calls[1:]):
            _,b,_,vb,_,ab=left.args;a,_,va,_,aa,_=right.args
            np.testing.assert_allclose(a,b)
            self.assertAlmostEqual(core.wrap(math.atan2(vb[1],vb[0])-math.atan2(va[1],va[0])),0.)
            self.assertAlmostEqual(curvature(vb,ab),curvature(va,aa))

    def test_fifth_run_large_lateral_error_does_not_overrule_heading_correction(self):
        fixture=validation.recorded_inputs()[0][-1]
        follower=core.PathFollower(core.plan_entry_path(fixture['start'],fixture['cones']))
        follower.index=800;follower.progress=follower.path.gates[4]
        follower.time=99.84;follower.output=.02;follower.response_output=.02
        follower.command((3.034,3.061,.462),100.,5.)
        self.assertTrue(follower.upper_exit_active)
        self.assertGreater(follower.lateral,.45)
        self.assertLess(follower.heading,-.45)
        self.assertLessEqual(abs(follower.lateral_heading),.30)
        self.assertAlmostEqual(follower.ff,0.)
        self.assertLess(follower.p,0.)
        self.assertLess(follower.output,0.)

    def test_actuator_response_has_an_independent_clock(self):
        fixture=validation.recorded_inputs()[0][0]
        f=core.PathFollower(core.plan_entry_path(fixture['start'],fixture['cones']))
        f.time=99.5;f.response_time=99.9;f.output=.30;f.response_output=0.
        f.command(tuple(f.path.samples[0,:3]),100.,5.)
        self.assertAlmostEqual(f.response_output,.30*(1.-math.exp(-.1/.12)))
        self.assertEqual(f.response_time,100.)
        f.reset_feedback(preserve_output=True)
        self.assertEqual(f.response_time,100.)
        f.reset_feedback();self.assertIsNone(f.response_time)

    def test_first_cone_geometry_and_feedback_policy_are_not_changed_by_exit_mode(self):
        fixture=validation.recorded_inputs()[0][0]
        path=core.plan_entry_path(fixture['start'],fixture['cones'])
        f=core.PathFollower(path);f.index=160;f.progress=path.gates[0]
        f.command(tuple(path.samples[160,:3]),100.,5.)
        self.assertFalse(f.upper_exit_active)
        self.assertAlmostEqual(f.p,.16*f.error)
        self.assertLessEqual(float(max(abs(path.samples[:321,3]))),1.35)
        self.assertGreaterEqual(float(min(path.samples[:321,3])),-.02)


if __name__=='__main__':unittest.main(verbosity=2)
