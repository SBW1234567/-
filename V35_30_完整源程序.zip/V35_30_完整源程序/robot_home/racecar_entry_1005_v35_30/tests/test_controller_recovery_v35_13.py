"""Actual stopped-recovery state machine with source samples and raw sweeps."""
from collections import deque
import math
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_stopped_curve_recovery_v35_13 as geometry

cm,core,ros=helpers.cm,helpers.core,helpers.ros


class ControllerRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.ros_time=1000.
        self.clock=patch.object(cm.time,'monotonic',side_effect=lambda:self.now).start()
        self.addCleanup(patch.stopall)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        c=self.c;c.phase=c.ORBIT_CONE_1;c.curve_curvature_gain=6.
        path=geometry.legacy_core.plan_entry_path(geometry.PLAN_START)
        c.curve_follower=geometry.follower_at_stop(path)
        c.curve_locator.pose=geometry.STOP_POSE;c.curve_locator.time=100.;c.curve_locator.hits=3
        c.curve_pose_odom=geometry.STOP_POSE;c.curve_pose_odom_alignment='SCAN_ALIGNED'
        c.curve_control_prediction_enabled=True
        c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=round(self.ros_time*1e9)))
        c.curve_last_drive_time=98.5
        for source in (999.4,999.5,999.6,999.7,999.8):self.source(source)
        self.inputs()

    def source(self,t,pose=geometry.STOP_POSE):
        """Real callback input, laser pose converted back to RF2O base frame."""
        ns=round(t*1e9);x,y,h=pose
        msg=NS(header=NS(stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)),
            pose=NS(pose=NS(position=NS(x=x-.07*math.cos(h),y=y-.07*math.sin(h)),
                orientation=NS(x=0.,y=0.,z=math.sin(h/2),w=math.cos(h/2)))),
            twist=NS(twist=NS(linear=NS(x=0.),angular=NS(z=0.))))
        self.c.odom_callback(msg)

    def inputs(self,pose=geometry.STOP_POSE,stamp=None):
        c=self.c;scan=helpers.scan_at(pose)
        ns=round(self.ros_time*1e9) if stamp is None else stamp
        scan.header.stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)
        c.curve_scan=scan;c.curve_scan_stamp=ns
        c.curve_scan_time=c.last_lidar_time=c.rel_time=self.now
        c.rel_data=dict(body_clear=True)

    def advance_time(self,dt):
        self.now+=dt;self.ros_time+=dt
        for t in (self.ros_time-.4,self.ros_time-.3,self.ros_time-.2,self.ros_time-.1):
            # Do not invent a 20 ms RF2O source pair when only the fake control
            # clock advances a little; the real velocity gate needs >=35 ms.
            if t>=self.c.last_motion_stamp+.04-1e-9:self.source(t)
        self.inputs()

    def start_presteer(self):
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertIsNotNone(self.c.curve_recovery_state)
        return command

    def configure_moving_entry(self):
        """Replay a delayed-pose overshoot seen in the closed-loop pressure case.

        Source samples are real callbacks. The 50 ms-old ray cast comes from
        the independent physical pose, so prediction error cannot disappear by
        rendering a perfect scan at the controller's estimated pose.
        """
        c=self.c
        pose=(6.886007629137173,1.919476557587803,1.7867924709733205)
        physical=(6.930296591468803,1.9108456823996738,1.5440887537565922)
        c.curve_curvature_gain=5.
        path=core.plan_entry_path((4.523,.78,.025))
        f=c.curve_follower=core.PathFollower(path)
        f.index=min(range(len(path.samples)),key=lambda j:core.dist(path.samples[j],pose))
        f.progress=float(path.lengths[f.index])
        c.curve_odom_samples.clear();c.curve_motion_samples.clear();c.last_motion_stamp=0
        for stamp in (999.4,999.5,999.6,999.7,999.8,999.9):
            sample=c.curve_integrate_motion(pose,(.9,0.,.921),stamp-1000.)
            self.source(stamp,sample)
        c.curve_locator.pose=sample;c.curve_pose_odom=sample
        c.curve_last_drive_time=99.95;c.last_lane_angular=.10
        c.last_lane_command_time=99.95;c.curve_drive=.35
        scan_pose=c.curve_integrate_motion(physical,(.9,0.,.331),-.05)
        self.inputs(scan_pose,round(999.95*1e9))
        f.output=.10;f.response_output=.092;f.time=99.9;f.reprime=False;f.error=-.52
        return pose,physical

    def test_moving_blocked_feedback_can_use_fresh_actual_response_checked_arc(self):
        self.configure_moving_entry()
        self.assertFalse(self.c.curve_recovery_stopped(self.now))
        command=self.c.curve_command(self.now)
        self.assertGreater(command.linear.x,0.)
        self.assertIn(round(command.angular.z,2),(.28,.32))
        detail=self.c.curve_recovery_status
        self.assertEqual(detail['normal_sweep']['result'],'SWEPT_OBSTACLE')
        self.assertFalse(detail['preposition_required'])
        self.assertFalse(detail['stopped'])
        self.assertTrue(detail['arc_clear'])
        self.assertLess(detail['elapsed_s'],.60)

    def test_recovery_compute_time_integrates_previous_issued_steer_once(self):
        self.configure_moving_entry()
        c=self.c;f=c.curve_follower
        prior_target=f.output;prior_response=f.response_output
        # 100 ms since the preceding issue, followed by an 80 ms callback.
        # During this callback only the PREVIOUS .10 command has been issued;
        # the new .32 request cannot already have moved the servo.
        expected=prior_target+(prior_response-prior_target)*math.exp(-.18/f.response_tau)
        original=c.curve_check_sweep;charged=False
        def whole_callback(*args):
            nonlocal charged
            result=original(*args)
            if not charged:
                self.now+=.08;self.ros_time+=.08;charged=True
            return result
        with patch.object(c,'curve_check_sweep',side_effect=whole_callback):
            command=c.curve_command(100.)
        self.assertGreater(command.linear.x,0.)
        self.assertAlmostEqual(f.time,self.now)
        self.assertAlmostEqual(f.response_output,expected,places=7)
        self.assertLess(f.response_output,prior_target)
        self.assertAlmostEqual(c.curve_recovery_status['response_at_check'],
            prior_target+(prior_response-prior_target)*math.exp(-.10/f.response_tau),places=7)

    def test_moving_arc_requires_recent_positive_drive_and_fresh_source(self):
        for defect in ('drive','source','scan','fault','emergency'):
            with self.subTest(defect=defect):
                self.configure_moving_entry();c=self.c
                c.curve_recovery_state=None;c.route_fault='';c.lidar_emergency=False
                if defect=='drive':c.curve_last_drive_time=self.now-.36
                elif defect=='source':c.last_odom_time=self.now-c.curve_odom_max_age-.01
                elif defect=='scan':c.curve_scan_time=self.now-.36
                elif defect=='fault':c.route_fault='TEST_FAULT'
                else:c.lidar_emergency=True
                command=c.curve_command(self.now)
                self.assertEqual(command.linear.x,0.)
                self.assertIsNone(c.curve_recovery_state)

    def test_new_real_returns_block_all_moving_recovery_candidates(self):
        pose,_=self.configure_moving_entry();c=self.c
        scan_pose=c.curve_scan_pose(self.now,pose)
        for steer in (.24,.28,.32):
            samples=core.constant_steer_horizon(pose,steer,5.,distance=.935,
                speed=.9,initial_steer=.09655)
            x,y=core.local(samples[20],scan_pose)
            k=int(round((math.atan2(y,x)%(2*math.pi))/c.curve_scan.angle_increment))%len(c.curve_scan.ranges)
            c.curve_scan.ranges[k]=math.hypot(x,y)
        command=c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(command.angular.z,0.)
        self.assertIsNone(c.curve_recovery_state)

    def test_fresh_receipt_of_old_stationary_source_cannot_start_presteer(self):
        self.c.curve_last_drive_time=99.4
        self.assertFalse(self.c.curve_recovery_stopped(self.now))
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(command.angular.z,0.)
        self.assertIsNone(getattr(self.c,'curve_recovery_state',None))

    def test_real_stopped_source_window_allows_only_zero_motor_presteer(self):
        self.assertTrue(self.c.curve_recovery_stopped(self.now))
        self.start_presteer()
        self.assertEqual(self.c.curve_reason,'STOPPED_STEERING_PREPOSITION')

    def test_window_span_motion_and_receipt_freshness_are_required(self):
        original=list(self.c.curve_motion_samples)
        for defect in ('short','translation','yaw','receipt','source_age'):
            with self.subTest(defect=defect):
                c=self.c;c.curve_motion_samples=deque(original,maxlen=8);c.last_odom_time=self.now
                self.ros_time=1000.
                if defect=='short':c.curve_motion_samples=deque(original[-3:],maxlen=8)
                elif defect=='translation':
                    a=list(c.curve_motion_samples[0]);a[1]+=.041;c.curve_motion_samples[0]=tuple(a)
                elif defect=='yaw':
                    a=list(c.curve_motion_samples[0]);a[3]+=.101;c.curve_motion_samples[0]=tuple(a)
                elif defect=='receipt':c.last_odom_time=self.now-.36
                else:self.ros_time=1000.6
                self.assertFalse(c.curve_recovery_stopped(self.now))

    def test_elapsed_060_is_required_even_with_settled_response(self):
        self.start_presteer();self.advance_time(.599)
        self.c.curve_follower.response_output=.32
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)

    def test_elapsed_time_without_actual_response_clearance_never_authorizes_drive(self):
        self.start_presteer();self.advance_time(.61)
        f=self.c.curve_follower;f.response_output=0.;f.output=.32;f.time=self.now
        f.response_time=self.now  # A fresh physical estimate, independent of PID time.
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertFalse(self.c.curve_recovery_status['arc_clear'])

    def test_060_presteer_and_real_raw_clearance_can_resume_drive(self):
        self.start_presteer();self.advance_time(.61)
        command=self.c.curve_command(self.now)
        self.assertGreater(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertEqual(self.c.curve_reason,'CHECKED_ARC_RECOVERY')
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertGreater(self.c.curve_follower.response_output,.30)

    def test_weak_recorded_gain_is_correctly_rejected_at_logged_stop_pose(self):
        for gain in (4.,5.):
            with self.subTest(gain=gain):
                self.c.curve_curvature_gain=gain
                self.c.curve_recovery_state=None
                command=self.c.curve_command(self.now)
                self.assertEqual(command.linear.x,0.)
                self.assertEqual(command.angular.z,0.)
                self.assertEqual(self.c.curve_recovery_status['state'],'NO_CLEAR_ARC')

    def test_new_raw_obstacle_cannot_be_ignored_after_presteer(self):
        self.start_presteer();self.advance_time(.61)
        c=self.c;f=c.curve_follower;f.response_output=.32
        samples=core.constant_steer_horizon(geometry.STOP_POSE,.32,6.,initial_steer=.32)
        x,y=core.local(samples[16],geometry.STOP_POSE);distance=math.hypot(x,y)
        k=int(round((math.atan2(y,x)%(2*math.pi))/c.curve_scan.angle_increment))%len(c.curve_scan.ranges)
        c.curve_scan.ranges[k]=distance
        command=c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertFalse(c.curve_recovery_status.get('arc_clear',False))

    def test_stale_source_scan_or_body_block_never_resumes_drive(self):
        # Static body-envelope stops are an explicit debugging option. Real
        # emergency/source/raw-sweep gates remain mandatory in the default.
        self.c.curve_static_body_guard_enabled=True
        self.start_presteer();self.advance_time(.61)
        for defect in ('source','scan','body','emergency'):
            with self.subTest(defect=defect):
                c=self.c;self.inputs();c.last_odom_time=self.now;c.lidar_emergency=False
                if defect=='source':c.last_odom_time=self.now-1.
                elif defect=='scan':c.curve_scan_time=self.now-.36
                elif defect=='body':c.rel_data['body_clear']=False
                else:c.lidar_emergency=True
                self.assertEqual(c.curve_command(self.now).linear.x,0.)

    def test_default_static_body_diagnostic_does_not_block_checked_recovery(self):
        c=self.c
        self.assertFalse(c.curve_static_body_guard_enabled)
        c.rel_data['body_clear']=False
        self.start_presteer();self.advance_time(.61)
        c.rel_data['body_clear']=False
        command=c.curve_command(self.now)
        self.assertGreater(command.linear.x,0.,c.curve_reason)
        self.assertTrue(c.curve_recovery_status['arc_clear'])
        self.assertEqual(c.curve_reason,'CHECKED_ARC_RECOVERY')

    def test_fresh_receipt_with_expired_source_age_cannot_resume(self):
        self.start_presteer();self.advance_time(.61)
        # Match both clocks and the receipt clock sample, so rejection comes
        # from old source data rather than an artificial clock-jump detector.
        self.now+=1.;self.ros_time+=1.;self.inputs()
        self.c.last_odom_time=self.now
        self.c.curve_motion_clock_sample=(self.now,round(self.ros_time*1e9))
        self.assertEqual(self.c.curve_command(self.now).linear.x,0.)
        self.assertEqual(self.c.curve_motion_status['policy'],'SOURCE_PREDICTION_LIMIT')

    def test_route_fault_cannot_request_recovery_presteer_or_drive(self):
        self.c.route_fault='TEST_ROUTE_FAULT'
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(command.angular.z,0.)

    def test_computation_overrun_keeps_zero_propulsion(self):
        self.start_presteer();self.advance_time(.61)
        original=self.c.curve_check_sweep
        def slow(*args):
            result=original(*args)
            self.now+=.11;self.ros_time+=.11
            return result
        with patch.object(self.c,'curve_check_sweep',side_effect=slow):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)

    def test_presteer_dwell_starts_when_steering_is_first_issued(self):
        original=self.c.curve_check_sweep
        def search_cost(*args):
            result=original(*args)
            # Strong-first selection can finish after three checks. Keep
            # enough search cost to distinguish callback start from issue.
            self.now+=.06;self.ros_time+=.06
            return result
        with patch.object(self.c,'curve_check_sweep',side_effect=search_cost):
            command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(self.c.curve_recovery_state['started'],self.now)
        self.assertGreater(self.now,100.15)
        self.advance_time(.45)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertLess(self.c.curve_recovery_status['elapsed_s'],.60)

    def test_hard_stop_cannot_reuse_old_recovery_dwell(self):
        self.start_presteer();self.advance_time(.40)
        self.c.publish_stop()
        self.assertIsNone(self.c.curve_recovery_state)
        # A neutral request does not instantly centre the physical wheels.
        self.assertGreater(self.c.curve_follower.response_output,.30)
        self.assertEqual(self.c.curve_follower.output,0.)
        self.assertAlmostEqual(self.c.curve_follower.response_time,self.now)
        self.advance_time(.31)
        self.start_presteer()
        self.assertAlmostEqual(self.c.curve_recovery_state['started'],self.now)
        self.advance_time(.59)
        self.assertEqual(self.c.curve_command(self.now).linear.x,0.)
        self.advance_time(.02)
        self.assertGreater(self.c.curve_command(self.now).linear.x,0.)

    def test_long_pause_discards_state_and_short_pause_discards_clear_evidence(self):
        self.start_presteer();self.advance_time(.61)
        self.assertGreater(self.c.curve_command(self.now).linear.x,0.)
        state=self.c.curve_recovery_state
        state['clear_hits']=1;state['clear_stamp']=self.c.curve_scan_stamp-1
        started=state['started'];self.advance_time(.10)
        command=self.c.curve_pause_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertAlmostEqual(command.angular.z,.32)
        self.assertIs(self.c.curve_recovery_state,state)
        self.assertEqual(state['clear_hits'],0)
        self.assertEqual(state['clear_stamp'],self.c.curve_scan_stamp)
        self.assertEqual(state['started'],started)
        self.advance_time(.30)
        command=self.c.curve_pause_command(self.now)
        self.assertEqual(command.angular.z,0.)
        self.assertIsNone(self.c.curve_recovery_state)

    def test_moving_obstructed_arc_uses_full_neutral(self):
        self.start_presteer();self.advance_time(.61)
        self.assertGreater(self.c.curve_command(self.now).linear.x,0.)
        self.advance_time(.1)
        samples=core.constant_steer_horizon(geometry.STOP_POSE,.32,6.,initial_steer=.32)
        x,y=core.local(samples[16],geometry.STOP_POSE);distance=math.hypot(x,y)
        k=int(round((math.atan2(y,x)%(2*math.pi))/self.c.curve_scan.angle_increment))%len(self.c.curve_scan.ranges)
        self.c.curve_scan.ranges[k]=distance
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(command.angular.z,0.)

    def test_two_distinct_clear_scans_are_required_to_leave_held_arc(self):
        self.start_presteer();self.advance_time(.61)
        self.assertGreater(self.c.curve_command(self.now).linear.x,0.)
        # Pose/frame estimation is isolated here; the ray-cast scan and all
        # ordinary/constant future-body checks remain real implementations.
        pose=geometry.advance(geometry.STOP_POSE,1.,.32,1.,.30)
        with patch.object(self.c,'curve_pose_estimate',return_value=pose),patch.object(self.c,'curve_scan_pose',return_value=pose):
            self.advance_time(.10);self.inputs(pose)
            first_stamp=self.c.curve_scan_stamp
            self.assertGreater(self.c.curve_command(self.now).linear.x,0.)
            self.assertIsNotNone(self.c.curve_recovery_state)
            self.assertEqual(self.c.curve_recovery_state['clear_hits'],1)
            self.advance_time(.10);self.inputs(pose,first_stamp)
            self.c.curve_command(self.now)
            self.assertIsNotNone(self.c.curve_recovery_state)
            self.assertEqual(self.c.curve_recovery_state['clear_hits'],1)
            self.advance_time(.10);self.inputs(pose)
            self.assertGreater(self.c.curve_command(self.now).linear.x,0.)
            self.assertIsNone(self.c.curve_recovery_state)
            self.assertEqual(self.c.curve_recovery_status['state'],'NORMAL_PATH_CLEAR')


if __name__=='__main__':unittest.main(verbosity=2)
