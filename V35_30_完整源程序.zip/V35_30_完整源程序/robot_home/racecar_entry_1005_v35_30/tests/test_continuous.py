"""V35.9 recovery/continuity tests. Synthetic scans only; no ROS/hardware."""
import ast
from concurrent.futures import Future
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import numpy as np
import ros_stubs as ros

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS));sys.path.insert(0,str(PACKAGE))
import race_task_controller as cm
import race_curve_core as core

def scan_at(pose,n=720):
    angles=np.arange(n)*2*math.pi/n+pose[2]
    dirs=np.column_stack((np.cos(angles),np.sin(angles)))
    origin=np.asarray(pose[:2]);ranges=np.full(n,math.inf)
    for a,b in core.WALLS:
        v=np.asarray(b)-a;w=np.asarray(a)-origin
        cross=dirs[:,0]*v[1]-dirs[:,1]*v[0]
        safe=np.where(abs(cross)>1e-10,cross,1e-10)
        distance=(w[0]*v[1]-w[1]*v[0])/safe
        u=(w[0]*dirs[:,1]-w[1]*dirs[:,0])/safe
        ranges=np.minimum(ranges,np.where((abs(cross)>1e-10)&(distance>0)&(u>=0)&(u<=1),distance,math.inf))
    for cone in core.CONES:
        delta=np.asarray(cone)-origin;proj=dirs@delta
        disc=proj**2-(delta@delta-.12**2)
        distance=proj-np.sqrt(np.maximum(disc,0))
        ranges=np.minimum(ranges,np.where((disc>=0)&(distance>0),distance,math.inf))
    return types.SimpleNamespace(ranges=ranges.tolist(),angle_min=0.,angle_increment=2*math.pi/n,
        range_min=.05,range_max=12.,header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=100,nanosec=0)))

class ContinuousTests(unittest.TestCase):
    def setUp(self):
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True,
            bounded_heading_control=True,lane_parallel_band_enabled=True,lane_band_min_distance=.35,
            lane_band_max_distance=.5,side_distance_guard_enabled=False,side_steering_guard_enabled=False)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        # Float-only fixtures exercise observation/anchor bridging, not time prediction.
        self.c.curve_control_prediction_enabled=False
        self.c.phase=self.c.SEEK_CONE_1

    def observation(self,now=100.,pose=(4.8,.65,0.)):
        c=self.c;c.curve_locator.pose=pose;c.curve_locator.time=now;c.curve_locator.hits=1
        c.curve_pose_scan=scan_at(pose);c.curve_pose_stamp=int(now*1e9)
        c.curve_pose_odom=(0.,0.,0.)
        c.curve_odom_samples.append((now,0.,0.,0.))
        c.last_odom_time=now;c.last_motion_stamp=now

    def inputs(self,now):
        c=self.c;c.curve_scan=scan_at((4.8,.65,0.));c.curve_scan_stamp=int(now*1e9)
        c.curve_scan_time=c.rel_time=c.last_lidar_time=c.last_odom_time=now
        c.rel_stamp=c.curve_scan_stamp
        c.rel_data=dict(stamp_ns=c.rel_stamp,body_clear=True,front_coverage=1.,exit_path_front=3.,
            exit_path_coverage=0.,entry_side_coverage=0.,entry_side_clear=False,cones=[])

    def test_expired_locator_reseeds_and_tracks(self):
        pose=(4.8,.65,.08);scan=scan_at(pose)
        loc=core.WallLocalizer(True);loc.pose=(4.6,.65,.08);loc.time=90.;loc.yaw=.08;loc.hits=1
        result,accepted,_=core.register_scan(loc,scan,100.,.08,pose)
        self.assertTrue(accepted,result.reason)
        np.testing.assert_allclose(result.pose,pose,atol=.01)
        self.assertEqual(result.time,100.)

    def test_expired_locator_without_seed_cannot_authorize_motion(self):
        loc=core.WallLocalizer(True);loc.pose=(4.8,.65,0.);loc.time=90.;loc.hits=1
        self.assertFalse(loc.update(np.tile((1.,0.),(60,1)),100.,0.))
        self.assertEqual(loc.reason,'WAIT_FRESH_SEED');self.assertEqual(loc.time,90.)

    def test_se2_motion_is_relative_to_odom_heading(self):
        result=core.bridge_pose((5.,1.,0.),(0.,0.,math.pi/2),(0.,.4,math.pi/2+.1))
        np.testing.assert_allclose(result,(5.4,1.,.1),atol=1e-9)

    def test_odom_interpolation_wraps_yaw(self):
        samples=[(100.,0.,0.,math.radians(179)),(100.2,.2,0.,math.radians(-179))]
        result=core.interpolate_odom(samples,100.1)
        self.assertAlmostEqual(result[0],.1);self.assertAlmostEqual(abs(result[2]),math.pi)
        self.assertIsNone(core.interpolate_odom(samples,99.))

    def test_300ms_result_accepted_with_acquisition_alignment(self):
        c=self.c;self.observation();c.curve_pose_stamp=int(99.9e9);loc=core.WallLocalizer(True)
        loc.pose=(4.8,.65,0.);loc.time=100.;loc.hits=1;loc.reason='TRACKING'
        f=Future();f.set_result((loc,True,.30))
        c.curve_job=(f,scan_at(loc.pose),100.,int(100e9),c.curve_generation)
        c.curve_poll_registration(100.3)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertEqual(c.curve_locator.time,100.)

    def test_result_over_fit_budget_is_discarded(self):
        c=self.c;self.observation();old=c.curve_locator
        f=Future();f.set_result((core.WallLocalizer(True),True,.9))
        c.curve_job=(f,None,100.,int(101e9),c.curve_generation)
        c.curve_poll_registration(101.3)
        self.assertIs(c.curve_locator,old);self.assertEqual(c.curve_registration_status,'RESULT_TOO_OLD')

    def test_failed_fit_preserves_successful_pose_and_cones(self):
        c=self.c;self.observation();old=c.curve_locator;c.curve_tracks.hits=[2,3]
        bad=core.WallLocalizer(True);bad.reason='WALL_REGISTRATION_REJECTED'
        f=Future();f.set_result((bad,False,.2))
        c.curve_job=(f,None,100.,int(101e9),c.curve_generation)
        c.curve_poll_registration(100.2)
        self.assertIs(c.curve_locator,old);self.assertEqual(c.curve_tracks.hits,[2,3])

    def test_pose_is_propagated_without_refreshing_observation_time(self):
        c=self.c;self.observation();c.curve_odom_samples.append((100.5,.3,0.,.1));c.last_odom_time=100.5
        result=c.curve_pose_estimate(100.5)
        np.testing.assert_allclose(result,(5.1,.65,.1),atol=1e-9)
        self.assertEqual(c.curve_locator.time,100.)
        self.assertIsNone(c.curve_pose_estimate(100.+c.curve_pose_ttl+.01))

    def test_prediction_distance_and_missing_odom_are_bounded(self):
        c=self.c;self.observation();c.curve_odom_samples.append((100.3,c.curve_prediction_distance+.01,0.,0.));c.last_odom_time=100.3
        self.assertIsNone(c.curve_pose_estimate(100.3))
        c.curve_odom_samples[-1]=(100.3,.2,0.,0.)
        self.assertIsNone(c.curve_pose_estimate(101.2))

    def test_one_hit_releases_pose_recovery_without_clearing_tracks(self):
        c=self.c;self.observation();c.entry_v34_turn_stop=c.entry_v33_braked=c.curve_pose_wait=True
        c.curve_tracks.hits=[2,0];c.last_odom_time=100.3
        c.curve_update_pose_wait(100.3)
        self.assertFalse(c.curve_pose_wait);self.assertEqual(c.curve_tracks.hits,[2,0])

    def test_stopped_gate_does_not_require_a_post_brake_fit(self):
        c=self.c;self.observation();self.inputs(100.3)
        c.entry_v33_braked=True;c.entry_v33_brake_since=99.9
        with patch.object(c,'entry_is_stopped',return_value=True):
            self.assertTrue(c.entry_gate_snapshot(100.3)['STOPPED'])
        with patch.object(c,'entry_is_stopped',return_value=False):
            self.assertFalse(c.entry_gate_snapshot(100.3)['STOPPED'])

    def test_entry_side_missing_is_not_an_independent_stop(self):
        self.inputs(100.)
        self.assertEqual(self.c.entry_v33_safety_reason(100.),'')
        self.c.rel_data['body_clear']=False
        self.assertEqual(self.c.entry_v33_safety_reason(100.),'')
        self.c.curve_static_body_guard_enabled=True
        self.assertEqual(self.c.entry_v33_safety_reason(100.),'REL_BODY_OBSTRUCTION')

    def test_curve_sensor_readiness_does_not_depend_on_old_camera(self):
        self.inputs(100.)
        self.assertTrue(self.c.sensors_ready(100.))
        self.c.phase=self.c.APPROACH_CROSSWALK
        self.assertFalse(self.c.sensors_ready(100.))

    def test_missing_rays_use_live_raw_scan_and_recover(self):
        c=self.c;self.inputs(100.);c.last_yaw=0.;samples=[(0.,0.,0.)]
        with patch.object(cm,'scan_hits_body',return_value=False),patch.object(cm,'scan_observes_body',return_value=(False,'SWEPT_UNKNOWN')):
            self.assertTrue(c.curve_check_sweep(c.curve_scan,(0.,0.,0.),samples,100.)[0])
            self.inputs(100.5)
            self.assertTrue(c.curve_check_sweep(c.curve_scan,(0.,0.,0.),samples,100.5)[0])
            c.curve_scan.ranges=[math.inf]*720
            self.assertFalse(c.curve_check_sweep(c.curve_scan,(0.,0.,0.),samples,100.5)[0])
        with patch.object(cm,'scan_hits_body',return_value=False),patch.object(cm,'scan_observes_body',return_value=(True,'CLEAR')):
            self.inputs(100.6);c.curve_check_sweep(c.curve_scan,(0.,0.,0.),samples,100.6)
            self.inputs(100.7);c.curve_check_sweep(c.curve_scan,(0.,0.,0.),samples,100.7)
        self.assertIsNone(c.curve_sweep_unknown_since)

    def test_unknown_grace_cannot_hide_real_obstacle_or_motion_limit(self):
        c=self.c;self.inputs(100.);c.last_yaw=0.
        scan=c.curve_scan;scan.ranges=[math.inf]*720;scan.ranges[0]=.5
        self.assertTrue(core.scan_hits_body(scan,(0.,0.,0.),[(.4,0.,0.)]))
        self.assertEqual(c.curve_check_sweep(scan,(0.,0.,0.),[(.4,0.,0.)],100.),(False,'SWEPT_OBSTACLE'))
        with patch.object(cm,'scan_hits_body',return_value=False),patch.object(cm,'scan_observes_body',return_value=(False,'SWEPT_UNKNOWN')):
            c.curve_check_sweep(scan,(0.,0.,0.),[(0.,0.,0.)],100.)
            c.travel_distance=.21
            self.assertFalse(c.curve_check_sweep(scan,(0.,0.,0.),[(0.,0.,0.)],100.1)[0])

    def test_temporary_pause_resets_feedback_preserves_path_and_servo_response(self):
        c=self.c;path=core.plan_entry_path((5.08,.86,.075))
        f=core.PathFollower(path);c.curve_follower=f
        f.progress=2.5;f.time=f.response_time=99.9
        f.output=.20;f.response_output=.10;c.last_lane_angular=.20
        f.error=f.integral=f.derivative=.40
        with patch.object(cm.time,'monotonic',return_value=100.):c.publish_stop()
        at_stop=.20+(.10-.20)*math.exp(-.10/f.response_tau)
        self.assertAlmostEqual(f.response_output,at_stop)
        self.assertEqual((f.error,f.integral,f.derivative),(0.,0.,0.))
        self.assertTrue(f.reprime)
        with patch.object(cm.time,'monotonic',return_value=100.12):c.publish_stop()
        self.assertAlmostEqual(f.response_output,at_stop*math.exp(-.12/f.response_tau))
        self.assertGreater(f.response_output,0.)
        self.assertEqual(f.output,0.)
        self.assertEqual(f.progress,2.5);self.assertIs(f.path,path)
        self.assertTrue(all(cmd.linear.x==0. and cmd.angular.z==0.
                            for cmd in c.cmd_pub.messages[-2:]))

    def test_curve_pose_loss_and_body_pause_are_recoverable_without_clearing_other_faults(self):
        c=self.c;c.phase=c.ORBIT_CONE_1;c.curve_follower=object()
        self.assertTrue(c.entry_recoverable_stop('CURVE_POSE_UNCONFIRMED',100.))
        for reason in ('REL_BODY_OBSTRUCTION','REL_LIDAR_EMERGENCY','REL_BODY_CLEARING'):
            self.assertTrue(c.entry_recoverable_stop(reason,100.))
        self.assertEqual(c.route_fault,'')
        c.route_fault='ORBIT_1_WRONG_TURN_DIRECTION'
        self.assertFalse(c.entry_recoverable_stop('REL_BODY_OBSTRUCTION',100.))
        self.assertEqual(c.route_fault,'ORBIT_1_WRONG_TURN_DIRECTION')

    def test_still_predicate_and_straight_control_unchanged(self):
        def functions(path):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return {n.name:ast.dump(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
        old=functions(PACKAGE/'tests/baselines/controller_before_v35_20.py')
        new=functions(SCRIPTS/'race_task_controller.py')
        # V18 intentionally meters approach drive; shared steering and stop
        # predicates remain byte-for-byte AST equivalent to V16.
        for name in ('odom_is_still','centre_heading_command','bounded_corridor_request'):
            self.assertEqual(old[name],new[name],name)

    def test_real_entry_handoff_then_curve_command(self):
        c=self.c;pose=(5.2,.79,0.);self.observation(pose=pose);self.inputs(100.1)
        c.curve_scan=scan_at(pose);c.curve_pose_scan=c.curve_scan
        c.last_yaw=0.;c.last_odom_xy=(0.,0.);c.last_route_status_time=100.
        c.entry_v33_braked=c.entry_v34_turn_stop=c.entry_hold=True;c.entry_v33_brake_since=99.5
        c.crosswalk_clear_count=c.post_crosswalk_clear_frames
        c.curve_tracks.xy=list(core.CONES);c.curve_tracks.hits=[1,0];c.curve_tracks.seen=[100.,-1e9]
        c.entry_plan_anchor=dict(pose=pose,started=100.,checked=100.,odom=(0.,0.,0.),
            samples=cm.deque([(99.5,0.,0.,0.),(99.8,0.,0.,0.),(100.,0.,0.,0.)]),stamp=100.)
        path=core.plan_entry_path(pose)
        c.entry_plan_ready=(path,pose,core.CONES,100.,c.curve_generation)
        with patch.object(c,'entry_is_stopped',return_value=True),patch.object(cm.time,'monotonic',return_value=100.12):
            c.curve_update(100.1)
        self.assertEqual(c.phase,c.ENTER_OBSTACLES,c.curve_reason)
        self.assertIsNotNone(c.curve_follower);self.assertFalse(c.route_fault)
        with patch.object(cm.time,'monotonic',return_value=100.16):
            command=c.curve_command(100.16)
        self.assertGreater(command.linear.x,0.,c.curve_reason)
        self.assertFalse(c.route_fault)

    def test_same_scan_cone_pairing_survives_400ms_compute_delay(self):
        c=self.c;pose=(4.8,.65,0.);stamp=int(100e9)
        c.entry_pose_pairs.append((stamp,100.,pose))
        cone=(*core.local(core.CONES[0],pose),0.,.2,8)
        c.curve_features.append((stamp,100.,dict(cones=[cone])))
        c.curve_observe_clusters(100.4)
        self.assertEqual(c.entry_pair_reason,'MATCHED_SAME_SCAN')
        self.assertTrue(c.curve_tracks.ready(0,100.4))

    def test_source_gap_preserves_anchor_but_invalid_timestamp_still_stops(self):
        self.observation();self.inputs(100.1)
        c=self.c;c.last_motion_stamp=100.;c.last_odom_xy=(0.,0.);c.last_yaw=0.
        msg=types.SimpleNamespace(header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=100,nanosec=400000000)),
            pose=types.SimpleNamespace(pose=types.SimpleNamespace(position=types.SimpleNamespace(x=0.,y=0.),
            orientation=types.SimpleNamespace(x=0.,y=0.,z=0.,w=1.))))
        with patch.object(cm.time,'monotonic',return_value=100.4):c.odom_callback(msg)
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertEqual(c.curve_locator.time,100.)
        self.assertIsNone(c.curve_odom_at(int(100.2e9)))
        msg.header.stamp.nanosec=300000000
        with patch.object(cm.time,'monotonic',return_value=100.5):c.odom_callback(msg)
        self.assertEqual(c.last_odom_time,0.)
        self.assertIsNone(c.curve_pose_estimate(100.5))

    def test_two_cone_trajectory_replay_with_300ms_pose_delay(self):
        # Replay a collision-free synthetic trajectory. This checks controller
        # continuity/state transitions, not an unmeasured physical vehicle model.
        self.test_real_entry_handoff_then_curve_command()
        c=self.c;path=c.curve_follower.path;poses=path.samples[::3]
        phases=set();stops=[]
        for i,current in enumerate(poses):
            now=101.+i*.1;observed=tuple(poses[max(0,i-3)][:3]);pose=tuple(current[:3])
            c.curve_locator.pose=observed;c.curve_locator.time=now-.3;c.curve_locator.hits=1
            c.curve_pose_odom=observed;c.curve_odom_samples.append((now,*pose))
            self.inputs(now);c.curve_scan=scan_at(pose);c.last_yaw=pose[2]
            c.last_boundary_time=now;c.last_route_status_time=now
            c.travel_distance=float(path.lengths[min(i*3,len(path.lengths)-1)])
            with patch.object(cm.time,'monotonic',return_value=now),patch.object(c,'relative_upper_pair',return_value=True):
                c.curve_update(now)
                # The real control loop switches to lane/light control on
                # this transition and no longer calls the curve controller.
                if c.phase==c.SEEK_LIGHT:break
                command=c.curve_command(now)
            phases.add(c.phase)
            if command.linear.x==0.:stops.append((i,c.curve_sweep,c.curve_reason))
            self.assertFalse(c.route_fault,(i,c.route_fault))
            if c.phase==c.SEEK_LIGHT:break
        self.assertIn(c.ORBIT_CONE_1,phases);self.assertIn(c.ORBIT_CONE_2,phases)
        self.assertEqual(c.phase,c.SEEK_LIGHT,(c.phase,c.curve_reason))
        self.assertFalse(stops,stops[:5])

if __name__=='__main__':unittest.main(verbosity=2)
