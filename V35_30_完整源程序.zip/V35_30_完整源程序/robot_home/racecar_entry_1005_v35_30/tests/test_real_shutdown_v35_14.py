"""Run the delivered main() through valid and signal-closed ROS contexts.

The real controller is constructed with offline ROS interfaces. Its real
publish_stop and worker cleanup run; a context-aware publisher reproduces the
failure of publishing after ROS has already handled SIGINT.
"""
import unittest
from unittest.mock import patch

import test_continuous as helpers

cm,ros=helpers.cm,helpers.ros


class RealShutdownTests(unittest.TestCase):
    def run_shutdown(self,signal_closes_context):
        events=[];state={'ok':True};nodes=[]
        real_controller=cm.RaceTaskController
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,
            exit_continuous=True,entry_v32_enabled=True,entry_v33_enabled=True,
            entry_v34_enabled=True,dry_run=True)

        def construct():
            node=real_controller();nodes.append(node)
            close_workers=node.close_curve_worker
            self.addCleanup(close_workers)
            publisher=node.cmd_pub
            real_publish=publisher.publish

            def publish(message):
                if not state['ok']:
                    raise RuntimeError('publisher context is invalid after SIGINT')
                events.append('publish_stop');real_publish(message)

            def close():
                events.append('close_workers');close_workers()

            publisher.publish=publish
            node.close_curve_worker=close
            node.destroy_node=lambda:events.append('destroy_node')
            return node

        def spin(node):
            self.assertIs(node,nodes[0]);events.append('spin')
            if signal_closes_context:state['ok']=False
            raise KeyboardInterrupt()

        def shutdown():
            self.assertTrue(state['ok']);events.append('shutdown');state['ok']=False

        with patch.object(cm,'RaceTaskController',side_effect=construct), \
             patch.object(cm.rclpy,'init',side_effect=lambda **kw:events.append('init'),create=True), \
             patch.object(cm.rclpy,'spin',side_effect=spin,create=True), \
             patch.object(cm.rclpy,'ok',side_effect=lambda:state['ok'],create=True), \
             patch.object(cm.rclpy,'shutdown',side_effect=shutdown,create=True):
            cm.main(args=[])
        return nodes[0],events,state

    def test_signal_closed_context_skips_publish_but_still_cleans_up(self):
        node,events,state=self.run_shutdown(signal_closes_context=True)
        self.assertEqual(events,['init','spin','close_workers','destroy_node'])
        self.assertEqual(node.cmd_pub.messages,[])
        self.assertFalse(state['ok'])

    def test_valid_context_publishes_zero_before_cleanup_and_shutdown(self):
        node,events,state=self.run_shutdown(signal_closes_context=False)
        self.assertEqual(events,['init','spin','publish_stop','close_workers','destroy_node','shutdown'])
        self.assertEqual(len(node.cmd_pub.messages),1)
        command=node.cmd_pub.messages[0]
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(command.angular.z,0.)
        self.assertFalse(state['ok'])


if __name__=='__main__':unittest.main(verbosity=2)
