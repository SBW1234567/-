"""Delayed source pairing with bounded scan observations, no ROS/hardware."""
import ast
from pathlib import Path
import math
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_registration_recovery as fixtures

cm, core = fixtures.cm, fixtures.core


class RegistrationLatencyTests(unittest.TestCase):
    def setUp(self):
        fixtures.RegistrationRecoveryTests.setUp(self)
        self.now = 100.
        self.clock = patch.object(cm.time, 'monotonic', side_effect=lambda: self.now)
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.c.get_clock = lambda: NS(now=lambda: NS(nanoseconds=round((900. + self.now) * 1e9)))

    def scan(self, stamp, pose=(5.24, .79, 0.)):
        return fixtures.RegistrationRecoveryTests.scan(self, stamp, pose)

    def source(self, stamp, laser_x=.04):
        ns = round(stamp * 1e9)
        msg = NS(header=NS(stamp=NS(sec=ns // 1000000000, nanosec=ns % 1000000000)),
                 pose=NS(pose=NS(position=NS(x=laser_x - .07, y=0.),
                     orientation=NS(x=0., y=0., z=0., w=1.))),
                 twist=NS(twist=NS(linear=NS(x=.1), angular=NS(z=0.))))
        self.c.odom_callback(msg)

    def test_continuous_eight_tenths_delay_repeatedly_pairs_latest_available(self):
        c = self.c
        for i in range(1, 26):
            offset = i / 10.
            self.now = 100. + offset
            if self.worker.jobs and not self.worker.jobs[-1][0].done():
                self.worker.complete()
                c.curve_poll_registration(self.now)
            c.curve_scan_callback(self.scan(1000. + offset, (5.2 + .1 * offset, .79, 0.)))
            if i >= 9:
                self.source(1000. + offset - .8, .1 * (offset - .8))
            self.assertLessEqual(sum(not f.done() for f, _, _ in self.worker.jobs), 1)
            self.assertLessEqual(len(c.curve_registration_scans), 16)
        self.assertGreaterEqual(len(self.worker.jobs), 4)
        submitted_receipts = [args[2] for _, _, args in self.worker.jobs]
        self.assertEqual(submitted_receipts, sorted(submitted_receipts))
        self.assertGreater(c.curve_pose_stamp, round(1001.1e9))
        self.assertLessEqual(self.now - c.curve_locator.time, 1.2)
        self.assertEqual(c.curve_pose_odom_alignment, 'SCAN_ALIGNED')
        # Accepted observation time is its receipt, not fit completion time.
        self.assertIn(c.curve_locator.time, submitted_receipts)
        self.assertAlmostEqual(c.curve_fit_result_ttl, 1.2)

    def test_old_point_three_five_deadline_no_longer_starves_real_pair(self):
        c = self.c
        self.now = 100.3
        c.curve_scan_callback(self.scan(1000.3))
        self.now = 101.1
        self.source(1000.3)
        self.assertEqual(len(self.worker.jobs), 1)
        self.assertEqual(c.curve_job[3], round(1000.3e9))
        self.assertEqual(c.curve_job[2], 100.3)
        self.assertEqual(c.curve_job_odom[2], (.04, 0., 0.))

    def test_single_sided_nearby_odom_cannot_be_historical_pair(self):
        c = self.c
        self.now = 100.1
        with patch.object(c, 'odom_is_still', return_value=False), patch.object(c, 'entry_is_stopped', return_value=False):
            c.curve_scan_callback(self.scan(1000.1))
            self.assertIsNotNone(c.curve_odom_at(round(1000.1e9)))  # Old nearest rule.
            self.assertIsNone(c.curve_select_registration_scan(self.now))
            self.assertEqual(len(self.worker.jobs), 0)
            self.now = 100.4
            self.source(1000.2, .08)
        self.assertEqual(len(self.worker.jobs), 1)
        self.assertEqual(c.curve_job_odom[2], (.04, 0., 0.))

    def test_unobserved_large_gap_is_not_filled_by_prediction(self):
        c = self.c
        self.now = 100.2
        with patch.object(c, 'odom_is_still', return_value=False), patch.object(c, 'entry_is_stopped', return_value=False):
            c.curve_scan_callback(self.scan(1000.2))
            c.curve_odom_samples.append((1000.4, .08, 0., 0.))
            self.now = 100.5
            c.curve_poll_registration(self.now)
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertEqual(len(self.worker.jobs), 0)

    def test_newest_strict_pair_wins_without_chasing_newer_unpaired_scan(self):
        c = self.c
        for stamp in (1000.1, 1000.2, 1000.3, 1000.4):
            c.curve_remember_registration_scan(self.scan(stamp), stamp - 900., round(stamp * 1e9))
        c.curve_odom_samples.append((1000.2, .04, 0., 0.))
        self.now = 100.9
        selected = c.curve_select_registration_scan(self.now)
        self.assertEqual(selected[2], round(1000.2e9))
        self.assertAlmostEqual(selected[1], 100.2)
        self.assertEqual(c.curve_registration_pair_status['history_count'], 4)

    def test_repeated_retry_never_renews_original_receipt(self):
        c = self.c
        original = self.scan(1000.3)
        c.curve_remember_registration_scan(original, 100.3, round(1000.3e9))
        c.curve_remember_registration_scan(original, 101.1, round(1000.3e9))
        self.assertEqual(len(c.curve_registration_scans), 1)
        self.assertEqual(c.curve_registration_scans[0][1], 100.3)
        self.now = 101.401
        c.curve_odom_samples.append((1000.3, .04, 0., 0.))
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertFalse(c.curve_registration_scans)

    def test_history_has_count_and_receipt_bounds_without_extra_workers(self):
        c = self.c
        for i in range(100):
            self.now = 100.01 + i * .01
            stamp = round((900. + self.now) * 1e9)
            c.curve_remember_registration_scan(self.scan(900. + self.now), self.now, stamp)
            self.assertLessEqual(len(c.curve_registration_scans), 16)
        self.assertEqual(len(c.curve_registration_scans), 16)
        self.assertEqual(len(self.worker.jobs), 0)
        self.now += 1.11
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertFalse(c.curve_registration_scans)

    def test_history_drops_generation_phase_and_replayed_observations(self):
        c = self.c
        c.curve_remember_registration_scan(self.scan(1000.1), 100.1, round(1000.1e9))
        c.curve_remember_registration_scan(self.scan(1000.), 100.2, round(1000.e9))
        self.assertEqual(len(c.curve_registration_scans), 1)
        self.now = 100.3
        c.curve_generation += 1
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertFalse(c.curve_registration_scans)
        c.curve_remember_registration_scan(self.scan(1000.2), 100.2, round(1000.2e9))
        c.phase = c.SEEK_LIGHT
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertFalse(c.curve_registration_scans)

    def test_reset_clears_history_without_renewing_old_anchor(self):
        c = self.c
        c.curve_remember_registration_scan(self.scan(1000.1), 100.1, round(1000.1e9))
        c.curve_reset_entry_pose()
        self.assertFalse(c.curve_registration_scans)
        self.assertIsNone(c.curve_registration_pending)
        self.assertIsNone(c.curve_locator.pose)

    def test_future_source_or_negative_receipt_age_never_matches(self):
        c = self.c
        c.curve_odom_samples.append((1000.2, .04, 0., 0.))
        c.curve_remember_registration_scan(self.scan(1000.2), 100., round(1000.2e9))
        self.now = 100.1  # ROS clock is 1000.1; even an odom pair is in future.
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.now = 99.9
        self.assertIsNone(c.curve_select_registration_scan(self.now))
        self.assertFalse(c.curve_registration_scans)

    def test_slow_worker_does_not_expand_existing_result_deadline(self):
        c = self.c
        self.now = 100.3
        c.curve_scan_callback(self.scan(1000.3))
        self.now = 101.1
        self.source(1000.3)
        old = c.curve_locator
        self.worker.complete()
        self.now = 101.501
        with patch.object(c, 'odom_is_still', return_value=False), patch.object(c, 'entry_is_stopped', return_value=False):
            c.curve_poll_registration(self.now)
        self.assertIs(c.curve_locator, old)
        self.assertEqual(c.curve_registration_status, 'RESULT_TOO_OLD')

    def test_delayed_pair_does_not_refresh_live_raw_scan_or_command_evidence(self):
        c = self.c
        self.now = 100.3
        c.curve_scan_callback(self.scan(1000.3))
        raw_receipt = c.curve_scan_time
        self.now = 101.1
        self.source(1000.3)
        self.worker.complete()
        self.now = 101.15
        c.curve_poll_registration(self.now)
        self.assertEqual(c.curve_scan_time, raw_receipt)
        c.curve_update_scan_wait(self.now)
        self.assertTrue(c.curve_scan_wait)
        self.assertEqual(c.curve_locator.time, 100.3)
        self.assertEqual(c.curve_prediction_max_time, .95)
        self.assertEqual(c.curve_prediction_max_distance, .80)

    def test_captured_strict_anchor_cannot_be_replaced_by_later_nearest_pose(self):
        c = self.c
        self.now = 100.3
        c.curve_scan_callback(self.scan(1000.3))
        self.now = 101.1
        self.source(1000.3)
        self.worker.complete()
        self.now = 101.15
        # Simulate history rollover and a different one-sided fallback result.
        c.curve_odom_samples.clear()
        c.curve_odom_samples.append((1000.5, .20, 0., 0.))
        with patch.object(c, 'curve_odom_at', return_value=(99., 99., 2.)):
            c.curve_poll_registration(self.now)
        self.assertEqual(c.curve_pose_odom, (.04, 0., 0.))
        self.assertEqual(c.curve_pose_odom_stamp, round(1000.3e9))
        self.assertEqual(c.curve_locator.time, 100.3)
        self.assertEqual(c.curve_registration_pair_status['last_applied']['scan_stamp'], round(1000.3e9))
        self.assertEqual(c.curve_registration_pair_status['last_applied']['captured_odom_anchor'], [.04, 0., 0.])
        # The paired old anchor can propagate through NEW actual odometry.
        c.last_odom_time = self.now
        estimate = c.curve_pose_estimate(self.now)
        self.assertAlmostEqual(estimate[0], 5.40, places=2)

    def test_missing_strict_job_anchor_is_not_reconstructed_from_nearest(self):
        c = self.c
        candidate = (c.curve_locator, self.scan(1000.3), 100.3,
                     round(1000.3e9), c.curve_generation, None, True)
        self.now = 100.5
        with patch.object(c, 'curve_odom_at', return_value=(9., 9., 0.)):
            self.assertEqual(c.curve_pair_registration(candidate, self.now), 'DROP')
        self.assertEqual(c.curve_registration_status, 'STRICT_PAIR_MISSING')
        self.assertEqual(c.curve_pose_odom, (0., 0., 0.))

    def test_pre_handoff_keeps_original_point_three_five_deadline(self):
        c = self.c
        c.curve_follower = None
        c.phase = c.SEEK_CONE_1
        self.now = 100.3
        c.curve_submit_registration(self.scan(1000.3), 100.3, round(1000.3e9))
        self.assertFalse(c.curve_registration_scans)
        c.curve_odom_samples.append((1000.3, .04, 0., 0.))
        self.now = 100.651
        c.curve_poll_registration(self.now)
        self.assertEqual(len(self.worker.jobs), 0)
        self.assertEqual(c.curve_registration_submit_status, 'SCAN_RETRY_EXPIRED')

    def test_predictive_command_and_initial_vision_methods_unchanged(self):
        package = Path(__file__).resolve().parents[1]
        def methods(path):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            cls = next(n for n in tree.body if isinstance(n, ast.ClassDef))
            return {n.name: ast.dump(n) for n in cls.body if isinstance(n, ast.FunctionDef)}
        before = methods(package / 'rollback/src/racecar/scripts/race_task_controller.py')
        after = methods(package / 'payload/src/racecar/scripts/race_task_controller.py')
        # V26 changes only the explicit historical-scan bridge in
        # curve_motion_at. Its default branch is compared with fixed V25 in
        # test_motion_continuity_v35_26; the V26 AST scope guards that method.
        for name in ('curve_pose_estimate', 'curve_update_scan_wait',
                     'curve_registration_stopped_anchor',
                     'vision_callback', 'approach_crosswalk_command', 'sensors_ready'):
            with self.subTest(method=name):
                self.assertEqual(before[name], after[name])


if __name__ == '__main__':
    unittest.main(verbosity=2)
