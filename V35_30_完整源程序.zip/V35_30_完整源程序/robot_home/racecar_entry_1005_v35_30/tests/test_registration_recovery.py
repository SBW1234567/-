"""Delayed RF2O/scan ordering and post-handoff registration recovery."""
from concurrent.futures import Future
import math
import unittest
from unittest.mock import patch

import test_continuous as helpers

cm=helpers.cm
core=helpers.core
ros=helpers.ros


class ControlledExecutor:
    """A worker whose completion is controlled separately from callbacks."""
    def __init__(self):self.jobs=[]
    def submit(self,function,*args):
        future=Future();self.jobs.append((future,function,args));return future
    def complete(self,index=-1):
        future,function,args=self.jobs[index]
        future.set_result(function(*args))
    def shutdown(self,**kwargs):pass


class RegistrationRecoveryTests(unittest.TestCase):
    def setUp(self):
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        # This fixture tests real-source registration, without a ROS clock.
        self.c.curve_control_prediction_enabled=False
        self.c.curve_executor.shutdown(wait=True)
        self.worker=ControlledExecutor();self.c.curve_executor=self.worker
        self.c.phase=self.c.ENTER_OBSTACLES;self.c.curve_follower=object()
        self.c.last_yaw=0.;self.c.last_odom_time=100.
        self.c.curve_locator.pose=(5.20,.79,0.)
        self.c.curve_locator.time=100.;self.c.curve_locator.yaw=0.
        self.c.curve_locator.hits=1;self.c.curve_pose_stamp=int(1000.e9)
        self.c.curve_pose_odom=(0.,0.,0.)
        self.c.curve_odom_samples.append((1000.,0.,0.,0.))

    def scan(self,stamp,pose=(5.24,.79,0.)):
        result=helpers.scan_at(pose)
        ns=round(stamp*1e9)
        result.header.stamp.sec=ns//1000000000
        result.header.stamp.nanosec=ns%1000000000
        return result

    def test_faster_scans_do_not_starve_delayed_odom_after_handoff(self):
        c=self.c
        with patch.object(c,'observe_departure_corridor') as unused_fit:
            with patch.object(cm.time,'monotonic',return_value=100.30):
                c.curve_scan_callback(self.scan(1000.30))
            self.assertEqual(c.curve_registration_submit_status,'WAIT_SCAN_ODOM')
            with patch.object(cm.time,'monotonic',return_value=100.40):
                c.curve_scan_callback(self.scan(1000.40))
            unused_fit.assert_not_called()
        self.assertEqual(c.curve_registration_pending[2],round(1000.30e9))
        self.assertFalse(self.worker.jobs)
        # RF2O publishes the source-stamped odom 220 ms after scan receipt.
        c.curve_odom_samples.append((1000.30,.04,0.,0.));c.last_odom_time=100.52
        with patch.object(cm.time,'monotonic',return_value=100.53):
            c.curve_poll_registration(100.53)
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_job[3],round(1000.30e9))
        self.worker.complete()
        with patch.object(cm.time,'monotonic',return_value=100.60):
            c.curve_poll_registration(100.60)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertEqual(c.curve_locator.time,100.30)
        self.assertEqual(c.curve_pose_stamp,round(1000.30e9))
        self.assertAlmostEqual(c.curve_locator.pose[0],5.24,places=2)
        self.assertIsNotNone(c.curve_pose_estimate(100.60))

    def test_late_odom_backfills_only_original_observation_anchor(self):
        c=self.c;c.curve_pose_odom=None
        c.curve_odom_samples.append((1000.20,.08,0.,.10))
        with patch.object(cm.time,'monotonic',return_value=100.20):
            result=c.curve_registration_seed(round(1000.20e9))
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertAlmostEqual(result[0],5.28)
        self.assertAlmostEqual(result[2],.10)
        self.assertEqual(c.curve_locator.time,100.)
        self.assertEqual(c.curve_pose_stamp,int(1000.e9))

    def test_stopped_missing_history_can_initialize_new_measured_fit(self):
        c=self.c;c.curve_pose_odom=None;c.curve_pose_stamp=int(979.e9)
        c.curve_locator.time=79.
        self.assertIsNone(c.curve_pose_estimate(100.10))
        c.curve_odom_samples.clear();c.curve_odom_samples.append((1000.10,.05,0.,0.))
        c.last_odom_time=100.10
        with patch.object(c,'odom_is_still',return_value=True),patch.object(cm.time,'monotonic',return_value=100.10):
            c.curve_submit_registration(self.scan(1000.10,(5.22,.79,0.)),100.10,round(1000.10e9))
        self.assertEqual(len(self.worker.jobs),1)
        # A seed cannot refresh the old pose or permit movement before fitting.
        self.assertEqual(c.curve_locator.time,79.)
        self.assertIsNone(c.curve_pose_estimate(100.15))
        self.worker.complete()
        with patch.object(cm.time,'monotonic',return_value=100.20):
            c.curve_poll_registration(100.20)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertEqual(c.curve_locator.time,100.10)
        self.assertIsNotNone(c.curve_pose_estimate(100.20))

    def test_missing_history_while_moving_waits_for_real_seed(self):
        c=self.c;c.curve_pose_odom=None;c.curve_pose_stamp=int(979.e9)
        c.curve_locator.time=79.
        c.curve_odom_samples.clear();c.curve_odom_samples.append((1000.10,.05,0.,0.))
        c.last_odom_time=100.10
        with patch.object(c,'odom_is_still',return_value=False),patch.object(cm.time,'monotonic',return_value=100.10):
            c.curve_submit_registration(self.scan(1000.10),100.10,round(1000.10e9))
        self.assertFalse(self.worker.jobs)
        self.assertEqual(c.curve_registration_submit_status,'WAIT_TRACKING_SEED')
        self.assertEqual(c.curve_locator.time,79.)
        self.assertIsNone(c.curve_pose_estimate(100.10))

    def test_stopped_reseed_measures_heading_without_odom_yaw_rejection(self):
        c=self.c;c.curve_pose_odom=None;c.curve_pose_stamp=int(979.e9)
        c.curve_locator.time=79.
        c.curve_odom_samples.clear()
        c.curve_odom_samples.append((1000.10,.05,0.,math.radians(16)))
        c.last_odom_time=100.10
        with patch.object(c,'odom_is_still',return_value=True),patch.object(cm.time,'monotonic',return_value=100.10):
            self.assertEqual(c.curve_registration_seed(round(1000.10e9)),c.curve_locator.pose)
            self.assertEqual(c.curve_locator.time,79.)
            c.curve_submit_registration(self.scan(1000.10,(5.22,.79,0.)),100.10,round(1000.10e9))
        self.assertEqual(len(self.worker.jobs),1)
        self.worker.complete()
        with patch.object(c,'odom_is_still',return_value=True),patch.object(cm.time,'monotonic',return_value=100.20):
            c.curve_poll_registration(100.20)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertEqual(c.curve_locator.time,100.10)
        self.assertAlmostEqual(c.curve_locator.pose[2],0.,places=2)

    def test_deferred_scan_expires_without_refreshing_source_age(self):
        c=self.c
        with patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_scan_callback(self.scan(1000.30))
        # V21 retains registration-only observations for delayed real pairing.
        # The original receipt still expires after the bounded 1.10 s window.
        c.curve_odom_samples.append((1000.30,.04,0.,0.));c.last_odom_time=101.40
        with patch.object(cm.time,'monotonic',return_value=101.401):
            c.curve_poll_registration(101.401)
        self.assertFalse(self.worker.jobs)
        self.assertIsNone(c.curve_registration_pending)
        self.assertEqual(c.curve_registration_submit_status,'SCAN_RETRY_EXPIRED')
        self.assertEqual(c.curve_locator.time,100.)

    def test_reset_generation_discards_pending_scan(self):
        c=self.c
        with patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_scan_callback(self.scan(1000.30))
        c.curve_generation+=1
        with patch.object(cm.time,'monotonic',return_value=100.40):
            c.curve_poll_registration(100.40)
        self.assertIsNone(c.curve_registration_pending)
        self.assertFalse(self.worker.jobs)

    def test_running_worker_holds_only_newest_pending_scan(self):
        c=self.c
        for offset in (.10,.20,.30):
            c.curve_odom_samples.append((1000.+offset,offset*.1,0.,0.))
            c.last_odom_time=100.+offset
            with patch.object(cm.time,'monotonic',return_value=100.+offset):
                c.curve_scan_callback(self.scan(1000.+offset,(5.20+offset*.1,.79,0.)))
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_registration_pending[2],round(1000.30e9))
        self.worker.complete()
        with patch.object(cm.time,'monotonic',return_value=100.45):
            c.curve_poll_registration(100.45)
        self.assertEqual(len(self.worker.jobs),2)
        self.assertEqual(c.curve_job[3],round(1000.30e9))
        self.assertEqual(c.curve_locator.time,100.10)

    def test_rejected_fit_preserves_observation_and_starts_pending_scan(self):
        c=self.c;old=c.curve_locator
        for offset in (.10,.20):
            c.curve_odom_samples.append((1000.+offset,offset*.1,0.,0.))
            c.last_odom_time=100.+offset
            with patch.object(cm.time,'monotonic',return_value=100.+offset):
                c.curve_scan_callback(self.scan(1000.+offset))
        failed=core.WallLocalizer(True);failed.reason='WALL_REGISTRATION_REJECTED'
        self.worker.jobs[0][0].set_result((failed,False,.15))
        with patch.object(cm.time,'monotonic',return_value=100.45):
            c.curve_poll_registration(100.45)
        self.assertIs(c.curve_locator,old)
        self.assertEqual(c.curve_registration_status,'WALL_REGISTRATION_REJECTED')
        self.assertEqual(len(self.worker.jobs),2)
        self.assertEqual(c.curve_job[3],round(1000.20e9))

    def test_worker_exception_still_allows_next_fresh_scan(self):
        c=self.c
        for offset in (.10,.20):
            c.curve_odom_samples.append((1000.+offset,offset*.1,0.,0.))
            c.last_odom_time=100.+offset
            with patch.object(cm.time,'monotonic',return_value=100.+offset):
                c.curve_scan_callback(self.scan(1000.+offset))
        self.worker.jobs[0][0].set_exception(ValueError('bad scan'))
        with patch.object(cm.time,'monotonic',return_value=100.45):
            c.curve_poll_registration(100.45)
        self.assertEqual(c.curve_registration_status,'ERROR_ValueError')
        self.assertEqual(len(self.worker.jobs),2)
        self.assertEqual(c.curve_job[3],round(1000.20e9))


if __name__=='__main__':unittest.main(verbosity=2)
