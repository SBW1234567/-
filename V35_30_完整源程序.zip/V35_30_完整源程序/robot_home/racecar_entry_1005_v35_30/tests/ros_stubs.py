"""Offline ROS interfaces; these never connect to ROS or hardware."""
import sys
import types

class Message:
    def __init__(self, data=None): self.data=data

class Twist:
    def __init__(self):
        self.linear=types.SimpleNamespace(x=0.)
        self.angular=types.SimpleNamespace(z=0.)

class Publisher:
    def __init__(self): self.messages=[]
    def publish(self, msg): self.messages.append(msg)

class FakeNode:
    overrides={}
    def __init__(self,*args): self.params={}
    def declare_parameter(self,name,default): self.params[name]=self.overrides.get(name,default)
    def get_parameter(self,name): return types.SimpleNamespace(value=self.params[name])
    def create_publisher(self,*args): return Publisher()
    def create_subscription(self,*args): pass
    def create_timer(self,*args): pass
    def get_logger(self):
        return types.SimpleNamespace(**{k:lambda *a,**kw:None for k in ('warn','info','error')})

def module(name,**values):
    result=types.ModuleType(name)
    result.__dict__.update(values)
    sys.modules[name]=result

module('rclpy')
module('rclpy.node',Node=FakeNode)
enum=types.SimpleNamespace(BEST_EFFORT=1,KEEP_LAST=1)
module('rclpy.qos',HistoryPolicy=enum,ReliabilityPolicy=enum,QoSProfile=lambda **kw:kw)
for name,values in {
    'geometry_msgs.msg':dict(Twist=Twist), 'nav_msgs.msg':dict(Odometry=Message),
    'sensor_msgs.msg':dict(LaserScan=Message),
    'std_msgs.msg':dict(Bool=Message,Float32MultiArray=Message,Int16MultiArray=Message,String=Message)
}.items():
    module(name.split('.')[0]);module(name,**values)
