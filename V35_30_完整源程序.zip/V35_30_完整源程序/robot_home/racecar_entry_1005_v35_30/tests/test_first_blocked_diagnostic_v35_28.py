"""Settled blocked arcs are a geometry wait, never a timeout permission.

The first-cone state tests deliberately retain the inherited V13 blocked PATH
and stationary source fixture: the new route is intended to avoid this pose,
whereas this diagnostic must remain correct if it nevertheless occurs. Raw
ray/body checking and current controller methods are real implementations.
Injected future returns represent a new obstacle, not replayed actual scans.
The separate V28 production-path tests validate prevention and continuity.
"""
import ast
import copy
import math
from pathlib import Path
from types import MethodType
import unittest

import test_controller_recovery_v35_13 as fixture
import test_second_recovery_v35_21 as second

cm,core=fixture.cm,fixture.core


def old_recovery(controller):
    path=Path(__file__).parent/'baselines/controller_before_v35_28.py'
    cls=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body
             if isinstance(n,ast.ClassDef))
    node=next(n for n in cls.body if isinstance(n,ast.FunctionDef)
              and n.name=='curve_obstacle_recovery')
    namespace=dict(cm.__dict__)
    exec(compile(ast.Module(body=[copy.deepcopy(node)],type_ignores=[]),str(path),'exec'),namespace)
    controller.curve_obstacle_recovery=MethodType(namespace[node.name],controller)


def future_return(controller,pose):
    state=controller.curve_recovery_state
    arc=core.constant_steer_horizon(pose,state['steer'],controller.curve_curvature_gain,
        distance=.65,initial_steer=state['steer'])
    x,y=core.local(arc[16],pose)
    scan=controller.curve_scan
    index=round((math.atan2(y,x)%(2*math.pi))/scan.angle_increment)%len(scan.ranges)
    scan.ranges[index]=math.hypot(x,y)


def snapshot(controller,command):
    return copy.deepcopy(dict(drive=command.linear.x,steer=command.angular.z,
        reason=controller.curve_reason,pause=controller.curve_pause_active,
        last_drive=controller.curve_last_drive_time,state=controller.curve_recovery_state,
        recovery=controller.curve_recovery_status,control=controller.curve_control_status))


def normalize_label(value):
    if isinstance(value,dict):return {k:normalize_label(v) for k,v in value.items()}
    if isinstance(value,list):return [normalize_label(v) for v in value]
    if isinstance(value,tuple):return tuple(normalize_label(v) for v in value)
    return 'STOPPED_STEERING_PREPOSITION' if value=='FIRST_CONE_ARC_BLOCKED' else value


class FirstBlockedDiagnosticV3528Tests(unittest.TestCase):
    source=fixture.ControllerRecoveryTests.source
    inputs=fixture.ControllerRecoveryTests.inputs
    advance_time=fixture.ControllerRecoveryTests.advance_time
    start_presteer=fixture.ControllerRecoveryTests.start_presteer

    def setUp(self):
        fixture.ControllerRecoveryTests.setUp(self)

    def blocked_tick(self,dt=.25):
        self.advance_time(dt)
        future_return(self.c,fixture.geometry.STOP_POSE)
        return self.c.curve_command(self.now)

    def test_settled_block_keeps_zero_and_steer_without_timeout_launch(self):
        self.start_presteer();state=self.c.curve_recovery_state;started=state['started']
        for index in range(21):
            command=self.blocked_tick(.7 if index==0 else .25)
            self.assertEqual(command.linear.x,0.)
            self.assertAlmostEqual(command.angular.z,.32)
            self.assertIs(self.c.curve_recovery_state,state)
            self.assertEqual(state['started'],started)
            self.assertEqual(self.c.curve_reason,'FIRST_CONE_ARC_BLOCKED')
            self.assertEqual(self.c.curve_recovery_status['raw_reason'],'SWEPT_OBSTACLE')
            self.assertTrue(self.c.curve_recovery_status['stopped'])
            self.assertFalse(self.c.curve_recovery_status['arc_clear'])
            self.assertFalse(self.c.curve_pause_active)
        self.assertGreater(self.now-started,5.)

    def test_before_dwell_expiry_remains_preposition_even_if_settled(self):
        self.start_presteer();self.advance_time(.599)
        f=self.c.curve_follower;f.response_output=.32;f.response_time=self.now
        future_return(self.c,fixture.geometry.STOP_POSE)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(self.c.curve_reason,'STOPPED_STEERING_PREPOSITION')
        self.assertFalse(self.c.curve_recovery_status['arc_clear'])

    def test_unsettled_response_remains_preposition_after_dwell(self):
        self.start_presteer();self.advance_time(.7)
        f=self.c.curve_follower;f.response_output=.28;f.response_time=self.now
        future_return(self.c,fixture.geometry.STOP_POSE)
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.assertEqual(self.c.curve_reason,'STOPPED_STEERING_PREPOSITION')
        self.assertAlmostEqual(self.c.curve_recovery_status['response_at_check'],.28)

    def test_stale_scan_cannot_release_but_new_fresh_clear_scan_can(self):
        self.start_presteer();self.blocked_tick(.7)
        self.advance_time(.1);self.c.curve_scan_time=self.now-.36
        command=self.c.curve_command(self.now)
        self.assertEqual(command.linear.x,0.)
        self.advance_time(.1)
        command=self.c.curve_command(self.now)
        self.assertGreater(command.linear.x,0.)
        self.assertTrue(self.c.curve_recovery_status['arc_clear'])
        self.assertEqual(self.c.curve_recovery_status['final_check_reason'],'')
        self.assertEqual(self.c.curve_reason,'CHECKED_ARC_RECOVERY')

    def test_first_outputs_and_state_match_v27_except_diagnostic_label(self):
        traces=[]
        for old in (False,True):
            if old:
                self.c.close_curve_worker();fixture.ControllerRecoveryTests.setUp(self)
                old_recovery(self.c)
            trace=[snapshot(self.c,self.start_presteer())]
            for dt in (.7,.25,2.):trace.append(snapshot(self.c,self.blocked_tick(dt)))
            self.advance_time(.1)
            trace.append(snapshot(self.c,self.c.curve_command(self.now)))
            traces.append(trace)
        self.assertEqual(normalize_label(traces[0]),traces[1])
        self.assertEqual(traces[0][1]['reason'],'FIRST_CONE_ARC_BLOCKED')
        self.assertEqual(traces[1][1]['reason'],'STOPPED_STEERING_PREPOSITION')

    def test_real_second_cone_recovery_matches_v27_without_label_change(self):
        traces=[]
        for old in (False,True):
            case=second.SecondRecoveryV3521Tests()
            try:
                case.setUp()
                if old:old_recovery(case.c)
                trace=[snapshot(case.c,case.c.curve_command(case.now))]
                self.assertTrue(case.c.curve_recovery_status['second_scope'])
                for index in range(9):
                    case.now+=.1;case.ros_time+=.1
                    case.source(case.ros_time,case.pose);case.fresh_scan(case.pose)
                    case.c.curve_locator.time=case.now
                    if index>=6:future_return(case.c,case.pose)
                    trace.append(snapshot(case.c,case.c.curve_command(case.now)))
                traces.append(trace)
            finally:case.doCleanups()
        self.assertEqual(traces[0],traces[1])
        self.assertNotIn('FIRST_CONE_ARC_BLOCKED',repr(traces[0]))


if __name__=='__main__':unittest.main(verbosity=2)
