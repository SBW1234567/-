"""Traffic events, callback ordering, and receipt freshness; no ROS/hardware.

The V19 CSV samples positive red at elapsed 72.374/.476 with receipt ages
.036/.061, implying distinct latest receipts 77 ms apart. It does not record
every intervening image. This fixture replays the observed positive events,
not an asserted full image sequence. The wire format has no capture stamp.
"""
from types import SimpleNamespace as NS
import unittest

import test_final_straight_v35_16 as fixture


class TrafficControlV3520Tests(unittest.TestCase):
    prepare_handoff=fixture.FinalStraightV3516Tests.prepare_handoff
    receive_laser_pose=fixture.FinalStraightV3516Tests.receive_laser_pose
    refresh_sensors=fixture.FinalStraightV3516Tests.refresh_sensors

    def setUp(self):
        fixture.FinalStraightV3516Tests.setUp(self)
        self.prepare_handoff()

    def advance_receipt(self,dt=.07):
        # Do not refresh last_vision_time here: only the actual callback can.
        self.now+=dt;self.source_now+=dt

    def receive(self,red=0,green=0,dt=.07):
        self.advance_receipt(dt)
        self.c.vision_callback(NS(data=[red,green,0,int(bool(red)),0]))

    def enter_red_wait(self):
        self.receive(red=1);self.receive(red=1)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)

    def test_default_red_two_green_four_and_receipt_gap(self):
        self.assertEqual(self.c.red_confirm_frames,2)
        self.assertEqual(self.c.green_confirm_frames,4)
        self.assertEqual(self.c.traffic_light_max_gap,.35)

    def test_recorded_two_distinct_red_receipts_brake_inside_second_callback(self):
        c=self.c;reference=c.final_straight_reference
        self.receive(red=1)
        self.assertEqual(c.phase,c.SEEK_LIGHT)
        self.assertFalse(c.cmd_pub.messages)
        self.receive(red=1,dt=.077)
        self.assertEqual(c.phase,c.RED_WAIT)
        self.assertEqual((c.cmd_pub.messages[-1].linear.x,c.cmd_pub.messages[-1].angular.z),(0.,0.))
        self.assertEqual(c.final_straight_reference,reference)
        self.assertEqual(c.traffic_light_status['state'],'RED_CONFIRMED_STOP')
        self.assertEqual(c.traffic_light_status['red_hits'],2)
        self.assertEqual(c.traffic_light_status['timestamp_policy'],'CALLBACK_RECEIPT')
        # A miss before the next control timer cannot erase confirmed red.
        self.receive();c.update_phase(self.now)
        self.assertEqual(c.phase,c.RED_WAIT)

    def test_one_red_or_red_miss_red_does_not_confirm(self):
        self.receive(red=1);self.receive();self.receive(red=1)
        self.c.update_phase(self.now)
        self.assertEqual(self.c.red_count,1)
        self.assertEqual(self.c.phase,self.c.SEEK_LIGHT)
        self.assertFalse(self.c.cmd_pub.messages)

    def test_sparse_red_does_not_accumulate(self):
        self.receive(red=1);self.receive(red=1,dt=.36)
        self.assertEqual(self.c.red_count,1)
        self.assertEqual(self.c.phase,self.c.SEEK_LIGHT)

    def test_nonadvancing_receipt_does_not_count_as_another_confirmation(self):
        self.receive(red=1);self.receive(red=1,dt=0.)
        self.assertEqual(self.c.red_count,1)
        self.assertEqual(self.c.phase,self.c.SEEK_LIGHT)

    def test_configured_four_red_also_latches_before_timer(self):
        self.c.red_confirm_frames=4
        for _ in range(3):self.receive(red=1)
        self.assertEqual(self.c.phase,self.c.SEEK_LIGHT)
        self.receive(red=1);self.receive()
        self.assertEqual(self.c.phase,self.c.RED_WAIT)

    def test_curve_red_is_not_cached_across_final_straight_handoff(self):
        c=self.c;c.phase='REL_UPPER_APPROACH'
        for _ in range(4):self.receive(red=1)
        self.assertEqual(c.phase,'REL_UPPER_APPROACH')
        self.assertEqual(c.red_count,0);self.assertFalse(c.cmd_pub.messages)
        c.set_phase(c.SEEK_LIGHT);c.update_phase(self.now)
        self.assertEqual(c.phase,c.SEEK_LIGHT)
        self.receive(red=1)
        self.assertEqual(c.phase,c.SEEK_LIGHT)
        self.receive(red=1)
        self.assertEqual(c.phase,c.RED_WAIT)

    def test_green_first_retains_required_red_then_green_sequence(self):
        for _ in range(8):self.receive(green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.SEEK_LIGHT)

    def test_four_fresh_green_release_and_preserve_the_fixed_straight_reference(self):
        self.enter_red_wait();c=self.c;reference=c.final_straight_reference
        for _ in range(3):self.receive(green=1);c.update_phase(self.now)
        self.assertEqual(c.phase,c.RED_WAIT)
        self.receive(green=1);c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)
        self.assertEqual(c.final_straight_reference,reference)
        self.assertEqual(c.traffic_light_status['state'],'GREEN_CONFIRMED')

    def test_green_positive_after_each_long_gap_never_releases(self):
        self.enter_red_wait()
        for _ in range(8):self.receive(green=1,dt=.36);self.c.update_phase(self.now)
        self.assertEqual(self.c.green_count,1)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)

    def test_one_missed_green_restarts_confirmation(self):
        self.enter_red_wait()
        for _ in range(3):self.receive(green=1)
        self.receive();self.receive(green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.green_count,1)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)

    def test_red_wins_even_when_detector_reports_both_lights(self):
        self.receive(red=1,green=1);self.receive(red=1,green=1)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        for _ in range(3):self.receive(green=1)
        self.receive(red=1,green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        self.assertEqual(self.c.green_count,0)
        self.assertEqual(self.c.traffic_light_status['state'],'RED_PRIORITY')

    def test_four_old_green_cannot_release_or_survive_unknown_stream_recovery(self):
        self.enter_red_wait()
        for _ in range(4):self.receive(green=1)
        self.advance_receipt(.36);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        self.assertEqual(self.c.green_count,0)
        self.assertEqual(self.c.traffic_light_status['state'],'WAIT_FRESH_GREEN')
        self.receive();self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        for _ in range(3):self.receive(green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        self.receive(green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.FINISH_APPROACH)

    def test_malformed_frame_clears_pending_green(self):
        self.enter_red_wait()
        for _ in range(4):self.receive(green=1)
        self.c.vision_callback(NS(data=[0,1]));self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        self.assertEqual(self.c.green_count,0)
        self.receive(green=1);self.c.update_phase(self.now)
        self.assertEqual(self.c.phase,self.c.RED_WAIT)
        self.assertEqual(self.c.green_count,1)

    def test_confirmed_red_wait_never_uses_lane_command(self):
        self.enter_red_wait()
        original=self.c.lane_command
        def forbidden():raise AssertionError('red wait requested driving')
        self.c.lane_command=forbidden
        try:self.c.control_loop()
        finally:self.c.lane_command=original
        self.assertEqual(self.c.cmd_pub.messages[-1].linear.x,0.)


if __name__=='__main__':unittest.main(verbosity=2)
