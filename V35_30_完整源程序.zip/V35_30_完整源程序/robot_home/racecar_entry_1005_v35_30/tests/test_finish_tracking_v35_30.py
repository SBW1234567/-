"""Current-ray endpoint tracking and physical closed-loop degradation tests.

These scans are raycast synthetic walls, not a reconstruction of the CSV's
unrecorded raw lidar. The physical model is also not an on-car calibration.
"""
import ast
from contextlib import contextmanager, ExitStack
import math
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers
import test_finish_parking_v35_22 as fixture
import test_finish_dynamics_v35_23 as dynamics
import test_finish_approach_v35_29 as approach

cm, core = helpers.cm, helpers.core
BASELINE = Path(__file__).resolve().parent/'baselines/controller_before_v35_30.py'


@contextmanager
def frozen_v29_parking():
    tree = ast.parse(BASELINE.read_text(encoding='utf-8'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'RaceTaskController')
    with ExitStack() as stack:
        for name in ('finish_parking_reset', 'finish_parking_observation',
                     'finish_parking_command', 'finish_parking_verified'):
            node = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
            namespace = dict(cm.__dict__)
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(BASELINE), 'exec'), namespace)
            stack.enter_context(patch.object(cm.RaceTaskController, name, namespace[name]))
        yield


def endpoint_scan(pose, *, end_x=8., tilt=0., partial=False, blank=False, obstacle=False):
    walls = [wall for wall in core.WALLS if wall != ((8., 0.), (8., 4.))]
    slope = math.tan(math.radians(tilt))
    walls.append(((end_x+slope*(3.05-3.55), 3.05),
                  (end_x+slope*(4.05-3.55), 4.05)))
    if obstacle:
        walls.append(((pose[0]+.30, 3.42), (pose[0]+.30, 3.68)))
    with patch.object(core, 'WALLS', walls):
        # Match the fixed radar view's 451-ray density rather than relying on
        # the more generous 720-ray default of the historical test helper.
        scan = helpers.scan_at(pose, n=451)
    if partial or blank:
        for i, r in enumerate(scan.ranges):
            if not math.isfinite(r):
                continue
            angle = scan.angle_min+i*scan.angle_increment+pose[2]
            x, y = r*math.cos(angle), r*math.sin(angle)
            if x > .20 and (blank or abs(y) > .245):
                scan.ranges[i] = math.inf
    return scan


def deliver_scan(case, scan, stamp):
    ns = round(stamp*1e9)
    scan.header.stamp = NS(sec=ns//1000000000, nanosec=ns%1000000000)
    case.c.curve_scan_callback(scan)
    front = min((r for i, r in enumerate(scan.ranges)
                 if abs(cm.normalize_angle(scan.angle_min+i*scan.angle_increment)) <= math.radians(25)),
                default=math.inf)
    case.c.front_clearance = case.c.boundary_front = min(3., front)


class FinishTrackingV3530Tests(unittest.TestCase):
    setUp = fixture.FinishParkingV3522Tests.setUp
    refresh_sensors = fixture.FinishParkingV3522Tests.refresh_sensors
    receive_laser_pose = fixture.FinishParkingV3522Tests.receive_laser_pose
    prepare = fixture.FinishParkingV3522Tests.prepare
    scan = fixture.FinishParkingV3522Tests.scan
    advance = fixture.FinishParkingV3522Tests.advance

    def step(self, dt=.10, *, pose=None, source_age=0., **scan_options):
        self.advance(dt)
        if pose is not None:
            self.pose = pose
        # Current odometry and older scans are independent data sources.
        self.receive_laser_pose(self.pose)
        scan = endpoint_scan(self.pose, **scan_options)
        deliver_scan(self, scan, self.source_now-source_age)
        command = self.c.lane_command()
        return command, dict(self.c.finish_parking_status)

    def acquire(self, x=6.7, yaw=0., **scan_options):
        self.prepare(x, yaw=yaw)
        self.c.curve_scan_stamp = 0
        results = [self.step(dt=.10, **scan_options) for _ in range(3)]
        self.assertFalse(results[0][1]['valid'])
        self.assertFalse(results[1][1]['valid'])
        self.assertTrue(results[2][1]['valid'], results[2][1])
        return results

    def test_initial_identity_requires_three_full_distinct_sources(self):
        self.prepare(6.7)
        self.c.curve_scan_stamp = 0
        for _ in range(4):
            cmd, status = self.step(partial=True)
            self.assertEqual(cmd.linear.x, 0.)
            self.assertFalse(status['valid'])
            self.assertIsNone(self.c.finish_parking['board_identity'])
        results = [self.step() for _ in range(3)]
        self.assertEqual([s['valid'] for _, s in results], [False, False, True])
        self.assertEqual(results[-1][1]['board_mode'], 'FULL')

    def test_alternating_partial_scans_continue_current_measurements(self):
        self.acquire(6.2)
        sources = []
        for i in range(20):
            command, status = self.step(pose=(self.pose[0]+.01, 3.55, 0.), partial=i%2 == 0)
            self.assertTrue(status['valid'], status)
            self.assertGreater(command.linear.x, 0., status)
            self.assertEqual(status['board_mode'], 'TRACKED_CURRENT_SCAN' if i%2 == 0 else 'FULL')
            self.assertAlmostEqual(status['raw_board_distance_m'], 8.-self.pose[0], delta=.006)
            sources.append(status['board_source_stamp'])
        self.assertTrue(all(b > a for a, b in zip(sources, sources[1:])))

    def test_partial_cannot_renew_identity_or_pollute_full_history(self):
        self.acquire()
        anchor = self.c.finish_parking['board_identity']['source_stamp']
        original_history = list(self.c.finish_parking['plane_history'])
        cmd, status = self.step(partial=True)
        self.assertTrue(status['valid'], status)
        self.assertEqual(self.c.finish_parking['board_identity']['source_stamp'], anchor)
        self.assertEqual(self.c.finish_parking['plane_history'], original_history)
        for _ in range(3):
            cmd, status = self.step(partial=True)
        self.assertEqual(cmd.linear.x, 0.)
        self.assertFalse(status['valid'])
        self.assertIsNone(self.c.finish_parking['board_identity'])

    def test_motion_budget_expires_before_time_budget(self):
        self.acquire()
        cmd, status = self.step(pose=(self.pose[0]+.16, 3.55, 0.), partial=True)
        self.assertEqual(cmd.linear.x, 0.)
        self.assertFalse(status['valid'])
        self.assertIsNone(self.c.finish_parking['board_identity'])

    def test_blank_scan_never_reuses_old_range(self):
        self.acquire()
        cmd, status = self.step(blank=True)
        self.assertEqual(cmd.linear.x, 0.)
        self.assertFalse(status['valid'])
        self.assertNotIn('raw_board_distance_m', status)
        cmd, status = self.step()
        self.assertTrue(status['valid'], status)
        self.assertEqual(status['board_mode'], 'FULL')

    def test_new_board_cannot_inherit_confirmation(self):
        self.acquire()
        cmd, status = self.step(end_x=7.8)
        self.assertEqual(cmd.linear.x, 0.)
        self.assertFalse(status['valid'])
        self.assertEqual(status['reason'], 'CONFIRM_ENDPOINT_BOARD')
        self.assertEqual(status['board_hits'], 1)

    def test_slowly_moving_full_board_cannot_chain_identity_forever(self):
        self.acquire()
        statuses = []
        for dx in (.03, .06, .09, .12):
            command, status = self.step(end_x=8.-dx)
            statuses.append((command.linear.x, status))
        self.assertTrue(any(not s['valid'] for _, s in statuses), statuses)
        self.assertEqual(statuses[-1][0], 0.)
        self.assertFalse(statuses[-1][1]['valid'])

    def test_old_scan_cannot_extend_partial_budget(self):
        self.acquire()
        self.step(partial=True)
        old_scan = self.c.curve_scan
        for _ in range(4):
            self.advance(.1)
            self.receive_laser_pose(self.pose)
            self.c.curve_scan_callback(old_scan)
            command = self.c.lane_command()
        self.assertEqual(command.linear.x, 0.)
        self.assertFalse(self.c.finish_parking_status['valid'])
        self.assertIsNone(self.c.finish_parking['board_identity'])

    def test_new_near_obstacle_is_not_removed_by_endpoint_association(self):
        self.acquire()
        command, status = self.step(partial=True, obstacle=True)
        self.assertLess(self.c.front_clearance, .32)
        self.assertEqual(command.linear.x, 0.)
        self.assertFalse(status['complete'])

    def test_full_scans_with_point_two_five_and_six_age_do_not_reconfirm_periodically(self):
        # Old scan poses must exist before the first delayed scan arrives.
        for age in (.25, .26):
            with self.subTest(source_age=age):
                self.prepare(6.7, delay=.30)
                self.c.curve_scan_stamp = 0
                results = [self.step(source_age=age) for _ in range(14)]
                usable = [s for _, s in results if s.get('valid')]
                self.assertGreaterEqual(len(usable), 8, results)
                first = next(i for i, (_, s) in enumerate(results) if s.get('valid'))
                for _, status in results[first:]:
                    self.assertTrue(status['valid'], status)
                    self.assertEqual(status['board_mode'], 'FULL')

    def test_lane_four_board_fourteen_far_can_advance_but_true_yaw_cannot(self):
        self.acquire(yaw=math.radians(-4), tilt=-10)
        command, status = self.step(tilt=-10)
        self.assertAlmostEqual(math.degrees(status['body_board_angle_rad']), -14, delta=1.)
        self.assertGreater(command.linear.x, 0., status)
        self.assertTrue(status['far_lane_aligned'])
        self.assertEqual(status['approach_heading_limit_rad'], math.radians(18))
        # A real lane-relative large yaw must still stop, not inherit tolerance.
        command, status = self.step(pose=(6.7, 3.55, math.radians(-14)))
        self.assertEqual(command.linear.x, 0.)

    def test_near_board_heading_limit_and_final_ten_degree_geometry_remain(self):
        self.acquire(x=7.1, yaw=math.radians(-4), tilt=-10)
        command, status = self.step(tilt=-10)
        self.assertEqual(command.linear.x, 0.)
        self.assertEqual(status['state'], 'PARK_HEADING_LIMIT')
        self.assertFalse(status['body_window_seen'])

    def test_partial_cannot_latch_body_or_verify_finished(self):
        self.acquire(x=7.44)
        self.c.finish_parking['body_window_seen'] = False
        command, status = self.step(partial=True)
        self.assertTrue(status['valid'], status)
        self.assertTrue(status['body_geometry_inside'])
        self.assertFalse(status['body_window_seen'])
        self.assertFalse(status['complete'])
        self.assertEqual(command.linear.x, 0.)
        self.c.finish_parking_status.update(complete=True, updated=self.now)
        with patch.object(self.c, 'finish_parking_settled', return_value=True):
            self.assertFalse(self.c.finish_parking_verified(self.now))

    def test_end_board_shift_keeps_eighty_centimetre_region_relative_to_board(self):
        # Both courses use 80cm before their actual board. No 50cm mode or
        # hard-coded 30cm correction enters production.
        for end_x in (8., 7.7):
            self.prepare(end_x-.50)
            self.c.curve_scan_stamp = 0
            results = [self.step(end_x=end_x) for _ in range(12)]
            self.assertTrue(results[-1][1]['complete'], results[-1][1])
            self.assertAlmostEqual(results[-1][1]['raw_board_distance_m'], .50, delta=.006)
            self.assertTrue(self.c.finish_parking_verified(self.now))


class FinishTrackingDynamicsV3530Tests(unittest.TestCase):
    comparisons = []
    traces = []

    def test_periodic_real_scan_degradation_reduces_drive_interruptions(self):
        results = []
        for baseline in (True, False):
            case = dynamics.FinishDynamicsV3523Tests()
            calls = {'n': 0, 'partial': 0}
            def noisy_scan(instance, position, stamp):
                calls['n'] += 1
                # Begin only after initial full-width identity. Restore full
                # coverage near the final region to demand strict stop proof.
                partial = calls['n'] > 6 and calls['n'] % 4 == 0 and position < 7.1
                calls['partial'] += int(partial)
                scan = endpoint_scan((position, 3.55, 0.), partial=partial)
                deliver_scan(instance, scan, stamp)
            try:
                case.setUp()
                with patch.object(dynamics.FinishDynamicsV3523Tests, 'delayed_scan', noisy_scan), \
                     patch.object(dynamics, 'MotorPlant', approach.LogCompatibleMotorPlant):
                    if baseline:
                        with frozen_v29_parking():
                            result = case.rollout('V29_periodic_current_scan', x=5.8,
                                scan_delay=.10, odom_delay=.15, duration=60., must_finish=False)
                    else:
                        result = case.rollout('V30_periodic_current_scan', x=5.8,
                            scan_delay=.10, odom_delay=.15, duration=60.)
                result['partial_scan_count'] = calls['partial']
                # Command segments are not physical stops. Count only a
                # >.10m/s -> <.03m/s -> >.10m/s sequence, excluding the final
                # stop that has no subsequent motion.
                moved = pending_stop = False
                stop_resumes = 0
                for sample in result['trace']:
                    if sample['v'] > .10:
                        if pending_stop:
                            stop_resumes += 1
                        moved, pending_stop = True, False
                    elif moved and sample['v'] < .03:
                        pending_stop = True
                result['physical_stop_resume_events'] = stop_resumes
                results.append(result)
            finally:
                case.doCleanups()
        old, new = results
        self.assertGreater(new['partial_scan_count'], 5)
        self.assertTrue(new['completed'])
        self.assertLess(new['elapsed_s'], old['elapsed_s'])
        self.assertLess(new['positive_bursts'], old['positive_bursts'])
        self.assertGreaterEqual(new['true_distance_m'], .229)
        self.assertLessEqual(new['true_distance_m'], .596)
        self.assertLess(new['true_speed_mps'], .05)
        self.comparisons.append(dict(synthetic_scan_pattern_not_csv_replay=True,
            synthetic_plant_not_vehicle_calibration=True,
            before={k: v for k, v in old.items() if k != 'trace'},
            after={k: v for k, v in new.items() if k != 'trace'}))
        self.traces.append(dict(before=old['trace'], after=new['trace']))


if __name__ == '__main__':
    unittest.main()
