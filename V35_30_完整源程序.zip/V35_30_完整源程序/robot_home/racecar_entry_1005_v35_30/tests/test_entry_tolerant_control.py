"""Uneven-wall entry continuity with physical ray casts and bounded pose use.

These are synthetic geometry/control tests, not physical car validation.
"""
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import ros_stubs as ros
import race_task_controller as cm
import race_curve_core as core
from test_continuous import scan_at
from test_uneven_wall import straight_board


def wall(heading=0.,distance=.7):
    return (distance,math.radians(heading),10,.44,.004)


class EntryTolerantControlTests(unittest.TestCase):
    def setUp(self):
        self.clock=patch.object(cm.time,'monotonic',return_value=100.)
        self.clock.start();self.addCleanup(self.clock.stop)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,
            exit_continuous=True,entry_v32_enabled=True,entry_v33_enabled=True,
            entry_v34_enabled=True,dry_run=True,bounded_heading_control=True,
            lane_parallel_band_enabled=True,lane_band_min_distance=.35,
            lane_band_max_distance=.5,side_distance_guard_enabled=False,
            side_steering_guard_enabled=False,normal_speed=.35)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.phase=self.c.SEEK_CONE_1
        self.c.lane_band_upper=.5

    def inputs_and_pose(self,pose=(4.2,.71,-.05),observation_age=.5):
        c=self.c
        c.curve_locator.pose=pose;c.curve_locator.time=100.-observation_age
        c.curve_locator.hits=1;c.curve_pose_stamp=int((100.-observation_age)*1e9)
        c.curve_pose_scan=scan_at(pose);c.curve_pose_odom=(0.,0.,0.)
        c.curve_odom_samples.clear();c.curve_odom_samples.append((100.,0.,0.,0.))
        c.curve_scan=scan_at(pose);c.curve_scan_time=100.;c.curve_scan_stamp=int(100e9)
        c.last_odom_time=c.last_motion_stamp=c.last_lidar_time=c.rel_time=100.
        c.last_yaw=pose[2];c.last_odom_xy=(0.,0.)
        c.rel_stamp=c.curve_scan_stamp
        c.rel_data=dict(stamp_ns=c.rel_stamp,body_clear=True,front_coverage=1.,exit_path_front=3.,
            exit_path_coverage=1.,entry_side_coverage=1.,entry_side_clear=True,cones=[])
        # Reproduce the expired local-wall fit while the global pose remains live.
        c.corridor_filtered=(.74,-.085);c.corridor_time=98.;c.lane_ready=True
        c.lane_selected_heading=-.085;c.lane_heading_observation=98.
        c.lane_direction_hits=3;c.last_lane_angular=0.;c.last_lane_command_time=99.9

    def test_segment_heading_support_relaxed_only_after_crosswalk(self):
        c=self.c
        direction=dict(near=wall(),rear=wall(6.),ahead=wall(-6.),
                       weight=.25,reason='SLIGHTLY_CROOKED_BOARDS')
        observations=(wall(),None,direction,1.)
        for t in (99.7,99.8,99.9):c.observe_departure_corridor(None,t,observations)
        self.assertEqual(c.lane_selected_heading,0.)
        self.assertEqual(c.lane_direction_hits,3)
        c.phase=c.APPROACH_CROSSWALK
        c.lane_raw_time=None;c.lane_selected_heading=None;c.lane_direction_hits=0
        for t in (99.7,99.8,99.9):c.observe_departure_corridor(None,t,observations)
        self.assertIsNone(c.lane_selected_heading)
        self.assertEqual(c.lane_direction_hits,0)

    def test_ray_cast_tilted_distant_board_is_scoped_to_seek_cone(self):
        c=self.c;scan=straight_board(distance=.9,heading=22.)
        for t in (99.7,99.8,99.9):c.observe_departure_corridor(scan,t)
        self.assertTrue(c.lane_ready)
        self.assertAlmostEqual(math.degrees(c.lane_selected_heading),22.,places=5)
        c.phase=c.APPROACH_CROSSWALK;c.lane_raw_time=None
        c.observe_departure_corridor(scan,100.)
        self.assertEqual(c.lane_fit_reason,'RIGHT_FIT_REJECTED')

    def test_progress_anchor_accepts_400_to_600ms_odom_bridged_pose(self):
        for age in (.4,.5,.6):
            with self.subTest(age=age):
                self.inputs_and_pose(pose=(4.0,.71,-.05),observation_age=age)
                c=self.c;c.entry_v34_anchor=None;c.entry_v34_anchor_stamp=0
                c.curve_odom_samples[-1]=(100.,.1,0.,0.)
                x,okay=c.entry_v34_progress(100.)
                self.assertTrue(okay)
                self.assertAlmostEqual(x,4.+.1*math.cos(.05),places=6)
                self.assertEqual(c.curve_pose_estimate_reason,'ODOM_BRIDGED')
                self.assertEqual(c.curve_locator.time,100.-age)

    def test_pose_straight_command_uses_current_scan_at_calibrated_drive(self):
        self.inputs_and_pose()
        cmd=self.c.entry_pose_straight_command(100.,.35)
        self.assertIsNotNone(cmd,self.c.curve_sweep)
        self.assertEqual(cmd.linear.x,.35)
        self.assertLessEqual(abs(cmd.angular.z),.035)
        self.assertEqual(self.c.lane_heading_gate,'ENTRY_POSE_STRAIGHT')
        self.assertEqual(self.c.curve_sweep,'CLEAR_RAW')
        self.assertEqual(self.c.curve_locator.time,99.5)

    def test_expired_local_wall_falls_back_through_curve_straight_command(self):
        self.inputs_and_pose()
        command=self.c.curve_straight_command(100.)
        self.assertEqual(command.linear.x,.35,self.c.rel_mode)
        self.assertEqual(self.c.rel_mode,'ENTRY_POSE_STRAIGHT')
        self.assertFalse(self.c.lane_recovering)

    def test_fallback_preserves_steering_slew_from_previous_drive(self):
        self.inputs_and_pose();self.c.last_lane_angular=-.02
        command=self.c.curve_straight_command(100.)
        self.assertEqual(command.linear.x,.35)
        self.assertLess(command.angular.z,0.)
        self.assertLessEqual(abs(command.angular.z+.02),.012+1e-9)

    def test_pose_or_data_expiring_during_sweep_cannot_authorize_drive(self):
        self.inputs_and_pose()
        with patch.object(cm.time,'monotonic',return_value=100.9):
            self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))

    def test_stale_global_pose_never_drives_the_fallback(self):
        self.inputs_and_pose(observation_age=10.01)
        self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
        self.assertEqual(self.c.curve_pose_estimate_reason,'OBSERVATION_EXPIRED')
        self.assertEqual(self.c.curve_straight_command(100.).linear.x,0.)

    def test_scan_expiring_during_check_stops_even_with_valid_pose(self):
        self.inputs_and_pose(observation_age=.10)
        self.c.last_odom_time=100.1
        with patch.object(cm.time,'monotonic',return_value=100.36):
            self.assertIsNotNone(self.c.curve_pose_estimate(100.36))
            self.assertIsNone(self.c.entry_pose_straight_command(100.2,.35))

    def test_fallback_does_not_enter_turn_or_extend_before_open_region(self):
        for x in (3.54,4.40,4.6):
            with self.subTest(x=x):
                self.inputs_and_pose(pose=(x,.71,-.05))
                self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
                self.assertEqual(self.c.curve_straight_command(100.).linear.x,0.)

    def test_fallback_rejects_unaligned_y_or_large_yaw(self):
        for pose in ((4.2,.29,0.),(4.2,1.06,0.),(4.2,.71,math.radians(21.))):
            with self.subTest(pose=pose):
                self.inputs_and_pose(pose=pose)
                self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))

    def test_fallback_requires_fresh_scan_odometry_and_lidar(self):
        for field in ('curve_scan_time','last_odom_time','last_lidar_time'):
            with self.subTest(field=field):
                self.inputs_and_pose();setattr(self.c,field,98.9)
                self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
                self.assertEqual(self.c.curve_straight_command(100.).linear.x,0.)
        self.inputs_and_pose();self.c.curve_scan=None
        self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
        self.inputs_and_pose();self.c.rel_data=None
        self.assertIsNotNone(self.c.entry_pose_straight_command(100.,.35))
        self.inputs_and_pose();self.c.rel_time=98.9
        self.assertIsNotNone(self.c.entry_pose_straight_command(100.,.35))

    def test_real_raw_scan_obstacle_still_stops_even_if_summary_says_clear(self):
        self.inputs_and_pose()
        self.c.curve_scan.ranges[0]=.50
        self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
        self.assertEqual(self.c.curve_sweep,'SWEPT_OBSTACLE')
        self.assertEqual(self.c.curve_straight_command(100.).linear.x,0.)

    def test_emergency_blocks_but_static_self_candidates_and_derived_coverage_do_not(self):
        self.inputs_and_pose();self.c.rel_data['body_clear']=False
        self.assertIsNotNone(self.c.entry_pose_straight_command(100.,.35))
        self.inputs_and_pose();self.c.lidar_emergency=True
        self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
        self.c.lidar_emergency=False;self.inputs_and_pose();self.c.rel_data['front_coverage']=.84
        self.c.rel_data['body_clear']=False
        # Clearing the real emergency requires two new feature source frames;
        # derived front coverage is not an additional motion gate.
        for i,now in enumerate((100.1,100.2),1):
            c=self.c;c.rel_stamp=c.curve_scan_stamp=int(now*1e9)
            c.rel_data['stamp_ns']=c.rel_stamp
            c.rel_time=c.last_lidar_time=c.last_odom_time=c.curve_scan_time=now
            with patch.object(cm.time,'monotonic',return_value=now):
                command=c.entry_pose_straight_command(now,.35)
            if i==1:
                self.assertIsNone(command)
                self.assertEqual(c.curve_body_guard_clear_hits,1)
            else:self.assertIsNotNone(command)

    def test_before_crosswalk_keeps_local_wall_stop_without_pose_fallback(self):
        self.inputs_and_pose();self.c.phase=self.c.APPROACH_CROSSWALK
        self.c.last_vision_time=self.c.last_boundary_time=100.
        self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
        self.assertEqual(self.c.approach_crosswalk_command().linear.x,0.)

    def test_hold_turn_stop_and_curve_owner_prevent_straight_fallback(self):
        for field,value in (('entry_hold',True),('entry_v34_turn_stop',True),('curve_follower',object())):
            with self.subTest(field=field):
                self.inputs_and_pose();setattr(self.c,field,value)
                self.assertIsNone(self.c.entry_pose_straight_command(100.,.35))
                setattr(self.c,field,False if isinstance(value,bool) else None)


if __name__=='__main__':unittest.main(verbosity=2)
