"""Current V28 path certificates, compared with the frozen V27 planner.

The three logged poses are HANDOFF observations, not exact worker seeds or
ground-truth poses. Nearby seed tests bound that uncertainty. Full physical
loops use delayed observations and independent motor/servo integration.
"""
import importlib.util
import math
from pathlib import Path
import sys
import threading
import unittest
from unittest.mock import patch
import numpy as np
import test_first_loop_v35_26 as plant

core=plant.core
spec=importlib.util.spec_from_file_location('first_profile_v27_baseline',
    Path(__file__).parent/'baselines/core_before_v35_28.py')
v27=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v27;spec.loader.exec_module(v27)
RUNS={
 '234400':dict(seed=(5.347373608137179,.9484710150081098,.2196544639197007),
   cones=((6.0264458478096765,1.9844850223961479),(2.0059389870360365,2.009872123704992))),
 '234810':dict(seed=(5.345136873886163,.9818709250526458,.19989160050837093),
   cones=((6.021470324953737,1.979730787567998),(2.007565875921235,2.0147173190776133))),
 '235339':dict(seed=(5.284230764198393,.9117351663414321,.22588256541709695),
   cones=((6.028510721223583,1.9823751104083298),(2.0072028526834114,2.011526570982438))),
}
for item in RUNS.values():item.update(pose=item['seed'],speed=0.,steer=0.)
RUNNING_SEEDS={
 '234400':(5.148281955477891,.9064118104393596,.19601384197149527),
 '234810':(5.334093207436512,.9734098392396686,.19304208423616587),
 '235339':(5.267723002983197,.9071297044948866,.22121838618911896),
}

def simulate(run,path,**kwargs):
    with patch.dict(plant.RUNS,{run:RUNS[run]}),patch.dict(plant.PATHS,{run:path}):
        return plant.simulate_first(run,initial_speed=0.,**kwargs)

class FirstProfileV3528Tests(unittest.TestCase):
    def test_logged_handoffs_have_three_certified_lower_north_candidates(self):
        for run,item in RUNS.items():
            before=v27.plan_entry_path(item['seed'],item['cones'])
            bank=core.first_cone_clearance_paths(item['seed'],item['cones'])
            self.assertEqual(len(bank),3,run)
            for path in bank:
                self.assertTrue(core.path_body_clear(path.samples,item['cones'],margin=.10))
                self.assertLessEqual(path.max_curvature,1/.55)
                self.assertLessEqual(path.first_half_max_curvature,1.35)
                self.assertGreaterEqual(path.first_half_min_curvature,0.)
                self.assertLessEqual(float(np.max(np.diff(path.lengths))),.055)
                self.assertLess(path.samples[320,1],before.samples[320,1]-.04)
                np.testing.assert_array_equal(path.samples[480:],before.samples[480:])

    def test_map_off_still_selects_default_and_does_not_wait(self):
        for item in RUNS.values():
            with patch.object(core,'optional_map_assist',return_value=False):
                path=core.plan_entry_path(item['seed'],item['cones'])
            self.assertEqual(path.entry_family,'CLEARANCE_RAMP_FIRST_CONE')
            self.assertAlmostEqual(path.first_cone_profile['east_offset_m'],.72)

    def test_ramp_and_both_first_cone_joins_preserve_heading_and_curvature(self):
        for item in RUNS.values():
            for path in core.first_cone_clearance_paths(item['seed'],item['cones']):
                p=path.samples
                np.testing.assert_allclose(p[0,:3],item['seed'],atol=1e-12)
                self.assertEqual(p[0,3],0.)
                for i,heading in ((160,math.pi/2),(320,math.pi)):
                    self.assertAlmostEqual(p[i,2],heading)
                    self.assertAlmostEqual(p[i,3],1/.75)
                    self.assertLess(abs(core.wrap(p[i,2]-p[i-1,2])),.025)
                    self.assertLess(abs(p[i,3]-p[i-1,3]),.01)
                self.assertLess(float(np.max(abs(np.diff(p[:321,3])))),.20)

    def test_nearby_seed_hypotheses_never_bypass_full_certificate(self):
        count=0
        for item in RUNS.values():
            for delta in ((-.06,0.,0.),(.06,0.,0.),(0.,-.03,0.),(0.,.03,0.),(0.,0.,-.025),(0.,0.,.025)):
                start=tuple(x+d for x,d in zip(item['seed'],delta))
                bank=core.first_cone_clearance_paths(start,item['cones'])
                for path in bank:
                    count+=1
                    self.assertTrue(core.path_body_clear(path.samples,item['cones'],margin=.10))
                    self.assertLessEqual(path.max_curvature,1/.55)
                    np.testing.assert_array_equal(path.samples[480:],v27.plan_entry_path(start,item['cones']).samples[480:])
        self.assertGreaterEqual(count,30)

    def test_cancel_and_deadline_apply_inside_candidate_bank(self):
        item=RUNS['234400'];event=threading.Event();event.set()
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(item['seed'],item['cones'],cancel=event)
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(item['seed'],item['cones'],deadline=0.)
        count=[0]
        def checkpoint():
            count[0]+=1
            if count[0]>=3:raise core.PlanningInterrupted('TEST_CANCEL')
        with self.assertRaises(core.PlanningInterrupted):
            core.first_cone_clearance_paths(item['seed'],item['cones'],checkpoint=checkpoint)

    def test_impossible_new_bank_retains_original_valid_family(self):
        start=(4.523,.78,.025);cones=((6.,2.),(2.,2.))
        before=v27.plan_entry_path(start,cones)
        with patch.object(core,'optional_map_assist',return_value=False):after=core.plan_entry_path(start,cones)
        self.assertEqual(after.entry_family,before.entry_family)
        np.testing.assert_array_equal(after.samples,before.samples)

    def test_original_body_rejection_cannot_be_overridden_by_new_bank(self):
        item=RUNS['234400']
        with patch.object(core,'path_body_clear',return_value=False):
            self.assertEqual(core.first_cone_clearance_paths(item['seed'],item['cones']),[])
            with self.assertRaises(ValueError):core.plan_entry_path(item['seed'],item['cones'])


class FirstLoopV3528Tests(unittest.TestCase):
    def test_earlier_running_seed_paths_accept_later_handoff_pose_without_manual_motion(self):
        walls=tuple(core.WALLS[:-1])+(((4.8,3.04),(8.,3.04)),)
        for run,item in RUNS.items():
            bank=core.first_cone_clearance_paths(RUNNING_SEEDS[run],item['cones'])
            # The extra cone-side reserve may reject a tighter alternative;
            # the default must remain available for these observed seeds.
            self.assertGreaterEqual(len(bank),1,run)
            self.assertAlmostEqual(bank[0].first_cone_profile['east_offset_m'],.72)
            for gain in (4.,5.,6.):
                with self.subTest(run=run,gain=gain),patch.object(core,'WALLS',walls):
                    r=simulate(run,bank[0],gain=gain,delay=.40,tau=.25)
                    self.assertTrue(r['reached'],plant.concise(r))
                    self.assertFalse(r['collision'],plant.concise(r))
                    self.assertGreater(r['minimum_clearance_m'],.10,plant.concise(r))
                    self.assertEqual(r['zero_commands'],0,plant.concise(r))

    def test_all_candidates_complete_latest_handoffs_with_weak_strong_turning(self):
        walls=tuple(core.WALLS[:-1])+(((4.8,3.04),(8.,3.04)),)
        for run,item in RUNS.items():
            for path in core.first_cone_clearance_paths(item['seed'],item['cones']):
                for gain in (4.,5.,6.):
                    with self.subTest(run=run,gap=path.first_cone_profile['east_offset_m'],gain=gain),patch.object(core,'WALLS',walls):
                        r=simulate(run,path,gain=gain,delay=.40,tau=.25)
                        self.assertTrue(r['reached'],plant.concise(r))
                        self.assertFalse(r['collision'],plant.concise(r))
                        self.assertGreater(r['minimum_clearance_m'],.10,plant.concise(r))
                        self.assertEqual(r['positive_runs'],1,plant.concise(r))
                        self.assertEqual(r['zero_commands'],0,plant.concise(r))

    def test_v27_weak_turning_deadlock_is_reproduced_and_new_default_resolves(self):
        walls=tuple(core.WALLS[:-1])+(((4.8,3.04),(8.,3.04)),)
        for run in ('235339',):
            item=RUNS[run]
            old=v27.plan_entry_path(item['seed'],item['cones'])
            new=core.first_cone_clearance_paths(item['seed'],item['cones'])[0]
            with patch.object(core,'WALLS',walls):
                a=simulate(run,old,gain=4.,delay=.25,tau=.25)
                b=simulate(run,new,gain=4.,delay=.25,tau=.25)
            self.assertFalse(a['reached'],plant.concise(a))
            self.assertTrue(a['stop_reasons'].get('RECOVERING_SWEPT_OBSTACLE'))
            self.assertTrue(b['reached'],plant.concise(b))
            self.assertEqual(b['zero_commands'],0,plant.concise(b))


if __name__=='__main__':unittest.main(verbosity=2)
