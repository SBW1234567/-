"""Certified fast entry planning and density-independent follower recovery."""
import math
from pathlib import Path
import sys
import threading
import unittest
from unittest.mock import patch

import numpy as np

SCRIPTS=Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import race_curve_core as core


LATEST_STOP=(5.383684667220603,.8430650117783423,.13949385774643297)


def straight_path(count=301,length=3.):
    x=np.linspace(0.,length,count)
    samples=np.column_stack((x,np.zeros(count),np.zeros(count),np.zeros(count)))
    return core.Path(samples,x,(),0.)


class CurveRelaxedTests(unittest.TestCase):
    def assert_certified(self,path,cones=core.CONES):
        self.assertTrue(core.path_body_clear(path.samples,cones))
        self.assertLessEqual(path.max_curvature,1/.55)
        self.assertLessEqual(float(np.max(np.diff(path.lengths))),.055)

    def test_latest_stopped_pose_uses_a_certified_fast_candidate(self):
        with patch.object(core,'plan_path',side_effect=AssertionError('Coordinate search unnecessary')):
            path=core.plan_entry_path(LATEST_STOP)
        self.assert_certified(path)
        np.testing.assert_allclose(path.samples[0,:3],LATEST_STOP,atol=1e-9)

    def test_fast_alternative_precedes_optimizer_when_default_curvature_fails(self):
        pose=(4.4,.65,0.)
        with self.assertRaisesRegex(ValueError,'PATH_CURVATURE'):
            core.make_path(pose)
        with patch.object(core,'plan_path',side_effect=AssertionError('Fixed alternative should be first')):
            path=core.plan_entry_path(pose)
        self.assert_certified(path)

    def test_shifted_logged_cone_keeps_body_and_radius_checks(self):
        # Approximate world conversion of the final logged local entry cone;
        # this is a geometry regression, not a same-frame physical replay.
        cone=core.world((.8246435523033142,1.0885734558105469),LATEST_STOP)
        cones=(cone,core.CONES[1])
        path=core.plan_entry_path(LATEST_STOP,cones)
        self.assert_certified(path,cones)

    def test_optimizer_is_still_tried_after_fixed_candidates_fail(self):
        with patch.object(core,'make_path',side_effect=ValueError('No fixed candidate')):
            with patch.object(core,'plan_path') as optimizer:
                # done() attaches measured timing to an actual path-like object.
                optimizer.return_value=type('Candidate',(),{})()
                result=core.plan_entry_path(LATEST_STOP)
                self.assertIs(result,optimizer.return_value)
                optimizer.assert_called_once()

    def test_impossible_geometry_still_rejects_collision(self):
        with self.assertRaisesRegex(ValueError,'ENTRY_NO_FEASIBLE_CURVE'):
            core.plan_entry_path((6.,2.,0.))

    def test_cancellation_and_deadline_apply_before_fast_candidates(self):
        cancel=threading.Event();cancel.set()
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(LATEST_STOP,cancel=cancel)
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(LATEST_STOP,deadline=core.time.monotonic()-1.)

    def test_dense_path_can_recover_more_than_sixty_points_ahead(self):
        follower=core.PathFollower(straight_path())
        self.assertEqual(follower.locate((1.2,0.,0.)),120)
        self.assertAlmostEqual(follower.progress,1.2)

    def test_search_window_is_metres_for_sparse_and_dense_sampling(self):
        for count in (31,301,3001):
            with self.subTest(count=count):
                follower=core.PathFollower(straight_path(count))
                follower.locate((1.2,0.,0.))
                self.assertAlmostEqual(follower.progress,1.2)

    def test_moderate_lateral_error_is_recoverable_but_large_error_is_rejected(self):
        follower=core.PathFollower(straight_path())
        self.assertEqual(follower.locate((.6,.6,0.)),60)
        with self.assertRaisesRegex(ValueError,'CURVE_TRACK_ERROR'):
            follower.locate((.6,.81,0.))

    def test_forward_search_remains_bounded_to_one_and_a_half_metres(self):
        with self.assertRaisesRegex(ValueError,'CURVE_TRACK_ERROR'):
            core.PathFollower(straight_path()).locate((2.31,0.,0.))

    def test_nearby_reverse_branch_cannot_steal_progress(self):
        samples=np.array([[0.,0.,0.,0.],[.2,0.,0.,0.],[.4,0.,0.,0.],
            [.4,.1,math.pi,0.],[.2,.1,math.pi,0.],[0.,.1,math.pi,0.]])
        lengths=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(samples[:,:2],axis=0),axis=1))]
        follower=core.PathFollower(core.Path(samples,lengths,(),0.))
        self.assertEqual(follower.locate((.2,.1,0.)),1)
        self.assertLess(follower.progress,.4)

    def test_progress_never_moves_backwards(self):
        follower=core.PathFollower(straight_path())
        follower.locate((.8,0.,0.))
        self.assertEqual(follower.locate((.75,0.,0.)),80)
        self.assertAlmostEqual(follower.progress,.8)

    def test_opposite_heading_and_nonfinite_pose_are_rejected(self):
        for pose in ((.4,0.,math.pi),(.4,math.nan,0.)):
            with self.subTest(pose=pose):
                with self.assertRaisesRegex(ValueError,'CURVE_TRACK_ERROR'):
                    core.PathFollower(straight_path()).locate(pose)


if __name__=='__main__':unittest.main(verbosity=2)
