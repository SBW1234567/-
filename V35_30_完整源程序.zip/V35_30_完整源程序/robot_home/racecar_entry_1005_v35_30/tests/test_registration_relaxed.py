"""Stopped full-fit recovery without fabricated scan/odom alignment."""
import types
import math
import unittest
from unittest.mock import patch

import test_registration_recovery as fixtures

cm=fixtures.cm
core=fixtures.core


class RegistrationRelaxedTests(unittest.TestCase):
    scan=fixtures.RegistrationRecoveryTests.scan

    def setUp(self):
        self.now=100.
        clock=patch.object(cm.time,'monotonic',side_effect=lambda:self.now)
        clock.start();self.addCleanup(clock.stop)
        fixtures.RegistrationRecoveryTests.setUp(self)
        # Existing per-callback monotonic patches and ROS now share a domain.
        self.c.get_clock=lambda:types.SimpleNamespace(now=lambda:types.SimpleNamespace(
            nanoseconds=round((900.+cm.time.monotonic())*1e9)))

    def source(self,stamp,received,laser_pose=(0.,0.,0.)):
        x,y,yaw=laser_pose
        message=self.odom_message(stamp,x-.07*math.cos(yaw),y-.07*math.sin(yaw),yaw)
        with patch.object(cm.time,'monotonic',return_value=received):
            self.c.odom_callback(message)

    def stationary_source_window(self):
        c=self.c;c.curve_last_drive_time=99.
        c.curve_odom_samples.clear();c.curve_motion_samples.clear();c.last_motion_stamp=0
        # Actual delayed source callbacks after propulsion stopped, spanning
        # .4s. They remain distinct from the newer scan's original stamp.
        for stamp in (999.6,999.7,999.8,999.9,1000.):self.source(stamp,100.30)

    def missing_alignment(self):
        c=self.c;c.curve_locator.time=96.;c.curve_pose_stamp=int(996.e9)
        c.curve_pose_odom_alignment='SCAN_ALIGNED';c.curve_pose_odom_stamp=c.curve_pose_stamp
        c.last_odom_time=100.30
        # Exactly the latest-log condition: source odom is >160 ms behind the
        # scan, although its callback arrived recently. No paired frame exists.
        self.assertIsNone(c.curve_odom_at(round(1000.30e9)))
        return c

    def test_stopped_log_alignment_gap_submits_fit_but_preserves_reference_until_paired(self):
        c=self.missing_alignment();original=c.curve_locator.time
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30,(5.24,.79,0.)),100.30,round(1000.30e9))
        self.assertEqual(c.curve_registration_submit_status,'SUBMITTED_STOPPED_FULL_FIT')
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_locator.time,original)
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.65):
            c.curve_poll_registration(100.65)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertEqual(c.curve_locator.time,original)
        self.assertEqual(c.curve_pose_stamp,int(996.e9))
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertIsNotNone(c.curve_pending_fit)
        self.assertAlmostEqual(c.curve_pending_fit[0].pose[0],5.24,places=2)

    def test_moving_gap_does_not_submit_or_fake_anchor(self):
        c=self.missing_alignment();original=c.curve_locator.time;anchor=c.curve_pose_odom
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        self.assertEqual(c.curve_registration_submit_status,'WAIT_SCAN_ODOM')
        self.assertFalse(self.worker.jobs)
        self.assertEqual(c.curve_locator.time,original)
        self.assertEqual(c.curve_pose_odom,anchor)

    def test_stopped_full_fit_requires_existing_localization(self):
        c=self.missing_alignment();c.curve_locator=core.WallLocalizer(True)
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        self.assertFalse(self.worker.jobs)
        self.assertEqual(c.curve_registration_submit_status,'WAIT_SCAN_ODOM')

    def test_stopped_missing_pairing_with_stale_odom_still_waits(self):
        c=self.missing_alignment();c.last_odom_time=99.49
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        self.assertFalse(self.worker.jobs)
        self.assertEqual(c.curve_registration_submit_status,'WAIT_SCAN_ODOM')

    def test_later_real_source_odom_backfills_original_stamp(self):
        c=self.missing_alignment()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30,(5.24,.79,0.)),100.30,round(1000.30e9))
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.65):
            c.curve_poll_registration(100.65)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertEqual(c.curve_locator.time,96.)
        self.source(1000.30,100.70,(.04,0.,0.))
        self.source(1000.40,100.70,(.06,0.,0.))
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.70):
            c.curve_poll_registration(100.70)
            projected=c.curve_registration_seed(round(1000.40e9))
        self.assertIsNone(c.curve_pending_fit)
        self.assertEqual(c.curve_pose_odom,(.04,0.,0.))
        self.assertEqual(c.curve_locator.time,100.30)
        self.assertEqual(c.curve_pose_stamp,round(1000.30e9))
        self.assertAlmostEqual(projected[0],5.26,places=2)

    def test_stopped_fit_not_accepted_without_alignment_after_moving(self):
        c=self.missing_alignment();original=c.curve_locator
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.65):
            c.curve_poll_registration(100.65)
        self.assertIs(c.curve_locator,original)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertIsNotNone(c.curve_pending_fit)

    def test_real_odom_callback_retries_pending_source_immediately(self):
        c=self.missing_alignment()
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        c.curve_scan_stamp=round(1000.30e9)
        message=types.SimpleNamespace(header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=1000,nanosec=300000000)),
            pose=types.SimpleNamespace(pose=types.SimpleNamespace(position=types.SimpleNamespace(x=-.03,y=0.),
                orientation=types.SimpleNamespace(w=1.,x=0.,y=0.,z=0.))))
        with patch.object(cm.time,'monotonic',return_value=100.50),patch.object(c,'entry_is_stopped',return_value=False,create=True):
            c.odom_callback(message)
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_odom_source_stamp,round(1000.30e9))
        self.assertEqual(c.curve_odom_source_gap,0.)
        self.assertEqual(c.curve_job[2],100.30)
        self.assertEqual(c.curve_job[3],round(1000.30e9))

    def test_plan_running_registration_is_rate_limited_not_queued(self):
        c=self.c;c.entry_plan_job=object();c.curve_last_process=100.
        c.curve_odom_samples.append((1000.20,.02,0.,0.));c.last_odom_time=100.20
        with patch.object(cm.time,'monotonic',return_value=100.20):
            c.curve_submit_registration(self.scan(1000.20),100.20,round(1000.20e9))
        self.assertFalse(self.worker.jobs)
        self.assertEqual(c.curve_registration_submit_status,'RATE_LIMIT')
        self.assertIsNotNone(c.curve_registration_pending)
        with patch.object(cm.time,'monotonic',return_value=100.52):
            c.curve_poll_registration(100.52)
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_job[2],100.20)

    def test_fit_result_age_is_independent_of_long_pose_bridge_ttl(self):
        c=self.c;c.curve_pose_ttl=10.;c.curve_fit_result_ttl=1.2
        c.curve_pose_stamp=int(999.e9)
        locator=core.WallLocalizer(True);locator.pose=(5.2,.79,0.)
        locator.time=100.;locator.hits=1;locator.reason='TRACKING'
        future=fixtures.Future();future.set_result((locator,True,1.3))
        c.curve_job=(future,self.scan(1000.),100.,int(1000.e9),c.curve_generation)
        with patch.object(c,'odom_is_still',return_value=False),patch.object(c,'entry_is_stopped',return_value=False,create=True):
            c.curve_poll_registration(101.21)
        self.assertEqual(c.curve_registration_status,'RESULT_TOO_OLD')
        self.assertIsNot(c.curve_locator,locator)

    def test_settled_stopped_fit_retains_real_odom_anchor_for_handoff(self):
        c=self.missing_alignment();c.entry_v33_braked=True;c.entry_v33_brake_since=99.5
        self.stationary_source_window()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30,(5.24,.79,0.)),100.30,round(1000.30e9))
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.64):
            c.curve_poll_registration(100.64)
        self.assertEqual(c.curve_pose_odom_alignment,'STOPPED_ODOM_ANCHOR')
        self.assertEqual(c.curve_pose_odom_stamp,int(1000.e9))
        self.assertEqual(c.curve_pose_stamp,round(1000.30e9))
        self.assertEqual(c.curve_locator.time,100.30)
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        # Continuous driving uses real relative motion from that stationary
        # reference; it does not need to pretend the wall observation is new.
        c.curve_odom_samples.append((1000.80,.20,0.,0.));c.last_odom_time=100.80
        with patch.object(c,'entry_is_stopped',return_value=False,create=True):
            result=c.curve_pose_estimate(100.80)
        self.assertIsNotNone(result)
        self.assertAlmostEqual(result[0],5.44,places=2)
        self.assertEqual(c.curve_locator.time,100.30)

    def test_pre_brake_odom_is_not_used_as_stopped_pose_anchor(self):
        c=self.missing_alignment();c.entry_v33_braked=True;c.entry_v33_brake_since=100.10
        self.stationary_source_window();c.curve_follower=None
        original=c.curve_locator;anchor=c.curve_pose_odom;stamp=c.curve_pose_odom_stamp
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30),100.30,round(1000.30e9))
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.65):
            c.curve_poll_registration(100.65)
        self.assertIs(c.curve_locator,original)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')
        self.assertEqual(c.curve_pose_odom,anchor)
        self.assertEqual(c.curve_pose_odom_stamp,stamp)

    def test_exact_late_source_replaces_explicit_stopped_approximation(self):
        c=self.c;c.curve_pose_odom=(.01,0.,0.)
        c.curve_pose_odom_alignment='STOPPED_ODOM_ANCHOR';c.curve_pose_odom_stamp=int(999.90e9)
        c.curve_odom_samples.append((1000.10,.04,0.,0.));c.last_odom_time=100.10
        with patch.object(cm.time,'monotonic',return_value=100.10),patch.object(c,'entry_is_stopped',return_value=False,create=True):
            result=c.curve_registration_seed(round(1000.10e9))
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')
        self.assertEqual(c.curve_pose_odom_stamp,int(1000.e9))
        self.assertAlmostEqual(result[0],5.24,places=2)

    def test_stopped_missing_pair_anchor_ignores_large_global_yaw_drift(self):
        c=self.missing_alignment();c.curve_pose_odom=None;c.last_yaw=1.2
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.30):
            c.curve_submit_registration(self.scan(1000.30,(5.24,.79,0.)),100.30,round(1000.30e9))
        self.assertEqual(len(self.worker.jobs),1)
        self.assertEqual(c.curve_locator.time,96.)
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=True,create=True),patch.object(cm.time,'monotonic',return_value=100.65):
            c.curve_poll_registration(100.65)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertAlmostEqual(c.curve_pending_fit[0].pose[2],0.,places=2)
        self.assertEqual(c.curve_locator.time,96.)
        self.source(1000.30,100.70,(0.,0.,1.2))
        with patch.object(cm.time,'monotonic',return_value=100.70):c.curve_poll_registration(100.70)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertAlmostEqual(c.curve_locator.pose[2],0.,places=2)
        self.assertEqual(c.curve_locator.time,100.30)

    def odom_message(self,stamp,x=0.,y=0.,yaw=0.):
        ns=round(stamp*1e9)
        return types.SimpleNamespace(header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=ns//1000000000,nanosec=ns%1000000000)),
            pose=types.SimpleNamespace(pose=types.SimpleNamespace(position=types.SimpleNamespace(x=x,y=y),
                orientation=types.SimpleNamespace(w=math.cos(yaw/2),x=0.,y=0.,z=math.sin(yaw/2)))))

    def test_400ms_source_gap_keeps_curve_anchor_but_crosswalk_stillness_resets(self):
        c=self.c;c.phase=c.ORBIT_CONE_1;c.last_motion_stamp=1000.
        c.odom_still_samples.append((100.,0.,0.,0.));c.last_still_stamp=1000.
        c.curve_pose_odom_alignment='SCAN_ALIGNED';c.curve_pose_odom_stamp=int(1000.e9)
        with patch.object(cm.time,'monotonic',return_value=100.40):
            c.odom_callback(self.odom_message(1000.40))
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertEqual(c.curve_pose_odom_stamp,int(1000.e9))
        self.assertEqual(len(c.curve_odom_samples),2)
        self.assertEqual(c.curve_odom_source_stamp,round(1000.40e9))
        self.assertEqual(len(c.odom_still_samples),1)
        self.assertEqual(c.odom_still_samples[0][0],100.40)

    def test_long_source_gap_retains_anchor_but_does_not_interpolate_missing_scan(self):
        c=self.c;c.phase=c.ORBIT_CONE_1;c.last_motion_stamp=1000.
        c.curve_pose_odom_alignment='SCAN_ALIGNED';c.curve_pose_odom_stamp=int(1000.e9)
        with patch.object(cm.time,'monotonic',return_value=100.81):
            c.odom_callback(self.odom_message(1000.81))
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))
        self.assertEqual(c.curve_pose_odom_stamp,int(1000.e9))
        self.assertEqual(c.curve_pose_odom_alignment,'SCAN_ALIGNED')
        self.assertEqual(len(c.curve_odom_samples),2)
        self.assertIsNone(c.curve_odom_at(round(1000.40e9)))

    def test_worker_uses_its_original_anchor_after_history_rollover(self):
        c=self.c;c.curve_odom_samples.append((1000.10,.02,0.,0.));c.last_odom_time=100.10
        with patch.object(cm.time,'monotonic',return_value=100.10):
            c.curve_submit_registration(self.scan(1000.10,(5.22,.79,0.)),100.10,round(1000.10e9))
        self.assertEqual(c.curve_job_odom,(round(1000.10e9),c.curve_generation,(.02,0.,0.)))
        c.curve_odom_samples.clear();c.curve_odom_samples.append((1000.80,.20,0.,0.))
        c.last_odom_time=100.60
        self.worker.complete()
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.60):
            c.curve_poll_registration(100.60)
        self.assertEqual(c.curve_registration_status,'TRACKING')
        self.assertEqual(c.curve_pose_odom,(.02,0.,0.))
        self.assertEqual(c.curve_pose_odom_stamp,round(1000.10e9))
        self.assertEqual(c.curve_locator.time,100.10)
        self.assertAlmostEqual(c.curve_pose_estimate(100.60)[0],5.40,places=2)

    def test_different_job_stamp_cannot_reuse_immutable_anchor(self):
        c=self.missing_alignment();c.curve_job_odom=(int(998.e9),c.curve_generation,(100.,100.,0.))
        locator=core.WallLocalizer(True);locator.pose=(5.2,.79,0.)
        locator.time=100.30;locator.hits=1;locator.reason='TRACKING'
        future=fixtures.Future();future.set_result((locator,True,.4))
        c.curve_job=(future,self.scan(1000.30),100.30,round(1000.30e9),c.curve_generation)
        with patch.object(c,'entry_is_stopped',return_value=False,create=True),patch.object(cm.time,'monotonic',return_value=100.70):
            c.curve_poll_registration(100.70)
        self.assertEqual(c.curve_registration_status,'WAIT_FIT_ODOM_ALIGNMENT')
        self.assertIsNot(c.curve_locator,locator)

    def test_normal_motion_over_half_second_callback_gap_does_not_fault(self):
        c=self.c;c.last_motion_stamp=1000.;c.last_odom_xy=(0.,0.)
        with patch.object(cm.time,'monotonic',return_value=100.50):
            c.odom_callback(self.odom_message(1000.50,.60,0.,.80))
        self.assertFalse(c.route_fault)
        self.assertEqual(c.last_odom_xy,(.60,0.))
        self.assertAlmostEqual(c.last_yaw,.80)
        self.assertAlmostEqual(c.travel_distance,.60)
        self.assertEqual(c.curve_pose_odom,(0.,0.,0.))

    def test_abrupt_three_metre_jump_over_100ms_still_faults(self):
        c=self.c;c.last_motion_stamp=1000.;c.last_odom_xy=(0.,0.);c.curve_follower=None
        with patch.object(cm.time,'monotonic',return_value=100.10):
            c.odom_callback(self.odom_message(1000.10,3.,0.,0.))
        self.assertEqual(c.route_fault,'ODOM_POSITION_JUMP')
        self.assertEqual(c.last_odom_time,0.)
        self.assertEqual(c.travel_distance,0.)

    def test_crosswalk_retains_original_fixed_motion_jump_bound(self):
        c=self.c;c.phase=c.CROSSWALK_STOP;c.last_motion_stamp=1000.;c.last_odom_xy=(0.,0.);c.curve_follower=None
        with patch.object(cm.time,'monotonic',return_value=100.50):
            c.odom_callback(self.odom_message(1000.50,.60,0.,0.))
        self.assertEqual(c.route_fault,'ODOM_POSITION_JUMP')
        self.assertEqual(c.travel_distance,0.)


if __name__=='__main__':unittest.main(verbosity=2)
