"""Distinguish late callback consumption from time spent computing control."""
from collections import deque
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as fixtures
cm = fixtures.cm


class SourceTimingTests(unittest.TestCase):
    def test_old_source_keeps_original_stamp_and_expires_during_control(self):
        c = cm.RaceTaskController.__new__(cm.RaceTaskController)
        c.curve_source_now = lambda: 1_000_100_000_000
        c.curve_motion_samples = deque([(999_900_000_000, 0., 0., 0.)], maxlen=8)
        c.curve_motion_status = {}
        msg = NS(twist=NS(twist=NS(linear=NS(x=.4), angular=NS(z=0.))))
        c.curve_update_motion(1_000_000_000_000, (.04, 0., 0.), 100., msg)
        self.assertAlmostEqual(c.curve_motion_status['odom_callback_source_age_s'], .1)
        self.assertEqual(c.curve_motion_samples[-1][0], 1_000_000_000_000)
        c.last_odom_time = 100.
        c.curve_odom_max_age = 2.
        c.curve_prediction_max_time = .95
        c.curve_prediction_max_distance = .80
        c.curve_prediction_max_turn = 1.8
        c.curve_pause_active = False
        c.curve_source_now = lambda: 1_001_100_000_000
        with patch.object(cm.time, 'monotonic', return_value=101.):
            pose, detail = c.curve_motion_at(1_001_100_000_000, 101.)
        self.assertIsNone(pose)
        self.assertEqual(detail['policy'], 'SOURCE_PREDICTION_LIMIT')
        self.assertAlmostEqual(detail['odom_source_age_s'], 1.1)
        self.assertAlmostEqual(c.curve_motion_status['odom_callback_source_age_s'], .1)
        self.assertEqual(c.curve_motion_status['odom_callback_monotonic'], 100.)

    def test_missing_source_clock_is_unavailable_not_zero_age(self):
        c = cm.RaceTaskController.__new__(cm.RaceTaskController)
        c.curve_source_now = lambda: None
        c.curve_update_motion(1_000_000_000_000, (0., 0., 0.), 100., NS())
        self.assertIsNone(c.curve_motion_status['odom_callback_source_age_s'])
        self.assertIsNone(c.curve_motion_clock_sample)
        self.assertEqual(c.curve_motion_status['velocity_policy'], 'WAIT_SOURCE_PAIR')


if __name__ == '__main__':
    unittest.main()
