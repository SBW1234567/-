"""Delayed closed-loop entry model, distinct from ideal path-point replay.

The gain, servo lag and drive speed are scenario assumptions, not newly measured
vehicle calibration. The model consumes delayed observations, limits steering,
and integrates its own trajectory; it never forces the vehicle onto the path.
"""
import importlib.util
import json
import math
from pathlib import Path
import sys
import unittest
import numpy as np

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
sys.path.insert(0,str(PACKAGE/'tests'))
import race_curve_core as core


def old_core():
    path=PACKAGE/'tests/baselines/race_curve_core_v35_11.py'
    spec=importlib.util.spec_from_file_location('curve_response_v35_11',path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    return module


def integrate(pose,vx,vy,omega,dt):
    angle=omega*dt
    if abs(omega)<1e-8:dx,dy=vx*dt,vy*dt
    else:
        a=math.sin(angle)/omega;b=(1.-math.cos(angle))/omega
        dx,dy=a*vx-b*vy,b*vx+a*vy
    x,y=core.world((dx,dy),pose)
    return (x,y,core.wrap(pose[2]+angle))


def observed_pose(history,stamp):
    if stamp<=history[0][0]:return history[0][1]
    j=min(len(history)-1,int(round(stamp/.01)))
    return history[j][1]


def delayed_estimate(history,now,delay,compensate):
    t=max(0.,now-delay);pose=observed_pose(history,t)
    if not compensate or t<=.10:return pose
    prior=observed_pose(history,t-.10);dx,dy=core.local(pose,prior)
    angle=core.wrap(pose[2]-prior[2]);omega=angle/.10
    if abs(angle)<1e-8:vx,vy=dx/.10,dy/.10
    else:
        a=math.sin(angle)/angle;b=(1.-math.cos(angle))/angle
        det=a*a+b*b
        vx,vy=(a*dx+b*dy)/det/.10,(-b*dx+a*dy)/det/.10
    return integrate(pose,vx,vy,omega,now-t)


def obstacle_clearance(pose):
    corners=[core.world(q,pose) for q in ((-.185,-.15),(.20,-.15),(.20,.15),(-.185,.15))]
    edges=list(zip(corners,corners[1:]+corners[:1]))
    wall=min(min(core.segment_distance(c,a,b),core.segment_distance(d,a,b),
                 core.segment_distance(a,c,d),core.segment_distance(b,c,d))
             for a,b in core.WALLS for c,d in edges)
    if any(core.segment_box(core.local(a,pose),core.local(b,pose),.185,.20,.15)
           for a,b in core.WALLS):wall=-wall
    cones=[]
    for cone in core.CONES:
        x,y=core.local(cone,pose)
        cones.append(math.hypot(max(-.185-x,0.,x-.20),max(abs(y)-.15,0.))-.20)
    cone=min(cones)
    return wall,cone,min(wall,cone)


def simulate_entry(follower_type,path,*,delay=.4,compute=.10,tau=.12,
                   gain_factor=1.,compensate=True,pause=True,horizon_check=False,preview=.20,
                   speed_mps=.9,route_goal='first_cone',controller_gain=5.):
    follower=follower_type(path);state=tuple(path.samples[0,:3])
    history=[(0.,state)];pending=[];target_u=0.;actual_u=0.;speed=0.
    next_control=0.;period=max(.10,compute);minimum=math.inf;max_lateral=0.
    stopped=False;errors=[];maximum_u=0.;reached=False;was_pause=False
    command_count=0;early_u=None;horizon_false=0;minimum_cone=minimum_all=math.inf
    for tick in range(1,4001 if route_goal=='upper_corridor' else 1601):
        now=tick*.01
        # One brief recovery pause around the approach bend. Hold the issued
        # steering for <=.35s in the new controller; old controller centres.
        paused=pause and 1.90<=now<2.15
        if paused and not was_pause:
            try:follower.reset_feedback(preserve_output=True)
            except TypeError:follower.reset_feedback()
            was_pause=True
        if not paused and was_pause:
            if follower_type.__module__=='curve_response_v35_11':
                follower.time=now-.05;follower.output=0.;follower.integral=follower.derivative=0.
            was_pause=False
        if now+1e-9>=next_control and not paused:
            measured=delayed_estimate(history,now-.01,delay,compensate)
            try:
                options=dict(preview_distance=preview) if hasattr(follower,'response_output') else {}
                u=follower.command(measured,now,controller_gain,.32,**options)
                max_lateral=max(max_lateral,abs(follower.lateral))
                maximum_u=max(maximum_u,abs(u));command_count+=1
                if early_u is None and now>=.40:early_u=u
                pending.append((now+compute,u))
                if horizon_check and hasattr(follower,'response_output'):
                    rollout=core.command_horizon(measured,follower,controller_gain,distance=1.,speed=max(.3,speed))
                    if not all(core.body_clear(q,margin=0.) for q in rollout):horizon_false+=1
            except ValueError as exc:
                errors.append(str(exc));stopped=True;pending.append((now+compute,0.))
            next_control=now+period
        while pending and pending[0][0]<=now+1e-9:_,target_u=pending.pop(0)
        if paused and follower_type.__module__=='curve_response_v35_11':target_u=0.
        actual_u+=min(1.,.01/max(.02,tau))*(target_u-actual_u)
        # .35 is the calibrated drive input; scenario speed is varied separately.
        desired_speed=0. if paused or stopped else speed_mps
        speed+=.01/.30*(desired_speed-speed)
        state=integrate(state,speed,0.,speed*controller_gain*gain_factor*actual_u,.01)
        history.append((now,state));wall,cone,all_gap=obstacle_clearance(state)
        minimum=min(minimum,wall);minimum_cone=min(minimum_cone,cone);minimum_all=min(minimum_all,all_gap)
        if not core.body_clear(state,margin=0.):
            return dict(collision=True,wall_clearance_m=minimum,cone_clearance_m=minimum_cone,
                minimum_clearance_m=minimum_all,max_lateral_m=max_lateral,
                reached=False,time_s=now,final_pose=state,maximum_command=maximum_u,
                first_command_at_400ms=early_u,track_errors=errors,
                horizon_map_rejections=horizon_false,command_count=command_count)
        # Complete the outside first-cone passage and its north-side turn.
        first_done=(state[0]<6.45 and state[1]>2.5 and abs(core.wrap(state[2]-math.pi))<.95)
        upper_done=(core.dist(state,path.samples[-1])<.25
                    and abs(core.wrap(state[2]-path.samples[-1,2]))<.45)
        if (first_done if route_goal=='first_cone' else upper_done):
            reached=True;break
        if stopped and speed<.01:break
    return dict(collision=False,wall_clearance_m=minimum,cone_clearance_m=minimum_cone,
        minimum_clearance_m=minimum_all,max_lateral_m=max_lateral,
        reached=reached,time_s=now,final_pose=state,maximum_command=maximum_u,
        first_command_at_400ms=early_u,track_errors=errors,
        horizon_map_rejections=horizon_false,command_count=command_count)


def simulate_controller_entry(*,delay=.5,compute=.08,tau=.15,gain_factor=1.,speed_mps=.9,
                              prediction_max_time=None,start_pose=(5.08,.86,.075),
                              actual_gain=None,trace=False):
    """Exercise the real command, scan sweep, source callback and stop gates.

    Ray-cast scans have 50 ms acquisition age. Periodic correct wall anchors
    are an explicit assumption; registration noise is not simulated here.
    Compute time advances both clocks before the command's freshness recheck.
    """
    import test_continuous as helpers
    from types import SimpleNamespace as NS
    from unittest.mock import patch
    cm,ros=helpers.cm,helpers.ros
    ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
        entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
    clock=dict(t=0.)
    with patch.object(cm.time,'monotonic',side_effect=lambda:100.+clock['t']):
        c=cm.RaceTaskController()
        try:
            path=core.plan_entry_path(start_pose);state=tuple(path.samples[0,:3])
            c.phase=c.ENTER_OBSTACLES;c.curve_follower=core.PathFollower(path)
            c.curve_control_prediction_enabled=True
            if prediction_max_time is not None:c.curve_prediction_max_time=prediction_max_time
            c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=round((1000.+clock['t'])*1e9)))
            c.curve_locator.pose=state;c.curve_locator.time=100.;c.curve_locator.hits=3
            c.curve_pose_odom=state;c.curve_pose_odom_alignment='SCAN_ALIGNED'
            history=[(0.,state)];pending=[];target_u=actual_u=speed=0.;target_drive=0.
            minimum=math.inf;reasons={};commands=zero_commands=0;reached=False;maximum_predict_dt=0.
            next_control=0.;next_source=0.;period=max(.1,compute)
            # ``compute`` models the entire callback, including all recovery
            # candidate sweeps. Charging it once per helper would multiply the
            # same budget and invent an overrun whenever recovery searches.
            sweep_time_charged=False;first_blocked=None;blocked_events=[]
            def source(source_t,laser_pose,received):
                clock['t']=received;ns=round((1000.+source_t)*1e9);x,y,h=laser_pose
                msg=NS(header=NS(stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)),
                    pose=NS(pose=NS(position=NS(x=x-.07*math.cos(h),y=y-.07*math.sin(h)),
                        orientation=NS(x=0.,y=0.,z=math.sin(h/2),w=math.cos(h/2)))),
                    twist=NS(twist=NS(linear=NS(x=0.),angular=NS(z=0.))))
                c.odom_callback(msg)
            source(-delay-.10,state,-.10);source(-delay,state,0.)
            original_sweep=c.curve_check_sweep
            def timed_sweep(*args):
                nonlocal sweep_time_charged,first_blocked
                result=original_sweep(*args)
                if trace and not sweep_time_charged and len(blocked_events)<8 and result[1]=='SWEPT_OBSTACLE':
                    scan,pose,_,checked_at=args
                    f=c.curve_follower
                    measured_speed=c.curve_motion_status.get('speed_mps')
                    horizon=.65 if measured_speed is None else max(.65,min(1.10,.35+.65*measured_speed))
                    arcs=[]
                    direction=1. if f.ff+f.p+f.i+f.d>=0. else -1.
                    for magnitude in (.24,.28,.32):
                        steer=direction*magnitude
                        samples=core.constant_steer_horizon(pose,steer,c.curve_curvature_gain,
                            c.curve_max_steer,distance=horizon,speed=max(.9,min(1.5,measured_speed or 0.)),
                            initial_steer=f.response_output)
                        # Diagnostic probes must not change the controller's
                        # sweep counters or recovery state.
                        scan_pose=c.curve_scan_pose(checked_at,pose)
                        clear=scan_pose is not None and not core.scan_hits_body(scan,scan_pose,samples)
                        why='CLEAR_RAW' if clear else ('SCAN_ODOM_ALIGNMENT' if scan_pose is None else 'SWEPT_OBSTACLE')
                        arcs.append(dict(steering=steer,clear=clear,reason=why))
                    event=dict(time_s=now,physical_pose=state,command_pose=tuple(pose),
                        physical_speed_mps=speed,physical_steering=actual_u,
                        requested_steering=f.output,response_estimate=f.response_output,
                        ff=f.ff,p=f.p,i=f.i,d=f.d,lateral=f.lateral,heading=f.heading,
                        horizon_m=horizon,motion=dict(c.curve_motion_status),constant_arcs=arcs)
                    if first_blocked is None:first_blocked=event
                    blocked_events.append(event)
                if not sweep_time_charged:
                    clock['t']+=compute;sweep_time_charged=True
                return result
            c.curve_check_sweep=timed_sweep
            for tick in range(1,2001):
                now=tick*.01;clock['t']=now
                if now+1e-9>=next_source:
                    source_t=now-delay;source_pose=observed_pose(history,source_t)
                    source(source_t,source_pose,now);next_source=now+.10
                    # A wall fit is anchored to its matched acquisition odom.
                    if tick%100==1:
                        c.curve_locator.pose=source_pose;c.curve_locator.time=100.+now
                        c.curve_pose_odom=tuple(c.curve_odom_samples[-1][1:4])
                if now+1e-9>=next_control:
                    sweep_time_charged=False
                    scan_t=max(0.,now-.05);scan=helpers.scan_at(observed_pose(history,scan_t))
                    ns=round((1000.+scan_t)*1e9)
                    scan.header.stamp=NS(sec=ns//1000000000,nanosec=ns%1000000000)
                    c.curve_scan=scan;c.curve_scan_stamp=ns
                    c.curve_scan_time=c.last_lidar_time=c.rel_time=100.+now
                    c.rel_data=dict(body_clear=core.body_clear(state,margin=0.))
                    command=c.curve_command(100.+now);commands+=1
                    if blocked_events and blocked_events[-1]['time_s']==now:
                        blocked_events[-1].update(issued_drive=command.linear.x,issued_steering=command.angular.z,
                            reason=c.curve_reason,recovery=dict(getattr(c,'curve_recovery_status',{})))
                    maximum_predict_dt=max(maximum_predict_dt,c.curve_motion_status.get('prediction_dt_s',0.))
                    if command.linear.x<=0.:
                        zero_commands+=1;reasons[c.curve_reason]=reasons.get(c.curve_reason,0)+1
                    pending.append((now+compute,command.angular.z,command.linear.x))
                    next_control=now+period
                while pending and pending[0][0]<=now+1e-9:
                    _,target_u,target_drive=pending.pop(0)
                actual_u+=min(1.,.01/max(.02,tau))*(target_u-actual_u)
                desired_speed=speed_mps if target_drive>0. else 0.
                speed+=.01/.30*(desired_speed-speed)
                # V35.13's measured-range scenarios are 4/5/6, centred on
                # the controller's new nominal 5. Explicit actual_gain keeps
                # recorded-pose and out-of-range experiments unambiguous.
                physical_gain=5.*gain_factor if actual_gain is None else actual_gain
                state=integrate(state,speed,0.,speed*physical_gain*actual_u,.01)
                history.append((now,state));minimum=min(minimum,obstacle_clearance(state)[2])
                collision=not core.body_clear(state,margin=0.)
                if collision:break
                if state[0]<6.45 and state[1]>2.5 and abs(core.wrap(state[2]-math.pi))<.95:
                    reached=True;break
            return dict(reached=reached,collision=collision,time_s=now,final_pose=state,
                minimum_clearance_m=minimum,zero_commands=zero_commands,commands=commands,
                stop_reasons=reasons,source_policy=c.curve_motion_status.get('policy'),
                max_predict_dt_s=maximum_predict_dt,
                path_family=getattr(path,'entry_family','LEGACY_FALLBACK'),first_blocked=first_blocked,
                blocked_events=blocked_events,
                final_recovery=dict(getattr(c,'curve_recovery_status',{})),
                assumptions='50ms raycast scan age; exact periodic wall anchors; real RF2O callbacks/gates')
        finally:c.close_curve_worker()


class CurveResponseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old=old_core();cls.path=core.plan_entry_path((5.08,.86,.075))

    def test_initial_feedforward_previews_upcoming_curve(self):
        new=core.PathFollower(self.path);old=self.old.PathFollower(self.path)
        new.command(tuple(self.path.samples[0,:3]),100.)
        old.command(tuple(self.path.samples[0,:3]),100.)
        self.assertGreater(new.ff,0.)
        self.assertGreater(new.output,old.output)
        self.assertLessEqual(new.output,.15)

    def test_preview_disabled_keeps_current_curvature_feedforward(self):
        follower=core.PathFollower(self.path)
        follower.command(tuple(self.path.samples[0,:3]),100.,preview_distance=0.)
        self.assertAlmostEqual(follower.ff,follower.curvature/6.)

    def test_long_gap_prime_does_not_freeze_zero(self):
        follower=core.PathFollower(self.path);pose=tuple(self.path.samples[100,:3])
        follower.time=99.;follower.output=0.
        self.assertGreater(follower.command(pose,100.),0.)
        self.assertLessEqual(abs(follower.output),.15+1e-12)

    def test_pause_preserves_output_and_real_elapsed_slew(self):
        follower=core.PathFollower(self.path);pose=tuple(self.path.samples[100,:3])
        follower.time=99.9;follower.output=.20;follower.integral=.008;follower.derivative=2.
        follower.reset_feedback(preserve_output=True)
        self.assertEqual(follower.output,.20);self.assertEqual(follower.time,99.9)
        self.assertEqual(follower.integral,0.)
        command=follower.command(pose,100.)
        self.assertLessEqual(abs(command-.20),.075+1e-9)
        self.assertLessEqual(abs(command),.32)

    def test_cold_reset_centres_model_and_limits_initial_step(self):
        follower=core.PathFollower(self.path);follower.output=.30;follower.response_output=.25
        follower.reset_feedback()
        self.assertEqual(follower.output,0.);self.assertEqual(follower.response_output,0.)
        follower.command(tuple(self.path.samples[100,:3]),100.)
        self.assertLessEqual(abs(follower.output),.15+1e-12)

    def test_command_rollout_models_actuator_lag_and_measured_speed(self):
        follower=core.PathFollower(self.path);pose=tuple(self.path.samples[100,:3])
        follower.command(pose,100.);follower.output=.32;follower.response_output=0.
        slow=core.command_horizon(pose,follower,6.,distance=.10,speed=.3)
        fast=core.command_horizon(pose,follower,6.,distance=.10,speed=1.2)
        # At equal distance a faster car has less time to build steering.
        self.assertLess(abs(core.wrap(fast[1][2]-pose[2])),abs(core.wrap(slow[1][2]-pose[2])))

    def test_delayed_closed_loop_nominal_response_completes_first_cone(self):
        result=simulate_entry(core.PathFollower,self.path,delay=.4,compute=.10,tau=.12,gain_factor=1.)
        self.assertFalse(result['collision'],result)
        self.assertTrue(result['reached'],result)
        self.assertLessEqual(result['maximum_command'],.32)

    def test_delay_and_servo_mismatch_matrix_keeps_body_clearance(self):
        for delay in (.3,.5):
            for compute in (.08,.15):
                for tau in (.08,.15):
                    for factor in (.8,1.,1.2):
                        with self.subTest(delay=delay,compute=compute,tau=tau,gain_factor=factor):
                            result=simulate_entry(core.PathFollower,self.path,
                                delay=delay,compute=compute,tau=tau,gain_factor=factor)
                            self.assertFalse(result['collision'],result)
                            self.assertTrue(result['reached'],result)
                            self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)
                            self.assertLessEqual(result['maximum_command'],.32)

    def test_speed_variation_with_long_latency_and_servo_lag(self):
        for speed in (.7,.9,1.2):
            for factor in (.8,1.,1.2):
                with self.subTest(speed=speed,gain_factor=factor):
                    result=simulate_entry(core.PathFollower,self.path,delay=.5,compute=.15,
                        tau=.15,gain_factor=factor,speed_mps=speed)
                    self.assertFalse(result['collision'],result)
                    self.assertTrue(result['reached'],result)
                    self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)
                    self.assertLessEqual(result['maximum_command'],.32)

    def test_real_controller_scan_and_prediction_gates_complete_entry(self):
        for factor in (.8,1.,1.2):
            with self.subTest(gain_factor=factor):
                result=simulate_controller_entry(delay=.5,compute=.08,tau=.15,gain_factor=factor)
                self.assertFalse(result['collision'],result)
                self.assertTrue(result['reached'],result)
                self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)
                self.assertNotIn('RECOVERING_SWEPT_OBSTACLE',result['stop_reasons'])

    def test_pressure_compute_case_obeys_explicit_source_age_limit(self):
        result=simulate_controller_entry(delay=.5,compute=.15,tau=.15,prediction_max_time=.60)
        self.assertFalse(result['reached'],result)
        self.assertFalse(result['collision'],result)
        self.assertEqual(result['zero_commands'],result['commands'])
        self.assertEqual(result['source_policy'],'SOURCE_PREDICTION_LIMIT')

    def test_pressure_compute_case_can_resume_with_bounded_075s_prediction(self):
        for factor in (.8,1.,1.2):
            with self.subTest(gain_factor=factor):
                result=simulate_controller_entry(delay=.5,compute=.15,tau=.15,
                    gain_factor=factor,prediction_max_time=.75)
                self.assertFalse(result['collision'],result)
                self.assertTrue(result['reached'],result)
                self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)

    def test_real_controller_high_speed_recovers_from_bounded_short_stops(self):
        result=simulate_controller_entry(delay=.5,compute=.15,tau=.15,speed_mps=1.2)
        self.assertFalse(result['collision'],result)
        self.assertTrue(result['reached'],result)
        self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)

    def test_nominal_two_cone_route_reaches_upper_corridor_in_closed_loop(self):
        result=simulate_entry(core.PathFollower,self.path,delay=.3,compute=.05,tau=.12,
                              gain_factor=1.,route_goal='upper_corridor')
        self.assertFalse(result['collision'],result)
        self.assertTrue(result['reached'],result)
        self.assertGreaterEqual(result['minimum_clearance_m'],.08,result)


def regression_report():
    previous=old_core();path=core.plan_entry_path((5.08,.86,.075));rows=[]
    for delay in (.3,.5):
        for compute in (.08,.15):
            for tau in (.08,.15):
                for factor in (.8,1.,1.2):
                    case=dict(delay=delay,compute=compute,tau=tau,gain_factor=factor)
                    rows.append(dict(case=case,
                        old_with_delayed_pose=simulate_entry(previous.PathFollower,path,**case,compensate=False),
                        old_same_pose_prediction=simulate_entry(previous.PathFollower,path,**case),
                        new=simulate_entry(core.PathFollower,path,**case,horizon_check=True)))
    speed_cases=[]
    for speed in (.7,.9,1.2):
        for factor in (.8,1.,1.2):
            case=dict(delay=.5,compute=.15,tau=.15,gain_factor=factor,speed_mps=speed)
            speed_cases.append(dict(case=case,new=simulate_entry(core.PathFollower,path,**case,horizon_check=True)))
    controller_cases=[]
    for compute in (.05,.08,.15):
        for factor in (.8,1.,1.2):
            case=dict(delay=.5,compute=compute,tau=.15,gain_factor=factor)
            controller_cases.append(dict(case=case,result=simulate_controller_entry(**case)))
    high_speed_case=dict(delay=.5,compute=.15,tau=.15,gain_factor=1.,speed_mps=1.2)
    controller_cases.append(dict(case=high_speed_case,result=simulate_controller_entry(**high_speed_case)))
    full_route_cases=[]
    for delay,compute,factor in ((.3,.05,1.),(.5,.08,1.),(.5,.15,.8),(.5,.15,1.2)):
        case=dict(delay=delay,compute=compute,tau=.12,gain_factor=factor,route_goal='upper_corridor')
        full_route_cases.append(dict(case=case,result=simulate_entry(core.PathFollower,path,**case)))
    return dict(assumptions=dict(start=(5.08,.86,.075),speed_mps=.9,calibrated_drive_input=.35,
        hardware_steering_limit=.32,nominal_curvature_gain=6.,controller_period_s='max(.10,compute)',
        yaw_rate_model='speed_mps * curvature_gain * applied_steering',preview_distance_m=.20,
        short_pause_s=.25,position_prediction='constant SE2 twist from delayed source pairs',
        scope='first cone entry/north passage; no measured vehicle dynamics certificate'),
        cases=rows,speed_cases=speed_cases,real_controller_cases=controller_cases,
        full_route_cases_without_sweep=full_route_cases,
        limitations=['Servo/speed/gain are scenario assumptions, not measured hardware calibration.',
            'The standalone follower matrix counts map horizon rejections but does not stop on them.',
            'Real controller cases use real source callbacks and sweep/stop gates with ideal periodic matched wall anchors.',
            'One severe full-route mismatch hits the lower divider at the second-cone approach; entry success does not prove all-route robustness.'])


if __name__=='__main__':
    if '--report' in sys.argv or '--save-report' in sys.argv:
        report=regression_report()
        if '--save-report' in sys.argv:
            destination=PACKAGE.parent/'response_simulation.json'
            destination.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            print(str(destination))
        else:print(json.dumps(report,ensure_ascii=False,indent=2))
    else:unittest.main(verbosity=2)
