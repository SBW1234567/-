#!/usr/bin/env python3
"""Installed controller / real DDS parking callback test in isolated DOMAIN226.

Only synthetic sensor publishers and the dry-run controller are constructed.
The terminal reference and FINISH_APPROACH phase are seeded explicitly; this is
not a physical car, actuator/braking simulation, or complete race validation.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',type=Path,default=Path('/home/bianbu/racecar'))
    parser.add_argument('--report',type=Path,default=Path('/tmp/real_ros_finish_parking_v35_26.json'))
    args=parser.parse_args()
    os.environ['ROS_DOMAIN_ID']='221';os.environ['ROS_LOCALHOST_ONLY']='1'
    root=args.workspace.resolve()
    executable=root/'install/racecar/lib/racecar/race_task_controller.py'
    config=root/'install/racecar/share/racecar/config/competition_params.yaml'
    prefix='/codex_validation/parking'
    report=dict(passed=False,workspace=str(root),ros_domain_id=221,localhost_only=True,
                driver_started=False,sensors_started=False,synthetic_sensor_messages=True,
                physical_command_topic_used=False,phase_seed='FINISH_APPROACH',
                reference_seed=[5.45,3.55,0.],phases=[],states=[],commands=[],errors=[])
    c=observer=executor=rclpy=None;started=time.monotonic()
    try:
        if not executable.is_file() or not config.is_file():raise RuntimeError('Missing installed source/config')
        report['controller_sha256']=hashlib.sha256(executable.read_bytes()).hexdigest()
        report['config_sha256']=hashlib.sha256(config.read_bytes()).hexdigest()
        import rclpy as real_rclpy
        from rclpy.node import Node
        from rclpy.executors import SingleThreadedExecutor
        from nav_msgs.msg import Odometry
        from sensor_msgs.msg import LaserScan
        from std_msgs.msg import Float32MultiArray,Int16MultiArray,String
        from geometry_msgs.msg import Twist
        rclpy=real_rclpy
        ros_args=['--ros-args','--params-file',str(config)]
        for value in ('dry_run:=true','curve_route:=true','relative_route:=true',
                      'exit_continuous:=true','entry_v32_enabled:=true',
                      'entry_v33_enabled:=true','entry_v34_enabled:=true',
                      'odom_topic:='+prefix+'/odom','lidar_topic:='+prefix+'/lidar',
                      'boundary_topic:='+prefix+'/boundary','vision_topic:='+prefix+'/vision'):
            ros_args.extend(('-p',value))
        ros_args.extend(('-r','/scan:='+prefix+'/scan','-r','/race/proposed_cmd_vel:='+prefix+'/cmd',
                         '-r','/car_cmd_vel:='+prefix+'/unused_actuator_cmd'))
        report['ros_arguments']=ros_args;rclpy.init(args=ros_args)
        sys.path.insert(0,str(executable.parent))
        spec=importlib.util.spec_from_file_location('installed_finish_controller_v35_26',executable)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        c=module.RaceTaskController()
        if not c.dry_run:raise RuntimeError('dry_run override failed')
        observer=Node('codex_v35_26_parking_observer')
        executor=SingleThreadedExecutor();executor.add_node(c);executor.add_node(observer)
        def twist(msg):
            values=[msg.linear.x,msg.linear.y,msg.linear.z,msg.angular.x,msg.angular.y,msg.angular.z]
            if not all(math.isfinite(v) for v in values):report['errors'].append('Nonfinite proposed command')
            report['commands'].append(dict(t=time.monotonic()-started,drive=msg.linear.x,steering=msg.angular.z))
        def phase(msg):
            if not report['phases'] or report['phases'][-1]['phase']!=msg.data:
                report['phases'].append(dict(t=time.monotonic()-started,phase=msg.data))
        def status(msg):
            try:parking=json.loads(msg.data).get('parking')
            except (ValueError,TypeError):return
            if parking is not None and (not report['states'] or report['states'][-1]['state']!=parking.get('state')):
                report['states'].append(dict(t=time.monotonic()-started,**parking))
        subscriptions=[observer.create_subscription(Twist,prefix+'/cmd',twist,10),
                       observer.create_subscription(String,'/race/task_phase',phase,10),
                       observer.create_subscription(String,'/race/entry_status',status,10)]
        pubs=dict(odom=observer.create_publisher(Odometry,prefix+'/odom',10),
                  scan=observer.create_publisher(LaserScan,prefix+'/scan',10),
                  lidar=observer.create_publisher(Float32MultiArray,prefix+'/lidar',10),
                  boundary=observer.create_publisher(Float32MultiArray,prefix+'/boundary',10),
                  vision=observer.create_publisher(Int16MultiArray,prefix+'/vision',10))
        def spin(seconds):
            deadline=time.monotonic()+seconds
            while time.monotonic()<deadline:executor.spin_once(timeout_sec=min(.01,max(0.,deadline-time.monotonic())))
        def expect(condition,why):
            if not condition:raise RuntimeError(why)
        def sensors(laser_x):
            stamp=observer.get_clock().now().to_msg();y=3.55
            odom=Odometry();odom.header.stamp=stamp;odom.header.frame_id='odom';odom.child_frame_id='base_footprint'
            odom.pose.pose.position.x=laser_x-.07;odom.pose.pose.position.y=y;odom.pose.pose.orientation.w=1.
            scan=LaserScan();scan.header.stamp=stamp;scan.header.frame_id='laser'
            scan.angle_min=-math.pi;scan.angle_increment=2*math.pi/720;scan.angle_max=math.pi-scan.angle_increment
            scan.range_min=.05;scan.range_max=8.;scan.scan_time=.1;scan.time_increment=0.
            ranges=[]
            for i in range(720):
                angle=scan.angle_min+i*scan.angle_increment;dx,dy=math.cos(angle),math.sin(angle)
                candidates=[]
                if dx>1e-6:candidates.append((8.-laser_x)/dx)
                if dy>1e-6:candidates.append((4.-y)/dy)
                elif dy<-1e-6:candidates.append((3.1-y)/dy)
                ranges.append(min(candidates) if candidates else float('inf'))
            scan.ranges=ranges
            lidar=Float32MultiArray();lidar.data=[0.,0.,0.,0.,8.-laser_x,0.,0.,0.,.45,.45,0.,1.]
            boundary=Float32MultiArray();boundary.data=[.45,.45,8.-laser_x,0.,0.,1.,1.,.45,.45]
            vision=Int16MultiArray();vision.data=[0,0,0,0,0]
            pubs['odom'].publish(odom);pubs['scan'].publish(scan)
            pubs['lidar'].publish(lidar);pubs['boundary'].publish(boundary)
            pubs['vision'].publish(vision)
        def feed(seconds,position):
            start=time.monotonic();next_send=start
            while time.monotonic()-start<seconds:
                now=time.monotonic()
                if now>=next_send:
                    next_send=now+.10
                    sensors(position(now-start) if callable(position) else position)
                executor.spin_once(timeout_sec=.01)
        spin(.5)
        c.final_straight_reference=(5.45,3.55,0.)
        c.final_straight_status=dict(state='ANCHORED',track_reference=(5.45,3.55,0.))
        c.set_phase(c.FINISH_APPROACH)
        # Real callbacks receive a cold, stationary pose 1.50m from the board.
        # V24 must sustain useful startup input rather than repeating V22's
        # ineffective .12s pulses. Synthetic motion below is prescribed and
        # is not presented as a motor/actuator response simulation.
        start_commands=len(report['commands'])
        feed(1.1,6.5)
        expect(c.phase==c.FINISH_APPROACH,'Parked outside full-body window was declared FINISHED')
        sustained=0.;positive_start=None
        for command in report['commands'][start_commands:]:
            if command['drive']>0.:
                if positive_start is None:positive_start=command['t']
                sustained=max(sustained,command['t']-positive_start)
            else:positive_start=None
        report['far_start_continuous_positive_s']=sustained
        expect(sustained>=.35,'Cold far start still limited to ineffective short pulses')
        expect(any(x['drive']>=.34 for x in report['commands'][start_commands:]),
               'Far startup did not reach the verified effective input')
        report['outside_window_not_finished']=True
        feed(5.3,lambda t:min(7.56,6.5+.20*t))
        expect(c.phase==c.FINISH_APPROACH,'Moving into parking zone immediately claimed completion')
        before=len(report['commands']);spin(.55)
        expect(c.phase==c.FINISH_APPROACH,'Stale source observation completed parking')
        expect(any(abs(x['drive'])<1e-12 for x in report['commands'][before:]),'Stale sensors did not yield zero drive')
        report['moving_and_stale_cannot_complete']=True
        feed(2.2,7.56);spin(.12)
        expect(c.phase==c.FINISHED,'Fresh stable body-inside observations did not complete parking')
        expect(c.finish_parking_status.get('complete'),'FINISHED lacked parking completion evidence')
        report['verified_complete']=dict(c.finish_parking_status)
        expect(report['commands'] and all(abs(x['drive'])<1e-12 for x in report['commands'][-2:]),
               'Final proposed commands were not zero')
        topics=[name for name,_ in observer.get_topic_names_and_types()]
        report['published_topics']=topics
        expect('/car_cmd_vel' not in topics,'Physical command topic unexpectedly present')
    except Exception as exc:report['errors'].append(type(exc).__name__+': '+str(exc))
    finally:
        report['observed_seconds']=time.monotonic()-started
        if c is not None:
            try:c.publish_stop();c.close_curve_worker();c.destroy_node()
            except Exception as exc:report['errors'].append('Controller cleanup: '+str(exc))
        if observer is not None:observer.destroy_node()
        if executor is not None:executor.shutdown()
        if rclpy is not None and rclpy.ok():rclpy.shutdown()
        report['passed']=not report['errors'];args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report.get(k) for k in ('passed','outside_window_not_finished','far_start_continuous_positive_s',
          'moving_and_stale_cannot_complete','verified_complete','errors')},ensure_ascii=False),flush=True)
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
