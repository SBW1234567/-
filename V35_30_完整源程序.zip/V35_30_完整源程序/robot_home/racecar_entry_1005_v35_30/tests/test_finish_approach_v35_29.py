"""Optional fast parking, irreversible body-window coast and independent dynamics.

The frozen V28 method supplies the explicit comparison. Both variants run
through the current controller, acquisition-time sensors and physical-body
checks. The log-compatible plants bracket observed input/speed pairs; they
are stipulated models, not a motor calibration or promised race time.
"""
import ast
from contextlib import contextmanager, ExitStack
import copy
import math
from pathlib import Path
import unittest
from unittest.mock import patch

import test_finish_dynamics_v35_23 as dynamics
import test_finish_distance_v35_24 as distance_tests
import test_finish_parking_v35_22 as fixture

cm = fixture.cm
PACKAGE = Path(__file__).resolve().parents[1]
BASELINE = PACKAGE/'tests/baselines/controller_before_v35_29.py'
CURRENT = PACKAGE/'payload/src/racecar/scripts/race_task_controller.py'


def command_node(path, name='finish_parking_command'):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef)
               and n.name == 'RaceTaskController')
    return next(n for n in cls.body if isinstance(n, ast.FunctionDef)
                and n.name == name)


@contextmanager
def frozen_v28_command():
    # V30 also changes reset/observation. Freeze the full parking observation
    # chain so the historical V28 comparison cannot inherit current tracking.
    with ExitStack() as patches:
        for name in ('finish_parking_reset', 'finish_parking_observation',
                     'finish_parking_command', 'finish_parking_verified'):
            node = command_node(BASELINE, name)
            namespace = dict(cm.__dict__)
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(BASELINE), 'exec'),
                 namespace)
            patches.enter_context(patch.object(cm.RaceTaskController, name, namespace[name]))
        yield


class FinishApproachTargetV3529Tests(unittest.TestCase):
    setUp = fixture.FinishParkingV3522Tests.setUp
    refresh_sensors = fixture.FinishParkingV3522Tests.refresh_sensors
    receive_laser_pose = fixture.FinishParkingV3522Tests.receive_laser_pose
    prepare = fixture.FinishParkingV3522Tests.prepare
    scan = fixture.FinishParkingV3522Tests.scan
    advance = fixture.FinishParkingV3522Tests.advance
    tick = fixture.FinishParkingV3522Tests.tick
    stopped_ticks = fixture.FinishParkingV3522Tests.stopped_ticks

    def make(self, distance=2.2, speed=.12):
        controller = self.prepare(8.-distance, speed=speed)
        controller.finish_parking.update(rolling_evidence=True, last_drive=.28,
                                        adjusted_at=self.now)
        return controller

    def issue(self, controller, distance=2.2, speed=.12, heading=0., closing=.12,
              scan_age=.05, odom_age=.05, valid=True, front=None, settled=False,
              raw_distance=Ellipsis, omit_raw=False):
        controller.curve_motion_velocity = (speed, 0., 0.)
        observation = dict(valid=valid, reason='TEST_INVALID_BOARD',
                           map_remaining_m=distance, distance_m=distance,
                           body_board_angle_rad=heading,
                           raw_board_distance_m=distance if raw_distance is Ellipsis else raw_distance,
                           board_closing_mps=closing, scan_source_age_s=scan_age)
        if omit_raw:
            observation.pop('raw_board_distance_m')
        detail = dict(odom_source_age_s=odom_age,
                      odom_source_stamp=controller.curve_source_now())
        with patch.object(controller, 'finish_parking_observation', return_value=observation), \
             patch.object(controller, 'finish_parking_settled', return_value=settled):
            drive = controller.finish_parking_command(self.pose, detail,
                distance if front is None else front, self.now)
        return drive, dict(controller.finish_parking_status)

    def test_first_finite_far_aligned_board_enables_fast_target_once(self):
        c = self.make()
        drive, status = self.issue(c)
        self.assertGreater(drive, 0.)
        self.assertEqual(status['target_speed_mps'], .45)
        self.assertEqual(status['fast_approach_decision'], 'FAST_FAR_ALIGNED')
        self.assertEqual(status['fast_approach_initial_range_m'], 2.2)
        self.assertEqual(status['fast_approach_coast_goal_m'], .42)
        self.assertTrue(status['fast_approach_decided'])
        self.assertTrue(status['fast_approach_eligible'])
        drive, status = self.issue(c, distance=1.1)
        self.assertGreater(drive, 0.)
        self.assertEqual(status['target_speed_mps'], .45)
        self.assertEqual(status['fast_approach_initial_range_m'], 2.2)

    def test_near_first_observation_never_upgrades_after_distance_jump(self):
        for distance in (.62, .85, 1.1, 1.6, 1.799):
            with self.subTest(distance=distance):
                c = self.make(distance)
                drive, status = self.issue(c, distance=distance)
                self.assertFalse(status['fast_approach_eligible'])
                self.assertEqual(status['fast_approach_decision'], 'BASELINE_INITIAL_NEAR')
                drive, status = self.issue(c, distance=2.2)
                self.assertFalse(status['fast_approach_eligible'])
                self.assertEqual(status['fast_approach_initial_range_m'], distance)
                self.assertLessEqual(status['target_speed_mps'], .34)

    def test_near_start_same_history_drive_matches_frozen_v28(self):
        for distance in (.62, .70, .85, .90, 1.0, 1.10, 1.60, 1.799):
            with self.subTest(distance=distance):
                with frozen_v28_command():
                    old_drive, old_status = self.issue(self.make(distance), distance=distance)
                drive, status = self.issue(self.make(distance), distance=distance)
                self.assertEqual(drive, old_drive)
                self.assertEqual(status['target_speed_mps'], old_status['target_speed_mps'])
                self.assertEqual(status['state'], old_status['state'])

    def test_bad_initial_heading_never_upgrades_after_alignment(self):
        c = self.make()
        self.issue(c, heading=math.radians(10.1))
        drive, status = self.issue(c, heading=0.)
        self.assertFalse(status['fast_approach_eligible'])
        self.assertEqual(status['fast_approach_decision'], 'BASELINE_INITIAL_HEADING')
        self.assertLessEqual(status['target_speed_mps'], .34)

    def test_invalid_or_nonfinite_initial_board_does_not_decide_qualification(self):
        for distance, heading, valid in ((2.2, 0., False), (math.nan, 0., True),
                                         (math.inf, 0., True), (2.2, math.nan, True)):
            with self.subTest(distance=distance, heading=heading, valid=valid):
                c = self.make()
                drive, status = self.issue(c, distance=distance, heading=heading, valid=valid)
                self.assertFalse(status['fast_approach_decided'])
                self.assertFalse(status['fast_approach_eligible'])
                drive, status = self.issue(c)
                self.assertTrue(status['fast_approach_eligible'])

    def test_stale_or_missing_initial_board_age_cannot_qualify_fast(self):
        for scan_age in (None, math.nan, .301, -.03):
            with self.subTest(scan_age=scan_age):
                c = self.make()
                drive, status = self.issue(c, scan_age=scan_age)
                self.assertEqual(drive, 0.)
                self.assertFalse(status['fast_approach_decided'])
                self.assertFalse(status['fast_approach_eligible'])
                drive, status = self.issue(c, distance=1.6)
                self.assertFalse(status['fast_approach_eligible'])
                self.assertEqual(status['fast_approach_initial_range_m'], 1.6)

    def test_point_two_six_scan_age_keeps_original_ordinary_control_without_fast(self):
        with frozen_v28_command():
            old_drive, old_status = self.issue(self.make(), scan_age=.26)
        drive, status = self.issue(self.make(), scan_age=.26)
        self.assertGreater(drive, 0.)
        self.assertEqual(drive, old_drive)
        self.assertEqual(status['target_speed_mps'], old_status['target_speed_mps'])
        self.assertFalse(status['fast_approach_eligible'])
        self.assertFalse(status['fast_approach_decided'])
        c = self.prepare_rolling_coast()
        drive, status = self.issue(c, distance=1.3, speed=.15, closing=.15, scan_age=.26)
        self.assertEqual(drive, 0.)
        self.assertEqual(status['fast_rolling_resume_count'], 0)
        self.assertTrue(status['final_coast'])

    def test_reset_new_run_clears_previous_fast_decision_and_body_latch(self):
        c = self.make()
        self.issue(c)
        self.issue(c, distance=.56, speed=.01, closing=.01)
        self.assertTrue(c.finish_parking['body_window_seen'])
        old_state = c.finish_parking
        c.finish_parking_reset(self.now)
        self.assertIsNot(c.finish_parking, old_state)
        drive, status = self.issue(c, distance=1.6)
        self.assertFalse(status['fast_approach_eligible'])
        self.assertFalse(status['body_window_seen'])
        self.assertEqual(status['fast_rolling_resume_count'], 0)

    def test_body_window_seen_latches_neutral_even_after_large_range_jump(self):
        c = self.make()
        self.issue(c)
        drive, status = self.issue(c, distance=.56, speed=.04, closing=.04)
        self.assertEqual(drive, 0.)
        self.assertTrue(status['body_window_seen'])
        for distance in (.8, 1.0, 1.8, 2.2):
            for settled in (False, True):
                drive, status = self.issue(c, distance=distance, speed=.10, closing=.10, settled=settled)
                self.assertEqual(drive, 0.)
                self.assertTrue(status['body_window_seen'])
                self.assertEqual(status['state'], 'PARK_VERIFY_BODY_WINDOW')
                self.assertFalse(status['complete'])

    def prepare_rolling_coast(self):
        c = self.make()
        self.issue(c)
        c.finish_parking.update(final_coast=True, near=True, last_drive=0.,
                                rolling_evidence=True, neutral_since=self.now-.2,
                                neutral_source=c.curve_source_now())
        return c

    def test_rolling_resume_requires_both_fresh_motion_sources(self):
        c = self.prepare_rolling_coast()
        drive, status = self.issue(c, distance=1.3, speed=.15, closing=.15)
        self.assertGreater(drive, 0.)
        self.assertFalse(status['final_coast'])
        self.assertEqual(status['fast_rolling_resume_count'], 1)
        self.assertFalse(c.finish_parking['trim_active'])

    def test_missing_stale_or_inconsistent_board_motion_cannot_resume(self):
        cases = [dict(closing=None), dict(closing=math.nan), dict(closing=math.inf),
                 dict(closing=0.), dict(closing=.025), dict(closing=.401),
                 dict(scan_age=None), dict(scan_age=.251), dict(scan_age=math.nan),
                 dict(scan_age=-.03), dict(odom_age=.251), dict(valid=False)]
        for config in cases:
            with self.subTest(config=config):
                c = self.prepare_rolling_coast()
                drive, status = self.issue(c, distance=1.3, speed=.15, **config)
                self.assertEqual(drive, 0.)
                self.assertEqual(status['fast_rolling_resume_count'], 0)
                self.assertTrue(status['final_coast'])

    def test_only_two_early_rolling_resumes_are_permitted(self):
        c = self.prepare_rolling_coast()
        for expected in (1, 2):
            c.finish_parking.update(final_coast=True, last_drive=0.)
            drive, status = self.issue(c, distance=1.3, speed=.15, closing=.15)
            self.assertGreater(drive, 0.)
            self.assertEqual(status['fast_rolling_resume_count'], expected)
        c.finish_parking.update(final_coast=True, last_drive=0.)
        drive, status = self.issue(c, distance=1.3, speed=.15, closing=.15)
        self.assertEqual(drive, 0.)
        self.assertEqual(status['fast_rolling_resume_count'], 2)
        self.assertEqual(status['state'], 'PARK_FINAL_COAST')

    def test_rolling_resume_requires_remaining_room_and_does_not_override_obstacle(self):
        cases = [dict(distance=.80), dict(distance=1.3, front=.20),
                 dict(distance=1.3, speed=.069), dict(distance=1.3, speed=.301),
                 dict(distance=1.3, heading=math.radians(13))]
        for config in cases:
            with self.subTest(config=config):
                c = self.prepare_rolling_coast()
                kwargs = dict(distance=1.3, speed=.15, closing=.15)
                kwargs.update(config)
                drive, status = self.issue(c, **kwargs)
                self.assertEqual(drive, 0.)
                self.assertEqual(status['fast_rolling_resume_count'], 0)

    def test_fast_target_never_claims_complete_while_rolling_inside_box(self):
        c = self.make()
        self.issue(c)
        drive, status = self.issue(c, distance=.56, speed=.12, closing=.12)
        self.assertEqual(drive, 0.)
        self.assertFalse(status['complete'])
        self.assertEqual(status['state'], 'PARK_VERIFY_STOP')

    def test_noise_projection_cannot_latch_body_before_raw_rear_proof(self):
        # Values from the first full-suite failure: true raw rear remained
        # outside although odometry projection had already crossed the edge.
        projected, raw = .5924116123467629, .5982116124192052
        c = self.make(raw, speed=0.)
        drive, status = self.issue(c, distance=projected, raw_distance=raw,
                                   speed=0., closing=0., settled=True)
        self.assertFalse(status['body_inside'])
        self.assertFalse(status['body_window_seen'])
        self.assertFalse(status['complete'])
        self.assertEqual(status['body_rear_check_distance_m'], raw)
        drive, status = self.issue(c, distance=projected, raw_distance=.594,
                                   speed=0., closing=0., settled=True)
        self.assertEqual(drive, 0.)
        self.assertTrue(status['body_inside'])
        self.assertTrue(status['body_window_seen'])

    def test_rear_proof_requires_both_projected_and_raw_distance_inside(self):
        for projected, raw in ((.592, .598), (.598, .592)):
            with self.subTest(projected=projected, raw=raw):
                c = self.make(.598, speed=0.)
                drive, status = self.issue(c, distance=projected, raw_distance=raw,
                                           speed=0., closing=0., settled=True)
                self.assertFalse(status['body_inside'])
                self.assertFalse(status['body_window_seen'])
                self.assertFalse(status['complete'])
                self.assertEqual(status['body_rear_check_distance_m'], .598)

    def test_invalid_or_missing_raw_board_holds_neutral_without_latching(self):
        for config in ([dict(raw_distance=v) for v in (None, math.nan, math.inf, 0., -.1)]
                       + [dict(omit_raw=True)]):
            with self.subTest(config=config):
                c = self.make(.56, speed=0.)
                drive, status = self.issue(c, distance=.56, speed=0., closing=0.,
                                           settled=True, **config)
                self.assertEqual(drive, 0.)
                self.assertEqual(status['state'], 'PARK_WAIT_RAW_BOARD_DISTANCE')
                self.assertFalse(status['body_window_seen'])
                self.assertFalse(status['complete'])
                self.assertFalse(status['fast_approach_decided'])

    def test_raw_rear_check_does_not_relax_projected_front_margin(self):
        c = self.make(.22, speed=0.)
        drive, status = self.issue(c, distance=.22, raw_distance=.56, front=.56,
                                   speed=0., closing=0., settled=True)
        self.assertEqual(drive, 0.)
        self.assertFalse(status['body_inside'])
        self.assertFalse(status['body_window_seen'])
        self.assertFalse(status['complete'])

    def test_new_callback_raw_rear_outside_blocks_previously_complete_phase(self):
        c = self.prepare(7.44)
        self.stopped_ticks(9)
        self.assertTrue(c.finish_parking_status['complete'])
        self.assertTrue(c.finish_parking_verified(self.now))
        observation = c.finish_parking_observation(self.pose, self.now)
        observation.update(distance_m=.5924116123467629,
                           raw_board_distance_m=.5982116124192052)
        with patch.object(c, 'finish_parking_observation', return_value=observation):
            self.assertFalse(c.finish_parking_verified(self.now))
            c.update_phase(self.now)
            self.assertEqual(c.phase, c.FINISH_APPROACH)
        drive, status = self.issue(c, distance=.5924116123467629,
                                   raw_distance=.5982116124192052,
                                   speed=0., closing=0., settled=True)
        self.assertEqual(drive, 0.)
        self.assertTrue(status['body_window_seen'])
        self.assertFalse(status['complete'])
        self.assertEqual(status['state'], 'PARK_VERIFY_BODY_WINDOW')

    def test_verification_rejects_missing_or_nonfinite_raw_callback(self):
        c = self.prepare(7.44)
        self.stopped_ticks(9)
        self.assertTrue(c.finish_parking_status['complete'])
        original = c.finish_parking_observation(self.pose, self.now)
        for raw in (None, math.nan, math.inf, 0., -.1, Ellipsis):
            with self.subTest(raw=raw):
                observation = dict(original, raw_board_distance_m=raw)
                if raw is Ellipsis:
                    observation.pop('raw_board_distance_m')
                with patch.object(c, 'finish_parking_observation', return_value=observation):
                    self.assertFalse(c.finish_parking_verified(self.now))


class LogCompatibleMotorPlant(dynamics.MotorPlant):
    """Hypothetical forward response anchored loosely to two observed runs."""
    peak_speed = .50

    def running_speed(self, pwm):
        points = ((.24, 0.), (.28, .16), (.30, .25), (.32, .35),
                  (.35, self.peak_speed))
        if pwm <= points[0][0]:
            return 0.
        for a, b in zip(points, points[1:]):
            if pwm <= b[0]:
                return a[1]+(b[1]-a[1])*(pwm-a[0])/(b[0]-a[0])
        return self.peak_speed


class FasterLogCompatibleMotorPlant(LogCompatibleMotorPlant):
    peak_speed = .60


class HighGainPressurePlant(dynamics.MotorPlant):
    """Deliberate pressure plant, not the measured .35-input vehicle response."""
    assumed_gain = 1.35
    assumed_coast_tau = .40

    def running_speed(self, pwm):
        return self.assumed_gain*super().running_speed(pwm)

    def step(self, pwm, dt=.005):
        self.coast_tau = self.assumed_coast_tau
        return super().step(pwm, dt)


class HighGainLongCoastPressurePlant(HighGainPressurePlant):
    assumed_coast_tau = .50


class NormalGainLongCoastPressurePlant(HighGainPressurePlant):
    assumed_gain = 1.0
    assumed_coast_tau = .50


class HighGainShortCoastPressurePlant(HighGainPressurePlant):
    assumed_coast_tau = .30


class FinishApproachDynamicsV3529Tests(unittest.TestCase):
    comparisons = []
    noise_regressions = []

    def compare(self, name, plant=dynamics.MotorPlant, **config):
        results = []
        for baseline in (True, False):
            case = dynamics.FinishDynamicsV3523Tests()
            try:
                case.setUp()
                with patch.object(dynamics, 'MotorPlant', plant):
                    if baseline:
                        with frozen_v28_command():
                            result = case.rollout('V28_'+name, **config)
                    else:
                        result = case.rollout('V29_'+name, **config)
                # rollout independently checks real body containment, continuing
                # coast after FINISHED, bounded input, and physical standstill.
                results.append(result)
            finally:
                case.doCleanups()
        before, after = results
        diagnostic = dict(scenario=name,
                          before_s=before['elapsed_s'], after_s=after['elapsed_s'],
                          before_bursts=before['positive_bursts'],
                          after_bursts=after['positive_bursts'])
        # Performance is reported alongside independently checked physical
        # containment. Qualification is decided from the first actual valid
        # delayed board observation, not from this test's nominal start x.
        self.assertLessEqual(after['last_status'].get('fast_rolling_resume_count', 0), 2)
        if not after['last_status'].get('fast_approach_eligible'):
            # Near starts keep the original speed law. Raw rear proof may
            # extend the last continuous positive segment (weak_1p2: .20s),
            # so full history equality would forbid this intended correction.
            old_positive = [(p['t'], p['drive']) for p in before['trace'] if p['drive'] > 0.]
            new_positive = [(p['t'], p['drive']) for p in after['trace'] if p['drive'] > 0.]
            self.assertEqual(new_positive[:len(old_positive)], old_positive, diagnostic)
            self.assertEqual(after['positive_bursts'], before['positive_bursts'], diagnostic)
            self.assertLessEqual(new_positive[-1][0]-old_positive[-1][0], .30, diagnostic)
            self.assertLessEqual(after['elapsed_s']-before['elapsed_s'], .30, diagnostic)
            self.assertLessEqual(before['true_distance_m']-after['true_distance_m'], .03, diagnostic)
        if name in ('normal_2p2', 'log_2p2', 'log_fast_2p2'):
            self.assertGreater(before['elapsed_s']-after['elapsed_s'], .50, diagnostic)
        self.assertGreaterEqual(after['true_distance_m'], .229, diagnostic)
        self.assertLessEqual(after['true_distance_m'], .596, diagnostic)
        self.assertLess(after['true_speed_mps'], .05, diagnostic)
        self.comparisons.append(dict(scenario=name, plant=plant.__name__,
            synthetic_not_vehicle_calibration=True,
            assumed_speed_gain=getattr(plant, 'assumed_gain', 1.0),
            assumed_coast_tau=getattr(plant, 'assumed_coast_tau', .40),
            before={k: v for k, v in before.items() if k != 'trace'},
            after={k: v for k, v in after.items() if k != 'trace'}))

    def test_normal_far_start(self):
        self.compare('normal_2p2', x=5.8)

    def test_high_friction_point_three_one_physical_parking(self):
        self.compare('friction31_2p2', x=5.8, dynamic_threshold=.31)

    def test_high_friction_point_three_three_physical_parking(self):
        self.compare('friction33_2p2', x=5.8, dynamic_threshold=.33)

    def test_slow_breakaway_with_independent_sensor_lag(self):
        self.compare('lag_2p2', x=5.8, start_delay=.5, accel_tau=.30,
                     odom_delay=.20, scan_delay=.15)

    def test_weak_start_far(self):
        self.compare('weak_2p2', distance_tests.SluggishStartPlant, x=5.8)

    def test_weak_start_near_does_not_gain_extra_pulses(self):
        self.compare('weak_1p2', distance_tests.SluggishStartPlant, x=6.8)

    def test_log_compatible_far_response(self):
        self.compare('log_2p2', LogCompatibleMotorPlant, x=5.8)

    def test_log_compatible_slow_breakaway(self):
        self.compare('log_lag_2p2', LogCompatibleMotorPlant, x=5.8,
                     start_delay=.5, accel_tau=.25, odom_delay=.20, scan_delay=.15)

    def test_faster_log_compatible_far_response(self):
        self.compare('log_fast_2p2', FasterLogCompatibleMotorPlant, x=5.8)

    def test_log_compatible_longer_approach(self):
        self.compare('log_far_2p5', LogCompatibleMotorPlant, x=5.5)

    def test_log_compatible_near_approach(self):
        self.compare('log_near_1p2', LogCompatibleMotorPlant, x=6.8)

    def test_faster_log_compatible_middle_approach(self):
        self.compare('log_fast_near_1p6', FasterLogCompatibleMotorPlant, x=6.4)

    def test_previously_failing_high_gain_delayed_case_preserves_front_margin(self):
        self.compare('pressure_gain135_coast40_delay25', HighGainPressurePlant,
                     x=5.8, start_delay=.5, accel_tau=.30, odom_delay=.25, scan_delay=.15)

    def test_previously_failing_high_gain_long_coast_delayed_case(self):
        self.compare('pressure_gain135_coast50_delay25', HighGainLongCoastPressurePlant,
                     x=5.8, start_delay=.5, accel_tau=.30, odom_delay=.25, scan_delay=.15)

    def test_previously_failing_normal_gain_long_coast_delayed_case(self):
        self.compare('pressure_gain100_coast50_delay25', NormalGainLongCoastPressurePlant,
                     x=5.8, start_delay=.5, accel_tau=.20, odom_delay=.25, scan_delay=.15)

    def test_known_high_gain_short_coast_slowdown_still_parks_physically(self):
        # Retain the disclosed performance counterexample: safety completion is
        # not a promise that every stipulated plant is faster or less pulsed.
        self.compare('pressure_gain135_coast30_delay20_performance_limit',
                     HighGainShortCoastPressurePlant, x=5.8, start_delay=.5,
                     accel_tau=.30, odom_delay=.20, scan_delay=.15)

    def test_observed_millimetre_odom_noise_cannot_finish_rear_outside(self):
        # Reproduce the unmodified full-suite failure with independent raw
        # scans and the same 1mm/0.20s odometry noise; inspect physical outcome.
        receive = dynamics.FinishDynamicsV3523Tests.receive_laser_pose
        def noisy(case, pose, source=None):
            stamp = case.source_now if source is None else source
            delta = .001*math.sin(stamp*2*math.pi/.20)
            return receive(case, (pose[0]+delta, pose[1], pose[2]), source=source)
        case = dynamics.FinishDynamicsV3523Tests()
        try:
            case.setUp()
            with patch.object(dynamics, 'MotorPlant', distance_tests.SluggishStartPlant), \
                 patch.object(dynamics.FinishDynamicsV3523Tests, 'receive_laser_pose', noisy):
                result = case.rollout('V29_weak_1mm_noise_rear_proof', x=5.6,
                    start_delay=.30, accel_tau=.25, micro_speed=.04,
                    nonlinear_coast=True, odom_delay=.15, scan_delay=.06)
            self.assertTrue(result['completed'])
            self.assertLessEqual(result['true_distance_m'], .596)
            self.assertGreaterEqual(result['true_distance_m'], .229)
            status = result['last_status']
            self.assertLessEqual(status['body_rear_check_distance_m'],
                                 .80-status['body_rear_extent_m']-.02)
            self.assertGreaterEqual(status['body_rear_check_distance_m'],
                                    status['raw_board_distance_m'])
            self.noise_regressions.append({k: v for k, v in result.items() if k != 'trace'})
        finally:
            case.doCleanups()


if __name__ == '__main__':
    unittest.main()
