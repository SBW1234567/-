"""V18 six-file install/rollback checks using real payloads and temporary trees."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE))
import apply_patch as installer

class PackageV3518Tests(unittest.TestCase):
    def test_exact_six_file_overlay_includes_vision_and_yaml_rollback(self):
        base,overlay,changes=installer.load_manifests()
        self.assertEqual(overlay['version'],'CROSSWALK_CURVE_1002_V35_18')
        self.assertEqual(base['version'],overlay['base'])
        self.assertEqual(overlay['base'],'FINAL_STRAIGHT_1002_V35_16')
        self.assertEqual(len(changes),6)
        for relative in ('src/racecar/scripts/ican_vision_node.py','src/racecar/config/competition_params.yaml'):
            self.assertIn(relative,changes)
            self.assertNotIn(relative,base['dependencies'])
            self.assertIsNotNone(changes[relative]['installed_path'])

    def fixture(self):
        base,overlay,changes=installer.load_manifests()
        base=copy.deepcopy(base)
        base['files']=[i for i in base['files'] if i['path'] in changes]
        cmake=b'project(racecar)\n'
        base['dependencies']={'src/racecar/CMakeLists.txt':hashlib.sha256(cmake).hexdigest()}
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name)/'racecar'
        for relative,data in [('src/racecar/CMakeLists.txt',cmake)]:
            p=root/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for relative,item in changes.items():
            for name in (relative,item['installed_path']):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(PACKAGE/'rollback'/relative,target)
        loader=patch.object(installer,'load_manifests',return_value=(base,overlay,changes));loader.start();self.addCleanup(loader.stop)
        running=patch.object(installer,'active_race_processes',return_value=[]);running.start();self.addCleanup(running.stop)
        return root,changes

    def build_fixture(self,root,changes):
        for relative,item in changes.items():shutil.copyfile(root/relative,root/item['installed_path'])

    def test_all_six_sources_and_installed_files_return_to_exact_v16(self):
        root,changes=self.fixture()
        installer.validate_tree(root,'original_v35',binaries=False)
        installer.copy_version(root,binaries=False)
        archives=list(root.parent.glob('racecar_before_entry_v35_18_*.tar.gz'))
        self.assertEqual(len(archives),1)
        with tarfile.open(archives[0]) as archive:
            self.assertEqual(set(archive.getnames()),set(changes))
            for relative in changes:
                self.assertEqual(archive.extractfile(relative).read(),(PACKAGE/'rollback'/relative).read_bytes())
        self.build_fixture(root,changes)
        installer.validate_tree(root,'v35',binaries=False)
        installer.copy_version(root,rollback=True,binaries=False)
        self.build_fixture(root,changes)
        installer.validate_tree(root,'original_v35',binaries=False)
        for relative,item in changes.items():
            expected=(PACKAGE/'rollback'/relative).read_bytes()
            self.assertEqual((root/relative).read_bytes(),expected)
            self.assertEqual((root/item['installed_path']).read_bytes(),expected)

    def test_unknown_installed_vision_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/changes['src/racecar/scripts/ican_vision_node.py']['installed_path']
        target.write_bytes(target.read_bytes()+b'\n# user edit\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)
        self.assertEqual(list(root.parent.glob('racecar_before_*')),[])

    def test_unknown_yaml_is_rejected_before_any_source_write(self):
        root,changes=self.fixture()
        target=root/'src/racecar/config/competition_params.yaml'
        target.write_bytes(target.read_bytes()+b'\n# user tuning\n')
        before={r:(root/r).read_bytes() for r in changes}
        with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
            installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

    def test_active_car_is_not_modified(self):
        root,changes=self.fixture()
        before={r:(root/r).read_bytes() for r in changes}
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing race'):
                installer.copy_version(root,binaries=False)
        self.assertEqual({r:(root/r).read_bytes() for r in changes},before)

if __name__=='__main__':unittest.main(verbosity=2)
