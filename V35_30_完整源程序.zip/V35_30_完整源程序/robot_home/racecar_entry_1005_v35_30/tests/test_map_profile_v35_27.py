"""Portable field configuration and exact occupancy-coordinate semantics."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

PACKAGE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('profile_builder_v27', PACKAGE/'prepare_map_profile.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


class MapProfileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.grid = np.zeros((80, 160), dtype=int)
        self.grid[0, :] = 100
        self.grid[-1, :] = 100
        self.grid[:, 0] = 100
        self.grid[:, -1] = 100
        self.grid[30:35, 40:45] = -1
        self.source = self.root/'grid.json'
        self.source.write_text(json.dumps({'metadata': {'height': 80, 'width': 160,
            'resolution': .05, 'origin': [0, 0, 0]}, 'data': self.grid.ravel().tolist()}), encoding='utf-8')
        self.alignment = self.root/'field.json'
        self.config = {'profile_id': 'new_venue', 'course_to_map': [0, 0, 0],
            'valid_course_polygon': [[-.1, -.1], [8.1, -.1], [8.1, 4.1], [-.1, 4.1]],
            'exclude_map_polygons': [[[0, 0], [.2, 0], [.2, .7], [0, .7]]]}
        self.alignment.write_text(json.dumps(self.config), encoding='utf-8')

    def build(self):
        return builder.prepare(self.source, self.alignment, self.root/'profile')

    def test_mask_removes_external_features_but_keeps_original(self):
        old = self.source.read_bytes()
        profile = self.build()
        with np.load(self.root/'profile/distance_field.npz') as data:
            self.assertEqual(int(data['valid'][1, 1]), 0)
            self.assertEqual(int(data['valid'][31, 41]), 0)
            self.assertGreater(float(data['distances'][1, 1]), .10)
            self.assertEqual(float(data['distances'][0, 20]), 0)
        self.assertEqual(self.source.read_bytes(), old)
        self.assertEqual(profile['distance_field_sha256'], hashlib.sha256((self.root/'profile/distance_field.npz').read_bytes()).hexdigest())

    def test_replacement_map_transform_is_config_only(self):
        self.config['course_to_map'] = [1.0, -.3, .05]
        self.config['exclude_map_polygons'] = []
        self.alignment.write_text(json.dumps(self.config), encoding='utf-8')
        result = self.build()
        self.assertEqual(result['course_to_map'], [1.0, -.3, .05])
        self.assertEqual(result['profile_id'], 'new_venue')

    def test_existing_profile_refuses_overwrite(self):
        self.build()
        with self.assertRaisesRegex(ValueError, 'never overwritten'):
            self.build()

    def test_mask_boundary_and_closed_polygons_match_runtime(self):
        import sys
        sys.path.insert(0, str(PACKAGE/'payload/src/racecar/scripts'))
        from race_curve_core import MapAssist
        points = np.asarray([[0, .5], [1, .5], [.5, 1], [.5, 0], [0, 0],
                             [1, 1], [.5, .5], [1.01, .5], [-.01, .5]])
        for polygon in ([[0, 0], [1, 0], [1, 1], [0, 1]],
                        [[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]):
            np.testing.assert_array_equal(builder.inside_polygon(points, polygon),
                                          MapAssist._inside(points, np.asarray(polygon)))

    def test_ros_pgm_rows_are_flipped_once(self):
        import cv2
        img = np.array([[0, 254, 127], [254, 0, 127]], dtype=np.uint8)
        cv2.imwrite(str(self.root/'map.pgm'), img)
        yaml = self.root/'map.yaml'
        yaml.write_text('image: map.pgm\nresolution: 0.05\norigin: [1, 2, 0]\nnegate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.25\n', encoding='utf-8')
        grid, resolution, origin, _ = builder.read_grid(yaml)
        np.testing.assert_array_equal(grid, [[0, 100, -1], [100, 0, -1]])
        np.testing.assert_array_equal(origin, [1, 2])
        self.assertEqual(resolution, .05)

    def test_json_grid_is_not_flipped(self):
        grid, _, _, _ = builder.read_grid(self.source)
        np.testing.assert_array_equal(grid, self.grid)

    def test_nonzero_image_origin_yaw_is_not_silently_ignored(self):
        data = json.loads(self.source.read_text(encoding='utf-8'))
        data['metadata']['origin'][2] = .4
        self.source.write_text(json.dumps(data), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'origin yaw=0'):
            self.build()

    def test_invalid_alignment_fails_before_output_creation(self):
        self.config['course_to_map'][0] = float('nan')
        self.alignment.write_text(json.dumps(self.config), encoding='utf-8')
        with self.assertRaises(ValueError):
            self.build()
        self.assertFalse((self.root/'profile').exists())


if __name__ == '__main__':
    unittest.main()
