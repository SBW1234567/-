"""Entry planning survives measured RF2O noise; crosswalk stays independent."""
from concurrent.futures import Future
import csv
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import ros_stubs as ros
import race_task_controller as cm
import race_curve_core as core


class EntryPlanRelaxedTests(unittest.TestCase):
    def setUp(self):
        self.clock=patch.object(cm.time,'monotonic',return_value=100.)
        self.clock.start();self.addCleanup(self.clock.stop)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,
            exit_continuous=True,entry_v32_enabled=True,entry_v33_enabled=True,
            entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        c=self.c;c.phase=c.SEEK_CONE_1;c.entry_v33_braked=c.entry_hold=True
        c.entry_v33_brake_since=99.;c.entry_plan_budget=8.;c.entry_plan_reference_ttl=60.
        c.entry_plan_odom_gap=2.;c.last_odom_xy=(5.,.30);c.last_yaw=math.radians(8.)
        c.last_odom_time=100.;c.last_still_stamp=100.
        c.curve_locator.pose=(5.39,.84,.14);c.curve_locator.time=100.;c.curve_locator.hits=20
        c.odom_still_samples=cm.deque([(99.5,5.,.30,math.radians(8.)),
                                     (99.8,5.,.30,math.radians(8.)),
                                     (100.,5.,.30,math.radians(8.))])
        self.anchor()

    def anchor(self,started=100.):
        c=self.c;c.entry_plan_anchor=dict(pose=(5.39,.84,.14),started=started,
            checked=100.,odom=(5.,.30,math.radians(8.)),samples=cm.deque(c.odom_still_samples),stamp=100.)

    def test_entry_noise_is_stopped_but_crosswalk_uses_original_threshold(self):
        c=self.c
        c.odom_still_samples=cm.deque([(99.5,5.,.30,math.radians(5.)),
            (99.8,5.02,.302,math.radians(9.)),(100.,5.03,.301,math.radians(10.))])
        c.last_odom_xy=(5.03,.301);c.last_yaw=math.radians(10.)
        self.assertTrue(c.entry_is_stopped(100.))
        self.assertFalse(c.odom_is_still(100.))

    def test_entry_stop_rejects_remaining_coast_or_large_turn(self):
        for x,yaw in ((5.16,8.),(5.,21.)):
            with self.subTest(x=x,yaw=yaw):
                c=self.c
                if hasattr(c,'entry_stopped_samples'):del c.entry_stopped_samples
                c.odom_still_samples=cm.deque([(99.5,5.,.30,math.radians(8.)),
                    (99.8,5.,.30,math.radians(8.)),(100.,x,.30,math.radians(yaw))])
                c.last_odom_xy=(x,.30);c.last_yaw=math.radians(yaw)
                self.assertFalse(c.entry_is_stopped(100.))

    def test_entry_stop_does_not_require_rebuilding_crosswalk_deque_after_gap(self):
        c=self.c;self.assertTrue(c.entry_is_stopped(100.))
        c.odom_still_samples.clear()
        c.last_odom_time=100.7;c.last_odom_xy=(5.04,.30);c.last_yaw=math.radians(10.)
        self.assertTrue(c.entry_is_stopped(100.7))
        self.assertFalse(c.odom_is_still(100.7))

    def test_entry_stop_requires_brake_time_and_recent_odometry(self):
        c=self.c;c.entry_v33_brake_since=99.8
        self.assertFalse(c.entry_is_stopped(100.))
        c.entry_v33_brake_since=99.;c.last_odom_time=99.
        self.assertFalse(c.entry_is_stopped(100.))

    def test_slow_odom_drift_no_longer_discards_reference(self):
        c=self.c;c.last_odom_xy=(5.2,.305);c.last_yaw=math.radians(25.)
        self.assertTrue(c.entry_plan_anchor_valid(100.))
        self.assertIsNotNone(c.entry_plan_anchor)

    def test_callback_sample_and_control_poll_gaps_do_not_discard_reference(self):
        c=self.c;c.entry_plan_anchor['checked']=98.5;c.last_odom_time=99.
        self.assertTrue(c.entry_plan_anchor_valid(100.))
        self.assertEqual(c.entry_plan_reference_reason,'HELD_WAIT_FRESH_ODOM')
        c.entry_plan_observe_odom(101.5,101.5,5.06,.305,math.radians(12.))
        self.assertIsNotNone(c.entry_plan_anchor)
        self.assertEqual(c.entry_plan_anchor['stamp'],101.5)

    def test_duplicates_are_ignored_and_genuine_large_motion_is_rejected(self):
        c=self.c;c.entry_plan_observe_odom(100.,100.,5.,.30,math.radians(8.))
        self.assertIsNotNone(c.entry_plan_anchor)
        c.entry_plan_observe_odom(100.1,100.1,5.51,.30,math.radians(8.))
        self.assertIsNone(c.entry_plan_anchor)
        self.assertEqual(c.entry_plan_reference_reason,'ODOM_MOVED')

    def test_out_and_back_movement_cannot_restore_invalidated_reference(self):
        c=self.c;c.entry_plan_observe_odom(100.1,100.1,5.,.30,math.radians(44.))
        c.entry_plan_observe_odom(100.2,100.2,5.,.30,math.radians(8.))
        self.assertIsNone(c.entry_plan_anchor)

    def test_fresh_wall_pose_large_change_invalidates_reference(self):
        for pose in ((5.70,.84,.14),(5.39,.84,.14+math.radians(21.))):
            with self.subTest(pose=pose):
                self.anchor();self.c.curve_locator.pose=pose
                self.assertFalse(self.c.entry_plan_anchor_valid(100.))
                self.assertEqual(self.c.entry_plan_reference_reason,'WALL_POSE_MOVED')

    def test_finished_plan_waits_beyond_compute_budget_for_fresh_gates(self):
        c=self.c;self.anchor(started=95.)
        path=types.SimpleNamespace(planning_ms=3400.)
        c.entry_plan_ready=(path,(5.39,.84,.14),core.CONES,95.,c.curve_generation)
        c.last_odom_time=110.;c.curve_locator.time=110.
        c.curve_poll_entry_plan(110.)
        self.assertIsNotNone(c.entry_plan_ready)
        self.assertIsNone(c.curve_follower)
        self.assertEqual(len(c.cmd_pub.messages),0)

    def test_running_worker_budget_and_generation_still_discard(self):
        c=self.c;future=Future();future.set_running_or_notify_cancel()
        c.entry_plan_job=(future,(5.39,.84,.14),core.CONES,90.,c.curve_generation)
        c.entry_plan_cancel=cm.Event();c.curve_poll_entry_plan(100.)
        self.assertTrue(c.entry_plan_cancel.is_set())
        self.assertEqual(c.entry_plan_worker_state,'DISCARD_PENDING')
        c.entry_plan_job=None;self.anchor()
        c.entry_plan_ready=(object(),(5.39,.84,.14),core.CONES,100.,c.curve_generation-1)
        c.curve_poll_entry_plan(100.)
        self.assertIsNone(c.entry_plan_ready)

    def test_completed_worker_result_is_retained_while_current_inputs_wait(self):
        c=self.c;self.anchor(started=97.)
        path=types.SimpleNamespace(planning_ms=3400.);future=Future();future.set_result(path)
        c.entry_plan_job=(future,(5.39,.84,.14),core.CONES,97.,c.curve_generation)
        c.curve_scan=None;c.rel_data=None
        c.curve_poll_entry_plan(100.)
        self.assertIsNotNone(c.entry_plan_ready)
        self.assertEqual(c.entry_plan_reason,'PLAN_READY_WAIT_FRESH_GATES')
        self.assertIsNone(c.curve_follower)
        self.assertEqual(len(c.cmd_pub.messages),0)

    def test_reference_ttl_and_phase_change_still_discard(self):
        c=self.c;self.anchor(started=39.)
        self.assertFalse(c.entry_plan_anchor_valid(100.))
        self.assertEqual(c.entry_plan_reference_reason,'REFERENCE_TTL')
        self.anchor();c.phase=c.APPROACH_CROSSWALK
        self.assertFalse(c.entry_plan_anchor_valid(100.))

    def test_stationary_noise_from_latest_run_keeps_completed_plan(self):
        # This measured replay tests reference survival only, not a physical
        # driving trajectory. The fixture contains only the stationary interval
        # and its measured odometry/full-wall-pose columns, with no alteration.
        source=PACKAGE/'tests/fixtures/race_control_20261001_173838.csv'
        if not source.exists():self.skipTest('Measured CSV fixture not packaged')
        with source.open(encoding='utf-8-sig') as stream:
            rows=list(csv.DictReader(stream))
        rows=[r for r in rows if float(r['elapsed_s'])>=25.32]
        c=self.c;first=rows[0]
        c.entry_plan_anchor['odom']=(float(first['odom_x_m']),float(first['odom_y_m']),
                                     math.radians(float(first['odom_yaw_deg'])))
        c.entry_plan_anchor['stamp']=100.
        c.entry_plan_ready=(object(),(5.39,.84,.14),core.CONES,100.,c.curve_generation)
        for r in rows:
            now=100.+float(r['elapsed_s'])-25.32
            x,y,yaw=float(r['odom_x_m']),float(r['odom_y_m']),math.radians(float(r['odom_yaw_deg']))
            c.last_odom_xy=(x,y);c.last_yaw=yaw;c.last_odom_time=now
            c.entry_plan_observe_odom(now,now,x,y,yaw)
            c.curve_locator.pose=(float(r['wall_x_m']),float(r['wall_y_m']),float(r['wall_yaw_rad']))
            c.curve_locator.time=now;c.curve_poll_entry_plan(now)
            self.assertIsNotNone(c.entry_plan_anchor,r['elapsed_s'])
            self.assertIsNotNone(c.entry_plan_ready,r['elapsed_s'])


if __name__=='__main__':unittest.main(verbosity=2)
