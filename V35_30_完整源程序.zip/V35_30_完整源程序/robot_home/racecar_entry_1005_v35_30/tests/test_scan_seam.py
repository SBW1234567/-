"""Full-turn LSN10 duplicate-endpoint regression; no hardware is exercised."""
import copy
import math
import types
import unittest

from test_straight import core


PATH=[(i*.05,-.05,0.) for i in range(14)]
TRAILING_PATH=[(i*.05,-.04,0.) for i in range(14)]


def scan(n=450):
    return types.SimpleNamespace(ranges=[2.]*n,angle_min=math.radians(-3.),
        angle_increment=2*math.pi/(n-1),range_min=.05,range_max=12.,
        header=types.SimpleNamespace(stamp=types.SimpleNamespace(sec=100,nanosec=0)))


def driver_scan(n=451,aligned=False):
    s=scan(n)
    s.angle_increment=2*math.pi/(n-2)
    s.angle_max=s.angle_min+2*math.pi+(s.angle_increment if aligned else 0.)
    return s


class ScanSeamTests(unittest.TestCase):
    def check(self,s,path=PATH):
        d={}
        result=core.scan_observes_body(s,(0.,0.,0.),path,
            allow_small_gaps=True,allow_scan_edge=True,diagnostics=d)
        return result,d

    def test_both_missing_endpoints_are_one_supported_direction(self):
        for n in (448,450):
            with self.subTest(n=n):
                s=scan(n);s.ranges[0]=s.ranges[-1]=math.inf
                result,d=self.check(s)
                self.assertEqual(result,(True,'CLEAR_GAP_TOLERATED'))
                self.assertTrue(d['duplicated_endpoint'])
                self.assertEqual(d['inferred_rays'],1)
                self.assertEqual(d['inferred_indices'],[0])

    def test_measured_endpoint_covers_its_unknown_duplicate(self):
        for n in (448,450):
            for missing in (0,-1):
                with self.subTest(n=n,missing=missing):
                    s=scan(n);s.ranges[missing]=math.inf
                    result,d=self.check(s)
                    self.assertEqual(result,(True,'CLEAR'))
                    self.assertEqual(d['inferred_rays'],0)

    def test_real_obstacle_on_either_endpoint_still_stops(self):
        for n in (448,450):
            for obstacle in (0,-1):
                with self.subTest(n=n,obstacle=obstacle):
                    s=scan(n);s.ranges[obstacle]=.5
                    result,d=self.check(s)
                    self.assertEqual(result,(False,'SWEPT_OBSTACLE'))
                    self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),PATH))

    def test_invalid_finite_endpoint_is_never_replaced(self):
        for invalid in (0.,.1,.29,-math.inf,13.):
            for endpoint in (0,-1):
                with self.subTest(invalid=invalid,endpoint=endpoint):
                    s=scan();s.ranges[endpoint]=invalid
                    result,d=self.check(s)
                    self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
                    self.assertEqual(d['unknown_reason'],'INVALID_RANGE')

    def test_partial_scan_keeps_unobserved_seam_unknown(self):
        for n in (448,450):
            with self.subTest(n=n):
                s=scan(n);s.ranges=s.ranges[:-2];s.ranges[0]=math.inf
                result,d=self.check(s)
                self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
                self.assertFalse(d['duplicated_endpoint'])
                self.assertEqual(d['unknown_reason'],'SCAN_EDGE')

    def test_full_circle_ordinary_ring_keeps_existing_support(self):
        s=scan();s.angle_increment=2*math.pi/len(s.ranges)
        s.ranges[0]=s.ranges[-1]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(True,'CLEAR_GAP_TOLERATED'))
        self.assertFalse(d['duplicated_endpoint'])
        self.assertEqual(d['inferred_rays'],2)

    def test_normalization_does_not_mutate_raw_scan(self):
        s=scan();s.ranges[0]=math.nan;s.ranges[-1]=math.inf
        before=copy.deepcopy(s)
        self.assertTrue(self.check(s)[0][0])
        self.assertTrue(math.isnan(s.ranges[0]))
        self.assertEqual(s.ranges[1:],before.ranges[1:])
        self.assertEqual(s.angle_increment,before.angle_increment)
        self.assertEqual(s.header.stamp,before.header.stamp)

    def test_driver_extra_bin_and_missing_duplicate_endpoint(self):
        for n in (449,451):
            for aligned in (False,True):
                with self.subTest(n=n,aligned=aligned):
                    s=driver_scan(n,aligned);s.ranges[0]=s.ranges[-2]=math.inf
                    result,d=self.check(s)
                    self.assertEqual(result,(True,'CLEAR_GAP_TOLERATED'))
                    self.assertTrue(d['duplicated_endpoint'])
                    self.assertEqual(d['inferred_indices'],[0])

    def test_driver_trailing_measured_direction_is_used(self):
        for n in (449,451):
            with self.subTest(n=n):
                s=driver_scan(n);s.ranges[1]=math.inf
                result,d=self.check(s,TRAILING_PATH)
                self.assertEqual(result,(True,'CLEAR'))
                self.assertEqual(d['inferred_rays'],0)

    def test_driver_trailing_nearest_return_is_not_discarded(self):
        for n in (449,451):
            with self.subTest(n=n):
                s=driver_scan(n);s.ranges[-1]=.94
                result,d=self.check(s,TRAILING_PATH)
                self.assertEqual(result,(False,'SWEPT_OCCLUDED'))
                self.assertEqual(d['ray_index'],1)
                self.assertEqual(d['observed_m'],.94)

    def test_driver_trailing_obstacle_is_not_discarded(self):
        for n in (449,451):
            with self.subTest(n=n):
                s=driver_scan(n);s.ranges[-1]=.5
                result,d=self.check(s)
                self.assertEqual(result,(False,'SWEPT_OBSTACLE'))
                self.assertTrue(core.scan_hits_body(s,(0.,0.,0.),PATH))

    def test_extra_bin_requires_precise_angular_metadata(self):
        for angular_span in (math.nan,2*math.pi-math.radians(.1),2*math.pi+math.radians(.1)):
            with self.subTest(angular_span=angular_span):
                s=driver_scan();s.angle_max=s.angle_min+angular_span
                s.ranges[0]=s.ranges[-2]=math.inf
                result,d=self.check(s)
                self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
                self.assertFalse(d['duplicated_endpoint'])

    def test_driver_scan_cropped_even_with_full_declared_max_is_not_wrapped(self):
        s=driver_scan();s.ranges=s.ranges[:-3];s.ranges[0]=math.inf
        result,d=self.check(s)
        self.assertEqual(result,(False,'SWEPT_UNKNOWN'))
        self.assertFalse(d['duplicated_endpoint'])
        self.assertEqual(d['unknown_reason'],'SCAN_EDGE')


if __name__=='__main__':
    unittest.main()
