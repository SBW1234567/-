"""Early stopped entry with the measured cone offsets from the 18:36 run."""
import math
from pathlib import Path
import sys
import threading
import unittest
from unittest.mock import patch

import numpy as np

SCRIPTS=Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS))
import race_curve_core as core


EARLY_STOP=(4.5230946940783765,.78,.025)
MEASURED_CONES=((6.09,2.08),(2.,1.97))


class PlanningRecoveryTests(unittest.TestCase):
    def assert_certified(self,path,start,cones):
        np.testing.assert_allclose(path.samples[0,:3],start,atol=1e-10)
        self.assertLessEqual(path.max_curvature,1/.55)
        self.assertLessEqual(float(np.max(np.diff(path.lengths))),.055)
        self.assertTrue(core.path_body_clear(path.samples,cones))
        # The handbook passage remains east of cone 1, below the upper divider.
        self.assertGreaterEqual(path.samples[160,0],cones[0][0]+1.0)
        self.assertLessEqual(path.samples[320,1],2.75)

    def assert_wide_first_cone(self,path):
        self.assertEqual(path.entry_family,'WIDE_FIRST_CONE')
        self.assertLessEqual(float(np.max(np.abs(path.samples[:321,3]))),1.35)
        self.assertGreaterEqual(float(np.min(path.samples[:321,3])),-.02)
        self.assertLessEqual(path.samples[320,1],2.70)

    def test_first_run_pose_and_cone_offsets_get_a_certified_fast_path(self):
        with patch.object(core,'plan_path',side_effect=AssertionError('No repeated coordinate search')):
            path=core.plan_entry_path(EARLY_STOP,MEASURED_CONES)
        self.assert_certified(path,EARLY_STOP,MEASURED_CONES)
        self.assert_wide_first_cone(path)

    def test_second_planning_retry_pose_also_uses_the_new_family(self):
        start=(4.516640562611716,.7814,.012)
        with patch.object(core,'plan_path',side_effect=AssertionError('Must use certified candidate')):
            path=core.plan_entry_path(start,MEASURED_CONES)
        self.assert_certified(path,start,MEASURED_CONES)
        self.assert_wide_first_cone(path)

    def test_nominal_first_run_geometry_still_finishes_without_optimizer(self):
        with patch.object(core,'plan_path',side_effect=AssertionError('Unnecessary optimizer')):
            path=core.plan_entry_path(EARLY_STOP)
        self.assert_certified(path,EARLY_STOP,core.CONES)
        self.assert_wide_first_cone(path)

    def test_earlier_pose_needs_a_longer_first_tangent(self):
        start=(4.1,.78,.02)
        with patch.object(core,'plan_path',side_effect=AssertionError('Use bounded candidate bank')):
            path=core.plan_entry_path(start,MEASURED_CONES)
        self.assert_certified(path,start,MEASURED_CONES)
        self.assert_wide_first_cone(path)

    def test_measured_pose_and_landmark_neighborhood_preserves_all_limits(self):
        for x in (4.45,4.52,4.62):
            for y in (.74,.78,.82):
                for heading in (-.02,.02,.06):
                    for north in (.06,.08,.10):
                        start=(x,y,heading);cones=((6.09,2.+north),(2.,1.97))
                        with self.subTest(start=start,cones=cones), \
                             patch.object(core,'plan_path',side_effect=AssertionError('Fast family must cover log neighborhood')):
                            path=core.plan_entry_path(start,cones)
                        self.assert_certified(path,start,cones)
                        self.assert_wide_first_cone(path)

    def test_later_second_run_entry_gets_an_earlier_gentler_turn(self):
        for cones in (((6.076,2.063),(1.999,1.96)),core.CONES):
            for start in ((5.505296236,.920365154,.139610142),(5.59,.92,.14),(5.6,.94,.17)):
                with self.subTest(start=start,cones=cones),patch.object(core,'plan_path',side_effect=AssertionError('Use fixed certified family')):
                    path=core.plan_entry_path(start,cones)
                self.assert_certified(path,start,cones)
                self.assert_wide_first_cone(path)

    def test_distinct_parameter_speeds_preserve_position_heading_and_curvature(self):
        original=core.quintic
        with patch.object(core,'quintic',wraps=original) as pieces:
            core.make_path((5.505,.92,.14),((6.08,2.06),(2.,1.97)),first_pass_offset=.25,
                first_east_offset=1.10,first_north_offset=(.20,.65),first_north_cap=2.70,
                segment_tangents=((1.2,3.2),(1.8,1.0),(1.8,1.45),(1.35,1.8),(1.8,3.118),(3.118,1.972)),
                knot_curvatures=(0.,1.20,1.0,-1.10,-1.20,-.60,0.))
        def curvature(v,a):
            return (v[0]*a[1]-v[1]*a[0])/math.hypot(*v)**3
        for left,right in zip(pieces.call_args_list,pieces.call_args_list[1:]):
            a,b,va,vb,aa,ab=left.args;next_a,next_b,next_va,next_vb,next_aa,next_ab=right.args
            np.testing.assert_allclose(b,next_a)
            self.assertAlmostEqual(core.wrap(math.atan2(vb[1],vb[0])-math.atan2(next_va[1],next_va[0])),0.)
            self.assertAlmostEqual(curvature(vb,ab),curvature(next_va,next_aa))
        self.assertNotAlmostEqual(math.hypot(*pieces.call_args_list[0].args[3]),math.hypot(*pieces.call_args_list[1].args[2]))

    def test_default_make_path_retains_the_original_geometry_for_comparison(self):
        path=core.make_path(EARLY_STOP,MEASURED_CONES,min_radius=.01,check_body=False)
        self.assertAlmostEqual(path.samples[160,0],MEASURED_CONES[0][0]+1.02)
        self.assertAlmostEqual(path.samples[320,0],MEASURED_CONES[0][0]-.15)
        self.assertAlmostEqual(path.samples[320,1],min(2.75,MEASURED_CONES[0][1]+.70))

    def test_body_collision_is_still_rejected(self):
        with self.assertRaisesRegex(ValueError,'ENTRY_NO_FEASIBLE_CURVE'):
            core.plan_entry_path((6.,2.,0.),MEASURED_CONES)

    def test_deadline_and_cancellation_still_apply_to_fast_family(self):
        cancel=threading.Event();cancel.set()
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(EARLY_STOP,MEASURED_CONES,cancel=cancel)
        with self.assertRaises(core.PlanningInterrupted):
            core.plan_entry_path(EARLY_STOP,MEASURED_CONES,deadline=core.time.monotonic()-1.)


if __name__=='__main__':unittest.main(verbosity=2)
