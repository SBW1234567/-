"""Approach motor decisions from real source-stamped odometry callbacks.

PWM is not a velocity calibration. These verify control decisions and stale
data behavior, not a guaranteed braking distance on the physical floor.
"""
import ast
import math
from pathlib import Path
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import test_continuous as helpers

cm,ros=helpers.cm,helpers.ros


class ApproachSpeedTests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.ros_time=1000.;self.x=0.
        clock=patch.object(cm.time,'monotonic',side_effect=lambda:self.now)
        clock.start();self.addCleanup(clock.stop)
        old=ros.FakeNode.overrides
        self.addCleanup(setattr,ros.FakeNode,'overrides',old)
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=cm.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.phase=self.c.APPROACH_CROSSWALK
        self.c.get_clock=lambda:NS(now=lambda:NS(nanoseconds=round(self.ros_time*1e9)))
        self.sample(0.)

    def sample(self,speed,dt=.1,delay=.1):
        self.now+=dt;self.ros_time+=dt;self.x+=speed*dt
        stamp=round((self.ros_time-delay)*1e9)
        msg=NS(header=NS(stamp=NS(sec=stamp//1000000000,nanosec=stamp%1000000000)),
            pose=NS(pose=NS(position=NS(x=self.x,y=0.),
                orientation=NS(x=0.,y=0.,z=0.,w=1.))),
            twist=NS(twist=NS(linear=NS(x=99.),angular=NS(z=99.))))
        self.c.odom_callback(msg)
        return self.c.approach_crosswalk_drive(self.now)

    def test_first_pair_and_still_car_keep_known_launch_input(self):
        self.assertEqual(self.c.approach_crosswalk_drive(self.now),.35)
        self.assertEqual(self.sample(0.),.35)
        self.assertEqual(self.sample(.10),.35)

    def test_moving_car_trims_without_using_rf2o_twist_as_speed(self):
        drive=self.sample(.55)
        self.assertGreaterEqual(drive,.30);self.assertLess(drive,.35)
        self.assertAlmostEqual(self.c.approach_speed_status['measured_mps'],.55)

    def test_latest_run_one_metre_per_second_requests_coast(self):
        self.assertEqual(self.sample(1.02),0.)
        self.assertEqual(self.c.approach_speed_status['mode'],'OVERSPEED_COAST')

    def test_hysteresis_keeps_coast_until_fresh_low_speed(self):
        self.assertEqual(self.sample(.80),0.)
        self.assertEqual(self.sample(.50),0.)
        self.assertEqual(self.sample(.36),0.)
        self.assertGreater(self.sample(.34),0.)

    def test_repeated_control_ticks_cannot_release_coast(self):
        self.sample(.80)
        for _ in range(15):
            self.now+=.1;self.ros_time+=.1
            self.assertEqual(self.c.approach_crosswalk_drive(self.now),0.)
        self.assertEqual(self.c.approach_speed_status['mode'],'COAST_WAIT_FRESH_SPEED')

    def test_new_receipt_of_old_source_cannot_restart_coast(self):
        self.sample(.8)
        self.now+=1.;self.ros_time+=1.
        # A queued sample has a new receipt time but is still >.75s old.
        self.assertEqual(self.sample(0.,delay=1.1),0.)
        self.assertFalse(self.c.approach_speed_status['fresh'])

    def test_source_span_gap_cannot_release_coast(self):
        self.sample(.8)
        self.assertEqual(self.sample(0.,dt=.7),0.)
        self.assertEqual(self.c.curve_motion_status['velocity_policy'],'SOURCE_SPAN_REJECTED')
        self.assertGreater(self.sample(0.),0.)

    def test_future_clock_and_clock_jump_cannot_release_coast(self):
        self.sample(.8)
        for jump in (-1.,1.):
            self.ros_time+=jump
            self.assertEqual(self.c.approach_crosswalk_drive(self.now),0.)
            self.assertFalse(self.c.approach_speed_status['fresh'])
            self.ros_time-=jump

    def test_lower_configured_motor_limit_is_respected(self):
        self.c.normal_speed=.25
        self.assertEqual(self.sample(0.),.25)
        self.assertLessEqual(self.sample(.5),.25)

    def test_approach_wrapper_preserves_existing_heading_command(self):
        self.sample(.8)
        self.c.crosswalk_stop_armed(self.now, initialize=True)
        sentinel=cm.Twist();sentinel.angular.z=.017
        with patch.object(self.c,'centre_heading_command',return_value=sentinel) as heading:
            self.assertIs(self.c.approach_crosswalk_command(),sentinel)
            heading.assert_called_once_with(self.now,0.)

    def test_legacy_route_does_not_use_new_speed_helper(self):
        self.c.curve_route=False
        with patch.object(self.c,'approach_crosswalk_drive',side_effect=AssertionError('wrong scope')):
            self.assertEqual(self.c.approach_crosswalk_command().linear.x,self.c.normal_speed)

    def test_startup_stop_hold_and_curve_running_drive_unchanged(self):
        def methods(path):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            return {n.name:ast.dump(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
        old=methods(helpers.PACKAGE/'tests/baselines/controller_before_v35_19.py')
        new=methods(helpers.SCRIPTS/'race_task_controller.py')
        for name in ('begin_crosswalk_stop','crosswalk_record_sample',
                     'crosswalk_reset_hold','curve_running_drive','publish_stop'):
            self.assertEqual(old[name],new[name],name)


if __name__=='__main__':unittest.main(verbosity=2)
