import ast
from concurrent.futures import Future
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
import shutil
import types
import unittest
from unittest.mock import patch
import ros_stubs as ros

PACKAGE=Path(__file__).resolve().parents[1]
SCRIPTS=PACKAGE/'payload/src/racecar/scripts'
sys.path.insert(0,str(SCRIPTS));sys.path.insert(0,str(PACKAGE))
import race_task_controller as controller
import race_curve_core as core
import apply_patch as installer

def wall(heading=0.,distance=.45):
    return (distance,math.radians(heading),10,.44,.004)

def observations(near=0.,rear=0.,ahead=0.,right=.45):
    return (wall(near,right),wall(near,.9-right),dict(near=wall(near,right),
        rear=wall(rear,right),ahead=wall(ahead,right),weight=1.,reason='TEST'),20.)

def scan(heading=0.,right=.45):
    n=720;inc=2*math.pi/n;ranges=[]
    slope=math.tan(math.radians(heading))
    for i in range(n):
        a=i*inc;d=math.sin(a)-slope*math.cos(a)
        ranges.append((.9-right)/d if d>1e-9 else (-right/d if d < -1e-9 else math.inf))
    return types.SimpleNamespace(ranges=ranges,angle_min=0.,angle_increment=inc,
        range_min=.05,range_max=12.,header=types.SimpleNamespace(
            stamp=types.SimpleNamespace(sec=100,nanosec=0)))

class StraightTests(unittest.TestCase):
    def setUp(self):
        ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,
            exit_continuous=True,entry_v32_enabled=True,entry_v33_enabled=True,
            entry_v34_enabled=True,dry_run=True,bounded_heading_control=True,
            lane_parallel_band_enabled=True,lane_band_min_distance=.35,
            lane_band_max_distance=.5,side_distance_guard_enabled=False,
            side_steering_guard_enabled=False)
        self.c=controller.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        self.c.phase=self.c.APPROACH_CROSSWALK
        self.c.last_lane_command_time=99.9

    def feed(self,t,**kw): self.c.observe_departure_corridor(None,t,observations(**kw))
    def drive(self,t): return self.c.centre_heading_command(t,.35)
    def prime(self,**kw):
        for t in (100.,100.1,100.2): self.feed(t,**kw)

    def test_mild_board_angle_four_degrees_accepted(self):
        self.prime(near=0.,rear=4.,ahead=-4.)
        cmd=self.drive(100.25)
        self.assertEqual(cmd.linear.x,.35);self.assertEqual(cmd.angular.z,0.)

    def test_sharp_conflicting_segments_still_stop(self):
        self.prime(near=0.,rear=8.,ahead=-8.)
        self.assertEqual(self.drive(100.25).linear.x,0.)

    def test_exact_five_degree_support_boundary(self):
        selected,_=self.c.select_corridor_heading(observations(rear=5.,ahead=7.)[2],wall(),wall())
        self.assertIsNotNone(selected)
        selected,_=self.c.select_corridor_heading(observations(rear=5.01,ahead=7.)[2],wall(),wall())
        self.assertIsNone(selected)

    def test_duplicate_scan_cannot_confirm_wall(self):
        for _ in range(6): self.feed(100.)
        self.assertEqual(self.c.lane_direction_hits,1)
        self.assertIsNone(self.c.lane_band_upper)
        self.assertEqual(self.drive(100.1).linear.x,0.)

    def test_short_processing_gap_stops_then_recovers_on_fresh_result(self):
        self.prime()
        self.assertEqual(self.drive(100.25).linear.x,.35)
        self.assertEqual(self.drive(100.56).linear.x,0.)
        self.assertEqual(self.c.lane_direction_hits,3)
        self.feed(100.6)
        self.assertEqual(self.drive(100.61).linear.x,.35)

    def test_long_gap_requires_three_new_measurements(self):
        self.prime();self.drive(101.)
        self.feed(101.);self.assertEqual(self.drive(101.01).linear.x,0.)
        self.feed(101.1);self.assertEqual(self.drive(101.11).linear.x,0.)
        self.feed(101.2);self.assertEqual(self.drive(101.21).linear.x,.35)

    def test_conflicting_new_heading_resets_confirmation(self):
        self.prime();self.feed(100.3,near=0.,rear=8.,ahead=-8.)
        self.assertEqual(self.c.lane_direction_hits,0)
        self.assertEqual(self.drive(100.31).linear.x,0.)

    def test_stale_result_never_drives(self):
        self.prime()
        for t in (100.551,101.,102.):
            self.assertEqual(self.drive(t).linear.x,0.)

    def test_offset_inside_35cm_band_has_no_centering(self):
        for right in (.36,.40,.45,.49):
            for t in (101.,101.1,101.2): self.feed(t,right=right)
            cmd=self.drive(101.21)
            self.assertEqual(cmd.linear.x,.35);self.assertEqual(cmd.angular.z,0.)
            self.c.lane_raw_time=None

    def test_small_heading_changes_can_confirm(self):
        for t,h in ((100.,0.),(100.1,3.),(100.2,0.)):
            self.feed(t,near=h,rear=h,ahead=h)
        self.assertEqual(self.drive(100.21).linear.x,.35)

    def test_async_result_before_crosswalk_is_used(self):
        job=Future();job.set_result(observations())
        self.c.entry_v34_lane_job=(job,None,100.,123)
        with patch.object(self.c,'curve_submit_registration'):
            self.c.entry_v34_poll_lane(100.2)
        self.assertEqual(self.c.lane_raw_time,100.)

    def test_old_async_result_is_rejected(self):
        job=Future();job.set_result(observations())
        self.c.entry_v34_lane_job=(job,None,100.,123)
        self.c.entry_v34_poll_lane(100.31)
        self.assertEqual(self.c.entry_v34_lane_status,'TOO_OLD')
        self.assertIsNone(self.c.lane_raw_time)

    def test_synthetic_scan_positive_and_negative_slopes(self):
        for h in (-8.,-4.,0.,4.,8.):
            s=scan(h);direction=core.local_wall_direction(s,-1)
            self.assertIsNotNone(direction['near'])
            self.assertAlmostEqual(math.degrees(direction['near'][1]),h,places=6)

    def test_missing_scan_cannot_be_wall(self):
        s=scan();s.ranges=[math.nan]*720
        self.assertIsNone(core.nearby_wall(s,-1))
        self.assertIsNone(core.local_wall_direction(s,-1)['near'])

    def test_body_obstacle_and_unknown_sweep_still_reject(self):
        s=scan();s.ranges=[math.nan]*720
        self.assertFalse(core.scan_observes_body(s,(0.,0.,0.),[(.4,0.,0.)])[0])
        s=scan();s.ranges[0]=.4
        self.assertEqual(core.scan_observes_body(s,(0.,0.,0.),[(.4,0.,0.)]),(False,'SWEPT_OBSTACLE'))

    def test_task_and_collision_methods_unchanged(self):
        def methods(path):
            tree=ast.parse(path.read_text(encoding='utf-8'))
            cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
            return {n.name:ast.dump(n) for n in cls.body if isinstance(n,ast.FunctionDef)}
        old=methods(PACKAGE/'rollback/src/racecar/scripts/race_task_controller.py')
        new=methods(SCRIPTS/'race_task_controller.py')
        allowed={'__init__','curve_update','entry_plan_anchor_valid',
                 'curve_poll_entry_plan','entry_gate_snapshot',
                 'curve_observe_clusters','curve_update_pose_wait','curve_command'}
        self.assertEqual(set(new)-set(old),set())
        self.assertEqual({k for k in old if old[k]!=new[k]},allowed)
        source=(SCRIPTS/'race_task_controller.py').read_text(encoding='utf-8').replace(
            'entry_plan_budget = 5.0','entry_plan_budget = 1.5').replace(
            'entry_plan_reference_ttl = 8.0','entry_plan_reference_ttl = 2.0')
        tree=ast.parse(source)
        method=next(n for cls in tree.body if isinstance(cls,ast.ClassDef)
                    for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='control_loop')
        self.assertEqual(ast.dump(method),old['control_loop'])

    def test_package_original_and_payload_hashes(self):
        installer.load_manifests()

    def test_install_and_rollback_restore_exact_v35(self):
        base,overlay,changes=installer.load_manifests()
        fixture=dict(base,dependencies={},files=[x for x in base['files'] if x['path'] in changes])
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'car'
            (root/'src/racecar').mkdir(parents=True)
            (root/'src/racecar/CMakeLists.txt').touch()
            for rel,item in changes.items():
                for target in (root/rel,root/item['installed_path']):
                    target.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copyfile(PACKAGE/'rollback'/rel,target)
            with patch.object(installer,'load_manifests',return_value=(fixture,overlay,changes)), \
                 patch.object(installer,'active_race_processes',return_value=[]):
                installer.copy_version(root,binaries=False)
                # Simulate the build copying scripts, then check source + install.
                for rel,item in changes.items(): shutil.copyfile(root/rel,root/item['installed_path'])
                installer.validate_tree(root,'v35',binaries=False)
                installer.copy_version(root,rollback=True,binaries=False)
                for rel,item in changes.items(): shutil.copyfile(root/rel,root/item['installed_path'])
                installer.validate_tree(root,'original_v35',binaries=False)
                for rel,item in changes.items():
                    self.assertEqual(installer.digest(root/rel),item['before_sha256'])
                first=next(iter(changes))
                (root/first).write_text('# unexpected external edit\n',encoding='utf-8')
                with self.assertRaisesRegex(ValueError,'Unknown source/install state'):
                    installer.copy_version(root,binaries=False)
                self.assertEqual((root/first).read_text(encoding='utf-8'),'# unexpected external edit\n')

    def test_running_car_refuses_install(self):
        with patch.object(installer,'active_race_processes',return_value=['123']):
            with self.assertRaisesRegex(ValueError,'Stop existing'):
                installer.copy_version(Path('/not-accessed'),binaries=False)

    def test_pre_crosswalk_callback_schedules_worker(self):
        class Executor:
            def __init__(self): self.calls=[]
            def submit(self,fn,arg):
                self.calls.append((fn,arg));return Future()
        executor=Executor()
        self.c.entry_v34_lane_executor.shutdown(wait=True)
        with patch.object(self.c,'entry_v34_lane_executor',executor), \
             patch.object(self.c,'curve_submit_registration'), \
             patch.object(self.c,'curve_poll_registration'), \
             patch.object(controller.time,'monotonic',return_value=100.):
            self.c.curve_scan_callback(scan())
        self.assertEqual(len(executor.calls),1)
        self.assertIsNotNone(self.c.entry_v34_lane_job)

    def test_geometry_only_approved_functions_changed(self):
        def functions(path):
            return {n.name:ast.dump(n) for n in ast.parse(path.read_text(encoding='utf-8')).body
                    if isinstance(n,ast.FunctionDef)}
        old=functions(PACKAGE/'rollback/src/racecar/scripts/race_curve_core.py')
        new=functions(SCRIPTS/'race_curve_core.py')
        self.assertEqual(set(new)-set(old),set())
        self.assertEqual(set(old)-set(new),set())
        self.assertEqual({k for k in old if old[k]!=new[k]}, {'scan_observes_body'})

if __name__=='__main__': unittest.main(verbosity=2)
