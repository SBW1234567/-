from collections import deque
"""Delayed planning/recovery tests. All observations synthetic, no hardware."""
from concurrent.futures import Future
import math
import unittest
from unittest.mock import patch
import test_entry_quick as q
import test_straight as t


class StoppedPlanTests(unittest.TestCase):
    def setUp(self):
        t.ros.FakeNode.overrides=dict(curve_route=True,relative_route=True,exit_continuous=True,
            entry_v32_enabled=True,entry_v33_enabled=True,entry_v34_enabled=True,dry_run=True)
        self.c=t.controller.RaceTaskController();self.addCleanup(self.c.close_curve_worker)
        c=self.c;c.phase=c.SEEK_CONE_1
        c.entry_v33_braked=c.entry_v34_turn_stop=c.entry_hold=True
        c.last_odom_xy=(5.,.7);c.last_yaw=.1;c.last_odom_time=100.
        c.entry_plan_anchor=dict(pose=(5.2,.79,0.),started=100.,checked=100.,odom=(5.,.7,.1),samples=deque([(99.5,5.,.7,.1),(99.8,5.,.7,.1),(100.,5.,.7,.1)]),stamp=100.)
        self.still=patch.object(c,'odom_is_still',return_value=True)
        self.still.start();self.addCleanup(self.still.stop)

    def job(self,done=True,path=None):
        c=self.c;f=Future()
        if done:f.set_result(path if path is not None else object())
        c.entry_plan_job=(f,(5.2,.79,0.),((6.,2.),(2.,2.)),100.,c.curve_generation)
        return f

    def tick(self,now):
        if self.c.entry_plan_anchor is not None and now>self.c.entry_plan_anchor['stamp']:
            self.c.entry_plan_observe_odom(now,now,*self.c.last_odom_xy,self.c.last_yaw)
        self.c.last_odom_time=now
        self.c.curve_poll_entry_plan(now)

    def test_completed_plan_collected_while_pose_waits(self):
        self.job();c=self.c;c.curve_pose_wait=True
        c.curve_locator.pose=None
        self.tick(100.1)
        self.assertIsNone(c.entry_plan_job)
        self.assertIsNotNone(c.entry_plan_ready)
        self.assertEqual(c.entry_plan_reason,'PLAN_READY_WAIT_FRESH_GATES')
        self.assertAlmostEqual(c.entry_plan_ms,100.)

    def test_pose_reset_preserves_only_stopped_plan_reference(self):
        self.job();c=self.c
        c.curve_locator.pose=(5.2,.79,0.);c.curve_locator.time=99.7
        c.curve_reset_entry_pose()
        self.tick(100.1)
        self.assertIsNone(c.curve_locator.pose)
        self.assertEqual(c.curve_tracks.hits,[0,0])
        self.assertIsNotNone(c.entry_plan_ready)
        gates=c.entry_gate_snapshot(100.1)
        self.assertFalse(gates['POSE']);self.assertFalse(gates['FIRST_CONE'])

    def test_stale_live_pose_never_hands_off(self):
        self.job();c=self.c;self.tick(100.1)
        c.curve_update(100.1)
        self.assertIsNone(c.curve_follower)
        self.assertEqual(c.phase,c.SEEK_CONE_1)
        self.assertIsNotNone(c.entry_plan_ready)

    def test_snapshot_expires_even_with_fresh_stationary_odometry(self):
        self.job()
        for i in range(1,80):self.tick(100.+i*.1)
        self.assertIsNotNone(self.c.entry_plan_anchor)
        self.tick(108.1)
        self.assertIsNone(self.c.entry_plan_ready)
        self.assertIsNone(self.c.entry_plan_anchor)
        self.assertIsNone(self.c.entry_plan_job)

    def test_reference_is_valid_until_eight_seconds(self):
        self.job()
        for i in range(1,80):self.tick(100.+i*.1)
        self.assertIsNotNone(self.c.entry_plan_anchor)

    def test_reference_expires_after_eight_seconds(self):
        self.job()
        for i in range(1,82):self.tick(100.+i*.1)
        self.assertIsNone(self.c.entry_plan_anchor)

    def test_translation_invalidates_reference(self):
        self.job();self.c.last_odom_xy=(5.021,.7);self.tick(100.1)
        self.assertIsNone(self.c.entry_plan_ready)

    def test_rotation_invalidates_reference(self):
        self.job();self.c.last_yaw=.1+math.radians(1.1);self.tick(100.1)
        self.assertIsNone(self.c.entry_plan_ready)

    def test_missing_odometry_invalidates_reference(self):
        self.job();self.c.last_odom_time=99.
        self.c.curve_poll_entry_plan(100.1)
        self.assertIsNone(self.c.entry_plan_ready)

    def test_loss_of_stillness_is_irreversible_for_old_plan(self):
        f=self.job(False)
        f.set_running_or_notify_cancel()
        self.c.entry_plan_observe_odom(100.1,100.1,5.016,.7,.1)
        self.tick(100.1)
        self.assertEqual(self.c.entry_plan_worker_state,'DISCARD_PENDING')
        f.set_result(object());self.tick(100.2)
        self.assertIsNone(self.c.entry_plan_ready)
        self.assertEqual(self.c.entry_plan_worker_state,'DISCARDED')

    def test_poll_gap_invalidates_reference(self):
        self.job();self.tick(100.61)
        self.assertIsNone(self.c.entry_plan_ready)

    def test_emergency_invalidates_reference(self):
        self.job();self.c.lidar_emergency=True;self.tick(100.1)
        self.assertIsNone(self.c.entry_plan_ready)

    def test_planning_failure_is_visible_during_recovery(self):
        f=self.job(False);f.set_exception(ValueError('ENTRY_NO_FEASIBLE_CURVE'))
        self.c.curve_pose_wait=True;self.tick(100.1)
        self.assertEqual(self.c.entry_plan_reason,'ENTRY_NO_FEASIBLE_CURVE')
        self.assertEqual(self.c.entry_plan_worker_state,'FAILED')

    def test_fresh_fit_uses_stopped_seed_not_freshened_cached_pose(self):
        c=self.c;seed=c.entry_plan_anchor['pose']
        c.curve_reset_entry_pose()
        with patch.object(t.controller.time,'monotonic',return_value=100.1), \
             patch.object(c.curve_executor,'submit',return_value=Future()) as submit, \
             patch.object(c,'entry_v33_seed',return_value=None) as regular:
            c.curve_submit_registration(q.scan_at(seed),100.1,123)
        self.assertEqual(submit.call_args.args[-1],seed)
        self.assertIsNone(submit.call_args.args[1].pose)
        self.assertEqual(submit.call_args.args[3],100.1)
        self.assertEqual(submit.call_args.args[1].hits,0)
        regular.assert_not_called()

    def test_completed_plan_can_handoff_after_fresh_reacquisition(self):
        c=self.c;pose=(5.2,.79,0.)
        path=q.g.plan_entry_path(pose)
        self.job(path=path)
        c.curve_reset_entry_pose();self.tick(100.1)
        # A new pose and scan are mandatory; simulate their successful checks.
        c.curve_locator.pose=pose;c.curve_locator.time=100.1;c.curve_locator.hits=2
        c.curve_pose_scan=q.scan_at(pose)
        with patch.object(c,'entry_gate_snapshot',return_value={'POSE':True,'FIRST_CONE':True}), \
             patch.object(c.curve_tracks,'ready',return_value=True), \
             patch.object(t.controller.time,'monotonic',return_value=100.12):
            c.curve_update(100.11)
        self.assertEqual(c.phase,c.ENTER_OBSTACLES)
        self.assertEqual(c.curve_sweep,'CLEAR')

    def test_different_reacquired_pose_requires_replan(self):
        c=self.c;self.job();c.curve_reset_entry_pose();self.tick(100.1)
        c.curve_locator.pose=(5.3,.79,0.)
        with patch.object(c,'entry_gate_snapshot',return_value={'POSE':True}):c.curve_update(100.11)
        self.assertEqual(c.entry_plan_reason,'REPLAN_CURRENT_POSE')
        self.assertIsNone(c.curve_follower)

    def test_fresh_sweep_still_blocks_collision(self):
        c=self.c;pose=(5.2,.79,0.);self.job(path=q.g.plan_entry_path(pose));self.tick(100.1)
        c.curve_locator.pose=pose;c.curve_pose_scan=q.scan_at(pose)
        with patch.object(c,'entry_gate_snapshot',return_value={'POSE':True}), \
             patch.object(c.curve_tracks,'ready',return_value=True), \
             patch.object(t.controller,'scan_observes_body',return_value=(False,'SWEPT_OBSTACLE')):
            c.curve_update(100.11)
        self.assertIsNone(c.curve_follower)
        self.assertEqual(c.route_fault,'ENTRY_SWEPT_OBSTACLE')

if __name__=='__main__':unittest.main(verbosity=2)
