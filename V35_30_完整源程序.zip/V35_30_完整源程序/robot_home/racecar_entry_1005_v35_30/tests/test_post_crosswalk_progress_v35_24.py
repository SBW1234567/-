"""Extra post-crosswalk stop: live corridor vs. finite global-anchor budget.

The two V23 CSVs record PROGRESS_LIMIT with fresh local wall measurements.
These reconstructed sensor states are counterexamples, not raw-lidar replay.
"""
import ast
import math
from pathlib import Path
import types
import unittest
from unittest.mock import patch

import test_final_straight_v35_16 as fixture

cm=fixture.cm


class PostCrosswalkProgressV3524Tests(unittest.TestCase):
    setUp=fixture.FinalStraightV3516Tests.setUp
    refresh_sensors=fixture.FinalStraightV3516Tests.refresh_sensors
    advance=fixture.FinalStraightV3516Tests.advance
    receive_laser_pose=fixture.FinalStraightV3516Tests.receive_laser_pose

    def prepare(self, delta=.90, age=2.15, x=1.25, heading=6.4):
        c=self.c;c.phase=c.SEEK_CONE_1;c.curve_follower=None
        c.entry_v34_anchor=(x,2.,self.now-age);c.entry_v34_anchor_stamp=123
        c.curve_locator.pose=None;c.curve_pose_scan=None;c.entry_wall=None
        c.entry_v34_turn_stop=False;c.entry_v33_braked=False
        c.corridor_filtered=(.59,math.radians(heading));c.corridor_time=self.now-.10
        c.lane_ready=True;c.lane_direction_hits=3
        c.lane_selected_heading=math.radians(heading);c.lane_heading_observation=self.now-.10
        c.curve_motion_samples.clear();c.curve_odom_samples.clear()
        c.curve_motion_velocity=None;c.curve_motion_status={}
        c.last_motion_stamp=0.;c.last_odom_xy=c.last_yaw=None
        self.receive_laser_pose((1.7,0.,0.),source=self.source_now-.2)
        self.receive_laser_pose((1.78,0.,0.),source=self.source_now-.1)
        c.travel_distance=2.+delta
        c.curve_scan=fixture.helpers.scan_at((2.25,.59,0.))
        c.curve_scan_time=self.now-.10
        c.curve_scan_stamp=round((self.source_now-.10)*1e9)
        return c

    def test_old_point_eight_or_two_second_limit_no_longer_stops_live_corridor(self):
        for delta,age in ((.81,1.2),(.50,2.1),(.90,2.15),(1.5,4.0)):
            with self.subTest(delta=delta,age=age):
                c=self.prepare(delta,age);anchor=c.entry_v34_anchor;stamp=c.entry_v34_anchor_stamp
                x,okay=c.entry_v34_progress(self.now)
                self.assertTrue(okay)
                self.assertAlmostEqual(x,1.25+1.15*delta)
                self.assertEqual(c.entry_v34_progress_reason,'LIVE_LANE_BOUNDED_PROGRESS')
                self.assertEqual(c.entry_v34_anchor,anchor)
                self.assertEqual(c.entry_v34_anchor_stamp,stamp)

    def test_fixed_v23_reproduces_the_extra_stop_on_identical_sensor_state(self):
        c=self.prepare()
        baseline=Path(__file__).resolve().parents[3]/'car_patch_v35_23/package/payload/src/racecar/scripts/race_task_controller.py'
        if not baseline.exists():
            baseline=Path(__file__).resolve().parent/'baselines/controller_before_v35_24.py'
        tree=ast.parse(baseline.read_text(encoding='utf-8'))
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RaceTaskController')
        method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='entry_v34_progress')
        namespace=dict(cm.__dict__)
        exec(compile(ast.Module(body=[method],type_ignores=[]),str(baseline),'exec'),namespace)
        before=types.MethodType(namespace['entry_v34_progress'],c)
        self.assertFalse(before(self.now)[1])
        self.assertTrue(c.entry_v34_progress(self.now)[1])

    def test_extension_is_finite_and_never_crosses_original_turn_threshold(self):
        for delta,age,x in ((1.801,2.,1.2),(.9,6.01,1.2),(.9,2.1,3.37),(-.01,2.1,1.2)):
            with self.subTest(delta=delta,age=age,x=x):
                c=self.prepare(delta,age,x)
                self.assertFalse(c.entry_v34_progress(self.now)[1])
        c=self.prepare();c.entry_v34_turn_stop=True
        self.assertFalse(c.entry_v34_progress(self.now)[1])

    def test_stale_or_conflicting_local_wall_does_not_extend_global_position(self):
        for field,value in (('corridor_time',99.6),('lane_heading_observation',99.6),
                            ('lane_direction_hits',2),('lane_selected_heading',math.radians(15.1)),
                            ('lane_ready',False),('curve_scan_time',99.74),('curve_scan',None),
                            ('curve_scan_stamp',round((1000.-.31)*1e9))):
            with self.subTest(field=field):
                c=self.prepare();setattr(c,field,value)
                self.assertFalse(c.entry_v34_progress(self.now)[1])

    def test_received_odom_is_not_enough_when_source_stamp_is_stale(self):
        c=self.prepare();c.curve_motion_samples.clear()
        c.curve_odom_samples.clear();c.last_motion_stamp=0.;c.last_odom_xy=c.last_yaw=None
        self.receive_laser_pose((1.6,0.,0.),source=self.source_now-.5)
        self.receive_laser_pose((1.68,0.,0.),source=self.source_now-.4)
        self.assertEqual(c.last_odom_time,self.now)
        self.assertFalse(c.entry_v34_progress(self.now)[1])

    def test_uncertain_clock_or_curve_phase_cannot_use_straight_extension(self):
        for phase in (self.c.APPROACH_CROSSWALK,self.c.ORBIT_CONE_1,self.c.FINISH_APPROACH):
            c=self.prepare();c.phase=phase
            self.assertFalse(c.entry_v34_progress(self.now)[1])
        c=self.prepare()
        with patch.object(c,'curve_source_now',return_value=None):
            self.assertFalse(c.entry_v34_progress(self.now)[1])

    def test_prepare_does_not_latch_extra_stop_but_actual_safety_reason_still_does(self):
        c=self.prepare()
        with patch.object(c,'entry_gate_snapshot',return_value={'POSE':False}), \
                patch.object(c,'entry_v33_safety_reason',return_value=''):
            c.entry_v34_prepare_update(self.now)
        self.assertFalse(c.entry_hold)
        self.assertFalse(c.entry_v33_braked)
        with patch.object(c,'entry_gate_snapshot',return_value={'POSE':False}), \
                patch.object(c,'entry_v33_safety_reason',return_value='CURVE_RAW_SCAN_STALE'):
            c.entry_v34_prepare_update(self.now)
        self.assertTrue(c.entry_hold)
        self.assertEqual(c.entry_v34_stop_trigger,'CURVE_RAW_SCAN_STALE')


if __name__=='__main__':unittest.main()
