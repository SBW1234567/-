"""V23 distance governor and acquisition-time wall-speed regressions."""
import math
import unittest
from unittest.mock import patch

import test_finish_parking_v35_22 as fixture

cm,core=fixture.cm,fixture.core


class FinishParkingV3523Tests(unittest.TestCase):
    setUp=fixture.FinishParkingV3522Tests.setUp
    refresh_sensors=fixture.FinishParkingV3522Tests.refresh_sensors
    advance=fixture.FinishParkingV3522Tests.advance
    receive_laser_pose=fixture.FinishParkingV3522Tests.receive_laser_pose
    prepare=fixture.FinishParkingV3522Tests.prepare
    scan=fixture.FinishParkingV3522Tests.scan
    tick=fixture.FinishParkingV3522Tests.tick
    stopped_ticks=fixture.FinishParkingV3522Tests.stopped_ticks

    def test_normal_start_can_apply_effective_drive_beyond_old_point_twelve(self):
        c=self.prepare(6.4)
        positive=[]
        for _ in range(16):
            cmd=self.tick();positive.append((self.now,cmd.linear.x))
        runs=[];start=None
        for t,drive in positive:
            if drive>=.349 and start is None:start=t
            elif drive<.349 and start is not None:runs.append(t-start);start=None
        if start is not None:runs.append(positive[-1][0]-start)
        self.assertTrue(runs)
        self.assertGreater(max(runs),.30)
        self.assertLessEqual(max(runs),1.10)

    def test_effective_start_deadline_still_blocks_a_late_publication(self):
        c=self.prepare(6.4)
        for _ in range(20):
            self.tick()
            if c.finish_parking['startup_deadline'] is not None:break
        self.assertIsNotNone(c.finish_parking['startup_deadline'])
        deadline=c.finish_parking['startup_deadline']
        cmd=cm.Twist();cmd.linear.x=.35
        out=c.finish_parking_bound_command(cmd,deadline+.001)
        self.assertEqual(out.linear.x,0.)

    def test_untimed_rolling_does_not_need_a_pulse_deadline(self):
        c=self.prepare(6.8)
        c.finish_parking.update(near=True,timed_drive=False,pulse_deadline=None)
        cmd=cm.Twist();cmd.linear.x=.28
        self.assertIs(c.finish_parking_bound_command(cmd,self.now),cmd)

    def test_near_zero_speed_does_not_bypass_trim_as_rolling(self):
        c=self.prepare(7.36,speed=.07)
        for _ in range(4):
            cmd=self.tick(pose=(self.pose[0]+.007,3.55,0.))
        self.assertEqual(c.finish_parking_status['state'],'PARK_NEEDS_START_ROOM')
        self.assertEqual(cmd.linear.x,0.)

    def test_near_slow_motion_with_prior_response_preserves_distance_control(self):
        c=self.prepare(7.36,speed=.07)
        # Unit fixture represents valid earlier far-region rolling evidence;
        # independent full-route plants exercise how this flag is obtained.
        c.finish_parking['rolling_evidence']=True
        for _ in range(4):cmd=self.tick(pose=(self.pose[0]+.007,3.55,0.))
        self.assertFalse(c.finish_parking['trim_active'])
        self.assertGreater(cmd.linear.x,0.)

    def test_moderate_overspeed_reduces_saved_hold_without_full_stop(self):
        # V29's far target reaches .40 m/s; .30 is no longer overspeed here.
        c=self.prepare(6.5,speed=.45);c.finish_parking['hold_drive']=.35
        for _ in range(4):self.tick(pose=(self.pose[0]+.045,3.55,0.))
        self.assertLess(c.finish_parking['hold_drive'],.35)
        self.assertGreater(c.finish_parking_status['issued_drive'],0.)
        self.assertLess(c.finish_parking_status['issued_drive'],.35)

    def test_last_trim_with_prior_motion_adapts_after_verified_no_motion(self):
        c=self.prepare(7.38);seen={}
        c.finish_parking['rolling_evidence']=True
        # V24 only corrects after its planned final coast has really stopped.
        c.finish_parking['final_coast']=True
        for _ in range(70):
            self.tick()
            deadline=c.finish_parking['pulse_deadline']
            if deadline is not None:seen.setdefault(deadline,c.finish_parking['pulse_duration'])
        durations=list(seen.values())
        self.assertGreaterEqual(len(durations),3)
        self.assertAlmostEqual(durations[0],.04)
        self.assertAlmostEqual(durations[1],.12)
        self.assertAlmostEqual(durations[2],.20)
        self.assertTrue(all(d<=.60 for d in durations))

    def test_unknown_cold_start_close_to_wall_stays_zero_without_repeated_pulses(self):
        c=self.prepare(7.39)
        commands=self.stopped_ticks(35)
        self.assertTrue(all(cmd.linear.x==0. for cmd in commands))
        self.assertIsNone(c.finish_parking['pulse_deadline'])
        self.assertEqual(c.finish_parking_status['state'],'PARK_NEEDS_START_ROOM')
        c.update_phase(self.now)
        self.assertEqual(c.phase,c.FINISH_APPROACH)

    def test_raw_wall_closing_does_not_come_from_odom_distance(self):
        c=self.prepare(7.0)
        for i in range(1,7):
            self.advance(.1)
            # Real scan closes, but actual odometry callback pose is fixed.
            self.pose=(7.+i*.01,3.55,0.)
            self.receive_laser_pose((7.,3.55,0.));self.scan();c.lane_command()
        p=c.finish_parking_status
        self.assertAlmostEqual(p['speed_mps'],0.,places=6)
        self.assertGreater(p['board_closing_mps'],.08)
        self.assertLess(p['board_closing_mps'],.12)
        self.assertGreater(p['control_speed_mps'],p['speed_mps'])

    def test_pure_yaw_does_not_create_an_approaching_board(self):
        c=self.prepare(7.0)
        for i in range(1,7):self.tick(pose=(7.,3.55,math.radians(i*.3)))
        self.assertLess(c.finish_parking_status['board_closing_mps'],.015)

    def test_centimetre_noise_in_multiframe_range_is_not_fast_motion(self):
        c=self.prepare(7.0)
        for shift in (0.,.004,-.004,.003,-.003,0.,.002):
            self.advance(.1);self.pose=(7.+shift,3.55,0.)
            self.receive_laser_pose((7.,3.55,0.));self.scan();c.lane_command()
        self.assertLess(c.finish_parking_status['board_closing_mps'],.06)

    def test_endpoint_identity_loss_discards_range_speed_history(self):
        c=self.prepare(6.4)
        self.stopped_ticks(8)
        self.assertGreater(len(c.finish_parking['range_samples']),0)
        fake=list(core.WALLS)+[((7.,3.1),(7.,4.))]
        self.tick(walls=fake)
        self.assertEqual(c.finish_parking['range_samples'],[])
        self.assertFalse(c.finish_parking_status['valid'])

    def test_scan_pose_loss_discards_range_speed_history(self):
        c=self.prepare(7.0);self.stopped_ticks(8)
        self.advance(.1);self.receive_laser_pose(self.pose);self.scan()
        with patch.object(c,'curve_motion_at',return_value=(None,{'policy':'SOURCE_CLOCK_CHANGED'})):
            observation=c.finish_parking_observation(self.pose,self.now)
        self.assertFalse(observation['valid'])
        self.assertEqual(c.finish_parking['range_samples'],[])

    def test_fresh_stationary_body_with_clear_gap_can_complete_without_driving(self):
        for distance in (.245,.585):
            with self.subTest(distance=distance):
                c=self.prepare(8.-distance)
                commands=self.stopped_ticks(10)
                self.assertTrue(all(cmd.linear.x==0. for cmd in commands))
                c.update_phase(self.now)
                self.assertEqual(c.phase,c.FINISHED)

    def test_contact_or_less_than_three_centimetres_body_gap_is_never_success(self):
        for distance in (.19,.215):
            with self.subTest(distance=distance):
                c=self.prepare(8.-distance)
                self.stopped_ticks(10);c.update_phase(self.now)
                self.assertNotEqual(c.phase,c.FINISHED)
                self.assertFalse(c.finish_parking_status['complete'])
                self.assertEqual(c.finish_parking_status['issued_drive'],0.)

    def test_legal_distance_still_requires_aligned_body_and_rear_inside(self):
        for distance,yaw in ((.48,math.radians(15)),(.48,-math.radians(15)),(.61,0.)):
            with self.subTest(distance=distance,yaw=yaw):
                c=self.prepare(8.-distance,yaw)
                self.stopped_ticks(10);c.update_phase(self.now)
                self.assertNotEqual(c.phase,c.FINISHED)
                self.assertFalse(c.finish_parking_status['complete'])

    def test_near_body_return_blocks_command_completion_despite_valid_end_plane(self):
        c=self.prepare(7.75);self.stopped_ticks(10)
        self.assertTrue(c.finish_parking_status['complete'])
        c.front_clearance=.19
        command=c.lane_command()
        self.assertEqual(command.linear.x,0.)
        self.assertFalse(c.finish_parking_status['complete'])
        self.assertEqual(c.finish_parking_status['state'],'PARK_NEAR_BODY_RETURN')

    def test_new_near_or_invalid_front_return_blocks_final_completion_recheck(self):
        for front in (.19,float('nan'),float('inf'),-1.):
            with self.subTest(front=front):
                c=self.prepare(7.75);self.stopped_ticks(10)
                self.assertTrue(c.finish_parking_status['complete'])
                c.front_clearance=front
                self.assertFalse(c.finish_parking_verified(self.now))
                c.update_phase(self.now)
                self.assertEqual(c.phase,c.FINISH_APPROACH)


if __name__=='__main__':unittest.main()
