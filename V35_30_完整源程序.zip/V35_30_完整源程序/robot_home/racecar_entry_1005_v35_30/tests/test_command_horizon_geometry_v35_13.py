"""Command rollout arcs retain outside-corner obstacles and feedback cadence."""
import math
from pathlib import Path
import sys
import types
import unittest

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'payload/src/racecar/scripts'))
import race_curve_core as core


class ConstantFollower:
    def __init__(self,output=.32,response=None,speed=.5):
        self.path=types.SimpleNamespace(lengths=np.array([0.,10.]))
        self.progress=0.;self.time=100.;self.output=output
        self.response_output=output if response is None else response
        self.speed=speed;self.calls=[]

    def command(self,pose,now,gain,limit):
        self.calls.append((tuple(pose),now,gain,limit))
        self.time=now
        return self.output


def old_rotate_then_translate(pose,output,gain,distance=.65):
    """Previous constant-steer Euler rollout, only for the missed-hit fixture."""
    out=[pose]
    for factor in (.8,1.,1.2):
        x,y,h=pose
        for _ in range(int(math.ceil(distance/.05))):
            h+=gain*output*factor*.05
            x+=.05*math.cos(h);y+=.05*math.sin(h)
            out.append((x,y,h))
    return out


class CommandHorizonGeometryTests(unittest.TestCase):
    def test_constant_turn_matches_analytic_arc_for_every_gain(self):
        pose=(6.7380605054,2.6548701225,2.4004394474)
        f=ConstantFollower();samples=core.command_horizon(pose,f,6.,distance=.65)
        self.assertEqual(len(samples),79)
        for branch,factor in enumerate((.8,1.,1.2)):
            k=6.*.32*factor;angle=pose[2]+k*.65
            expected=(pose[0]+(math.sin(angle)-math.sin(pose[2]))/k,
                pose[1]+(math.cos(pose[2])-math.cos(angle))/k,angle)
            np.testing.assert_allclose(samples[(branch+1)*26],expected,atol=1e-12)
            prior=pose
            for q in samples[branch*26+1:(branch+1)*26+1]:
                self.assertLessEqual(core.dist(q,prior),.025+1e-12)
                self.assertAlmostEqual(q[2]-prior[2],k*.025)
                prior=q

    def test_inside_corner_euler_bias_cannot_hide_a_real_finite_return(self):
        pose=(6.7380605054,2.6548701225,2.4004394474)
        old=old_rotate_then_translate(pose,.32,6.)
        current=core.command_horizon(pose,ConstantFollower(),6.,distance=.65)
        # A real return just below y=3.1, inside the exact swept padded body.
        # Rotating first cuts inward by about 9 mm and misses this point.
        obstacle=(6.3093608761600555,3.0977479138421997)
        point=core.local(obstacle,pose)
        scan=types.SimpleNamespace(ranges=[math.hypot(*point)]+[math.inf]*449,
            angle_min=math.atan2(point[1],point[0]),angle_increment=2*math.pi/450,
            range_min=.05,range_max=12.)
        self.assertFalse(core.scan_hits_body(scan,pose,[pose]))
        self.assertFalse(core.scan_hits_body(scan,pose,old))
        detail={}
        self.assertTrue(core.scan_hits_body(scan,pose,current,diagnostics=detail))
        self.assertGreater(detail['sample_index'],0)
        np.testing.assert_allclose(detail['hit_xy_world'],obstacle,atol=1e-12)

    def test_feedback_updates_at_original_five_centimetre_cadence(self):
        f=ConstantFollower(speed=.7);pose=(0.,0.,0.)
        core.command_horizon(pose,f,5.,distance=.65,speed=.7)
        self.assertEqual(len(f.calls),3*12)
        expected=[100.+j*.05/.7 for _ in range(3) for j in range(1,13)]
        np.testing.assert_allclose([call[1] for call in f.calls],expected,atol=1e-12)
        self.assertEqual(f.time,100.)
        self.assertEqual(f.output,.32);self.assertEqual(f.response_output,.32)

    def test_response_state_integrates_over_original_control_step(self):
        f=ConstantFollower(output=.32,response=.10,speed=.5)
        samples=core.command_horizon((0.,0.,.1),f,5.,distance=.05,speed=.5,steer_tau=.12)
        dt=.05/.5
        mean=.32+(.10-.32)*.12/dt*(1.-math.exp(-dt/.12))
        self.assertEqual(len(samples),7)
        self.assertFalse(f.calls)
        for branch,factor in enumerate((.8,1.,1.2)):
            self.assertAlmostEqual(samples[(branch+1)*2][2],.1+5.*mean*factor*.05)

    def test_constant_target_lag_matches_analytic_yaw_at_every_sample(self):
        pose=(0.,0.,.2);speed=.2;tau=.12;target=.32;initial=.0;gain=5.
        samples=core.command_horizon(pose,ConstantFollower(target,initial,speed),gain,
            distance=.65,speed=speed,steer_tau=tau)
        for branch,factor in enumerate((.8,1.,1.2)):
            for j,q in enumerate(samples[branch*26+1:(branch+1)*26+1],start=1):
                t=j*.025/speed
                response_integral=target*t+(initial-target)*tau*(1.-math.exp(-t/tau))
                expected=pose[2]+gain*factor*speed*response_integral
                self.assertAlmostEqual(q[2],expected,places=12)
        # Using the step END response across the entire first .05 m would
        # rotate 48% too far at this slow speed, even with exact arc geometry.
        end_response=target*(1.-math.exp(-(.05/speed)/tau))
        old_first_yaw=pose[2]+gain*.8*end_response*.05
        self.assertGreater(old_first_yaw-samples[2][2],.018)

    def test_straight_and_near_zero_curvature_stay_numerically_stable(self):
        pose=(2.,3.,.7)
        for output in (0.,1e-13):
            with self.subTest(output=output):
                samples=core.command_horizon(pose,ConstantFollower(output),5.,distance=.65)
                expected=(pose[0]+.65*math.cos(pose[2]),pose[1]+.65*math.sin(pose[2]),pose[2])
                for end in (26,52,78):np.testing.assert_allclose(samples[end],expected,atol=1e-12)


if __name__=='__main__':unittest.main()
