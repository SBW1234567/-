"""Map failure isolation, source time semantics, and existing recovery boundaries."""
import copy
import importlib.util
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE/'payload/src/racecar/scripts'))
import race_curve_core as core


class Hint:
    ready = True
    status = {'state': 'READY', 'profile_id': 'test'}

    def __init__(self, seed):
        self.seed = seed
        self.calls = 0

    def candidate(self, points, seed, deadline):
        self.calls += 1
        return self.seed


class Locator:
    """The first failure destroys hits; a successful retry needs pristine state."""
    def __init__(self, success=False, finish=None):
        self.hits = 7
        self.reason = 'PREVIOUS_TRACKING'
        self.residual = .02
        self.pose = (5., 1., 0.)
        self.time = 99.
        self.yaw = 0.
        self.success = success
        self.finish = finish

    def update(self, points, received, yaw, seed):
        if not self.success and (seed is None or seed[0] <= 5.):
            self.hits = 0
            self.reason = 'WALL_REGISTRATION_REJECTED'
            self.residual = .18
            return False
        self.pose = tuple(self.finish or seed)
        self.hits += 1
        self.time, self.yaw = received, yaw
        self.reason, self.residual = 'TRACKING', .03
        return True


class OptionalMapTests(unittest.TestCase):
    def setUp(self):
        self.scan = SimpleNamespace(ranges=[1.]*180, range_min=.1, range_max=10.,
            angle_min=-math.pi, angle_increment=2*math.pi/180)
        self.seed = (5., 1., 0.)

    def call(self, locator, hint):
        return core.register_scan(locator, self.scan, 100., .02, self.seed, hint)

    def test_successful_original_fit_never_requests_hint(self):
        loc = Locator(success=True)
        hint = Hint((5.1, 1., 0.))
        result, ok, _ = self.call(loc, hint)
        self.assertIs(result, loc)
        self.assertTrue(ok)
        self.assertEqual(hint.calls, 0)
        self.assertEqual(result.pose, self.seed)

    def test_retry_uses_pristine_hits_and_original_source_times(self):
        loc = Locator()
        result, ok, _ = self.call(loc, Hint((5.1, 1., 0.)))
        self.assertTrue(ok)
        self.assertIsNot(result, loc)
        self.assertEqual(loc.hits, 0)
        self.assertEqual(result.hits, 8)
        self.assertEqual(result.time, 100.)
        self.assertEqual(result.yaw, .02)
        self.assertEqual(result.map_assist['outcome'], 'ASSISTED_CURRENT_SCAN')

    def test_second_failed_fit_returns_first_failed_object(self):
        loc = Locator()
        result, ok, _ = self.call(loc, Hint((4.9, 1., 0.)))
        self.assertIs(result, loc)
        self.assertFalse(ok)
        self.assertEqual((result.hits, result.reason, result.residual, result.time),
                         (0, 'WALL_REGISTRATION_REJECTED', .18, 99.))

    def test_hint_error_does_not_become_registration_error(self):
        hint = Hint(None)
        with patch.object(hint, 'candidate', side_effect=ValueError('corrupt profile')):
            loc = Locator()
            result, ok, _ = self.call(loc, hint)
        self.assertIs(result, loc)
        self.assertFalse(ok)
        self.assertEqual(result.reason, 'WALL_REGISTRATION_REJECTED')

    def test_unavailable_map_does_not_retry(self):
        hint = Hint((5.1, 1., 0.))
        hint.ready = False
        loc = Locator()
        result, ok, _ = self.call(loc, hint)
        self.assertIs(result, loc)
        self.assertFalse(ok)
        self.assertEqual(hint.calls, 0)

    def test_hint_cannot_create_a_seed_when_original_has_none(self):
        hint = Hint((5.1, 1., 0.))
        _, ok, _ = core.register_scan(Locator(), self.scan, 100., 0., None, hint)
        self.assertFalse(ok)
        self.assertEqual(hint.calls, 0)

    def test_combined_translation_budget_is_not_additive(self):
        loc = Locator(finish=(5.31, 1., 0.))
        result, ok, _ = self.call(loc, Hint((5.15, 1., 0.)))
        self.assertIs(result, loc)
        self.assertFalse(ok)

    def test_combined_yaw_budget_is_not_additive(self):
        loc = Locator(finish=(5.1, 1., .141))
        result, ok, _ = self.call(loc, Hint((5.1, 1., .06)))
        self.assertIs(result, loc)
        self.assertFalse(ok)

    def test_wrong_or_large_hint_cannot_pass_through(self):
        for seed in ((5.16, 1., 0.), (5.1, 1., .08), (float('nan'), 1., 0.)):
            with self.subTest(seed=seed):
                loc = Locator()
                result, ok, _ = self.call(loc, Hint(seed))
                self.assertIs(result, loc)
                self.assertFalse(ok)

    def test_late_retry_returns_original_failure(self):
        # Advance the monotonic compute clock only at the final acceptance check.
        with patch.object(core.time, 'perf_counter', side_effect=[10., 10., 10.005, 10.07, 10.071]):
            loc = Locator()
            result, ok, _ = self.call(loc, Hint((5.1, 1., 0.)))
        self.assertIs(result, loc)
        self.assertFalse(ok)

    def test_off_has_exact_original_public_state_for_success_and_failure(self):
        for success in (True, False):
            loc = Locator(success=success)
            expected = copy.copy(loc)
            expected.update(None, 100., .02, self.seed)
            result, ok, _ = self.call(loc, False)
            self.assertEqual(vars(result), vars(expected))
            self.assertEqual(ok, success)

    def test_real_original_fitter_is_unchanged_with_assist_off(self):
        spec = importlib.util.spec_from_file_location('v26_core_optional_reference',
            PACKAGE/'tests/baselines/core_before_v35_27.py')
        original = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = original
        spec.loader.exec_module(original)
        for ranges in ([1.]*180, [float('inf')]*180, [.2]*180):
            self.scan.ranges = ranges
            before, a, _ = original.register_scan(original.WallLocalizer(), self.scan, 100., .02, self.seed)
            after, b, _ = self.call(core.WallLocalizer(), False)
            self.assertEqual(vars(before), vars(after))
            self.assertEqual(a, b)


if __name__ == '__main__':
    unittest.main()
