"""Byte-level Linux launch checks, separate from algorithm/ROS stub tests.

Run the file tests before finalizing. After building the delivery ZIP, set
RACECAR_PACKAGE_ZIP to its path and rerun this module to check archived bytes.
The ZIP test deliberately does not compare this test file to its archived copy,
so adding or executing the test does not create a packaging self-reference.
"""
import os
from pathlib import Path
import unittest
import zipfile
import tempfile
import sys
import json


PACKAGE=Path(__file__).resolve().parents[1]
ARCHIVE_PREFIX='racecar_entry_1005_v35_30/'
ENTRYPOINTS=(
    'launch_centered.py',
    'apply_patch.py',
    'install.sh',
    'run_v35_30.sh',
    'verify_v35_30.sh',
    'rollback_v35_29.sh',
    'rf2o_release.py',
    'payload/src/racecar/scripts/race_task_controller.py',
    'payload/src/racecar/scripts/race_lidar_guard.py',
    'payload/src/racecar/scripts/race_curve_core.py',
    'payload/src/racecar/scripts/ican_vision_node.py',
)


class PosixPackagingTests(unittest.TestCase):
    def test_actual_rf2o_install_and_rollback_keep_v35_15_release(self):
        import hashlib
        import json
        manifest = json.loads((PACKAGE / 'rf2o_manifest.json').read_text(encoding='utf-8'))
        expected = '3e6e6faa843070a30216c42675cd9e336c6d3471cf594dc804a8d944293a416f'
        self.assertEqual(manifest['sha256'], expected)
        self.assertEqual(manifest['before_sha256'], expected)
        for directory in ('payload_binary', 'rollback_binary'):
            data = (PACKAGE / directory / 'rf2o_laser_odometry_node').read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), expected)

    def assert_lf_bytes(self,data,label):
        # read_text()/universal newlines would hide precisely the env python3\r
        # interpreter failure that prevented both real V35.14 attempts starting.
        self.assertNotIn(b'\r',data,label+' contains a CR byte')
        if data.startswith(b'#!'):
            first,separator,_=data.partition(b'\n')
            self.assertTrue(separator,label+' has no terminated shebang')
            self.assertNotIn(b'\r',first,label+' has a CR in its interpreter')

    def test_interpreter_check_rejects_crlf_even_when_normalized_hash_matches(self):
        sys.path.insert(0,str(PACKAGE))
        from apply_patch import digest,check_executable_header
        with tempfile.TemporaryDirectory() as temp:
            good=Path(temp)/'good.py';bad=Path(temp)/'bad.py'
            good.write_bytes(b'#!/usr/bin/env python3\npass\n')
            bad.write_bytes(b'#!/usr/bin/env python3\r\npass\r\n')
            self.assertEqual(digest(good),digest(bad))
            check_executable_header(good)
            with self.assertRaisesRegex(ValueError,'interpreter header'):
                check_executable_header(bad)

    def test_actual_linux_entrypoints_have_executable_lf_shebangs(self):
        for relative in ENTRYPOINTS:
            with self.subTest(path=relative):
                data=(PACKAGE/relative).read_bytes()
                self.assertTrue(data.startswith(b'#!'),relative+' has no byte-zero shebang')
                self.assert_lf_bytes(data,relative)

    def test_all_packaged_python_and_shell_files_use_lf_bytes(self):
        files=sorted(p for p in PACKAGE.rglob('*')
                     if p.is_file() and p.suffix in ('.py','.sh'))
        self.assertTrue(files,'No Python/shell package files found')
        for path in files:
            with self.subTest(path=str(path.relative_to(PACKAGE))):
                self.assert_lf_bytes(path.read_bytes(),str(path.relative_to(PACKAGE)))

    def test_finalized_zip_preserves_lf_entrypoint_and_payload_bytes(self):
        value=os.environ.get('RACECAR_PACKAGE_ZIP')
        if not value:self.skipTest('Post-finalizer check: set RACECAR_PACKAGE_ZIP explicitly')
        archive_path=Path(value)
        self.assertTrue(archive_path.is_file(),'Delivery ZIP is missing: '+str(archive_path))
        with zipfile.ZipFile(archive_path) as archive:
            self.assertIsNone(archive.testzip(),'Delivery ZIP CRC check failed')
            sources=[item for item in archive.infolist()
                     if not item.is_dir() and Path(item.filename).suffix in ('.py','.sh')]
            self.assertTrue(sources,'Delivery ZIP has no Python/shell sources')
            for item in sources:
                with self.subTest(member=item.filename):
                    self.assert_lf_bytes(archive.read(item),item.filename)
            for relative in ENTRYPOINTS:
                member=ARCHIVE_PREFIX+relative
                with self.subTest(entrypoint=member):
                    archived=archive.read(member)
                    self.assertTrue(archived.startswith(b'#!'),member+' lost its shebang')
                    self.assert_lf_bytes(archived,member)
                    self.assertEqual(archived,(PACKAGE/relative).read_bytes(),
                                     member+' differs from the finalized package source')
            manifest=json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))
            for item in manifest['files']:
                for mode in ('payload','rollback'):
                    relative=mode+'/'+item['path']
                    member=ARCHIVE_PREFIX+relative
                    with self.subTest(overlay=member):
                        archived=archive.read(member)
                        self.assertEqual(archived,(PACKAGE/relative).read_bytes(),
                                         member+' differs from the finalized overlay/rollback')
                        if Path(relative).suffix in ('.py','.sh'):
                            self.assert_lf_bytes(archived,member)


if __name__=='__main__':unittest.main(verbosity=2)
