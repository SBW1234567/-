"""Current V35.10 behavior plus inherited straight and collision checks."""
import unittest
import test_continuous
import test_straight
import test_sweep_gaps
import test_scan_seam
import test_uneven_wall
import test_registration_recovery
import test_entry_tolerant_control

suite=unittest.TestSuite()
for module in (test_continuous,test_scan_seam,test_uneven_wall,
               test_registration_recovery,test_entry_tolerant_control):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
# Keep the same inherited raw-sweep selection as V35.9. The historical
# SweepControllerTests freeze V35.8's old double-check call structure.
suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(test_sweep_gaps.SweepGapTests))
for test in unittest.defaultTestLoader.loadTestsFromTestCase(test_straight.StraightTests):
    if test._testMethodName not in ('test_task_and_collision_methods_unchanged',
                                    'test_geometry_only_approved_functions_changed'):
        suite.addTest(test)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
