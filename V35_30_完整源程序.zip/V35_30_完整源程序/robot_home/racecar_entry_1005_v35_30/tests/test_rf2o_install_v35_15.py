"""Reject unknown/active targets; verify exact binary install and rollback."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import rf2o_release as installer


class RF2OInstallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        base = Path(self.temp.name)
        self.package = base / 'package'
        self.root = base / 'racecar'
        relative = 'install/rf2o_laser_odometry/lib/rf2o_laser_odometry/rf2o_laser_odometry_node'
        self.target = self.root / relative
        self.target.parent.mkdir(parents=True)
        header = b'\x7fELF\x02\x01' + b'\x00' * 12 + (243).to_bytes(2, 'little')
        self.before, self.after = header + b'original', header + b'release'
        for directory, data in [('rollback_binary', self.before), ('payload_binary', self.after)]:
            folder = self.package / directory
            folder.mkdir(parents=True)
            (folder / self.target.name).write_bytes(data)
        self.target.write_bytes(self.before)
        self.target.chmod(0o755)
        self.manifest = dict(installed_path=relative,
                            before_sha256=hashlib.sha256(self.before).hexdigest(),
                            sha256=hashlib.sha256(self.after).hexdigest())
        self.save_manifest()
        self.addCleanup(patch.stopall)
        patch.object(installer, 'PACKAGE', self.package).start()
        patch.object(installer, 'active_race_processes', return_value=[]).start()

    def save_manifest(self):
        (self.package / 'rf2o_manifest.json').write_text(json.dumps(self.manifest), encoding='utf-8')

    def test_install_and_rollback_preserve_exact_bytes_and_backup(self):
        installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.after)
        backups = list(self.root.parent.glob('rf2o_before_v35_27_*'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), self.before)
        installer.verify(self.root, 'v35')
        installer.install(self.root, rollback=True)
        self.assertEqual(self.target.read_bytes(), self.before)
        installer.verify(self.root, 'original_v35')

    def test_same_release_hash_install_and_rollback_are_verified_no_ops(self):
        (self.package / 'rollback_binary' / self.target.name).write_bytes(self.after)
        self.manifest['before_sha256'] = self.manifest['sha256']
        self.save_manifest()
        self.target.write_bytes(self.after)
        with patch.object(installer.os, 'replace') as replace:
            installer.install(self.root)
            installer.install(self.root, rollback=True)
            replace.assert_not_called()
        self.assertEqual(self.target.read_bytes(), self.after)
        self.assertEqual(list(self.root.parent.glob('rf2o_before_v35_27_*')), [])
        installer.verify(self.root, 'v35')
        installer.verify(self.root, 'original_v35')

    @unittest.skipUnless(os.name == 'posix', 'POSIX execute-bit semantics')
    def test_nonexecutable_known_binary_cannot_report_success(self):
        self.target.write_bytes(self.after)
        self.target.chmod(0o644)
        with self.assertRaisesRegex(ValueError, 'permission'):
            installer.install(self.root)

    def test_active_race_prevents_binary_replacement(self):
        with patch.object(installer, 'active_race_processes', return_value=['42']):
            with self.assertRaisesRegex(ValueError, 'active race'):
                installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.before)

    def test_unknown_installed_binary_is_not_overwritten(self):
        self.target.write_bytes(self.before + b'changed')
        with self.assertRaisesRegex(ValueError, 'Unknown RF2O'):
            installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.before + b'changed')

    def test_damaged_payload_does_not_touch_live_binary(self):
        (self.package / 'payload_binary' / self.target.name).write_bytes(b'bad')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.before)

    def test_wrong_architecture_is_rejected_even_with_matching_checksum(self):
        wrong = bytearray(self.after)
        wrong[18:20] = (62).to_bytes(2, 'little')
        (self.package / 'payload_binary' / self.target.name).write_bytes(wrong)
        self.manifest['sha256'] = hashlib.sha256(wrong).hexdigest()
        self.save_manifest()
        with self.assertRaisesRegex(ValueError, 'RISC-V'):
            installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.before)

    def test_failed_staging_keeps_original_target(self):
        with patch.object(installer.os, 'replace', side_effect=OSError('simulated failure')):
            with self.assertRaises(OSError):
                installer.install(self.root)
        self.assertEqual(self.target.read_bytes(), self.before)
        self.assertEqual(list(self.target.parent.glob('*.v35_27_pending_*')), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
