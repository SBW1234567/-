"""Optional route preference against immutable, independently built fields.

Synthetic paths exercise the preference interface, not the full race planner's
body/curvature certificate. Those remain separate current-production tests.
The wall field is created in map coordinates from a known course-frame line;
rotated profiles must make the same decision without altering any path sample.
"""
import copy
import hashlib
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
from test_map_matcher_v35_27 import module as core


class MapPathV3528Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory=Path(self.temp.name)
        self.serial=0

    def path(self,y=.70,*,rows=321):
        samples=np.zeros((rows,4),dtype=float)
        samples[:,0]=np.linspace(-1.,1.,rows)
        samples[:,1]=y
        samples.setflags(write=False)
        return SimpleNamespace(samples=samples)

    @staticmethod
    def to_map(points,transform):
        tx,ty,angle=transform
        result=[]
        for x,y in points:
            result.append([tx+math.cos(angle)*x-math.sin(angle)*y,
                           ty+math.sin(angle)*x+math.cos(angle)*y])
        return result

    def profile(self,*,transform=(0.,0.,0.),known=None,excludes=(),polygon=None,**overrides):
        self.serial+=1
        directory=self.directory/str(self.serial)
        directory.mkdir()
        resolution=.01
        origin=np.asarray([-3.,-3.])
        row,column=np.indices((600,600))
        map_x=origin[0]+(column+.5)*resolution
        map_y=origin[1]+(row+.5)*resolution
        tx,ty,angle=transform
        # Independent inverse rigid transform for an infinite course y=1 wall.
        course_x=math.cos(angle)*(map_x-tx)+math.sin(angle)*(map_y-ty)
        course_y=-math.sin(angle)*(map_x-tx)+math.cos(angle)*(map_y-ty)
        distances=np.abs(1.-course_y).astype(np.float32)
        valid=np.ones(distances.shape,dtype=np.uint8)
        if known is not None:
            valid=np.asarray(known(course_x,course_y),dtype=np.uint8)
        field=directory/'distance_field.npz'
        np.savez(field,distances=distances,valid=valid,origin_xy=origin,resolution=resolution)
        profile=dict(schema=1,profile_id='independent-map-path-'+str(self.serial),
            distance_field=field.name,distance_field_sha256=hashlib.sha256(field.read_bytes()).hexdigest(),
            course_to_map=list(transform),
            valid_course_polygon=polygon or [[-2.,-2.],[2.,-2.],[2.,2.],[-2.,2.]],
            exclude_map_polygons=[self.to_map(p,transform) for p in excludes],
            purpose='Historical localization metadata does not substitute for runtime route checks')
        profile.update(overrides)
        path=directory/'profile.json'
        path.write_text(json.dumps(profile),encoding='utf-8')
        return path

    def load(self,path=None,**options):
        helper=core.MapAssist(path if path is not None else self.profile(**options))
        helper._loader.join(3.)
        self.assertFalse(helper._loader.is_alive())
        return helper

    def rank(self,helper,paths):
        with patch.object(core._map_time,'perf_counter',return_value=100.):
            return helper.rank_paths(paths)

    def select(self,helper,paths):
        with patch.object(core,'optional_map_assist',return_value=helper), \
                patch.object(core._map_time,'perf_counter',return_value=100.):
            return core.select_first_cone_path(paths)

    def test_real_wall_field_prefers_larger_clearance_without_editing_samples(self):
        helper=self.load()
        paths=[self.path(.70),self.path(.64)]
        before=[p.samples.tobytes() for p in paths]
        selected,detail=self.rank(helper,paths)
        self.assertEqual(selected,1)
        self.assertEqual(detail['state'],'MAP_CLEARANCE_PREFERRED')
        self.assertAlmostEqual(detail['scores'][0]['min_clearance_m'],.07,places=6)
        self.assertAlmostEqual(detail['scores'][1]['min_clearance_m'],.13,places=6)
        self.assertGreater(detail['improvement_m'],.015)
        self.assertEqual([p.samples.tobytes() for p in paths],before)
        self.assertTrue(all(not p.samples.flags.writeable for p in paths))

    def test_rotated_translated_profile_preserves_ranking_and_clearances(self):
        paths=[self.path(.70),self.path(.64)]
        plain=self.rank(self.load(),paths)
        rotated=self.rank(self.load(transform=(.31,-.27,.41)),paths)
        self.assertEqual(plain[0],rotated[0])
        for a,b in zip(plain[1]['scores'],rotated[1]['scores']):
            self.assertAlmostEqual(a['score_m'],b['score_m'],places=6)
            self.assertAlmostEqual(a['min_clearance_m'],b['min_clearance_m'],places=6)

    def test_improvement_threshold_keeps_default_below_fifteen_mm(self):
        # For this uniform line clearance, score = 1.30 * clearance.
        helper=self.load()
        selected,detail=self.rank(helper,[self.path(.70),self.path(.70-(.015-.0001)/1.30)])
        self.assertEqual(selected,0)
        self.assertLess(detail['improvement_m'],.015)
        self.assertEqual(detail['state'],'DEFAULT_CLEARANCE_PREFERRED')

    def test_improvement_threshold_prefers_alternative_above_fifteen_mm(self):
        helper=self.load()
        selected,detail=self.rank(helper,[self.path(.70),self.path(.70-(.015+.0001)/1.30)])
        self.assertEqual(selected,1)
        self.assertGreaterEqual(detail['improvement_m'],.015)

    def test_tie_and_saturated_far_clearance_keep_first_candidate(self):
        for heights in ((.70,.70),(.1,-.1)):
            selected,detail=self.rank(self.load(),[self.path(y) for y in heights])
            self.assertEqual(selected,0)
            self.assertEqual(detail['state'],'DEFAULT_CLEARANCE_PREFERRED')

    def test_unknown_better_candidate_falls_back_to_default(self):
        helper=self.load(known=lambda x,y:y>.45)
        selected,detail=self.rank(helper,[self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'INSUFFICIENT_MAP_COVERAGE')

    def test_map_exclusion_applies_after_transform_and_falls_back(self):
        excluded=[[-2.,.395],[2.,.395],[2.,.435],[-2.,.435]]
        for transform in ((0.,0.,0.),(.31,-.27,.41)):
            helper=self.load(transform=transform,excludes=[excluded])
            selected,detail=self.rank(helper,[self.path(.70),self.path(.64)])
            self.assertEqual(selected,0)
            self.assertEqual(detail['state'],'INSUFFICIENT_MAP_COVERAGE')

    def test_course_polygon_applies_before_map_transform(self):
        polygon=[[-2.,.45],[2.,.45],[2.,2.],[-2.,2.]]
        helper=self.load(transform=(.31,-.27,.41),polygon=polygon)
        selected,detail=self.rank(helper,[self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'INSUFFICIENT_MAP_COVERAGE')

    def test_outside_distance_field_is_not_treated_as_open_space(self):
        helper=self.load()
        outside=self.path(.64)
        samples=outside.samples.copy();samples[:,0]+=20.;samples.setflags(write=False)
        outside.samples=samples
        selected,detail=self.rank(helper,[self.path(.70),outside])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'INSUFFICIENT_MAP_COVERAGE')

    def test_missing_and_bad_profile_fall_back_without_mutating_load_status(self):
        for path in (self.directory/'missing.json',self.profile(distance_field_sha256='0'*64)):
            helper=self.load(path)
            self.assertFalse(helper.ready)
            status=copy.deepcopy(helper.status)
            paths=[self.path(.70),self.path(.64)]
            chosen=self.select(helper,paths)
            self.assertIs(chosen,paths[0])
            self.assertEqual(chosen.map_planning_status['state'],'NOT_READY')
            self.assertEqual(helper.status,status)

    def test_map_off_false_and_none_select_default_with_map_off_status(self):
        for helper in (False,None):
            paths=[self.path(.70),self.path(.64)]
            chosen=self.select(helper,paths)
            self.assertIs(chosen,paths[0])
            self.assertEqual(chosen.map_planning_status['state'],'MAP_OFF')

    def test_loader_pending_never_waits_for_map(self):
        helper=self.load()
        helper.ready=False
        with patch.object(helper,'_values',side_effect=AssertionError('must not inspect pending field')):
            selected,detail=self.rank(helper,[self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'NOT_READY')

    def test_single_candidate_needs_no_grid_work(self):
        helper=self.load()
        with patch.object(helper,'_values',side_effect=AssertionError('unneeded field work')):
            selected,detail=self.rank(helper,[self.path(.70)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'SINGLE_CANDIDATE')

    def test_malformed_numeric_paths_cannot_be_selected(self):
        invalid=[np.zeros((320,4)),np.zeros((321,2)),np.zeros(321)]
        nonfinite=np.zeros((321,4));nonfinite[12,1]=float('nan');invalid.append(nonfinite)
        for samples in invalid:
            selected,detail=self.rank(self.load(),[self.path(.70),SimpleNamespace(samples=samples)])
            self.assertEqual(selected,0)
            self.assertEqual(detail['state'],'INVALID_PATH')

    def test_malformed_path_object_and_bad_rank_result_are_caught_by_selector(self):
        paths=[self.path(.70),SimpleNamespace()]
        self.assertIs(self.select(self.load(),paths),paths[0])
        self.assertEqual(paths[0].map_planning_status['state'],'MAP_RANK_UNAVAILABLE')
        for result in (-1,2,'1',None):
            helper=SimpleNamespace(rank_paths=lambda paths,result=result:(result,{}))
            selected=self.select(helper,paths)
            self.assertIs(selected,paths[0])
            self.assertEqual(selected.map_planning_status['state'],'INVALID_MAP_RANK')

    def test_no_candidate_is_a_planner_error_not_a_map_wait(self):
        with self.assertRaisesRegex(ValueError,'NO_FIRST_CONE_CANDIDATES'):
            core.select_first_cone_path([])

    def test_budget_expired_before_work_keeps_default(self):
        helper=self.load()
        with patch.object(core._map_time,'perf_counter',side_effect=[100.,100.061]), \
                patch.object(helper,'_values') as work:
            selected,detail=helper.rank_paths([self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'BUDGET_EXPIRED')
        work.assert_not_called()

    def test_result_after_budget_is_discarded_even_if_alternative_scores_better(self):
        helper=self.load()
        with patch.object(core._map_time,'perf_counter',side_effect=[100.,100.,100.,100.,100.061,100.061]):
            selected,detail=helper.rank_paths([self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'BUDGET_EXPIRED')
        self.assertGreater(detail['scores'][1]['score_m'],detail['scores'][0]['score_m'])

    def test_at_most_four_candidates_are_inspected(self):
        helper=self.load()
        paths=[self.path(.70)]*4+[SimpleNamespace()]
        selected,detail=self.rank(helper,paths)
        self.assertEqual(selected,0)
        self.assertEqual(detail['candidates'],4)
        self.assertEqual(len(detail['scores']),4)
        self.assertTrue(all(s['poses']==81 and s['points_per_pose']==49 for s in detail['scores']))

    def test_ranking_does_not_mutate_registration_state_fields_or_profile_files(self):
        profile=self.profile()
        helper=self.load(profile)
        helper.status=dict(state='CANDIDATE',attempts=7,marker='previous registration result')
        helper._attempts=7;helper._next_attempt=321.
        identity=helper.status;status=copy.deepcopy(identity)
        files={path:path.read_bytes() for path in profile.parent.iterdir()}
        arrays={name:getattr(helper,name).tobytes() for name in ('_distance','_valid','_fa','_fb','_fc','_fd','_fq')}
        paths=[self.path(.70),self.path(.64)]
        chosen=self.select(helper,paths)
        self.assertIs(chosen,paths[1])
        self.assertFalse(hasattr(paths[0],'map_planning_status'))
        self.assertIs(helper.status,identity)
        self.assertEqual(helper.status,status)
        self.assertEqual((helper._attempts,helper._next_attempt),(7,321.))
        for name,data in arrays.items():
            self.assertEqual(getattr(helper,name).tobytes(),data)
            self.assertFalse(getattr(helper,name).flags.writeable)
        self.assertEqual({path:path.read_bytes() for path in files},files)

    def test_budget_expiring_after_validation_never_enters_batch(self):
        helper=self.load()
        with patch.object(core._map_time,'perf_counter',side_effect=[100.,100.,100.,100.061]), \
                patch.object(helper,'_values') as work:
            selected,detail=helper.rank_paths([self.path(.70),self.path(.64)])
        self.assertEqual(selected,0)
        self.assertEqual(detail['state'],'BUDGET_EXPIRED')
        work.assert_not_called()

    def test_one_time_plan_budget_is_sixty_ms_without_changing_registration_budget(self):
        self.assertEqual(core.MapAssist.MAX_SECONDS,.030)
        helper=self.load()
        with patch.object(core._map_time,'perf_counter',side_effect=[100.,100.,100.,100.,100.040,100.040]):
            selected,detail=helper.rank_paths([self.path(.70),self.path(.64)])
        self.assertEqual(selected,1)
        self.assertEqual(detail['state'],'MAP_CLEARANCE_PREFERRED')
        self.assertEqual(detail['budget_ms'],60.)
        self.assertAlmostEqual(detail['elapsed_ms'],40.)

    def test_batch_calls_field_lookup_once_without_reducing_footprint_samples(self):
        helper=self.load()
        paths=[self.path(y) for y in (.70,.67,.64,.61)]
        with patch.object(helper,'_values',wraps=helper._values) as lookup:
            self.rank(helper,paths)
        self.assertEqual(lookup.call_count,1)
        self.assertEqual(lookup.call_args.args[0].shape,(4*81*49,))

    @staticmethod
    def old_rank(helper,paths):
        source=Path(__file__).parent/'baselines/rank_paths_before_vectorization_v35_28.py'
        namespace=dict(core.__dict__)
        exec(compile(source.read_text(encoding='utf-8'),str(source),'exec'),namespace)
        with patch.object(core._map_time,'perf_counter',return_value=100.):
            return namespace['rank_paths'](helper,paths)

    def assert_rank_equivalent(self,helper,paths):
        original=self.old_rank(helper,paths)
        batched=self.rank(helper,paths)
        self.assertEqual(original[0],batched[0])
        self.assertEqual(original[1]['state'],batched[1]['state'])
        self.assertEqual(original[1].keys(),batched[1].keys())
        for key in original[1]:
            if key=='budget_ms':
                # Measured one-time planner budget intentionally raised; all
                # numerical scores/threshold decisions remain equivalent.
                self.assertEqual(original[1][key],30.)
                self.assertEqual(batched[1][key],60.)
            elif key=='scores':
                self.assertEqual(len(original[1][key]),len(batched[1][key]))
                for old,new in zip(original[1][key],batched[1][key]):
                    self.assertEqual(old.keys(),new.keys())
                    for field in old:
                        # Equivalent operations should match to numerical
                        # precision, without weakening any production cutoff.
                        self.assertAlmostEqual(old[field],new[field],delta=2e-14)
            elif isinstance(original[1][key],float):
                self.assertAlmostEqual(original[1][key],batched[1][key],delta=2e-14)
            else:self.assertEqual(original[1][key],batched[1][key])

    def test_batched_scores_match_frozen_loop_on_rotated_real_fields(self):
        for transform in ((0.,0.,0.),(.31,-.27,.41),(-.27,.12,-.33)):
            helper=self.load(transform=transform)
            for ys in ((.70,.64),(.70,.70),(.1,-.1),(.70,.67,.64,.61),
                       (.70,.70-(.015-.0001)/1.3),(.70,.70-(.015+.0001)/1.3)):
                self.assert_rank_equivalent(helper,[self.path(y) for y in ys])

    def test_batched_coverage_failure_matches_frozen_loop(self):
        paths=[self.path(.70),self.path(.64)]
        self.assert_rank_equivalent(self.load(known=lambda x,y:y>.45),paths)
        self.assert_rank_equivalent(self.load(transform=(.31,-.27,.41),
            excludes=[[[-2.,.395],[2.,.395],[2.,.435],[-2.,.435]]]),paths)

    def test_batched_scores_match_frozen_loop_on_all_three_lab_seed_banks(self):
        from test_first_profile_v35_28 import RUNS
        profile=Path(__file__).resolve().parents[1]/'maps/lab_20261003/profile.json'
        helper=self.load(profile)
        self.assertTrue(helper.ready,helper.status)
        for run,item in RUNS.items():
            with self.subTest(run=run):
                bank=core.first_cone_clearance_paths(item['seed'],item['cones'])
                self.assertEqual(len(bank),3)
                self.assert_rank_equivalent(helper,bank)


if __name__=='__main__':unittest.main(verbosity=2)
