V35.28 第一桶北侧转弯空间调整
版本：FIRST_CONE_CLEARANCE_1004_V35_28
精确回退目标：V35.27 OPTIONAL_MAP_ASSIST_1003_V35_27

一、针对的问题

第 1、2、5 次 V35.27 实跑在第一桶 +y 侧出现预测车体扫到内隔板的停车。
第 1、2 次有人工推车或扶正，第 5 次自行通过但仍有卡顿，不能把前两次
人工移动后的轨迹当作自主恢复，也不能把第五次通过当作问题已消失。

本版先尝试三条第一桶路线：先直行，再用 0.20m 路段平滑增加曲率，
接半径 0.75m 的圆弧。东侧切点相对实时桶心为 0.72m（默认）、0.68m、
0.70m；北侧位置随入口姿态和桶心计算，不整体放大绕圈。候选均逐点通过
原 0.10m 车体余量、0.55m 最小半径和采样间距检查。候选不成立时保留
原来的完整规划回退。入口曲率从零起步，避免突然施加固定满舵。

持续受阻时，确认停稳、预转向达到原时间、模型转向到位且弧线仍不通，
日志改为 FIRST_CONE_ARC_BLOCKED，便于区分几何受阻与舵尚未到位。
这只是准确诊断，不会到时间后强行驶出。准确修改范围以交付目录 DELIVERY.json 和冻结的
tests/v35_28_scope.json 为准。候选路径通过离线检查不等于实车必然无卡顿。

预建图对上述已通过检查的候选比较第一桶车体余量；改善分数至少 0.015m
才选择非默认路线，差别不足时保留默认。评分取前 321 点中每隔 4 点的
车体内部/边缘小网格；距离场截断 0.20m，覆盖不足 98% 或超出 60ms
合作式预算则回退默认。它是路线偏好，不是完整连续碰撞认证，也不是硬实时定时器。
评分合并处理各候选；这项预算只用于一次入口规划，原实时定位的 30ms
地图初值搜索预算及 60ms 整体重试预算不变。车载静态测得完整路线评分
约 40–49ms，故没有继续使用会使评分总被丢弃的早期 30ms 草案。
地图缺失、加载中或出错均不等待。原有“墙定位失败后借地图重试”的功能保留。
日志 plan_map_assist 记录是否参与选路、每条评分及选中序号；
plan_first_cone_profile 记录实际选中的圆弧和切点参数。
原地图配置格式兼容，不把本实验室挡板形状或地图坐标硬编码进通用代码。
实时雷达与扫掠检查始终保留，地图不能覆盖当前扫描中的障碍。

第一桶到第二桶的连接段随第一桶调整；从第 480 个路径采样点起，第二桶及
进入最后直道的既有路线精确保留；斑马线、红绿灯、终点停车、
driver、雷达 -3°、外部持久化设置沿用 V35.27。完整源码/配置差异及检查
结果见交付记录，不应从版本号或旧测试数量推断当前验证结果。

二、运行

使用默认实验室地图：
bash /home/bianbu/racecar_entry_1004_v35_28/run_v35_28.sh /home/bianbu/racecar false

关闭可选地图辅助，保留 V35.28 其余代码：
bash /home/bianbu/racecar_entry_1004_v35_28/run_v35_28.sh /home/bianbu/racecar false 0.35 off

第四个参数选择新地图目录或 profile.json：
bash /home/bianbu/racecar_entry_1004_v35_28/run_v35_28.sh /home/bianbu/racecar false 0.35 /home/bianbu/maps/official_profile

路径含空格时用双引号包住。参数依次为工作区、dry_run、原起步输入、地图。
省略第二个参数仍为 true；第三个参数仍只接受原已标定的 0.35，单位不是 m/s。
缺失或不可用的地图继续退回原实时定位流程，不等待地图。
入口先核对源码和 install 哈希，再选择地图。只给本次进程传环境变量，
不修改 .bashrc 或全局启动设置，不重新引入 V35.17 的启动预热门槛。

V35.27 的可选定位辅助和等价计算优化保留。V35.28 入口仍显式传入
enable_slam:=false，关闭重复 Cartographer 完整建图；雷达、局部墙定位、
RF2O、静态 TF、视觉和 driver 保留。通用 launch 默认值仍为 true。
入口停稳交接仍存在，并非把所有零驱动或障碍检查删除。

三、更换地图

新场地图不需要重写控制器。为每张图准备新的 profile.json 与
distance_field.npz，然后用第四个启动参数选择。规则尺寸相同也不能保证
建图的原点和朝向相同；新图须校准 course_to_map 和有效赛道/排除场外范围，
不能仅替换 PGM/YAML 后沿用旧坐标转换。随包原实验室 profile 字节保持不变，
其中 purpose 是创建时的历史描述；本版实际用途已扩展为定位初值和候选选路。
新 prepare_map_profile.py 生成的用途说明同时包含这两项。

python3 /home/bianbu/racecar_entry_1004_v35_28/prepare_map_profile.py --map /home/bianbu/maps/new_course/course.yaml --alignment /home/bianbu/maps/new_course/alignment.json --output /home/bianbu/maps/official_profile

输出目录必须尚不存在。工具支持 ROS trinary YAML+PGM 及原 OccupancyGrid
JSON。alignment 格式可参考 maps/lab_alignment.json，但不同场地不能照抄
其中的坐标数值。assist_mask.png 仅展示辅助匹配区域，不修改原始地图或扫描。

四、安装、验证和精确回退

实际车端改动前必须先对源文件、install、启动脚本及外部持久化设置作
Git 提交，并将离线 bundle 下载到本电脑校验。安装/回退都须停止现有比赛、
驱动和传感器进程；以下脚本本身不发动车辆。

安装：
bash /home/bianbu/racecar_entry_1004_v35_28/install.sh /home/bianbu/racecar

只读验证：
bash /home/bianbu/racecar_entry_1004_v35_28/verify_v35_28.sh /home/bianbu/racecar

精确回退到修改前 V35.27：
bash /home/bianbu/racecar_entry_1004_v35_28/rollback_v35_27.sh /home/bianbu/racecar

回退验证成功后使用原入口：
bash /home/bianbu/racecar_entry_1003_v35_27/run_v35_27.sh /home/bianbu/racecar false

不要混用版本入口。关闭地图辅助并不等同于回退代码。
rollback 包含实际 V35.27 的七个源码文件，包括两个 launch 原文件；RF2O
二进制、视觉、保护和配置均精确保留。旧 V35.27 安装包和 Git bundle 不覆盖。
原全车 snapshot 工具未自动覆盖新增 V35.27/V35.28 独立包，因此每次修改
这些包或其中地图时，还必须对实际独立目录提交并导出 Git --all bundle，
验证后再建立修改后的提交。源码备份不能替代系统环境镜像。

五、验证

当前完整回归入口：python3 tests/run_tests_v35_28.py
继承既有行为测试；旧 V22 停车策略对照仍明确保留。第一桶几何的历史
精确坐标断言应由新的当前路径验证替代，但不应借此跳过碰撞或第二桶行为测试。
V35.28 的实际测试数量、车端安装状态、Git 提交和实跑状态以 DELIVERY.json
为准。包内旧 README 仅供历史追溯，不能作为当前运行入口。
