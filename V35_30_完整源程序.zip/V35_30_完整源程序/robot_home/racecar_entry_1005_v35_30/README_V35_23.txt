V35.23 — 终点段按距离控制
版本：DISTANCE_PARKING_1002_V35_23
基线：V35.22 FINISH_PARKING_1002_V35_22

范围
- 修复绿灯放行后远离末墙仍被极短点动限制、车辆难以起步的问题。远端允许有效起步并按实测速度维持前进，接近末墙时按距离和速度卸油；停车段改动仅位于finish_parking_方法。
- 本次六文件覆盖仅控制器改变，几何核心、视觉、YAML、雷达保护、launch和RF2O二进制保持精确V22，底盘驱动不改。
- V22第一桶恢复、红绿灯确认、斑马线、启动流程以及原控制调度和发布前停车守卫保持原样。
- 驱动输入不是标定m/s；0映射PWM1500中性请求，不等于强制瞬时刹停。本补丁没有加入主动反向制动。
- 规则要求四个轮子停在80cm终点区内且不撞板；完成判定保留保守车体模型、新鲜末墙和真实停稳证据。实际轮廓及标线应现场核对。
- 前进禁入采用车头前10cm缓冲；已经实际停稳后的几何完成采用车体前端3cm、后端2cm测量余量。两者用途不同：停稳位置满足几何要求不等于允许继续前进，也不把发出零驱动视为停稳。
- 完成时最近前向回波还必须有效且在车头外至少3cm；不能因拟合出了较远的末墙，就忽略车头范围内的更近障碍。
- 仅在没有本段先前真实运动证据、距末墙不足0.85m且车辆近乎静止的特殊冷启动情况下，保持PARK_NEEDS_START_ROOM并拒绝盲目起步，不声称完成；该版本不承诺从所有贴近末墙的初始位置都能完成停车。
- 本轮安装与隔离验证不驱动车辆，不能据此声称已完成实车赛道验证。

Git备份
修改前实际车端V22提交：092c62895dd24de7dbc546352fe425109255fe8c
车端仓库：/home/bianbu/racecar_git_backups
备份工具：/home/bianbu/snapshot_vehicle_git.py
本地bundle：vehicle_git_backups/racecar_backup_092c62895dd2.bundle
安装与回退先核对现状并备份；备份失败不会写源码。

安装（只安装和构建）
  bash /home/bianbu/racecar_entry_1002_v35_23/install.sh /home/bianbu/racecar

核对安装
  bash /home/bianbu/racecar_entry_1002_v35_23/verify_v35_23.sh /home/bianbu/racecar

后续人工运行命令（本轮不执行）
  bash /home/bianbu/racecar_entry_1002_v35_23/run_v35_23.sh /home/bianbu/racecar false
默认dry_run=true；false允许实车运动。Ctrl+C停止。

回退V22（只回退和构建）
  bash /home/bianbu/racecar_entry_1002_v35_23/rollback_v35_22.sh /home/bianbu/racecar
六文件源码和安装内容均核对精确V22哈希，未知修改不覆盖。
回退后人工运行命令：
  bash /home/bianbu/racecar_entry_1002_v35_22/run_v35_22.sh /home/bianbu/racecar false

测试
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 tests/run_tests_v35_23.py
新增终点距离控制与独立电机响应测试。旧V22的五个脉冲协议专属测试及一个旧停车余量测试，通过HistoricalV22ParkingPolicyTests显式运行于固定V22控制器；这六项结果仅证明历史基线，不作为V23效果证据。其它19项旧停车测试继续测试V23生产控制器。
所有非停车方法逐AST对照tests/baselines/controller_before_v35_23.py，包含V22原有control_loop、update_phase、发布守卫、第一桶和视觉确认流程。
旧视觉21张标定图、V20报告和各历史基线保持不变。

隔离真实ROS检查（dry_run，localhost-only，不启动driver/camera/lidar节点）
  python3 tests/validate_real_ros_startup_v35_23.py --workspace /home/bianbu/racecar --report /tmp/real_ros_startup_v35_23.json
  python3 tests/validate_start_zone_v35_23.py --workspace /home/bianbu/racecar --report /tmp/real_ros_start_zone_v35_23.json
  python3 tests/validate_traffic_v35_23.py --workspace /home/bianbu/racecar --report /tmp/real_ros_traffic_v35_23.json
  python3 tests/validate_traffic_images_v35_23.py --workspace /home/bianbu/racecar --report /tmp/real_ros_traffic_images_v35_23.json
  python3 tests/validate_finish_parking_v35_23.py --workspace /home/bianbu/racecar --report /tmp/real_ros_finish_parking_v35_23.json
DOMAIN222启动缺传感器零驱动，223起步区斑马线，224红绿灯DDS，225真实图片识别链路，226停车控制DDS。停车测试显式设置末段阶段，不是完整赛道或真实动力学试跑。
实际测试结果单独记录，本文不预写实装通过。

证据边界
日志中的位置响应包含源传感器延迟，不能把接收到的零指令时间当作电机实际刹车时间。
独立电机模型覆盖多组起动延迟、死区和惯性，仍不能替代真实车辆标定或现场运行。
