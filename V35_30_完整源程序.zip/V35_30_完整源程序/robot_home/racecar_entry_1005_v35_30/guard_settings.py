#!/usr/bin/env python3
"""Read explicit scalar-distance guards. Collision envelopes stay enabled."""
from pathlib import Path
import math
import yaml


def validate_guards(data):
    keys = {'side_distance_guard_enabled', 'side_steering_guard_enabled',
            'exit_front_stop_distance'}
    if not isinstance(data, dict) or set(data) != keys:
        raise ValueError('Guard settings must contain exactly: '+', '.join(sorted(keys)))
    for key in ('side_distance_guard_enabled', 'side_steering_guard_enabled'):
        if type(data[key]) is not bool:
            raise ValueError(key+' must be true or false, without quotes')
    value = data['exit_front_stop_distance']
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('exit_front_stop_distance must be a number in metres')
    if not math.isfinite(value) or not .50 <= value <= 1.50:
        raise ValueError('exit_front_stop_distance must be within 0.50..1.50 metres')
    return dict(data, exit_front_stop_distance=float(value))


def read_guards(path=None):
    path = Path(__file__).resolve().parent.parent/'racecar_restore_v29_0925/guard_settings.yaml' if path is None else path
    try:
        data = yaml.safe_load(path.read_text(encoding='utf-8'))
    except yaml.YAMLError as exc:
        raise ValueError(f'Invalid guard YAML: {exc}') from exc
    if not isinstance(data, dict) or data.get('schema') != 1:
        raise ValueError('Unknown guard settings schema')
    return validate_guards({key: value for key, value in data.items() if key != 'schema'})
