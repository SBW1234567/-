#!/usr/bin/env python3
"""Install or restore the exact, offline-validated RF2O executable."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
from baseline_check import active_race_processes

PACKAGE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metadata():
    data = json.loads((PACKAGE / 'rf2o_manifest.json').read_text(encoding='utf-8'))
    for mode, key in [('payload_binary', 'sha256'), ('rollback_binary', 'before_sha256')]:
        path = PACKAGE / mode / 'rf2o_laser_odometry_node'
        if digest(path) != data[key]:
            raise ValueError('RF2O package hash mismatch: ' + str(path))
        header = path.read_bytes()[:20]
        if header[:6] != b'\x7fELF\x02\x01' or int.from_bytes(header[18:20], 'little') != 243:
            raise ValueError('Expected a 64-bit little-endian RISC-V executable')
    return data


def verify(root, version='either'):
    data = metadata()
    root = Path(root).resolve()
    target = (root / data['installed_path']).resolve()
    if not target.is_relative_to(root):
        raise ValueError('RF2O target outside workspace')
    accepted = ({data['sha256']} if version == 'v35' else
                {data['before_sha256']} if version == 'original_v35' else
                {data['sha256'], data['before_sha256']})
    if not target.is_file() or digest(target) not in accepted:
        raise ValueError('Unknown RF2O executable; no overwrite: ' + str(target))
    if os.name == 'posix' and (not target.stat().st_mode & 0o111 or not os.access(target, os.X_OK)):
        raise ValueError('RF2O executable permission is missing: ' + str(target))
    return target, data


def install(root, rollback=False):
    running = active_race_processes()
    if running:
        raise ValueError('Stop active race processes first: ' + ', '.join(running))
    target, data = verify(root)
    wanted = data['before_sha256'] if rollback else data['sha256']
    if digest(target) == wanted:
        print('RF2O executable already matches requested version.')
        return
    backup = Path(root).resolve().parent / ('rf2o_before_v35_27_' +
             datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    shutil.copy2(target, backup)
    source = PACKAGE / ('rollback_binary' if rollback else 'payload_binary') / target.name
    pending = target.with_name(target.name + '.v35_27_pending_' + str(os.getpid()))
    try:
        shutil.copyfile(source, pending)
        pending.chmod(0o755)
        if digest(pending) != wanted:
            raise ValueError('RF2O staging checksum mismatch')
        os.replace(pending, target)
    finally:
        pending.unlink(missing_ok=True)
    verify(root, 'original_v35' if rollback else 'v35')
    print('RF2O backup: ' + str(backup))
    print('RF2O ' + ('original restored' if rollback else 'Release installed') + '; verified SHA256.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--rollback', action='store_true')
    args = parser.parse_args()
    from install_lock import workspace_lock
    with workspace_lock():
        install(args.workspace, args.rollback)
