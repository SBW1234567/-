"""Share the runner lock across the complete shell install/build transaction."""
from contextlib import contextmanager
import os
from pathlib import Path


@contextmanager
def workspace_lock():
    import fcntl
    path = Path.home() / '.config/racecar/steering_center.lock'
    path.parent.mkdir(parents=True, exist_ok=True)
    inherited = os.environ.get('RACECAR_INSTALL_LOCK_FD')
    if inherited is not None:
        descriptor = int(inherited)
        actual, expected = os.fstat(descriptor), path.stat()
        if (actual.st_dev, actual.st_ino) != (expected.st_dev, expected.st_ino):
            raise ValueError('Inherited descriptor is not the workspace lock')
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # The invoking shell owns this descriptor and holds it through build.
        yield
        return
    with path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
