V35.27 可选地图辅助定位
版本：OPTIONAL_MAP_ASSIST_1003_V35_27
基线与精确回退目标：V35.26 FIRST_CONE_CONTINUITY_1002_V35_26

一、这一版地图负责什么

地图用于原有局部墙面定位失败时，提供经过当前雷达匹配的小范围候选位置，
再交给原定位和运动检查判断。它不是新的全局导航程序，不直接决定油门、
绕桶路线、斑马线停车、红绿灯或终点停车，也没有新增“地图没准备好就不发车”的门槛。
地图文件缺失、选择 off 或辅助匹配不被接受时，继续原有定位流程。
辅助效果需要实车验证，离线测试通过不等于定位精度或比赛用时已有保证。
车端性能测量后，地图采样保留144点和原搜索网格，固定距离场与搜索偏移提前
缓存；原定位成功时不执行地图搜索。候选搜索合作预算30ms，连同原墙拟合重试
的总额外预算60ms，超时丢弃辅助结果；这不是操作系统硬实时承诺。
原配对、观测年龄和碰撞检查仍保留。不要把单帧补救当成整圈提速证据。

针对走走停停，还对两个原有计算环节做了等价优化：先排除不可能接触任何
预测车体的远处回波，再做原逐点矩形检查；路径最近点方向已一致时避免
重复计算整段方向掩膜。没有改变绕桶路线、车体余量、采样步长或新鲜度限制。
控制日志新增 odom_callback_source_age_s，区分进入回调时已旧的数据和控制
计算过程中变旧的数据。没有更改单线程调度或降低控制频率。

原程序两桶及其出口共用一条完整路线，不会在每个桶重新规划。入口仍保留
原来的停稳交接。本版减少计算负担并补充定位，不声称已经取消所有短停；
新的地图和全部代码仍需在实车同条件跑圈中比较卡顿次数与用时。

二、运行入口

V35.27 比赛入口显式关闭完整 Cartographer 在线 SLAM（含地图栅格发布器），
减少重复建图负担；实时雷达、局部墙面定位、RF2O 里程计、静态 TF、视觉、
底盘驱动及比赛状态机继续运行。此项不改变 RF2O 发布 TF 的原设置，也不
新建 map/odom 坐标变换。静态地图辅助直接读文件，不依赖在线 SLAM。
通用 Run_explorer 与 race_competition 的 enable_slam 参数默认仍为 true；
只有本版比赛入口传入 false。降低负担不代表已证明卡顿由 SLAM 引起，
实际源数据延迟及赛道效果仍需对比验证。

使用默认实验室地图：
bash /home/bianbu/racecar_entry_1003_v35_27/run_v35_27.sh /home/bianbu/racecar false

第四个参数选择其他地图目录：
bash /home/bianbu/racecar_entry_1003_v35_27/run_v35_27.sh /home/bianbu/racecar false 0.35 /home/bianbu/racecar_entry_1003_v35_27/maps/official

也可以把第四个参数直接写成该目录下的 profile.json 完整路径。
路径含空格时请加双引号。

关闭地图辅助：
bash /home/bianbu/racecar_entry_1003_v35_27/run_v35_27.sh /home/bianbu/racecar false 0.35 off

参数依次为：工作区、dry_run、原已标定起步输入、地图配置目录/文件/off。
第二个参数省略时仍为 true。第三个参数仍只接受原来的 0.35，没有改成真实速度。
第四个参数省略时使用本包 maps/lab_20261003/profile.json。
入口先执行原有源码/install 哈希检查，再选择地图，并通过 RACECAR_MAP_PROFILE
环境变量传递给本次启动的控制器；不写 .bashrc、不更改下次启动的全局设置。
显式 off 关闭辅助。缺失目录只会提示 MAP ASSIST: off，不会阻止原比赛程序启动。

三、以后换比赛场地图

不需要为每张新地图修改控制器代码。保留旧地图目录，为新地图建立新的独立目录，
再在第四个参数中选择新目录即可。profile.json 和 distance_field.npz 要一起保留。

但是“规则尺寸相同”不代表两次建图的坐标原点和朝向相同。新图必须先完成
赛道坐标到地图坐标的标定，并注明有效赛道区域、需要排除的场外区域。
不能只复制一张新的 PGM 或 YAML，同时继续使用旧图的坐标转换。
雷达 -3° 是传感器安装补偿，与这里的赛道/地图坐标转换不是同一件事。

准备工具示例（只生成新的地图配置，不修改原地图或小车控制源码）：
python3 /home/bianbu/racecar_entry_1003_v35_27/prepare_map_profile.py --map /home/bianbu/maps/new_course/course.yaml --alignment /home/bianbu/maps/new_course/alignment.json --output /home/bianbu/racecar_entry_1003_v35_27/maps/official

--map 支持工具所列的 ROS trinary YAML+PGM 或原 OccupancyGrid JSON。
--alignment 指向经过校准的配置文件，包含 profile_id、course_to_map
（平移 x/y 单位米，偏航单位弧度）、valid_course_polygon，及可选的
exclude_map_polygons。可参考实验室配置的结构，但新图不能照抄其数值。
--output 必须是尚不存在的新目录，工具拒绝覆盖已有配置。
生成的 assist_mask.png 展示实际参与匹配的范围；它不是修过墙的替代原地图。
更换地图前先保留当前配置和 Git/bundle 备份，再检查新图及坐标匹配情况。
当前全车 snapshot 工具覆盖原源码/install/旧启动入口，但尚未自动包含本版
racecar_entry_1003_v35_27 独立目录。因此修改本包或 maps 前，还须对这个目录
自己的 Git 仓库提交并导出 --all bundle，下载校验；修改验证后再提交。
本次交付同时保留全车与该独立包的离线 bundle。

四、安装、验证与回退

安装和回退都要求先停止现有比赛、驱动和传感器进程。安装脚本本身不发动车辆。
每次修改前继续执行实际车端 Git 快照，并将可离线恢复的 bundle 保存到本电脑；
不能只保留本地源码草稿。安装后另建快照，并核对源码、install 和外部设置。

安装：
bash /home/bianbu/racecar_entry_1003_v35_27/install.sh /home/bianbu/racecar

只读验证：
bash /home/bianbu/racecar_entry_1003_v35_27/verify_v35_27.sh /home/bianbu/racecar

精确恢复本版修改前的 V35.26：
bash /home/bianbu/racecar_entry_1003_v35_27/rollback_v35_26.sh /home/bianbu/racecar

回退验证成功后，使用保留的 V35.26 原入口：
bash /home/bianbu/racecar_entry_1002_v35_26/run_v35_26.sh /home/bianbu/racecar false

V35.27 安装后不要混用旧启动脚本；回退后也不要继续使用 V35.27 入口。
本包 rollback 是 V35.26 的精确文件，不是 V35.25。
安装清单包含 7 个源码文件及对应 install 验证，其中两个 launch 文件均
纳入精确回退；回退后原 V35.26 入口恢复此前默认启用 Cartographer 的行为。
关闭地图辅助只切换运行选项；它不等同于把安装文件回退到 V35.26。

五、测试范围

当前完整回归入口：python3 tests/run_tests_v35_27.py
继承 V35.26 全部行为测试，历史 V22 停车策略对照仍明确保留；
包装和修改范围检查更新为 V35.27，并补充地图匹配、配置与可选入口测试。
最终验证结果以本次 DELIVERY/LOCAL_VALIDATION 记录为准，不能沿用 V35.26 的
725 项通过或旧 ROS 验证结果来宣称 V35.27 已验证。
包内更早版本 README 和测试基线仅供追溯；实际操作以上述 V35.27 入口为准。
