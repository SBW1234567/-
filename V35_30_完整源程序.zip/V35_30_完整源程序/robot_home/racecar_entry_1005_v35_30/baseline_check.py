#!/usr/bin/env python3
"""Validate a known source snapshot, back it up, and copy this patch only."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import subprocess
from datetime import datetime


def digest(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n', b'\n')).hexdigest()


def confined(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise SystemExit(f'Path outside workspace: {relative}')
    return path


def active_race_processes(proc_root=Path('/proc')):
    """Read-only Linux process check; do not terminate anything automatically."""
    found = []
    if not proc_root.is_dir():
        return found
    for process in proc_root.iterdir():
        if not process.name.isdigit():
            continue
        try:
            args = (process/'cmdline').read_bytes().decode('utf-8', errors='replace').split('\0')
        except (OSError, PermissionError):
            continue
        controller = any(Path(arg).name == 'race_task_controller.py' for arg in args if arg)
        launcher = (any(Path(arg).name == 'ros2' for arg in args if arg)
                    and any(args[i:i+2] == ['launch', 'racecar'] for i in range(len(args)-1)))
        driver = any(Path(arg).name in ('racecar_driver_node', 'racecar_driver_node_one') for arg in args if arg)
        lidar = any(Path(arg).name in ('lslidar_driver_node', 'race_scan_alignment.py', 'rf2o_laser_odometry_node') for arg in args if arg)
        if controller or launcher or driver or lidar:
            found.append(process.name)
    return found


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--check', action='store_true', help='Validate without changing files')
    parser.add_argument('--verify-install', action='store_true')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    manifest = json.loads((package/'manifest.json').read_text(encoding='utf-8'))
    root = args.workspace.resolve()
    if not (root/'src/racecar/CMakeLists.txt').is_file():
        raise SystemExit('Not a racecar workspace: ' + str(root))
    for relative, expected in manifest['dependencies'].items():
        target = confined(root, relative)
        if not target.is_file() or digest(target) != expected:
            raise SystemExit('Dependency differs; no files changed: ' + relative)
    targets = []
    for item in manifest['files']:
        relative = item['path']
        target = confined(root, relative)
        source = confined(package, 'payload/' + relative)
        if digest(source) != item['sha256']:
            raise SystemExit('Damaged patch payload: ' + relative)
        if source.suffix=='.py':
            compile(source.read_text(encoding='utf-8'), str(source), 'exec')
        if args.verify_install:
            if not target.is_file() or digest(target) != item['sha256']:
                raise SystemExit('Source not patched: ' + relative)
            if item.get('installed_path'):
                installed = confined(root, item['installed_path'])
                if not installed.is_file() or digest(installed) != item['sha256']:
                    raise SystemExit('Installed file not updated: ' + str(installed))
        elif target.exists():
            if not target.is_file() or digest(target) not in item['accepted_before'] + [item['sha256']]:
                raise SystemExit('Source differs; no files changed: ' + relative)
        elif item['accepted_before'] and not item.get('allow_missing_before', False):
            raise SystemExit('Required source missing: ' + relative)
        targets.append((source, target))
    if args.verify_install:
        binary = confined(root, 'install/racecar_driver/lib/racecar_driver/racecar_driver_node')
        if not binary.is_file() or b'V23_SERVO_CENTER_0924' not in binary.read_bytes():
            raise SystemExit('Old/missing driver executable; rebuild racecar_driver. No driver executed.')
        try:
            result = subprocess.run([str(binary), '--center-build-info'], capture_output=True, text=True, timeout=5, check=True)
        except (OSError, subprocess.SubprocessError) as exc:
            raise SystemExit('Driver binary verification failed; rebuild racecar_driver: ' + str(exc))
        if result.stdout.strip() != 'V23_SERVO_CENTER_0924':
            raise SystemExit('Old driver executable; rebuild racecar_driver before running.')
        rf2o = confined(root, 'install/rf2o_laser_odometry/lib/rf2o_laser_odometry/rf2o_laser_odometry_node')
        if not rf2o.is_file() or b'V26_TF_READY' not in rf2o.read_bytes():
            raise SystemExit('Old/missing RF2O executable; rebuild rf2o_laser_odometry.')
        print('INSTALL VERIFIED: ' + manifest['version'] + '; source and install match.')
        return
    if args.check:
        print('BASELINE VERIFIED; no files changed.')
        return
    running = active_race_processes()
    if running:
        raise SystemExit('Race process still running (PID ' + ', '.join(running)
                         + '). Stop its launch with Ctrl+C first; no files changed.')
    backup = root.parent / ('racecar_before_restore_v29_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.tar.gz')
    with tarfile.open(backup, 'w:gz') as archive:
        archive.add(root/'src/racecar', arcname='src/racecar')
        archive.add(root/'src/racecar_driver', arcname='src/racecar_driver')
        archive.add(root/'src/rf2o_laser_odometry', arcname='src/rf2o_laser_odometry')
    print('SOURCE BACKUP: ' + str(backup), flush=True)
    for source, target in targets:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if target.suffix == '.py' and target.parent.name == 'scripts':
            target.chmod(target.stat().st_mode | 0o111)
    print('PATCH COPIED. Build and verify installed files before testing.')


if __name__ == '__main__':
    main()
