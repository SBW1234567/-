V35.26 FIRST_CONE_CONTINUITY_1002_V35_26

相对于精确 V35.25，仅修改控制器五个曲线辅助方法，核心 plan_entry_path、command_horizon 及 PathFollower 的 command、locate 两方法。

第一桶：当旧宽弯家族不能满足原曲率门槛时，尝试更早向内建立转向的局部曲线，仍必须通过原全车余量和最小半径认证。
两次最新日志六种可能入口种子均选择新家族。成功的旧宽弯保持不变；第二桶 samples[480:] 与 V25 精确一致。
零驱动预转向：已真实停稳时，允许固定最多1.20秒保留已摆舵角，不反复归中。推车/时钟变化/超时/新正输入仍使旧证明失效。
历史雷达对齐：只在有真实前后源帧及相邻运动支持时允许至多.45秒跨度插值，并按不确定性增加碰撞余量；不扩大当前源外推、正动力或原始碰撞门限。
计算优化：减少相同轨迹预演的重复运算，保留三个转向增益、全部路径采样和原始回波检查。本机耗时改善不等于实车控制周期保证。

斑马线净前进.80m及停稳后3.2秒、红绿灯、最后停车辅助方法保持V25。视觉、YAML、launch、driver、RF2O和雷达-3度不改。
完整改动AST范围见 tests/v35_26_scope.json。固定几何的旧预摆时序测试仍运行当前控制器；独立新路径闭环另测生产规划。
模型使用合成扫描和假设电机/舵机响应，不是实际完整雷达重放或实车效果保证。

本地验证：tests/run_tests_v35_26.py；Linux 另有5项隔离ROS验证，localhost-only域217–221，不启动driver/实际传感器。
实际安装与测试结果由项目 car_patch_v35_26/DELIVERY.json 记录，本README不预先宣称通过。

安装：bash install.sh /home/bianbu/racecar
人工实跑：bash /home/bianbu/racecar_entry_1002_v35_26/run_v35_26.sh /home/bianbu/racecar false
核验：bash /home/bianbu/racecar_entry_1002_v35_26/verify_v35_26.sh /home/bianbu/racecar
回退V25：bash /home/bianbu/racecar_entry_1002_v35_26/rollback_v35_25.sh /home/bianbu/racecar

安装/回退均持锁、核对已知哈希、Git快照后才写入，并重新构建核对安装副本；未知修改不会被覆盖。运行旧版本命令会拒绝混用。
