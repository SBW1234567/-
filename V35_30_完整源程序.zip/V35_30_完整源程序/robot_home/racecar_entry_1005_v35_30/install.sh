#!/usr/bin/env bash
set -e
set -o pipefail
PATCH_FILE=$(readlink -f -- "$0")
PATCH_DIR=$(dirname -- "$PATCH_FILE")
RACE_WORKSPACE=${1:-/home/bianbu/racecar}
mkdir -p "$HOME/.config/racecar"
exec 9>"$HOME/.config/racecar/steering_center.lock"
flock -n 9 || { echo 'A race runner or installer is active; no files changed.' >&2; exit 1; }
export RACECAR_INSTALL_LOCK_FD=9
if [ -f /opt/bros/humble/setup.bash ]; then
    source /opt/bros/humble/setup.bash
elif [ -f /opt/ros/humble/setup.bash ]; then
    source /opt/ros/humble/setup.bash
else
    echo 'ROS2 Humble environment not found; no files changed.' >&2
    exit 1
fi
command -v colcon >/dev/null
if [ "$(readlink -f -- "$RACE_WORKSPACE")" != /home/bianbu/racecar ]; then
    echo "Git snapshot tool covers only /home/bianbu/racecar; no files changed." >&2
    exit 1
fi
python3 -c "import sys; sys.path.insert(0, sys.argv[1]); from band_settings import read_band; from straight_settings import read_straight; from guard_settings import read_guards; from lidar_settings import read_correction; b=read_band(); s=read_straight(); print('BAND:',b); print('INHERITED STRAIGHT:',s); print('INHERITED GUARDS:',read_guards()); print('LIDAR:',read_correction()); assert not b['lane_parallel_band_enabled'] or s['bounded_heading_control'], 'Enable bounded_heading_control first'" "$PATCH_DIR"
python3 "$PATCH_DIR/apply_patch.py" --workspace "$RACE_WORKSPACE" --check
python3 /home/bianbu/snapshot_vehicle_git.py --label before-v35-30-install
python3 "$PATCH_DIR/apply_patch.py" --workspace "$RACE_WORKSPACE"
cd -- "$RACE_WORKSPACE"
colcon build --packages-select racecar
source install/setup.bash
python3 "$PATCH_DIR/rf2o_release.py" --workspace "$RACE_WORKSPACE"
python3 "$PATCH_DIR/apply_patch.py" --workspace "$RACE_WORKSPACE" --verify-install
echo 'V35.30 build verified. Installer does not start the car.'
