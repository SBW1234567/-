#!/usr/bin/env bash
set -e
set -o pipefail
PATCH_FILE=$(readlink -f -- "$0")
PATCH_DIR=$(dirname -- "$PATCH_FILE")
RACE_WORKSPACE=${1:-/home/bianbu/racecar}
RACE_DRY_RUN=${2:-true}
RACE_PREPARE_DRIVE=${3:-0.35}
RACE_MAP_PROFILE=${4:-$PATCH_DIR/maps/lab_20261003/profile.json}
if [ "$#" -gt 4 ]; then echo 'Usage: bash run_v35_30.sh WORKSPACE [true|false] [MEASURED_PREPARE_DRIVE] [PROFILE_DIR|PROFILE_JSON|off]' >&2; exit 1; fi
if [ "$RACE_DRY_RUN" != true ] && [ "$RACE_DRY_RUN" != false ]; then echo 'dry_run must be true or false' >&2; exit 1; fi
if [ -f /opt/bros/humble/setup.bash ]; then source /opt/bros/humble/setup.bash; elif [ -f /opt/ros/humble/setup.bash ]; then source /opt/ros/humble/setup.bash; else echo 'ROS2 Humble environment not found.' >&2; exit 1; fi
source "$RACE_WORKSPACE/install/setup.bash"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export RACECAR_MAP_PROFILE="$RACE_MAP_PROFILE"
exec python3 "$PATCH_DIR/launch_centered.py" run "$RACE_WORKSPACE" --dry-run "$RACE_DRY_RUN" --prepare-drive "$RACE_PREPARE_DRIVE"
