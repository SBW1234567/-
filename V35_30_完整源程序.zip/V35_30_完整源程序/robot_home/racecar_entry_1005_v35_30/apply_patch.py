#!/usr/bin/env python3
"""V35.30 parking approach overlay for V35.29, with exact V35.29 rollback."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
from baseline_check import active_race_processes

PACKAGE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest()


def check_executable_header(path):
    data=path.read_bytes()
    if data.startswith(b'#!') and b'\r' in data.split(b'\n',1)[0]:
        raise ValueError('Invalid Linux interpreter header (CRLF): '+str(path))


def confined(root, relative):
    result = (root/relative).resolve()
    if not result.is_relative_to(root):
        raise ValueError('Path outside root: '+relative)
    return result


def load_manifests():
    base = json.loads((PACKAGE/'baseline_manifest.json').read_text(encoding='utf-8'))
    overlay = json.loads((PACKAGE/'manifest.json').read_text(encoding='utf-8'))
    changes = {item['path']:item for item in overlay['files']}
    base_files = {item['path']:item for item in base['files']}
    if len(changes) != 7 or set(changes) != {'src/racecar/scripts/race_task_controller.py',
                                            'src/racecar/launch/race_competition.launch.py',
                                            'src/racecar/launch/Run_explorer.launch.py',
                                            'src/racecar/scripts/race_curve_core.py',
                                            'src/racecar/scripts/race_lidar_guard.py',
                                            'src/racecar/scripts/ican_vision_node.py',
                                            'src/racecar/config/competition_params.yaml'}:
        raise ValueError('Unexpected overlay file list')
    for relative,item in changes.items():
        if item['before_sha256'] != base_files[relative]['sha256']:
            raise ValueError('Rollback does not match baseline manifest: '+relative)
        for mode,expected in [('payload',item['sha256']),('rollback',item['before_sha256'])]:
            path = confined(PACKAGE,mode+'/'+relative)
            if digest(path) != expected:
                raise ValueError('Damaged package: '+str(path))
            check_executable_header(path)
            if path.suffix == '.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            elif path.suffix == '.yaml':
                import yaml
                if not isinstance(yaml.safe_load(path.read_text(encoding='utf-8')),dict):
                    raise ValueError('Invalid YAML package: '+str(path))
    return base,overlay,changes


def validate_tree(root, version='either', installed=True, binaries=True):
    base,overlay,changes = load_manifests()
    if not (root/'src/racecar/CMakeLists.txt').is_file():
        raise ValueError('Not a racecar workspace: '+str(root))
    for relative,expected in base['dependencies'].items():
        path=confined(root,relative)
        if not path.is_file() or digest(path) != expected:
            raise ValueError('Dependency differs; no overwrite: '+relative)
    for item in base['files']:
        relative=item['path'];accepted={item['sha256']}
        if relative in changes:
            accepted = ({changes[relative]['sha256']} if version=='v35' else
                        {item['sha256']} if version=='original_v35' else
                        {item['sha256'],changes[relative]['sha256'],*changes[relative].get('also_accept',[])})
        for candidate in [relative]+([item['installed_path']] if installed and item.get('installed_path') else []):
            path=confined(root,candidate)
            if not path.is_file() or digest(path) not in accepted:
                raise ValueError('Unknown source/install state; no overwrite: '+candidate)
            if version in ('v35','original_v35'):check_executable_header(path)
    if binaries:
        driver=confined(root,'install/racecar_driver/lib/racecar_driver/racecar_driver_node')
        rf2o=confined(root,'install/rf2o_laser_odometry/lib/rf2o_laser_odometry/rf2o_laser_odometry_node')
        if not driver.is_file() or b'V23_SERVO_CENTER_0924' not in driver.read_bytes():
            raise ValueError('V33 driver not installed')
        if not rf2o.is_file() or b'V26_TF_READY' not in rf2o.read_bytes():
            raise ValueError('V33 RF2O not installed')
        from rf2o_release import verify as verify_rf2o
        verify_rf2o(root, version)
        result=subprocess.run([str(driver),'--center-build-info'],capture_output=True,text=True,check=True,timeout=5)
        if result.stdout.strip()!='V23_SERVO_CENTER_0924':
            raise ValueError('Driver version check failed')
    return base,overlay,changes


def copy_version(root, rollback=False, binaries=True):
    running=active_race_processes()
    if running:
        raise ValueError('Stop existing race/driver/lidar processes with Ctrl+C first. PIDs: '+', '.join(running))
    base,overlay,changes=validate_tree(root,binaries=binaries)
    backup=root.parent/('racecar_before_'+('rollback_v35_30_' if rollback else 'entry_v35_30_')+
                        datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.tar.gz')
    with tarfile.open(backup,'w:gz') as archive:
        for relative in changes:
            archive.add(confined(root,relative),arcname=relative,recursive=False)
    print('SOURCE BACKUP: '+str(backup),flush=True)
    mode='rollback' if rollback else 'payload'
    for relative in changes:
        target=confined(root,relative)
        shutil.copyfile(confined(PACKAGE,mode+'/'+relative),target)
        if target.parent.name=='scripts':
            target.chmod(target.stat().st_mode|0o111)
    print(('Previous V35.29' if rollback else 'V35.30')+' source copied. Build racecar and verify before running.',flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workspace',type=Path,required=True)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--verify-install',action='store_true')
    group.add_argument('--verify-previous-v35','--verify-original-v35',dest='verify_previous_v35',action='store_true')
    group.add_argument('--rollback',action='store_true')
    group.add_argument('--check',action='store_true')
    args=p.parse_args();root=args.workspace.resolve()
    if args.verify_install or args.verify_previous_v35 or args.check:
        version='v35' if args.verify_install else 'original_v35' if args.verify_previous_v35 else 'either'
        validate_tree(root,version)
        print('INSTALL VERIFIED: '+('PARKING_CONTINUITY_1005_V35_30' if version=='v35' else
              'PARKING_APPROACH_1005_V35_29' if version=='original_v35' else 'KNOWN_V35_28_OR_V35_29')+'; source and install match accepted hashes.')
        return
    # Runner and installer share the existing midpoint lock; no config writes.
    from install_lock import workspace_lock
    with workspace_lock():
        copy_version(root,args.rollback)


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,subprocess.SubprocessError) as exc:
        raise SystemExit(str(exc))
