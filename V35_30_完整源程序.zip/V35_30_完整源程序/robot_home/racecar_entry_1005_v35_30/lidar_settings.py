#!/usr/bin/env python3
"""Save a measured yaw correction without starting ROS or the car."""
import argparse
import math
from pathlib import Path
import yaml


def checked(value):
    if isinstance(value, bool):
        raise ValueError('Correction must be a finite number within -15..15 degrees.')
    n = float(value)
    if not math.isfinite(n) or abs(n) > 15:
        raise ValueError('Correction must be a finite number within -15..15 degrees.')
    return n


def settings_path():
    return Path(__file__).resolve().parent.parent/'racecar_lidar_alignment_0925_v26/lidar_alignment.yaml'


def read_correction(path=None):
    path = settings_path() if path is None else path
    try:
        data = yaml.safe_load(path.read_text(encoding='utf-8'))
    except yaml.YAMLError as exc:
        raise ValueError(f'Invalid lidar YAML: {exc}') from exc
    if not isinstance(data, dict) or data.get('schema') != 1:
        raise ValueError('Unknown lidar alignment schema.')
    return checked(data['lidar_yaw_correction_deg'])


def save_correction(value, path=None):
    value = checked(value)
    path = settings_path() if path is None else path
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.yaml.tmp')
    temporary.write_text(yaml.safe_dump({'schema': 1, 'lidar_yaw_correction_deg': value},
                                        sort_keys=False), encoding='utf-8')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--set', type=checked, dest='value')
    args = parser.parse_args()
    if args.value is not None:
        from apply_patch import active_race_processes
        if active_race_processes():
            parser.error('Stop the lidar/competition launch with Ctrl+C before changing calibration.')
        save_correction(args.value)
    print(f'lidar_yaw_correction_deg={read_correction():+.3f}; {settings_path()}')
    print('Positive rotates points left; negative rotates points right. No hardware started.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, TypeError, KeyError, OSError) as exc:
        raise SystemExit(str(exc))
