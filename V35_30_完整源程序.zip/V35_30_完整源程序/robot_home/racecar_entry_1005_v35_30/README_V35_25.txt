V35.25 — 第二桶局部路径修复
版本：SECOND_CONE_1002_V35_25
基线：已安装 V35.24 CONTINUITY_1002_V35_24

当前状态
这是待最终验证和安装的 V25 包。安装结果以包外 DELIVERY.json 和 vehicle_validation 证据为准。
历史 V24 目录和 ZIP 保持不变；本地测试及隔离 ROS 检查不能替代实际赛道验证。

修改目的与范围
两次 V24 日志实际未选择 WIDE_FIRST_CONE 分支，第二桶后半段可能出现小反弯及近直段。
本版将第二桶西侧外扩局部收回约 5 cm，并联合调整西侧锚点高度、出口连接点和段端切线，保持顺时针绕行并以零曲率衔接上直道。
局部参数：西侧锚相对第二桶(-0.97,+0.60)m，原值(-1.02,+0.05)m；直段连接点(2.4,3.55)m。两段端切线(1.8,2.2)/(1.8,2.4)，最后直段(2.4,1.972)，局部节点曲率(-0.8,-1.2,0,0)/m。
这是局部形状重构，不是整个圆半径统一减小，也不是通过删碰撞检查完成。
所有实际可选规划分支都必须应用新局部形状并通过曲率及车体证书；不允许失败后静默选回原来的反弯路径。
最终生产范围由 tests/v35_25_scope.json 精确约束。控制器只有三个版本字符串变化，除此之外字节保持 V24。
斑马线、红绿灯、第一桶恢复、终点停车、定位与指令新鲜性逻辑均保留；视觉、YAML、雷达保护、launch、RF2O、driver 和雷达 -3 度补偿保持原值。
保留原 0.55 m 最小转弯半径与车体净距检查；没有放宽 V21 恢复的原始扫描、地图、progress/offset/距离边界。
已经靠近上方挡板的晚停姿态仍可能没有可行的前进恢复路线，不能把人工推车后的继续行驶算作自主恢复。

修改前备份
本地独立 Git 仓库 car_patch_v35_25，分支 codex/v35-25-second-cone。
完整 V24 基线提交：954ef4efb6f7e4a3942ad1754ab0bd3a94d31c71。
离线 bundle：offline_backups/v24_baseline_954ef4efb6f7.bundle，已执行 git bundle verify 和 fsck。
180 个 V24 交付文件逐字节匹配原 ZIP，原 ZIP SHA256：
3a4bf9b24d6559a1e08d83f1655548e5a172d0ee5d444ef014d9dfbce7f488ad
本地备份不代替实际车端修改前快照。install 和 rollback 均先核对已知哈希并创建车端 Git 备份，备份失败不继续修改。

安装与核对（不启动比赛）
  bash /home/bianbu/racecar_entry_1002_v35_25/install.sh /home/bianbu/racecar
  bash /home/bianbu/racecar_entry_1002_v35_25/verify_v35_25.sh /home/bianbu/racecar

后续人工运行
  bash /home/bianbu/racecar_entry_1002_v35_25/run_v35_25.sh /home/bianbu/racecar false
默认 dry_run=true；false 允许实车运动。Ctrl+C 停止。

精确回退 V24（只回退和构建）
  bash /home/bianbu/racecar_entry_1002_v35_25/rollback_v35_24.sh /home/bianbu/racecar
六文件源码和安装副本恢复精确 V24；未知修改会阻止覆盖。
回退后人工运行：
  bash /home/bianbu/racecar_entry_1002_v35_24/run_v35_24.sh /home/bianbu/racecar false

验证入口
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python3 tests/run_tests_v35_25.py
完整原套件继续测当前 V25，仅既有七项 V22 历史策略对照继续绑定原历史源。本版不将新失败测试任意移到历史或跳过。
旧 test_upper_exit_v35_14 仅将直段连接点断言 x=2.3 更新为本版批准的 x=2.4；保留其余全车净距、曲率、G2 连续与直段断言。
旧 V21 恢复测试 test_lower_stop_37deg_veto_removed_but_forward_offset_bounds_retained 保留原停姿、offset/progress/raw检查，并新增同位置航向减0.10rad的明确合成姿态，以继续覆盖超过旧37度否决门槛的情况；新路径在原姿态上的航向误差已小于该门槛，不把降低误差当作测试失败，也不删除该门槛回归。
tests/baselines/core_before_v35_25.py 和 controller_before_v35_25.py 保存精确 V24，用于反事实和范围检查。
原 21 张视觉标定图及固定历史基线保留。
5 项隔离 ROS 脚本后缀 v35_25，域 222–226，dry_run、localhost-only、输出 remap 至 codex_validation；不启动 driver/camera/lidar。
依次检查缺传感器零驱动、斑马线起步区、红绿灯 DDS、实拍视觉到 DDS、停车 DDS。
这些脚本不让车辆行驶，不是第二桶真实动力学验证。

证据边界
小矩阵及模型使用日志冻结的锥桶参数和现有矩形车体模型，没有重新测量硬件或现场桶位。
CSV 未记录精确规划种子及完整原始雷达；接管姿态重建虽能匹配局部反弯曲率，不能称作整个实跑精确重放。
最终收圈效果与扫板净距仍需实际赛道运行确认。0 驱动是 PWM1500 中性请求，不是主动瞬时制动。
